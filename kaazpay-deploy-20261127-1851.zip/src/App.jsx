import { Suspense, lazy, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { PAGES } from './lib/pages';
import { BrowserRouter as Router, Routes, Route, useLocation, useNavigationType } from 'react-router-dom';
import { LazyMotion, MotionConfig, m } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import MobileContactBar from './components/MobileContactBar';
import Home from './pages/Home/Home';
import { Navigate } from './components/LocaleLink';
import { langFromPath, normalizePath } from './lib/locale';
import { initSmoothScroll, scrollToTop, scrollToElement, scrollToY } from './lib/smoothScroll';

const loadMotionFeatures = () => import('./motionFeatures').then((r) => r.default);

// Lazy-loaded pages (chunks shared with link prefetching in lib/pages.js)
const MarketPage = lazy(PAGES.MarketPage);
const Industries = lazy(PAGES.Industries);
const Developers = lazy(PAGES.Developers);
const Capabilities = lazy(PAGES.Capabilities);
const Contact = lazy(PAGES.Contact);
const Roadmap = lazy(PAGES.Roadmap);
const About = lazy(PAGES.About);
const MethodsIndex = lazy(PAGES.MethodsIndex);
const MethodPage = lazy(PAGES.MethodPage);
const IndustryPage = lazy(PAGES.IndustryPage);
const NotFound = lazy(PAGES.NotFound);
const ArticlesIndex = lazy(PAGES.ArticlesIndex);
const ArticlePage = lazy(PAGES.ArticlePage);
const Glossary = lazy(PAGES.Glossary);
const FaqPage = lazy(PAGES.FaqPage);



const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
  </div>
);

// Scroll positions per history entry, so Back/Forward return to where the visitor was.
const savedScroll = new Map();
const useIsoLayoutEffect = typeof window === 'undefined' ? useEffect : useLayoutEffect;
if (typeof window !== 'undefined' && 'scrollRestoration' in history) history.scrollRestoration = 'manual';

/**
 * Route-change scrolling: Back/Forward restores the saved position, a #hash glides/jumps to that
 * section (retrying while lazy content mounts), anything else starts at the top.
 * The browser's own restoration is off — it moved the page behind Lenis's back, so the next wheel
 * snapped to Lenis's stale position (the top).
 */
const useScrollManager = (location) => {
  const navType = useNavigationType();
  const lastPath = useRef(null);
  const keyRef = useRef(location.key);

  // remember the current entry's position as the visitor scrolls
  useEffect(() => {
    const onScroll = () => savedScroll.set(keyRef.current, window.scrollY);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // switch entries before the new page paints, so a clamp-scroll during the swap isn't saved to the old entry
  useIsoLayoutEffect(() => { keyRef.current = location.key; }, [location.key]);

  useEffect(() => {
    const samePage = lastPath.current === location.pathname;
    lastPath.current = location.pathname;

    let tries = 0;
    let raf;
    let cancelled = false;
    // let the freshly mounted page lay out (two frames + webfonts) before measuring
    const afterLayout = (fn) => {
      raf = requestAnimationFrame(() => {
        raf = requestAnimationFrame(() => {
          (document.fonts?.ready || Promise.resolve()).then(() => { if (!cancelled) fn(); });
        });
      });
    };

    const saved = navType === 'POP' ? savedScroll.get(location.key) : undefined;
    if (saved !== undefined) {
      const restore = () => {
        // wait (briefly) until the page is tall enough to hold the saved position
        if (document.documentElement.scrollHeight - window.innerHeight >= saved - 1 || tries++ >= 60) afterLayout(() => scrollToY(saved));
        else raf = requestAnimationFrame(restore);
      };
      restore();
    } else if (!location.hash) {
      scrollToTop();
    } else {
      const seek = () => {
        const el = document.getElementById(decodeURIComponent(location.hash.slice(1)));
        if (el) afterLayout(() => scrollToElement(el, { immediate: !samePage }));
        else if (tries++ < 60) raf = requestAnimationFrame(seek);
      };
      seek();
    }
    return () => { cancelled = true; cancelAnimationFrame(raf); };
  }, [location.pathname, location.hash, location.key, navType]);
};

const Layout = ({ children }) => {
  const location = useLocation();
  const { i18n } = useTranslation();

  useScrollManager(location);
  useEffect(() => { initSmoothScroll(); }, []);

  // Pages after the first one fade in softly instead of hard-cutting (first paint stays as prerendered).
  const [firstPath] = useState(location.pathname);
  const isFirst = location.pathname === firstPath;

  // The URL decides the language (/zh/... = Chinese); keep i18n in step on Back/Forward too.
  const lang = langFromPath(location.pathname);
  // The first page's SEO tags are already in its prerendered HTML: don't download the SEO module (and the glossary /
  // FAQ / methods data it pulls in) during the first load, only once the visitor navigates within the site.
  const seoReady = useRef(typeof document !== 'undefined'
    && document.getElementById('root')?.dataset.route === normalizePath(window.location.pathname));
  useEffect(() => {
    if (!i18n.language?.startsWith(lang)) i18n.changeLanguage(lang);
    document.documentElement.lang = lang === 'zh' ? 'zh-CN' : 'en';
    if (seoReady.current) { seoReady.current = false; return undefined; }
    let live = true;
    import('./seo').then(({ getSeo, applySeo }) => { if (live) applySeo(getSeo(location.pathname)); });
    return () => { live = false; };
  }, [location.pathname, lang, i18n]);

  return (
    <div className="min-h-screen flex flex-col font-sans text-text-body selection:bg-primary/30 selection:text-white">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[60] focus:px-4 focus:py-2 focus:rounded-full focus:bg-primary focus:text-black">Skip to content</a>
      <Navbar />
      <main id="main" className="flex-grow pt-20">
        <m.div key={location.pathname} initial={isFirst ? false : { opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}>
          {children}
        </m.div>
      </main>
      <Footer />
      <MobileContactBar />
    </div>
  );
};

/** Routes + layout, shared by the browser app and the build-time prerenderer. */
export const AppShell = () => (
  <LazyMotion features={loadMotionFeatures}>
  <MotionConfig reducedMotion="user">
    <Layout>
      <Suspense fallback={<PageLoader />}>
        <Routes>
          {['', '/zh'].map((pre) => (
            <Route key={pre || 'en'} path={pre || '/'}>
              <Route index element={<Home />} />
              {/* /payment-methods on its own is the coverage section of the home page */}
              <Route path="payment-methods" element={<Navigate to="/#coverage" replace />} />
              <Route path="payment-methods/:slug" element={<MarketPage />} />
              <Route path="methods" element={<MethodsIndex />} />
              <Route path="methods/:slug" element={<MethodPage />} />
              <Route path="industries" element={<Industries />} />
              <Route path="industries/:id" element={<IndustryPage />} />
              <Route path="guides" element={<ArticlesIndex kind="guide" />} />
              <Route path="guides/:slug" element={<ArticlePage kind="guide" />} />
              <Route path="compare" element={<ArticlesIndex kind="compare" />} />
              <Route path="compare/:slug" element={<ArticlePage kind="compare" />} />
              <Route path="glossary" element={<Glossary />} />
              <Route path="faq" element={<FaqPage />} />
              <Route path="capabilities" element={<Capabilities />} />
              <Route path="developers" element={<Developers />} />
              <Route path="contact" element={<Contact />} />
              <Route path="roadmap" element={<Roadmap />} />
              <Route path="about" element={<About />} />
              <Route path="*" element={<NotFound />} />
            </Route>
          ))}
        </Routes>
      </Suspense>
    </Layout>
  </MotionConfig>
  </LazyMotion>
);

function App() {
  return (
    <Router>
      <AppShell />
    </Router>
  );
}

export default App;
