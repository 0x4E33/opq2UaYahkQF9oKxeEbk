import { useLayoutEffect, useRef } from 'react';
import { m, useAnimationControls, useReducedMotion, useScroll, useTransform } from 'framer-motion';

/**
 * Site-wide motion vocabulary.
 *
 *  <Reveal>           – fades/rises in once, the first time it enters the viewport (IntersectionObserver).
 *                       Content already on screen when the page starts is shown as prerendered, not hidden.
 *  <Reveal index={i}> – siblings follow a beat later (max 3 steps), so a row reads as one gesture.
 *  <ParallaxImage>    – photo settles from a slight zoom while it crosses the viewport.
 *
 * Tokens live here so every page moves the same way.
 */
const EASE_OUT = [0.22, 1, 0.36, 1];

export const Reveal = ({ as = 'div', index = 0, y = 14, className, children, ...rest }) => {
    const reduced = useReducedMotion();
    const ref = useRef(null);
    const controls = useAnimationControls();
    const Tag = m[as];
    // The prerendered HTML shows every block (no opacity:0 waiting for JavaScript, so the first screen paints
    // immediately and its largest image counts for LCP straight away). Once the page runs, only blocks that are
    // still below the fold are hidden — before the browser paints them — and rise in as they scroll into view.
    useLayoutEffect(() => {
        const el = ref.current;
        if (reduced || !el || typeof IntersectionObserver === 'undefined') return undefined;
        const r = el.getBoundingClientRect();
        if (r.top < window.innerHeight && r.bottom > 0) return undefined;
        controls.set({ opacity: 0, y });
        const io = new IntersectionObserver(([e]) => {
            if (!e.isIntersecting) return;
            io.disconnect();
            controls.start({ opacity: 1, y: 0, transition: { duration: 0.8, delay: Math.min(index, 3) * 0.07, ease: EASE_OUT } });
        }, { threshold: 0.12 });
        io.observe(el);
        return () => io.disconnect();
    }, [reduced, controls, index, y]);
    return <Tag ref={ref} className={className} animate={controls} {...rest}>{children}</Tag>;
};

/** priority: the page's hero photo — load it straight away (not lazily) and ahead of other images, for LCP. */
export const ParallaxImage = ({ src, srcSet, sizes, alt = '', className = '', imgClassName = '', zoom = 0.08, priority = false, children }) => {
    const ref = useRef(null);
    const reduced = useReducedMotion();
    const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
    const scale = useTransform(scrollYProgress, [0, 0.5], [1 + zoom, 1]);
    const y = useTransform(scrollYProgress, [0, 1], ['-3%', '3%']);
    return (
        <div ref={ref} className={`relative overflow-hidden ${className}`}>
            <m.img src={src} srcSet={srcSet} sizes={sizes} alt={alt} loading={priority ? 'eager' : 'lazy'} fetchPriority={priority ? 'high' : undefined} decoding="async"
                style={reduced ? undefined : { scale, y }}
                className={`parallax-layer absolute inset-0 h-[106%] w-full object-cover ${imgClassName}`} />
            {children}
        </div>
    );
};
