import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import viteCompression from 'vite-plugin-compression';
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer';

/** Preload the Latin body + heading fonts so they don't wait for the CSS. */
const preloadFonts = () => ({
  name: 'preload-fonts',
  apply: 'build',
  transformIndexHtml: {
    order: 'post',
    handler(html, ctx) {
      // Inter (body) and Sora (headings — the hero H1 is the LCP element)
      const fonts = Object.keys(ctx.bundle || {}).filter((f) => /(inter|sora)-latin-wght-normal.*\.woff2$/.test(f));
      const tags = fonts.map((f) => `<link rel="preload" href="/${f}" as="font" type="font/woff2" crossorigin />`).join('\n    ');
      return tags ? html.replace('</title>', `</title>\n    ${tags}`) : html;
    },
  },
});

/**
 * Cloudflare Rocket Loader rewrites every <script> so it only runs after the page has rendered: the language redirect
 * then fires late (the page flashes before switching to /zh) and hydration / reveal animations start seconds later.
 * data-cfasync="false" opts our scripts out even if Rocket Loader is switched on in the Cloudflare dashboard.
 */
const cfNoRocket = () => ({
  name: 'cf-no-rocket-loader',
  apply: 'build',
  transformIndexHtml: { order: 'post', handler: (html) => html.replace(/<script type="module"/g, '<script data-cfasync="false" type="module"') },
});

// https://vite.dev/config/
export default defineConfig(({ isSsrBuild }) => ({
  build: {
    // Only tiny icons (<1 KB) are inlined into the JS. Larger flags / logos stay as separate, long-cached files that
    // load only on the pages and sections that show them, instead of every page downloading ~100 KB of base64.
    assetsInlineLimit: 1024,
    // the only chunk over 500 kB is the three.js globe, loaded on desktop after the page is idle
    chunkSizeWarningLimit: 600,
    rollupOptions: {
      onwarn(warning, warn) {
        // SSR imports every article statically to prerender it; the browser build still splits them. Not a problem.
        if (/dynamic import will not move module into another chunk/.test(warning.message)) return;
        warn(warning);
      },
      output: {
        // Long-lived vendor chunks: a content deploy doesn't invalidate React / router / i18n in returning visitors' caches.
        manualChunks: (id) => {
          if (!id.includes('node_modules')) return undefined;
          if (/node_modules\/(react|react-dom|scheduler|react-router|react-router-dom)\//.test(id)) return 'vendor-react';
          if (/node_modules\/(i18next|react-i18next|i18next-browser-languagedetector)\//.test(id)) return 'vendor-i18n';
          return undefined;
        },
      },
    },
  },
  plugins: [
    react(),
    preloadFonts(),
    cfNoRocket(),
    // compression and image optimisation only matter for the files the browser downloads (not the SSR bundle)
    ...(isSsrBuild ? [] : [
    viteCompression({
        algorithm: 'gzip',
        ext: '.gz',
    }),
    viteCompression({
        algorithm: 'brotliCompress',
        ext: '.br',
    }),
    ViteImageOptimizer({
        // WebP photos are already encoded at the right quality by our own scripts; re-encoding only makes them bigger
        test: /\.(jpe?g|png|gif|tiff|svg|avif)$/i,
        png: {
            quality: 80,
        },
        jpeg: {
            quality: 80,
        },
        jpg: {
            quality: 80,
        },
    }),
    ]),
  ],
}))
