export default {
    slug: 'live-streaming-platform-payments',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['united-states', 'global-cards', 'mexico', 'brazil', 'malaysia', 'philippines', 'indonesia', 'kenya', 'usdt'],
        methods: ['pix', 'qris', 'gcash', 'duitnow', 'paypal', 'cash-app', 'mobile-money'],
        industries: ['live-streaming', 'digital-goods'],
        articles: ['mass-payouts-emerging-markets', 'payment-success-rate', 'social-dating-app-payments', 'usdt-vs-local-currency-settlement'],
    },
    en: {
        title: 'Live Streaming Payments: Coin Top-ups and Host Payouts',
        description: 'Run live streaming payments end to end: local coin top-ups for viewers, weekly host and agency payouts, clean two-way reconciliation and USDT settlement.',
        h1: 'How do live streaming platforms collect coin top-ups and pay hosts?',
        summary: 'A live streaming platform collects coin top-ups from viewers through local wallets, QR codes, instant bank payments and cards, then pays hosts and agencies their share on local payout rails or in USDT. KaazPay handles both directions in one merchant account, with signed notifications for every top-up and payout and settlement in USDT.',
        takeaways: [
            'A streaming platform runs two money flows on one ledger: coin sales to viewers and earnings payouts to hosts.',
            'Gifting happens mid-stream, so top-ups must confirm while the viewer is still watching; instant methods like Pix, QRIS, GCash and DuitNow fit best.',
            'Hosts are often in different countries from viewers, so check payout coverage per market and use USDT where there is no local payout.',
            'One reference per transaction and notification-driven balances keep coin and earnings ledgers in sync.',
            'Collected funds are settled as the equivalent amount in USDT, with the cycle confirmed per channel.',
        ],
        sections: [
            {
                id: 'two-ledgers',
                heading: 'What payment flows does a live streaming app need?',
                blocks: [
                    'Live and social streaming apps share the same payment cycle. Viewers buy coins, spend them on gifts and paid features during a stream, the gifts turn into host earnings, and the platform pays those earnings out on a schedule.',
                    {
                        table: {
                            head: ['Flow', 'Who pays whom', 'Typical pattern', 'What matters most'],
                            rows: [
                                ['Coin top-up', 'Viewer to platform', 'Small amounts, several times a week, often mid-stream', 'Familiar method, fast confirmation'],
                                ['Gift conversion', 'Inside the platform', 'Coins become host points or diamonds', 'Accurate ledger per host'],
                                ['Host payout', 'Platform to host', 'Weekly or monthly, in the host\'s country', 'Local rail, predictable timing'],
                                ['Agency payout', 'Platform to agency', 'One payment covering a group of hosts', 'Clear statements, batch processing'],
                            ],
                        },
                    },
                    'Viewers and hosts are often in different countries. A platform may earn most of its coin revenue in Brazil and Indonesia while its hosts stream from the Philippines, Kenya or the United States, so pay-in and payout coverage have to be planned separately.',
                ],
            },
            {
                id: 'one-week-example',
                heading: 'Worked example: one week of money on a streaming platform',
                blocks: [
                    'One week on a mid-sized platform shows where each payment step occurs:',
                    {
                        steps: [
                            '**Monday evening:** a viewer in Indonesia scans a QRIS code to buy a coin pack. KaazPay sends a signed notification and the coins are credited once it is verified.',
                            '**Midweek:** viewers in Brazil top up by Pix and in Malaysia by DuitNow; US viewers use Apple Pay, Google Pay or Cash App.',
                            '**Throughout:** each gift is converted into host points in your ledger, tagged with the host ID.',
                            '**Sunday:** your system totals each host\'s and agency\'s earnings for the week and applies your own checks.',
                            '**Monday morning:** one batch payout goes out: PayPal and Cash App for US hosts, bank transfer in the Philippines, mobile money in Kenya, USDT for hosts in pay-in only markets.',
                            '**After settlement:** that week\'s collections reach you as the equivalent amount in USDT on each channel\'s confirmed cycle.',
                        ],
                    },
                ],
            },
            {
                id: 'viewer-methods',
                heading: 'Which top-up methods should viewers see in each market?',
                blocks: [
                    'Lead with the method each market uses every day and keep cards as the second option. A selection of KaazPay channels:',
                    {
                        table: {
                            head: ['Market', 'Viewer top-ups', 'Host payouts'],
                            rows: [
                                ['[United States](/payment-methods/united-states)', 'Cash App, Apple Pay, Google Pay', '[PayPal](/methods/paypal), [Cash App](/methods/cash-app), Chime, cards, ACH'],
                                ['[Global cards](/payment-methods/global-cards)', 'Visa, Mastercard, UnionPay', 'Not applicable'],
                                ['[Mexico](/payment-methods/mexico)', 'SPEI, bank transfer, cash payment', 'Bank transfer'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix), bank transfer, Boleto, cash payment', 'Bank transfer'],
                                ['[Malaysia](/payment-methods/malaysia)', '[DuitNow](/methods/duitnow), FPX, Touch \'n Go', 'Bank transfer'],
                                ['[Philippines](/payment-methods/philippines)', '[GCash](/methods/gcash)', 'Bank transfer'],
                                ['[Indonesia](/payment-methods/indonesia)', '[QRIS](/methods/qris)', 'Bank transfer, mobile money'],
                                ['[Kenya](/payment-methods/kenya)', 'M-Pesa, local cards', 'Bank transfer, [mobile money](/methods/mobile-money)'],
                                ['[Global USDT](/payment-methods/usdt)', 'USDT', 'USDT'],
                            ],
                        },
                    },
                    { note: 'Japan, Chile and Peru are examples of pay-in only markets. Channels, limits and settlement cycles are confirmed with your account manager before go-live.' },
                    'Cash vouchers and some bank transfers confirm only when the viewer completes payment, so offer them for bigger packs rather than as the quick top-up inside a stream.',
                ],
            },
            {
                id: 'mid-stream-failures',
                heading: 'How do you stop top-ups failing in the middle of a stream?',
                blocks: [
                    'A top-up that fails during a stream is rarely retried later, because the moment to send a gift has passed. Most fixes are product decisions:',
                    {
                        list: [
                            '**Detect the market** and show the local wallet or QR option on the first screen.',
                            '**Sell fixed packs** rather than free amounts, so the viewer makes one tap instead of typing.',
                            '**Open payment in an overlay** where possible, so the stream keeps playing in the background.',
                            '**Credit from the notification**, not from the viewer\'s return to the app.',
                            '**Use multi-channel routing** where a market has more than one channel, so traffic fails over if one slows.',
                        ],
                    },
                    'See the [payment success rate guide](/guides/payment-success-rate) for a full troubleshooting list.',
                ],
            },
            {
                id: 'host-payouts',
                heading: 'How should you pay hosts and agencies across countries?',
                blocks: [
                    'Pay each recipient on a rail they already use at home. With KaazPay that means PayPal, Cash App, Chime, cards or ACH in the United States, bank transfer or mobile money in the payout markets, and USDT anywhere, which covers hosts in markets without local payouts.',
                    'Run the regular cycle as batch payouts and keep single payouts for ad-hoc withdrawals. Agencies are usually paid as one recipient and then pay their own hosts, which cuts the number of payouts you send. Validate recipient details before each batch; the [mass payouts guide](/guides/mass-payouts-emerging-markets) covers data checks and handling returned payouts.',
                ],
            },
            {
                id: 'reconciliation',
                heading: 'How do you keep coin and earnings ledgers reconciled?',
                blocks: [
                    {
                        list: [
                            'Give every top-up and every payout its own reference and store it next to the user or host ID.',
                            'Update balances only from signed notifications; KaazPay sends them for pay-ins and for payout status changes.',
                            'Make handlers idempotent so a repeated notification never adds coins or pays a host twice.',
                            'Reconcile both directions in the KaazPay dashboard against your own ledger at the end of each payout cycle.',
                        ],
                    },
                ],
            },
            {
                id: 'currency-and-settlement',
                heading: 'How is revenue in many currencies settled?',
                blocks: [
                    'Viewers pay in reais, rupiah, pesos, ringgit and dollars, while host earnings are often counted in a single unit. KaazPay settles collected funds as the equivalent amount in USDT, so you do not need a bank account in every viewer market. Many channels settle D+0, others D+1 or later, confirmed per channel. For the trade-offs, read [USDT vs local currency settlement](/compare/usdt-vs-local-currency-settlement).',
                    'Opening an account is subject to a business review. Moderation and clear host policies remain your responsibility as the operator. More on our [live streaming solution](/industries/live-streaming).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How to set up live streaming payments with KaazPay',
                blocks: [
                    {
                        steps: [
                            '**Open a merchant account**, telling us where your viewers and hosts are and how often you pay out.',
                            '**Get API keys** from the merchant dashboard.',
                            '**Integrate with engineer support**: top-ups, notifications and batch payouts, guided by the [developer docs](/developers).',
                            '**Go live**, with each market\'s channels and settlement cycle confirmed in advance.',
                        ],
                    },
                    'Contact our business team on Telegram via the [contact page](/contact). We reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'How can viewers buy coins without a credit card?', a: 'Offer their local method: Pix in Brazil, QRIS in Indonesia, GCash in the Philippines, DuitNow in Malaysia or Cash App in the US. KaazPay notifies you when each payment confirms so coins can be credited.' },
            { q: 'Can we pay hosts in several countries from one account?', a: 'Yes. KaazPay pays out to PayPal, Cash App, Chime, cards and ACH in the US, by bank transfer or mobile money in the payout markets, and in USDT, singly or in batches.' },
            { q: 'What about hosts in markets without local payouts?', a: 'Some markets are pay-in only. Hosts there can be paid in USDT, after your own recipient checks.' },
            { q: 'Should we pay hosts directly or through agencies?', a: 'Both work. Paying agencies as single recipients reduces payout volume; paying hosts directly gives you more control. The two can also be combined.' },
            { q: 'How is our coin revenue settled?', a: 'As the equivalent amount in USDT. Many channels settle D+0, others D+1 or later, confirmed per channel before go-live.' },
        ],
        queries: [
            'How do live streaming apps let viewers in Indonesia and Brazil buy coins with QRIS and Pix?',
            'How to pay live stream hosts and agencies in many countries every week',
            'Payment gateway for a social live streaming app with gift top-ups and host payouts',
            'How do we reconcile coin top-ups and host withdrawals on a streaming platform?',
        ],
    },
    zh: {
        title: '直播平台支付：金币充值代收与主播代付',
        description: '直播平台支付全流程：观众用本地钱包、扫码、实时银行支付和银行卡充值金币，按周向主播和公会代付，双向对账方法，以及多币种收入如何以 USDT 结算。',
        h1: '直播平台如何代收观众充值并向主播发放收益？',
        summary: '直播平台通过本地电子钱包、扫码、实时银行支付和银行卡代收观众的金币充值，再经本地代付通道或 USDT 向主播和公会发放分成。KaazPay 在同一个商户账户中处理这两个方向，每笔充值和代付都有签名通知，代收资金以 USDT 结算。',
        takeaways: [
            '直播平台在一本账上运行两条资金流：向观众销售金币，向主播发放收益。',
            '打赏发生在直播进行中，充值须在观众观看期间完成确认，Pix、QRIS、GCash、DuitNow 等实时方式最合适。',
            '主播和观众往往不在同一个国家，代付覆盖要按市场确认，没有本地代付的地方可用 USDT。',
            '每笔交易使用唯一编号、余额以通知为准，可保持金币账与收益账一致。',
            '代收资金按等值 USDT 结算，结算周期按通道确认。',
        ],
        sections: [
            {
                id: 'two-ledgers',
                heading: '直播 App 需要哪几条资金流？',
                blocks: [
                    '直播和社交直播 App 的资金流程基本相同：观众购买金币，在直播中送礼物、开通付费功能，礼物折算成主播收益，平台再按周期发放收益。',
                    {
                        table: {
                            head: ['资金流', '付款方 → 收款方', '典型特征', '关键点'],
                            rows: [
                                ['金币充值', '观众 → 平台', '金额小，一周多次，常在直播中', '熟悉的方式、快速确认'],
                                ['礼物折算', '平台内部', '金币转为主播积分或钻石', '每位主播账目准确'],
                                ['主播代付', '平台 → 主播', '按周或按月，付到主播所在国家', '本地通道、时间可预期'],
                                ['公会代付', '平台 → 公会', '一笔款项覆盖一组主播', '账单清晰、批量处理'],
                            ],
                        },
                    },
                    '观众和主播往往不在同一个国家。平台的金币收入可能主要来自巴西和印尼，主播却在菲律宾、肯尼亚或美国开播，所以代收和代付覆盖要分开规划。',
                ],
            },
            {
                id: 'one-week-example',
                heading: '实例：直播平台一周的资金流转',
                blocks: [
                    '以下以一家中型平台的一周为例，说明各支付环节所处的位置：',
                    {
                        steps: [
                            '**周一晚上**：印尼观众扫 QRIS 码买金币，KaazPay 发出签名通知，验签后即发放金币。',
                            '**周中**：巴西观众用 Pix 充值，马来西亚观众用 DuitNow，美国观众用 Apple Pay、Google Pay 或 Cash App。',
                            '**全程**：每份礼物都在您的账本中折算成主播积分，并打上主播 ID。',
                            '**周日**：系统汇总每位主播和每家公会本周收益，并执行您自己的审核规则。',
                            '**下周一上午**：发出一批代付：美国主播通过 PayPal、Cash App，菲律宾通过银行转账，肯尼亚通过移动钱包，仅支持代收市场的主播通过 USDT。',
                            '**结算**：这一周的代收资金按各通道确认的周期，以等值 USDT 结算给您。',
                        ],
                    },
                ],
            },
            {
                id: 'viewer-methods',
                heading: '各市场的观众充值页应展示哪些方式？',
                blocks: [
                    '优先展示各市场的日常支付方式，银行卡放第二位。以下为 KaazPay 部分通道：',
                    {
                        table: {
                            head: ['市场', '观众充值', '主播代付'],
                            rows: [
                                ['[美国](/payment-methods/united-states)', 'Cash App、Apple Pay、Google Pay', '[PayPal](/methods/paypal)、[Cash App](/methods/cash-app)、Chime、银行卡、ACH'],
                                ['[全球信用卡](/payment-methods/global-cards)', 'Visa、Mastercard、银联', '不适用'],
                                ['[墨西哥](/payment-methods/mexico)', 'SPEI、银行转账、现金支付', '银行转账'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)、银行转账、Boleto、现金支付', '银行转账'],
                                ['[马来西亚](/payment-methods/malaysia)', '[DuitNow](/methods/duitnow)、FPX、Touch \'n Go', '银行转账'],
                                ['[菲律宾](/payment-methods/philippines)', '[GCash](/methods/gcash)', '银行转账'],
                                ['[印度尼西亚](/payment-methods/indonesia)', '[QRIS](/methods/qris)', '银行转账、移动钱包'],
                                ['[肯尼亚](/payment-methods/kenya)', 'M-Pesa、本地银行卡', '银行转账、[移动钱包](/methods/mobile-money)'],
                                ['[全球 USDT](/payment-methods/usdt)', 'USDT', 'USDT'],
                            ],
                        },
                    },
                    { note: '日本、智利、秘鲁等市场仅支持代收。通道、限额与结算周期均在上线前与客户经理确认。' },
                    '现金凭证和部分银行转账须待观众完成付款后才确认，更适合大额金币包，不适合直播中的即时充值。',
                ],
            },
            {
                id: 'mid-stream-failures',
                heading: '如何避免直播中充值失败？',
                blocks: [
                    '直播中充值失败后，观众通常不会事后重试，因为送礼的时机已经过去。解决办法大多在产品层面：',
                    {
                        list: [
                            '**识别观众所在市场**，第一屏就展示本地钱包或扫码选项。',
                            '**提供固定档位的金币包**，观众一键选择，无需输入金额。',
                            '**尽量用浮层打开支付页**，直播画面在后台继续播放。',
                            '**以通知为准发放金币**，而不是等观众跳回 App。',
                            '**多通道路由**：市场有多条通道时，一条通道变慢时自动切换。',
                        ],
                    },
                    '完整的排查清单见[支付成功率指南](/guides/payment-success-rate)。',
                ],
            },
            {
                id: 'host-payouts',
                heading: '如何向多国主播和公会发放收益？',
                blocks: [
                    '用收款人本国常用的通道发放。通过 KaazPay，美国可走 PayPal、Cash App、Chime、银行卡或 ACH，代付市场可走银行转账或移动钱包，全球均可用 USDT，没有本地代付的市场也能覆盖。',
                    '固定周期的结算用批量代付，临时提现用单笔代付。公会通常作为一个收款人，再自行分给旗下主播，可减少您的出款笔数。每批发出前先校验收款资料，数据检查与退回处理见[批量代付指南](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'reconciliation',
                heading: '如何保持金币账与收益账一致？',
                blocks: [
                    {
                        list: [
                            '每笔充值、每笔代付都有独立编号，并与用户或主播 ID 一起保存。',
                            '余额只依据签名通知变更，KaazPay 对代收和代付状态变化都会发送通知。',
                            '处理逻辑做幂等，重复通知不会多加金币，也不会重复给主播打款。',
                            '每个代付周期结束时，用 KaazPay 后台的双向记录与自家账本核对。',
                        ],
                    },
                ],
            },
            {
                id: 'currency-and-settlement',
                heading: '多币种直播收入如何结算？',
                blocks: [
                    '观众用雷亚尔、印尼盾、比索、林吉特和美元付款，主播收益却常以单一单位计算。KaazPay 将代收资金按等值 USDT 结算，无需在每个观众市场开设银行账户。许多通道为 D+0，其他通道为 D+1 或更长，按通道确认。两种方式的取舍见 [USDT 结算 vs 本币结算](/compare/usdt-vs-local-currency-settlement)。',
                    '开户需经过业务审核，内容审核和主播规范仍由平台方负责。更多内容见[直播行业方案](/industries/live-streaming)。',
                ],
            },
            {
                id: 'get-started',
                heading: '直播平台如何接入 KaazPay',
                blocks: [
                    {
                        steps: [
                            '**开通商户账户**，说明观众和主播的分布以及收益发放频率。',
                            '**获取 API 密钥**，在商户后台查看。',
                            '**工程师协助对接**充值、通知与批量代付，参考[开发者文档](/developers)。',
                            '**正式上线**，各市场通道与结算周期提前确认。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '没有信用卡的观众如何购买金币？', a: '提供当地支付方式：巴西 Pix、印尼 QRIS、菲律宾 GCash、马来西亚 DuitNow、美国 Cash App。每笔付款确认后 KaazPay 都会通知您发放金币。' },
            { q: '能用一个账户给多个国家的主播发收益吗？', a: '可以。KaazPay 在美国支持 PayPal、Cash App、Chime、银行卡和 ACH，在代付市场支持银行转账或移动钱包，也可用 USDT，单笔批量均可。' },
            { q: '主播所在市场没有本地代付时如何处理？', a: '部分市场仅支持代收，这些主播可在您完成收款人审核后以 USDT 发放。' },
            { q: '收益应该直接发给主播还是发给公会？', a: '两种都可以。发给公会能减少出款笔数，直接发给主播则掌控度更高，也可两者结合。' },
            { q: '金币收入如何结算？', a: '按等值 USDT 结算。许多通道为 D+0，其他通道为 D+1 或更长，上线前按通道确认。' },
        ],
        queries: [
            '直播 App 想让印尼、巴西观众用 QRIS 和 Pix 充值金币，如何接入？',
            '海外直播平台每周给多个国家的主播和公会发收益，用什么代付方案？',
            '社交直播平台的礼物充值和主播提现，哪家支付通道能同时支持？',
            '直播平台的金币充值和主播提现如何对账？',
        ],
    },
};
