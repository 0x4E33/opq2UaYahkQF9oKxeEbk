export default {
    slug: 'south-africa-payment-methods',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['south-africa'],
        methods: ['eft', 'capitec-pay'],
        industries: ['e-commerce', 'gaming', 'digital-goods', 'education'],
        articles: ['africa-mobile-money', 'mobile-money-vs-bank-transfer-africa', 'payment-success-rate', 'usdt-settlement'],
    },
    en: {
        title: 'South Africa Payments: EFT, Capitec Pay and Cards',
        description: 'Collect rand online: EFT, Capitec Pay and South African cards compared, a Capitec Pay checkout walk-through, method ordering, ZAR payouts and USDT settlement.',
        h1: 'How to accept online payments in South Africa',
        summary: 'South African shoppers pay online mainly from their bank account, through EFT or by approving in the Capitec banking app with Capitec Pay, and by local card, all in rand (ZAR). A South African checkout should lead with these bank-based options and keep cards alongside. KaazPay offers EFT, Capitec Pay and South Africa Cards for pay-in, ZAR payouts to bank accounts, and USDT settlement.',
        queries: [
            'What payment methods do South African online shoppers actually use?',
            'How does Capitec Pay work for an online store?',
            'Is EFT still worth offering at a South African checkout?',
            'Can we accept rand payments and pay South African sellers without a local entity bank account?',
            'Does mobile money work in South Africa like it does in Kenya?',
        ],
        takeaways: [
            'South Africa is a bank-first market on KaazPay: the local options are EFT, Capitec Pay and cards, not mobile money.',
            'Capitec Pay lets customers of Capitec, the country’s largest retail bank by clients, approve a payment in their banking app without card details.',
            'EFT suits shoppers who pay from online banking and those making larger purchases.',
            'Payouts in South Africa go to bank accounts in ZAR; mobile money payouts are not offered.',
            'ZAR collections are settled to you in USDT, with the cycle confirmed per channel before go-live.',
        ],
        sections: [
            { id: 'bank-first-market', heading: 'Why is South Africa a bank-first market for online payments?', blocks: [
                'South Africa has one of the most developed retail banking systems on the continent, and online shoppers are comfortable paying straight from a bank account. This differs from Kenya and much of West Africa, where mobile wallets are the default. KaazPay has no mobile money channel in South Africa; the available methods are **EFT**, **Capitec Pay** and **South African cards**, all in rand (ZAR).',
                'For merchants, this means designing the checkout around bank payments first and cards second. The current channel list is on the [South Africa market page](/payment-methods/south-africa).',
            ] },
            { id: 'methods-at-a-glance', heading: 'EFT, Capitec Pay and cards at a glance', blocks: [
                { table: { head: ['', 'EFT', 'Capitec Pay', 'South Africa Cards'], rows: [
                    ['Where the shopper approves', 'Online banking', 'The Capitec banking app', 'Card authentication at checkout'],
                    ['Card details entered', 'No', 'No', 'Yes'],
                    ['Who it reaches', 'Customers of South African banks who pay online', 'Capitec clients', 'Card holders'],
                    ['Best fit', 'Larger baskets, card-averse buyers', 'Mobile shoppers, quick approvals', 'Repeat and impulse buyers'],
                    ['Role on KaazPay', 'Pay-in', 'Pay-in', 'Pay-in'],
                ] } },
                { note: 'Money going out (refunds, withdrawals, seller earnings) is paid to South African bank accounts in ZAR.' },
            ] },
            { id: 'capitec-pay-walkthrough', heading: 'What does a Capitec Pay checkout look like?', blocks: [
                '**Capitec Pay** is designed around the banking app the customer already uses. Here is a shopper in Cape Town paying R450 for an online course through a KaazPay-powered checkout:',
                { steps: [
                    'She picks Capitec Pay and identifies herself as a Capitec client as the payment page asks.',
                    'Your backend has already created a 450 ZAR pay-in order through the KaazPay API with a unique order ID.',
                    'A payment request appears in her Capitec app; she checks the amount and approves it.',
                    'KaazPay sends your server a signed notification with the result.',
                    'You verify it, unlock the course and the checkout page shows success when she switches back.',
                ] },
                'Because Capitec is the largest retail bank in the country by number of clients, Capitec Pay usually merits a prominent position. See the [Capitec Pay method page](/methods/capitec-pay).',
            ] },
            { id: 'eft-online', heading: 'How does EFT work for online orders?', blocks: [
                '**EFT** (electronic funds transfer) lets the shopper pay from their own account through online banking. The customer chooses EFT, completes the payment with their bank, and the order is confirmed when KaazPay notifies your server.',
                'EFT appeals to shoppers who do not like typing card numbers on websites and to those buying something expensive enough that they would rather pay directly from the account. It involves the bank’s own login steps, so make the return to your site clear and never fulfil on the browser redirect alone. More on the [EFT method page](/methods/eft).',
            ] },
            { id: 'checkout-ordering', heading: 'How should you order payment methods on a South African checkout?', blocks: [
                'Use this as a starting point and refine it with your own data:',
                { list: [
                    '**Mobile traffic:** show Capitec Pay near the top, since approval happens in an app already on the phone.',
                    '**Desktop and higher-value orders:** give EFT equal prominence with Capitec Pay.',
                    '**Subscriptions, impulse buys and returning customers:** make sure cards are visible without scrolling.',
                    '**International visitors in your store:** keep cards available for anyone who does not bank in South Africa.',
                    '**After launch:** compare completion per method weekly and reorder if one consistently outperforms.',
                ] },
            ] },
            { id: 'failed-payments', heading: 'What causes failed or abandoned payments in South Africa?', blocks: [
                { table: { head: ['Problem', 'Typical cause', 'Fix'], rows: [
                    ['Shopper leaves during EFT', 'Unfamiliar steps or a long bank login', 'Explain the steps before redirecting and keep the order open for their return'],
                    ['Capitec Pay request not approved', 'Shopper did not notice the app notification', 'Tell them to open the Capitec app and offer to resend'],
                    ['Card declined', 'Authentication not completed or bank decline', 'Suggest EFT or Capitec Pay as an alternative on the same page'],
                    ['Order paid but not delivered', 'Fulfilment tied to the redirect', 'Deliver only after verifying the signed notification'],
                ] } },
                'Having three methods on one checkout is itself a recovery tool: a shopper whose card fails can finish with a bank method instead. Read more in our [payment success rate guide](/guides/payment-success-rate).',
            ] },
            { id: 'zar-payouts-settlement', heading: 'How do payouts and settlement work in South Africa?', blocks: [
                'KaazPay sends **ZAR payouts to South African bank accounts** from the same merchant account as your collections, singly or in batches, with a status notification for each one. Mobile money payouts are not offered in South Africa. For scheduled payout runs, see [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
                'Collections in rand are settled to you as the equivalent amount in **USDT**, so no South African bank account is required on your side. Many KaazPay channels settle D+0, others D+1 or later; the cycle for each South African channel is confirmed before launch. See [USDT settlement](/guides/usdt-settlement).',
            ] },
            { id: 'start-south-africa-kaazpay', heading: 'How to start accepting payments in South Africa with KaazPay', blocks: [
                { steps: [
                    'Open a merchant account and describe your product and South African volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with an engineer on hand using the [developer documentation](/developers), testing EFT, Capitec Pay, cards and payouts.',
                    'Go live with all three pay-in methods and bank payouts in one dashboard.',
                ] },
                'For wallet-first markets elsewhere in Africa, see the [mobile money vs bank transfer comparison](/compare/mobile-money-vs-bank-transfer-africa) and the [Africa mobile money guide](/guides/africa-mobile-money). For pricing and settlement terms, contact our business team on Telegram through the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Which payment methods can I accept in South Africa with KaazPay?', a: 'EFT, Capitec Pay and South Africa Cards for pay-in, all in ZAR through one integration, plus payouts to South African bank accounts.' },
            { q: 'Do customers need to enter card details for Capitec Pay?', a: 'No. Capitec clients approve the payment inside their Capitec banking app, so no card number is entered on your checkout.' },
            { q: 'Is mobile money available in South Africa?', a: 'Not on KaazPay. South Africa is served with bank-based methods (EFT and Capitec Pay) and cards, and payouts go to bank accounts.' },
            { q: 'Should I still offer cards if I have EFT and Capitec Pay?', a: 'Yes. Some shoppers always reach for a card, and cards also give a fallback when a bank payment is not completed.' },
            { q: 'How are rand collections settled?', a: 'KaazPay settles the equivalent amount in USDT. Settlement cycles are set per channel, with many at D+0 and others D+1 or later, confirmed before go-live.' },
        ],
    },
    zh: {
        title: '南非收款方式：EFT、Capitec Pay 与银行卡',
        description: '如何在线收南非兰特：EFT、Capitec Pay 与南非银行卡三者对比，Capitec Pay 收银台流程示例，支付方式排序建议，以及 ZAR 代付和 USDT 结算说明。',
        h1: '如何在南非接入线上收款？',
        summary: '南非消费者线上付款主要依靠银行账户，即通过 EFT 网银付款，或用 Capitec Pay 在 Capitec 银行 App 中确认，另外也常用本地银行卡，全部以兰特（ZAR）计价。南非收银台应以银行类方式为主，同时保留银行卡。KaazPay 提供 EFT、Capitec Pay 与南非银行卡代收、ZAR 银行账户代付，并以 USDT 结算。',
        queries: [
            '南非的网购用户实际上都用什么方式付款？',
            'Capitec Pay 在网店里是怎么用的？',
            '南非收银台还有必要提供 EFT 吗？',
            '没有南非公司银行账户，能收兰特并给南非卖家付款吗？',
            '南非能像肯尼亚那样用移动钱包收款吗？',
        ],
        takeaways: [
            '在 KaazPay 上南非是“银行优先”市场：本地方式是 EFT、Capitec Pay 和银行卡，而不是移动钱包。',
            'Capitec Pay 让南非客户数最多的零售银行 Capitec 的用户在银行 App 中确认付款，无需卡号。',
            'EFT 适合习惯网银付款的顾客和较大金额的订单。',
            '南非代付以 ZAR 打到银行账户，不提供移动钱包代付。',
            'ZAR 代收以 USDT 结算，各通道周期在上线前确认。',
        ],
        sections: [
            { id: 'bank-first-market', heading: '为什么说南非线上支付是“银行优先”？', blocks: [
                '南非的零售银行体系在非洲属于最成熟之列，网购用户习惯直接从银行账户付款。这与肯尼亚及西非大部分地区不同，那些市场以手机钱包为主。KaazPay 在南非没有移动钱包通道，提供的是 **EFT**、**Capitec Pay** 和**南非银行卡**，均以兰特（ZAR）计价。',
                '对商户而言，收银台应优先围绕银行付款设计，银行卡作为第二选择。最新通道列表见[南非市场页面](/payment-methods/south-africa)。',
            ] },
            { id: 'methods-at-a-glance', heading: 'EFT、Capitec Pay、银行卡一览', blocks: [
                { table: { head: ['', 'EFT', 'Capitec Pay', '南非银行卡'], rows: [
                    ['顾客在哪里确认', '网银', 'Capitec 银行 App', '收银台上的卡验证'],
                    ['是否输入卡号', '否', '否', '是'],
                    ['覆盖人群', '在网上付款的南非各银行客户', 'Capitec 客户', '持卡人'],
                    ['最适合', '大额订单、不爱刷卡的顾客', '手机用户、快速确认', '复购与冲动消费'],
                    ['在 KaazPay 的角色', '代收', '代收', '代收'],
                ] } },
                { note: '对外付款（退款、提现、卖家收益）以 ZAR 打到南非银行账户。' },
            ] },
            { id: 'capitec-pay-walkthrough', heading: 'Capitec Pay 收银台是怎样的？', blocks: [
                '**Capitec Pay** 基于顾客已在使用的银行 App。以开普敦一位顾客通过 KaazPay 收银台支付 R450 网课费为例：',
                { steps: [
                    '她选择 Capitec Pay，按支付页面提示表明自己是 Capitec 客户。',
                    '您的后端此前已通过 KaazPay API 创建一笔 450 ZAR 的代收订单，带唯一订单号。',
                    '她的 Capitec App 中出现付款请求，核对金额后确认。',
                    'KaazPay 向您的服务器推送带签名的结果通知。',
                    '您验签后开通课程，她切回页面时即可看到支付成功。',
                ] },
                'Capitec 按客户数是南非最大的零售银行，Capitec Pay 通常应放在显眼位置。详见 [Capitec Pay 支付方式页面](/methods/capitec-pay)。',
            ] },
            { id: 'eft-online', heading: 'EFT 在线上订单中怎么运作？', blocks: [
                '**EFT**（电子资金转账）让顾客通过网银从自己的账户付款。顾客选择 EFT，在银行端完成付款，KaazPay 通知您的服务器后订单即确认。',
                '不喜欢在网站上输入卡号的顾客，以及买贵重商品、宁愿直接从账户付款的顾客，都偏爱 EFT。由于涉及银行自己的登录步骤，返回您网站的路径要清楚，并且不能只凭浏览器跳转就发货。详见 [EFT 支付方式页面](/methods/eft)。',
            ] },
            { id: 'checkout-ordering', heading: '南非收银台上的支付方式该怎么排序？', blocks: [
                '可先参考以下建议，再根据自身数据调整：',
                { list: [
                    '**手机流量：**Capitec Pay 放在靠前位置，因为确认就在手机上已有的 App 里完成。',
                    '**电脑端与高客单价：**EFT 与 Capitec Pay 同样醒目。',
                    '**订阅、冲动消费与老顾客：**确保不用滚动就能看到银行卡选项。',
                    '**海外访客：**保留银行卡，供未在南非开户的顾客使用。',
                    '**上线之后：**每周比较各方式的完成率，将表现持续更好的方式前移。',
                ] },
            ] },
            { id: 'failed-payments', heading: '南非付款失败或放弃的常见原因是什么？', blocks: [
                { table: { head: ['问题', '常见原因', '解决办法'], rows: [
                    ['顾客在 EFT 过程中离开', '步骤陌生或银行登录太长', '跳转前先说明步骤，并保留订单等待顾客返回'],
                    ['Capitec Pay 请求未确认', '顾客没注意到 App 通知', '提示顾客打开 Capitec App，并提供重新发送'],
                    ['银行卡被拒', '未完成验证或银行拒绝', '在同一页面推荐改用 EFT 或 Capitec Pay'],
                    ['已付款却没发货', '发货逻辑绑定在跳转上', '只在验签通过的通知到达后发货'],
                ] } },
                '同一收银台提供三种方式，本身即可挽回部分失败交易：刷卡失败的顾客可以改用银行方式完成付款。更多方法见[支付成功率指南](/guides/payment-success-rate)。',
            ] },
            { id: 'zar-payouts-settlement', heading: '南非的代付和结算怎么运作？', blocks: [
                'KaazPay 从您收款的同一商户账户，以 **ZAR 代付到南非银行账户**，单笔、批量均可，每笔都有状态通知。南非不提供移动钱包代付。定期批量代付的做法见[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)。',
                '兰特代收按等额 **USDT** 结算给您，您这边不需要南非银行账户。KaazPay 不少通道为 D+0，也有 D+1 或更长的，南非各通道的周期在上线前确认。详见 [USDT 结算](/guides/usdt-settlement)。',
            ] },
            { id: 'start-south-africa-kaazpay', heading: '如何通过 KaazPay 在南非开始收款', blocks: [
                { steps: [
                    '开设商户账户，介绍您的产品和南非交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，测试 EFT、Capitec Pay、银行卡和代付。',
                    '正式上线三种代收方式和银行代付，在一个后台统一管理。',
                ] },
                '非洲其他以钱包为主的市场，请参阅[移动钱包与银行转账对比](/compare/mobile-money-vs-bank-transfer-africa)和[非洲移动钱包指南](/guides/africa-mobile-money)。关于报价和结算条款，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'KaazPay 在南非支持哪些支付方式？', a: '代收支持 EFT、Capitec Pay 和南非银行卡，均以 ZAR 计价、一次对接；代付支持南非银行账户。' },
            { q: '用 Capitec Pay 付款需要输入卡号吗？', a: '不需要。Capitec 客户在 Capitec 银行 App 内确认付款，您的收银台上不会输入卡号。' },
            { q: '南非可以用移动钱包收款吗？', a: 'KaazPay 在南非不提供移动钱包。南非通过 EFT、Capitec Pay 等银行方式和银行卡收款，代付打到银行账户。' },
            { q: '已经有 EFT 和 Capitec Pay，还需要银行卡吗？', a: '需要。部分顾客习惯用卡付款，银行付款未完成时，银行卡也可作为备选。' },
            { q: '兰特代收如何结算？', a: 'KaazPay 以等额 USDT 结算。结算周期按通道确定，不少为 D+0，也有 D+1 或更长，上线前确认。' },
        ],
    },
};
