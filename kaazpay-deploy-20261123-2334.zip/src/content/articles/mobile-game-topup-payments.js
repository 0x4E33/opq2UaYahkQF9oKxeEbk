export default {
    slug: 'mobile-game-topup-payments',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['united-states', 'global-cards', 'japan', 'mexico', 'colombia', 'brazil', 'malaysia', 'philippines', 'indonesia'],
        methods: ['apple-pay', 'google-pay', 'visa', 'jcb', 'spei', 'pix', 'duitnow', 'gcash', 'qris'],
        industries: ['gaming', 'digital-goods'],
        articles: ['southeast-asia-payment-methods', 'instant-payments-vs-bank-transfer', 'payment-gateway-integration-checklist', 'usdt-settlement'],
    },
    en: {
        title: 'Game Top-Up Website Payments: Methods and Setup',
        description: 'Set up payments for an official game top-up website: which local wallets, QR and instant payments fit each pack size, instant crediting, launch checks, USDT.',
        h1: 'How do you accept payments on a mobile game top-up website?',
        summary: "A mobile game top-up website takes the player's game ID, creates an order, lets the player pay with a method common in their country, and credits diamonds or coins when a signed payment notification reaches the game server. Instant methods such as Pix, SPEI, DuitNow, GCash and QRIS suit small packs; cards and vouchers cover other buyers. KaazPay provides these methods from one account and settles in USDT.",
        queries: [
            'We are launching an official top-up site for our mobile RPG in Southeast Asia. What payment methods do players there actually use?',
            'Players in Brazil keep asking if they can buy gems with Pix on our website. How do we add it?',
            'How do we stop players getting diamonds twice when the payment callback is sent more than once?',
            'What should we test before opening a game web shop with local payments in Mexico and the Philippines?',
            'Can our game studio receive web top-up revenue from several countries in USDT?',
        ],
        takeaways: [
            'Match methods to pack size: instant wallets and QR for small packs, vouchers and bank transfers for bigger bundles.',
            'Validate the player ID before taking money; many "wrong account" tickets start there.',
            'Credit items only from a verified, signed server notification and make crediting idempotent per order.',
            'Prepare for launch-day and event spikes with more than one channel per market where available.',
            'KaazPay settles collected funds as the equivalent amount in USDT; settlement cycles are confirmed per channel.',
        ],
        sections: [
            {
                id: 'how-a-topup-site-works',
                heading: 'What happens when a player tops up on a game website?',
                blocks: [
                    'A web top-up store is a publisher-run page where players buy in-game currency or items outside the app. From the player’s side, the flow is short:',
                    {
                        steps: [
                            'The player enters their game ID (and server or region, if your game has several). Your site looks it up and shows the character name.',
                            'The player picks a pack, for example 300 diamonds, priced in local currency.',
                            'The player chooses a payment method and pays in their wallet, banking app or by scanning a QR code.',
                            'The payment gateway confirms the payment to your server with a signed notification.',
                            'Your game server credits the pack and the player sees it in their inbox or balance.',
                        ],
                    },
                    'Publishers run these sites to offer payment methods that app stores may not, and to build a direct relationship with paying players. App stores have their own rules on purchases made outside the app; read and follow the current rules of every store your game is listed in.',
                ],
            },
            {
                id: 'methods-by-market',
                heading: 'Which payment methods do players use to top up in each market?',
                blocks: [
                    'Many players in growth markets do not pay for games by credit card. They top up with an e-wallet, a QR code or a bank app. The table is a selection of KaazPay pay-in methods relevant to game top-ups.',
                    {
                        table: {
                            head: ['Market', 'Methods', 'Typical confirmation'],
                            rows: [
                                ['United States', '[Apple Pay](/methods/apple-pay), [Google Pay](/methods/google-pay), Cash App', 'At payment'],
                                ['Worldwide', '[Visa](/methods/visa), Mastercard, UnionPay cards', 'At payment'],
                                ['[Japan](/payment-methods/japan)', '[JCB](/methods/jcb) cards', 'At payment'],
                                ['[Mexico](/payment-methods/mexico)', '[SPEI](/methods/spei), bank transfer, cash payment', 'Instant (SPEI) / when paid'],
                                ['Colombia', 'PSE, Bre-B (key or QR), Bancolombia, cash payment', 'Instant / when paid'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix), Boleto, bank transfer, cash payment', 'Seconds (Pix) / when paid'],
                                ['[Malaysia](/payment-methods/malaysia)', "[DuitNow](/methods/duitnow), Touch 'n Go, FPX", 'Instant'],
                                ['[Philippines](/payment-methods/philippines)', '[GCash](/methods/gcash)', 'Instant'],
                                ['[Indonesia](/payment-methods/indonesia)', '[QRIS](/methods/qris)', 'Instant'],
                            ],
                        },
                    },
                    { note: 'Availability depends on market and business model and is confirmed with your KaazPay account manager before go-live. For the region in depth, see [Southeast Asia payment methods](/guides/southeast-asia-payment-methods).' },
                ],
            },
            {
                id: 'pack-size-and-method',
                heading: 'How should pack sizes and payment methods fit together?',
                blocks: [
                    'Players buying an extra pack during an event expect it immediately; players buying a monthly bundle are more willing to wait. Use that difference when you decide which methods to show next to which packs.',
                    {
                        table: {
                            head: ['Purchase type', 'Best-fit methods', 'Why'],
                            rows: [
                                ['Small, impulse packs', 'GCash, QRIS, DuitNow, Pix, SPEI, Bre-B, Apple Pay, Google Pay', 'Approved in a few taps, confirms quickly'],
                                ['Mid-size packs and passes', 'Above plus FPX, PSE, cards', 'Slightly longer flow is acceptable'],
                                ['Large bundles, gift purchases', 'Above plus Boleto, cash payment, bank transfer', 'Player is willing to wait for confirmation'],
                            ],
                        },
                    },
                    'When you show a voucher or bank transfer, say clearly that the pack arrives after the payment is confirmed, not immediately. The difference between the two kinds of payment is explained in [instant payments vs bank transfer](/compare/instant-payments-vs-bank-transfer).',
                ],
            },
            {
                id: 'instant-crediting',
                heading: 'How do you credit diamonds and coins safely right after payment?',
                blocks: [
                    'Credit from the server, never from the browser. A player closing the payment page, a lost connection or a slow redirect should not change whether the item arrives. KaazPay sends a real-time notification signed with your keys once a payment is confirmed.',
                    {
                        list: [
                            '**Verify the signature** of every notification before reading its contents.',
                            '**Check the amount and currency** against the order you created.',
                            '**Credit once per order ID.** Notifications can be retried; a second one must not credit again.',
                            '**Store the payment status** so a delayed voucher payment still credits automatically when it confirms.',
                            '**Return the expected acknowledgement** so the notification is not retried unnecessarily.',
                        ],
                    },
                    'The [payment gateway integration checklist](/guides/payment-gateway-integration-checklist) walks through each of these, and the API is documented on the [developers page](/developers).',
                ],
            },
            {
                id: 'support-playbook',
                heading: 'How do you resolve "I paid but did not get my diamonds" tickets?',
                blocks: [
                    'These tickets are a major support cost for a top-up site. They usually fall into four cases, and each can be checked from your own logs and the KaazPay dashboard:',
                    {
                        list: [
                            '**Payment not completed:** the order exists but no confirmation arrived. Ask the player to check their wallet or bank app history.',
                            '**Paid, not yet confirmed:** common with vouchers and some bank transfers. Tell the player the expected time.',
                            '**Confirmed, not credited:** your server rejected or missed the notification. Re-run crediting for that order ID.',
                            '**Credited to the wrong account:** the player typed another game ID. Prevent it by showing the character name before payment.',
                        ],
                    },
                    'Searching by order ID across your logs, notifications and the dashboard makes each of these a quick lookup.',
                ],
            },
            {
                id: 'peaks-and-risk',
                heading: 'How do you keep top-ups working during launches and events?',
                blocks: [
                    'New seasons, limited skins and holiday events bring sharp spikes. Where a market has more than one channel, KaazPay routes each payment to the best-performing channel and fails over automatically, and channels are monitored around the clock.',
                    'On your side, set sensible per-account limits, watch for many orders from one account or device in a short time, and keep rate limits on the ID lookup so it cannot be scraped. Simple rules like these help block common abuse without slowing genuine players.',
                ],
            },
            {
                id: 'before-launch',
                heading: 'What should you check before opening a game top-up site?',
                blocks: [
                    {
                        list: [
                            'Prices in local currency for every pack in every launch market.',
                            'Player ID lookup with character name confirmation.',
                            'At least one instant method per market, plus cards.',
                            'Signed notification handling tested with retries and duplicate notifications.',
                            'A "processing" screen for methods that confirm later.',
                            'Support access to order search by order ID and game ID.',
                            'Agreed settlement cycle per channel and a USDT wallet for settlement.',
                        ],
                    },
                ],
            },
            {
                id: 'settlement',
                heading: 'How is top-up revenue from many countries settled?',
                blocks: [
                    'Players pay in reais, pesos, ringgit, pesos filipinos and rupiah. KaazPay settles the collected funds to the studio as the equivalent amount in USDT, so there is no need to hold local accounts in each market. Many channels settle D+0, others D+1 or later, confirmed per channel before go-live. See [how USDT settlement works](/guides/usdt-settlement).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you launch a game top-up site with KaazPay?',
                blocks: [
                    'KaazPay supports [game publishers](/industries/gaming) selling in-game currency and items. This guide covers non-gambling games; onboarding includes a business review.',
                    {
                        steps: [
                            '**Open a merchant account:** share your game, launch markets and pack structure.',
                            '**Get your API keys:** build against the sandbox with test game IDs.',
                            '**Integrate with engineer support:** order creation, signed notifications and idempotent crediting; see the [developer docs](/developers).',
                            '**Go live:** channels are confirmed per market, then your top-up site opens to players.',
                        ],
                    },
                    'Tell us which countries your players are in. [Reach us on Telegram](/contact) and we reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'Which payment methods should a game top-up website offer?', a: "Each market's everyday method, such as GCash in the Philippines, QRIS in Indonesia, DuitNow in Malaysia, Pix in Brazil or SPEI in Mexico, plus Visa, Mastercard and UnionPay cards, JCB in Japan and Apple Pay or Google Pay in the US." },
            { q: 'Can players without a credit card buy diamonds on our website?', a: 'Yes. KaazPay supports e-wallets, QR payments, instant bank payments and cash vouchers in many markets, so players can top up without a card.' },
            { q: 'How do we avoid crediting a pack twice?', a: 'Credit only from a signed server notification after verifying it, and make crediting idempotent per order ID so a retried notification does nothing.' },
            { q: 'Are we allowed to sell items on our own website?', a: 'Each app store sets its own rules for purchases made outside the app. Check and follow the current rules of every store where your game is published.' },
            { q: 'How does KaazPay settle top-up revenue?', a: 'As the equivalent amount in USDT. Many channels settle D+0, others D+1 or later, confirmed per channel before go-live.' },
        ],
    },
    zh: {
        title: '游戏官网充值收款：支付方式与搭建要点',
        description: '手游官网充值页怎么接支付：不同面额礼包适合哪些本地钱包、扫码与实时支付，如何安全地即时到账，上线前检查清单，以及海外收入的 USDT 结算。',
        h1: '手游官网充值页如何接入海外支付？',
        summary: '手游官网充值页的流程是：玩家输入游戏 ID，系统创建订单，玩家用所在国常用的方式付款，游戏服务器收到带签名的支付通知后发放钻石或金币。Pix、SPEI、DuitNow、GCash、QRIS 等实时方式适合小额礼包，信用卡与凭证类方式用于补充。KaazPay 在同一账户中提供这些支付方式，并以 USDT 结算。',
        queries: [
            '我们的手游要在东南亚开官网充值，当地玩家实际都用什么方式付款？',
            '巴西玩家一直问能不能在官网用 Pix 买宝石，要怎么接？',
            '支付回调重复发送，怎样避免玩家钻石被发两次？',
            '在墨西哥和菲律宾上线官网充值前，需要测试哪些环节？',
            '游戏公司多个国家的官网充值收入，能统一结算成 USDT 吗？',
        ],
        takeaways: [
            '支付方式要和礼包面额匹配：小额用实时钱包和扫码，大额礼包可以接受凭证和银行转账。',
            '扣款前先校验玩家 ID，许多“充错账号”的工单都源于这一步。',
            '只根据验签通过的服务器通知发货，并按订单号幂等处理。',
            '开服和活动高峰前，在条件允许的市场准备多条通道。',
            'KaazPay 将代收资金按等值 USDT 结算，结算周期按通道确认。',
        ],
        sections: [
            {
                id: 'how-a-topup-site-works',
                heading: '玩家在官网充值的流程是怎样的？',
                blocks: [
                    '官网充值页是发行商自己运营的页面，玩家可以在 App 之外购买游戏币或道具。从玩家角度看，流程如下：',
                    {
                        steps: [
                            '玩家输入游戏 ID（有多个区服的还要选区服），页面查询并显示角色名。',
                            '玩家选择礼包，例如 300 钻石，价格以本币显示。',
                            '玩家选择支付方式，在钱包、银行 App 中付款或扫码付款。',
                            '支付网关向商户服务器发送带签名的通知，确认付款成功。',
                            '游戏服务器发放礼包，玩家在邮箱或余额中看到到账。',
                        ],
                    },
                    '发行商开设官网充值，主要是为了提供应用商店可能没有的本地支付方式，并与付费玩家建立直接联系。各应用商店对 App 外购买有自己的规定，请阅读并遵守游戏上架的每个商店的现行规则。',
                ],
            },
            {
                id: 'methods-by-market',
                heading: '各市场玩家充值习惯用哪些支付方式？',
                blocks: [
                    '在很多新兴市场，玩家充值较少使用信用卡，而是用电子钱包、扫码或银行 App 充值。下表列出 KaazPay 支持、适合游戏充值的部分代收方式。',
                    {
                        table: {
                            head: ['市场', '支付方式', '一般确认时间'],
                            rows: [
                                ['美国', '[Apple Pay](/methods/apple-pay)、[Google Pay](/methods/google-pay)、Cash App', '付款即确认'],
                                ['全球', '[Visa](/methods/visa)、Mastercard、银联卡', '付款即确认'],
                                ['[日本](/payment-methods/japan)', '[JCB](/methods/jcb) 卡', '付款即确认'],
                                ['[墨西哥](/payment-methods/mexico)', '[SPEI](/methods/spei)、银行转账、现金支付', '实时（SPEI）/ 付款后确认'],
                                ['哥伦比亚', 'PSE、Bre-B（密钥或扫码）、Bancolombia、现金支付', '实时 / 付款后确认'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)、Boleto、银行转账、现金支付', '秒级（Pix）/ 付款后确认'],
                                ['[马来西亚](/payment-methods/malaysia)', "[DuitNow](/methods/duitnow)、Touch 'n Go、FPX", '实时'],
                                ['[菲律宾](/payment-methods/philippines)', '[GCash](/methods/gcash)', '实时'],
                                ['[印度尼西亚](/payment-methods/indonesia)', '[QRIS](/methods/qris)', '实时'],
                            ],
                        },
                    },
                    { note: '具体可用性取决于市场与业务类型，上线前由 KaazPay 客户经理确认。东南亚市场详见[东南亚支付方式指南](/guides/southeast-asia-payment-methods)。' },
                ],
            },
            {
                id: 'pack-size-and-method',
                heading: '礼包面额和支付方式怎么搭配？',
                blocks: [
                    '活动期间追加购买礼包的玩家希望立即到账；购买月度大礼包的玩家则更愿意等待。决定哪些礼包旁边显示哪些支付方式时，可以利用这一差别。',
                    {
                        table: {
                            head: ['购买类型', '适合的支付方式', '原因'],
                            rows: [
                                ['小额冲动消费', 'GCash、QRIS、DuitNow、Pix、SPEI、Bre-B、Apple Pay、Google Pay', '几下点击即可确认，到账快'],
                                ['中等面额礼包与通行证', '以上方式，加上 FPX、PSE、信用卡', '流程稍长也能接受'],
                                ['大额礼包、送礼', '以上方式，加上 Boleto、现金支付、银行转账', '玩家愿意等待付款确认'],
                            ],
                        },
                    },
                    '展示凭证或银行转账时，要明确告诉玩家：礼包在付款确认后到账，而不是立即到账。两类支付的区别见[实时支付 vs 银行转账](/compare/instant-payments-vs-bank-transfer)。',
                ],
            },
            {
                id: 'instant-crediting',
                heading: '付款后如何安全、即时地发放钻石和金币？',
                blocks: [
                    '一律由服务器发货，不依赖浏览器。玩家关掉支付页、网络中断或跳转变慢，都不应影响道具是否到账。付款确认后，KaazPay 会发送以您的密钥签名的实时通知。',
                    {
                        list: [
                            '**先验签**，再读取通知内容。',
                            '**核对金额与币种**，与创建的订单一致。',
                            '**每个订单号只发一次货**。通知可能重试，第二次不能重复发放。',
                            '**保存支付状态**，凭证类付款延后确认时也能自动发货。',
                            '**按约定返回确认响应**，避免通知被不必要地重发。',
                        ],
                    },
                    '[支付网关对接清单](/guides/payment-gateway-integration-checklist)逐项讲解了这些要点，接口文档见[开发者页面](/developers)。',
                ],
            },
            {
                id: 'support-playbook',
                heading: '玩家反映“付了钱没收到钻石”，怎么处理？',
                blocks: [
                    '这类工单是官网充值的主要客服成本之一，通常可分四种情况，都能通过自家日志和 KaazPay 后台查清：',
                    {
                        list: [
                            '**付款未完成**：订单已创建，但没有收到确认。请玩家查看钱包或银行 App 记录。',
                            '**已付款、待确认**：凭证和部分银行转账常见，告知玩家预计到账时间。',
                            '**已确认、未发货**：服务器拒收或漏收通知，按订单号重新执行发货。',
                            '**充值到错误账号**：玩家输错游戏 ID。付款前显示角色名即可预防。',
                        ],
                    },
                    '在日志、通知记录和后台中都能按订单号检索，处理每张工单只需查一次。',
                ],
            },
            {
                id: 'peaks-and-risk',
                heading: '开服和活动期间，如何保持充值稳定？',
                blocks: [
                    '新赛季、限定皮肤和节日活动都会带来流量高峰。在有多条通道的市场，KaazPay 会把每笔付款分配到当前表现最好的通道并自动切换，通道全天候监控。',
                    '商户自身也应设置合理的单账号限额，留意短时间内同一账号或设备的大量订单，并对 ID 查询接口做频率限制，防止被批量抓取。这些简单规则有助于拦截常见滥用，同时不影响正常玩家。',
                ],
            },
            {
                id: 'before-launch',
                heading: '官网充值上线前要检查什么？',
                blocks: [
                    {
                        list: [
                            '每个上线市场、每个礼包都有本币价格。',
                            '玩家 ID 查询并显示角色名确认。',
                            '每个市场至少一种实时支付方式，加上信用卡。',
                            '签名通知处理已测试重试和重复通知场景。',
                            '延后确认的支付方式有“处理中”页面。',
                            '客服可以按订单号和游戏 ID 查询订单。',
                            '已确认各通道结算周期，并准备好接收结算的 USDT 钱包。',
                        ],
                    },
                ],
            },
            {
                id: 'settlement',
                heading: '多个国家的充值收入怎么结算？',
                blocks: [
                    '玩家以雷亚尔、比索、林吉特、菲律宾比索和印尼盾付款，KaazPay 将代收资金按等值 USDT 结算给游戏公司，无需在各市场持有本地账户。不少通道 D+0 结算，其余 D+1 或更长，上线前按通道确认。详见 [USDT 结算说明](/guides/usdt-settlement)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何用 KaazPay 上线游戏官网充值？',
                blocks: [
                    'KaazPay 的本地支付通道服务销售游戏币和道具的[游戏发行商](/industries/gaming)。本文适用于非博彩类游戏，开户需经过业务审核。',
                    {
                        steps: [
                            '**开通商户账户**：提供游戏信息、上线市场和礼包结构。',
                            '**获取 API 密钥**：用测试游戏 ID 在测试环境联调。',
                            '**工程师协助对接**：完成下单、签名通知与幂等发货，见[开发者文档](/developers)。',
                            '**正式上线**：逐个市场确认通道后，向玩家开放充值页。',
                        ],
                    },
                    '告诉我们您的玩家分布在哪些国家。[通过 Telegram 联系我们](/contact)，一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '游戏官网充值页应该接哪些支付方式？', a: '各市场的日常支付方式，例如菲律宾 GCash、印尼 QRIS、马来西亚 DuitNow、巴西 Pix、墨西哥 SPEI，加上 Visa、Mastercard、银联卡，日本 JCB，以及美国的 Apple Pay 或 Google Pay。' },
            { q: '没有信用卡的玩家能在官网买钻石吗？', a: '可以。KaazPay 在众多市场支持电子钱包、扫码、实时银行支付和现金凭证，玩家无需信用卡即可充值。' },
            { q: '怎样避免礼包重复发放？', a: '只根据验签通过的服务器通知发货，并按订单号做幂等处理，重试的通知不会再次发放。' },
            { q: '可以在自己的官网卖游戏道具吗？', a: '各应用商店对 App 外购买有各自的规定，请查阅并遵守游戏上架的每个商店的现行规则。' },
            { q: 'KaazPay 怎么结算充值收入？', a: '按等值 USDT 结算。不少通道 D+0，其余 D+1 或更长，上线前按通道确认。' },
        ],
    },
};
