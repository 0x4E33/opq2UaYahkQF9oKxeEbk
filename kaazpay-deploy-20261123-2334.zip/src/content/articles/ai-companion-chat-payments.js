export default {
    slug: 'ai-companion-chat-payments',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['united-states', 'global-cards', 'japan', 'brazil', 'malaysia', 'philippines', 'indonesia', 'usdt'],
        methods: ['apple-pay', 'visa', 'mastercard', 'jcb', 'pix', 'gcash', 'qris'],
        industries: ['digital-goods', 'gaming'],
        articles: ['chargebacks-vs-local-payments', 'international-card-acquiring', 'ai-saas-tools-payments', 'usdt-settlement'],
    },
    en: {
        title: 'AI Companion App Payments: Credits and Memberships',
        description: 'How AI companion and character chat apps sell credits and memberships abroad on a web checkout with cards and local wallets, pass review and limit disputes.',
        h1: 'How can an AI companion or character chat app accept payments from users abroad?',
        summary: 'An AI companion or character chat app can collect from users abroad by running a web checkout that pairs Visa, Mastercard, UnionPay and JCB cards with the wallets, QR codes and instant bank payments of each market, and by crediting accounts only on confirmed payment. KaazPay offers these methods in one account after a business review and settles collected funds in USDT.',
        takeaways: [
            'Users pay when they hit a limit, so credit packs, quotas and memberships all need a checkout that completes in seconds.',
            'A web checkout with cards plus local methods such as Pix, GCash and QRIS reaches users a card-only setup leaves out.',
            'Expect a payment partner review of your product, content policy, moderation, age-gating and refund handling.',
            'Many disputes start with confusion: unclear pricing, an unfamiliar descriptor or credits that arrive late.',
            'KaazPay opens accounts after review and settles collected funds as the equivalent amount in USDT.',
        ],
        sections: [
            {
                id: 'what-users-buy',
                heading: 'What do AI companion app users pay for?',
                blocks: [
                    'AI companion and character chat products (sometimes nicknamed "AI tavern" apps by Chinese-speaking builders) sell longer and higher-quality conversations. Paid products usually fall into four categories:',
                    {
                        table: {
                            head: ['Product', 'How it is consumed', 'When users pay'],
                            rows: [
                                ['Credit or token pack', 'Drawn down by messages, voice replies, long memory or images', 'When the balance runs out mid-chat'],
                                ['Daily quota top-up', 'Extends a free daily allowance', 'When the free limit is reached'],
                                ['Membership tier', 'Higher limits, premium characters, faster replies', 'Weekly, monthly or yearly'],
                                ['Virtual gift', 'Sent to a character; may be shared with its creator', 'Impulse, small amounts'],
                            ],
                        },
                    },
                    'Money mostly flows from users to the app. If you share revenue with character creators, a payout flow is added on top.',
                ],
            },
            {
                id: 'web-vs-store',
                heading: 'Should an AI chat app sell through the app store or a web checkout?',
                blocks: [
                    'Many apps use both. App store billing is convenient inside the app but carries commissions on digital purchases and offers only the store\'s payment options. A web checkout, where store rules allow it, lets you show local methods and set your own price points.',
                    {
                        list: [
                            '**Store billing:** familiar for iOS and Android users, but limited method choice and a commission on each sale.',
                            '**Web checkout:** cards and local wallets, QR and instant bank payments, with your own pack sizes and promotions.',
                            '**Practical split:** keep store billing for users who prefer it, and link to the web checkout from your site, emails or account page where permitted.',
                        ],
                    },
                ],
            },
            {
                id: 'checkout-methods',
                heading: 'Which payment methods should the web checkout include?',
                blocks: [
                    'Combine international cards with the instant local methods of your largest markets. A selection of KaazPay pay-in channels:',
                    {
                        table: {
                            head: ['Market', 'Pay-in methods', 'Best used for'],
                            rows: [
                                ['[United States](/payment-methods/united-states)', '[Apple Pay](/methods/apple-pay), Google Pay, Cash App', 'Fast mobile top-ups'],
                                ['[Global cards](/payment-methods/global-cards)', '[Visa](/methods/visa), [Mastercard](/methods/mastercard), UnionPay', 'Memberships and larger packs'],
                                ['[Japan](/payment-methods/japan)', '[JCB](/methods/jcb)', 'Memberships and packs for Japanese users'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix), bank transfer, Boleto, cash payment', 'Credit packs, prepaid passes'],
                                ['[Malaysia](/payment-methods/malaysia)', 'DuitNow, FPX, Touch \'n Go', 'Credit packs, prepaid passes'],
                                ['[Philippines](/payment-methods/philippines)', '[GCash](/methods/gcash)', 'Small packs and gifts'],
                                ['[Indonesia](/payment-methods/indonesia)', '[QRIS](/methods/qris)', 'Small packs and gifts'],
                                ['[Global USDT](/payment-methods/usdt)', 'USDT', 'Users who prefer stablecoins'],
                            ],
                        },
                    },
                    { note: 'What is available depends on the channel and on your business model, and is confirmed with your account manager before go-live.' },
                    'For the card side in more depth, see [international card acquiring](/guides/international-card-acquiring).',
                ],
            },
            {
                id: 'credits-and-renewals',
                heading: 'How should credits and memberships be delivered and renewed?',
                blocks: [
                    {
                        steps: [
                            'Sell credits in fixed packs and memberships as clearly dated periods.',
                            'Create each order through the API with your own order ID and the user\'s account ID.',
                            'Apply credits or extend the membership only when the signed payment notification arrives.',
                            'Show the new balance or expiry date on screen immediately, so the user can see that the payment succeeded.',
                        ],
                    },
                    'Automatic renewal depends on the method and is confirmed with your account manager. Local push payments such as Pix, GCash and QRIS are approved by the user each time, so wallet-first markets usually get prepaid weekly or monthly passes with a reminder before expiry and a one-tap repurchase.',
                ],
            },
            {
                id: 'partner-review',
                heading: 'What will a payment partner review before onboarding?',
                blocks: [
                    'Companion and character chat apps sit in a newer digital category, so expect detailed questions. Prepare the following before you apply:',
                    {
                        list: [
                            'An honest product description: characters, user-generated characters, gifts and any creator revenue share.',
                            'Terms of service, a content policy and a description of how moderation works.',
                            'How age requirements are enforced, including age-gating at sign-up.',
                            'A refund policy and a support channel users can reach from inside the app.',
                            'Your target markets and expected volumes per market.',
                        ],
                    },
                    'Opening a KaazPay account is subject to this kind of business review. After go-live, continue to sell the product as described; accurate descriptions help keep the payment setup stable.',
                ],
            },
            {
                id: 'disputes',
                heading: 'How can an AI chat app keep disputes and chargebacks low?',
                blocks: [
                    'Many disputes on digital subscriptions stem from confusion rather than fraud. Common triggers and fixes:',
                    {
                        table: {
                            head: ['Trigger', 'Fix'],
                            rows: [
                                ['User does not recognise the charge', 'Use a statement descriptor and receipt that clearly name your app'],
                                ['Renewal came as a surprise', 'Show renewal terms before payment and send a reminder before each period'],
                                ['Credits seemed to be missing', 'Credit on the notification and show the new balance immediately'],
                                ['No easy way to get help', 'Offer an in-app refund request that is quicker than calling the bank'],
                            ],
                        },
                    },
                    'The payment mix matters too. Card payments follow card-scheme dispute rules, while local push payments are authorised by the user in their own wallet or banking app and handled under each method\'s own rules. The differences are explained in [chargebacks vs local payments](/compare/chargebacks-vs-local-payments).',
                ],
            },
            {
                id: 'settlement-and-creators',
                heading: 'How is revenue settled and how are creators paid?',
                blocks: [
                    'KaazPay settles collected funds as the equivalent amount in USDT. Many channels settle D+0, others D+1 or later, confirmed per channel before go-live; see [how USDT settlement works](/guides/usdt-settlement).',
                    'If you share revenue with character creators, payouts can go to PayPal, Cash App, Chime, cards or ACH in the United States, to bank accounts or mobile money in the payout markets, or in USDT. A related model is covered in [AI SaaS and tools payments](/guides/ai-saas-tools-payments), and an overview sits on our [digital goods page](/industries/digital-goods).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How to launch payments for an AI companion app with KaazPay',
                blocks: [
                    {
                        steps: [
                            '**Open a merchant account** and share your product, markets, content and age policies for review.',
                            '**Get API keys** from the merchant dashboard once approved.',
                            '**Integrate with engineer support**: orders, signed notifications and, if needed, creator payouts, following the [developer docs](/developers).',
                            '**Go live** with channels and settlement cycles confirmed per market.',
                        ],
                    },
                    'Talk to our business team on Telegram via the [contact page](/contact). We reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'Can users buy AI chat credits without a card?', a: 'Yes, where the channel is available for your business: KaazPay supports wallets, QR and instant payments such as Pix in Brazil, GCash in the Philippines and QRIS in Indonesia, alongside cards.' },
            { q: 'Why are card payments for AI companion apps sometimes declined?', a: 'Issuers can be cautious with newer digital categories. Adding local methods next to cards gives users another way to complete the purchase.' },
            { q: 'Can memberships renew automatically?', a: 'It depends on the method and is confirmed with your account manager. With local push payments, apps usually sell prepaid passes and remind users before expiry.' },
            { q: 'What does KaazPay need to review?', a: 'Your product description, content policy and moderation, age-gating, refund policy and target markets. Accounts are opened after this business review.' },
            { q: 'How is revenue from an AI chat app settled?', a: 'As the equivalent amount in USDT, on a settlement cycle confirmed per channel before go-live.' },
        ],
        queries: [
            'How do AI companion apps let users buy credits on the web with local wallets?',
            'Payment gateway for an AI character chat app with users in Brazil and Southeast Asia',
            'Our AI chat app card payments are often declined. What are the alternatives?',
            'What do payment providers check before onboarding an AI companion app?',
        ],
    },
    zh: {
        title: 'AI 陪伴 / 角色聊天 App 出海收款指南',
        description: 'AI 陪伴与角色聊天 App（俗称 AI 酒馆）出海收款：点数包与会员如何通过网页收银台接入国际卡和当地钱包，开户审核看什么，以及如何减少争议和拒付。',
        h1: 'AI 陪伴、角色聊天 App 如何向海外用户收款？',
        summary: 'AI 陪伴和角色聊天 App 可以用网页收银台，把 Visa、Mastercard、银联、JCB 卡与各市场的电子钱包、扫码、实时银行支付组合起来，并且只在付款确认后为账户加点数，从而向海外用户收款。KaazPay 经业务审核后在一个账户中提供这些方式，代收资金以 USDT 结算。',
        takeaways: [
            '用户往往在额度用完时付费，所以点数包、额度和会员都需要几秒内完成的收银台。',
            '网页收银台同时提供银行卡和 Pix、GCash、QRIS 等本地方式，能覆盖只接卡时漏掉的用户。',
            '支付合作方会审核产品、内容政策、审核机制、年龄限制和退款处理。',
            '许多争议源于误会：价格不清晰、账单名称陌生、点数延迟到账。',
            'KaazPay 审核后开户，代收资金按等值 USDT 结算。',
        ],
        sections: [
            {
                id: 'what-users-buy',
                heading: 'AI 陪伴 App 的用户为哪些内容付费？',
                blocks: [
                    'AI 陪伴和角色聊天产品（中文圈常叫“AI 酒馆”）销售的是更长、更优质的对话体验，收费项目大致分为四类：',
                    {
                        table: {
                            head: ['产品', '消耗方式', '用户何时付费'],
                            rows: [
                                ['点数 / Token 包', '按消息、语音回复、长记忆或生图扣减', '对话中余额不足时'],
                                ['每日额度加购', '在免费额度之外追加', '免费次数用完时'],
                                ['会员等级', '更高额度、高级角色、更快回复', '按周、按月或按年'],
                                ['虚拟礼物', '送给角色，可能与角色创作者分成', '冲动消费，金额小'],
                            ],
                        },
                    },
                    '资金主要从用户流向平台；如与角色创作者分成，则需另设代付流程。',
                ],
            },
            {
                id: 'web-vs-store',
                heading: '应用商店内购和网页收银台，该选哪个？',
                blocks: [
                    '很多 App 两者并用。商店内购在 App 里很方便，但数字商品要付佣金，支付方式也只有商店提供的几种；在商店规则允许的前提下，网页收银台可以展示本地支付方式，价格档位也由自己决定。',
                    {
                        list: [
                            '**商店内购**：iOS、Android 用户熟悉，但支付方式有限，每笔需支付佣金。',
                            '**网页收银台**：银行卡加本地钱包、扫码与实时银行支付，充值档位和促销由商户自行设定。',
                            '**常见搭配**：保留商店内购给偏好它的用户，在规则允许的地方，从官网、邮件或账户页引导到网页收银台。',
                        ],
                    },
                ],
            },
            {
                id: 'checkout-methods',
                heading: '网页收银台应该接哪些支付方式？',
                blocks: [
                    '建议将国际信用卡与主要市场的本地实时支付方式组合使用。以下为 KaazPay 部分代收通道：',
                    {
                        table: {
                            head: ['市场', '代收方式', '适合场景'],
                            rows: [
                                ['[美国](/payment-methods/united-states)', '[Apple Pay](/methods/apple-pay)、Google Pay、Cash App', '手机端快速充值'],
                                ['[全球信用卡](/payment-methods/global-cards)', '[Visa](/methods/visa)、[Mastercard](/methods/mastercard)、银联', '会员和较大点数包'],
                                ['[日本](/payment-methods/japan)', '[JCB](/methods/jcb)', '日本用户的会员与点数包'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)、银行转账、Boleto、现金支付', '点数包、预付会员'],
                                ['[马来西亚](/payment-methods/malaysia)', 'DuitNow、FPX、Touch \'n Go', '点数包、预付会员'],
                                ['[菲律宾](/payment-methods/philippines)', '[GCash](/methods/gcash)', '小额点数包和礼物'],
                                ['[印度尼西亚](/payment-methods/indonesia)', '[QRIS](/methods/qris)', '小额点数包和礼物'],
                                ['[全球 USDT](/payment-methods/usdt)', 'USDT', '偏好稳定币的用户'],
                            ],
                        },
                    },
                    { note: '具体可用范围取决于通道和您的业务模式，上线前由客户经理确认。' },
                    '银行卡收单的细节见[国际信用卡收单](/guides/international-card-acquiring)。',
                ],
            },
            {
                id: 'credits-and-renewals',
                heading: '点数和会员应如何发放与续费？',
                blocks: [
                    {
                        steps: [
                            '点数做成固定档位，会员做成有明确起止日期的周期。',
                            '每笔订单通过 API 创建，带上您自己的订单号和用户账户 ID。',
                            '收到签名支付通知后，才加点数或延长会员。',
                            '立即在页面上显示新余额或到期日，让用户确认付款已成功。',
                        ],
                    },
                    '能否自动续费取决于支付方式，由客户经理确认。Pix、GCash、QRIS 这类本地推式付款每次都要用户确认，因此钱包为主的市场一般采用预付周卡、月卡，到期前提醒，并支持一键续购。',
                ],
            },
            {
                id: 'partner-review',
                heading: '开户前，支付合作方会审核哪些内容？',
                blocks: [
                    'AI 陪伴和角色聊天属于较新的数字品类，审核时会被详细询问。申请前建议准备：',
                    {
                        list: [
                            '如实的产品说明：角色、用户自建角色、礼物以及是否与创作者分成。',
                            '服务条款、内容政策以及内容审核机制说明。',
                            '如何落实年龄限制，包括注册时的年龄验证。',
                            '退款政策，以及用户在 App 内就能找到的客服入口。',
                            '目标市场和各市场预计交易规模。',
                        ],
                    },
                    'KaazPay 开户需经过这类业务审核。上线后请继续销售与申请时描述一致的产品，描述准确，支付配置才会稳定。',
                ],
            },
            {
                id: 'disputes',
                heading: '怎样减少争议和拒付？',
                blocks: [
                    '数字订阅类的许多争议源于误会，而非欺诈。常见诱因与对策：',
                    {
                        table: {
                            head: ['诱因', '对策'],
                            rows: [
                                ['用户无法识别这笔扣款', '账单名称和收据清楚显示您的 App 名称'],
                                ['用户未预料到续费', '付款前说明续费规则，每期到期前提醒'],
                                ['点数似乎未到账', '以通知为准发放，并立即显示新余额'],
                                ['找不到求助渠道', '提供 App 内退款申请，比打电话给银行更方便'],
                            ],
                        },
                    },
                    '支付方式的组合也有影响：银行卡付款适用卡组织的争议规则，本地推式付款则由用户在自己的钱包或银行 App 中授权，按各方式自身规则处理。差别详见[信用卡拒付 vs 本地支付](/compare/chargebacks-vs-local-payments)。',
                ],
            },
            {
                id: 'settlement-and-creators',
                heading: '收入如何结算？创作者分成如何发放？',
                blocks: [
                    'KaazPay 将代收资金按等值 USDT 结算。不少通道 D+0，其余 D+1 或更长，上线前按通道确认，详见 [USDT 结算说明](/guides/usdt-settlement)。',
                    '如果与角色创作者分成，可在美国通过 PayPal、Cash App、Chime、银行卡或 ACH 代付，在代付市场代付到银行账户或移动钱包，也可用 USDT 出款。相近的业务模式可参考 [AI SaaS 与工具出海收款](/guides/ai-saas-tools-payments)，行业概览见[数字商品方案](/industries/digital-goods)。',
                ],
            },
            {
                id: 'get-started',
                heading: 'AI 陪伴 App 如何接入 KaazPay',
                blocks: [
                    {
                        steps: [
                            '**开通商户账户**，提交产品、目标市场、内容与年龄政策供审核。',
                            '**获取 API 密钥**，审核通过后在商户后台查看。',
                            '**工程师协助对接**下单、签名通知以及需要时的创作者代付，参考[开发者文档](/developers)。',
                            '**正式上线**，各市场通道与结算周期均已确认。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '没有信用卡的用户能买 AI 聊天点数吗？', a: '可以，前提是该通道对您的业务开放。KaazPay 除银行卡外，还支持巴西 Pix、菲律宾 GCash、印尼 QRIS 等钱包、扫码与实时支付。' },
            { q: '为什么 AI 陪伴 App 的银行卡付款有时被拒？', a: '发卡行对较新的数字品类可能比较谨慎。在银行卡之外提供本地支付方式，可为用户提供另一种完成付款的方式。' },
            { q: '会员可以自动续费吗？', a: '取决于支付方式，由客户经理确认。本地推式付款通常做成预付会员，并在到期前提醒用户。' },
            { q: 'KaazPay 开户要审核什么？', a: '产品说明、内容政策与审核机制、年龄限制、退款政策和目标市场，审核通过后开户。' },
            { q: 'AI 聊天 App 的收入如何结算？', a: '按等值 USDT 结算，结算周期在上线前按通道确认。' },
        ],
        queries: [
            'AI 酒馆类 App 出海，如何让用户在网页上用本地钱包购买点数？',
            'AI 角色聊天 App 用户在巴西和东南亚，应接入哪家支付通道？',
            '我们的 AI 陪伴 App 信用卡付款经常被拒，有什么替代方案？',
            'AI 陪伴 App 开户时，支付公司会审核哪些资料？',
        ],
    },
};
