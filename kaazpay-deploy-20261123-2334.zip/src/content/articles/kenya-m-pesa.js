export default {
    slug: 'kenya-m-pesa',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['kenya'],
        methods: ['m-pesa', 'mobile-money'],
        industries: ['gaming', 'live-streaming', 'e-commerce', 'digital-goods'],
        articles: ['africa-mobile-money', 'mobile-money-vs-bank-transfer-africa', 'mass-payouts-emerging-markets', 'usdt-settlement'],
    },
    en: {
        title: 'M-Pesa Payment Gateway for Kenya: Merchant Guide',
        description: 'Accept M-Pesa in Kenya: how the phone prompt flow works, why payments go unapproved, adding Kenyan cards, KES payouts to banks and wallets, USDT settlement.',
        h1: 'How to accept M-Pesa payments online in Kenya',
        summary: 'To accept M-Pesa online, a payment gateway sends a payment prompt to the customer’s phone for the order amount in KES, and the customer approves it on the handset with their M-Pesa PIN. KaazPay offers M-Pesa and Kenyan card pay-in, payouts to Kenyan bank accounts and mobile money wallets, and settles collections to you in USDT.',
        queries: [
            'How can a foreign online business accept M-Pesa from Kenyan customers?',
            'Our M-Pesa prompts often time out before customers approve. How do we reduce that?',
            'Do we need cards as well as M-Pesa for a Kenyan checkout?',
            'Can we send withdrawals to Kenyan users’ mobile money wallets through an API?',
            'Is there an M-Pesa gateway that settles in USDT instead of Kenyan shillings?',
        ],
        takeaways: [
            'M-Pesa, run by Safaricom, is the primary way many Kenyans pay and transfer money, so it should be the first option at a Kenyan checkout.',
            'The payment is approved on the customer’s phone, so your page collects a phone number, not card details.',
            'Most failed attempts are unapproved prompts: wrong number format, missed prompts and low balances. Design the waiting screen for them.',
            'KaazPay adds Kenyan cards for pay-in and supports payouts to bank accounts and mobile money wallets in Kenya.',
            'KES collections are settled to you in USDT; each channel’s cycle is confirmed before launch.',
        ],
        sections: [
            { id: 'why-m-pesa-first', heading: 'Why does a Kenyan checkout need M-Pesa first?', blocks: [
                '**M-Pesa** is Safaricom’s mobile money service, and in Kenya it is the default way to move money: paying shops, sending money to family, receiving wages. It is widely used by adults, many of whom rarely pay by card online.',
                'For an online business, this sets the starting point. If a Kenyan customer sees only a card form, many ready buyers may abandon the payment. With M-Pesa at the top, priced in Kenyan shillings (KES), the customer pays with a service they use routinely. More on the [M-Pesa method page](/methods/m-pesa).',
            ] },
            { id: 'm-pesa-prompt-flow', heading: 'What happens during an online M-Pesa payment, step by step?', blocks: [
                'Consider a viewer in Nairobi buying 1,000 KES of live-stream coins on your site. Through KaazPay the payment runs like this:',
                { steps: [
                    'The viewer selects M-Pesa and enters the Safaricom number linked to their wallet.',
                    'Your backend creates a pay-in order through the KaazPay API for 1,000 KES, with a unique order ID.',
                    'A payment prompt appears on the viewer’s phone showing the amount and the payee name.',
                    'The viewer enters their M-Pesa PIN on the handset to approve.',
                    'KaazPay sends your server a signed notification with the final status; you verify it and credit the coins.',
                ] },
                'Nothing sensitive passes through your page: the approval and the PIN stay on the customer’s own phone.',
            ] },
            { id: 'unapproved-prompts', heading: 'Why do M-Pesa payments go unapproved, and how do you recover them?', blocks: [
                'A push payment depends on the customer acting on their phone within a short window. When that does not happen, the order ends as failed or expired. The common causes are well known:',
                { table: { head: ['Cause', 'What happens', 'How to recover'], rows: [
                    ['Number typed in the wrong format', 'The prompt goes nowhere', 'Accept both 07… / 01… and 254… formats and normalise them before sending'],
                    ['Prompt missed or phone locked', 'The prompt times out', 'Tell the customer to watch their phone and offer a “send again” button'],
                    ['Not enough balance', 'The customer cannot approve', 'Show a clear failure message and let them retry after topping up, or switch to a card'],
                    ['Customer taps pay twice', 'Two prompts, risk of double charge', 'Disable the button while waiting and reuse the same order ID'],
                    ['Browser closed while waiting', 'Customer does not see the result', 'Rely on the server notification and show the status when they return'],
                ] } },
                'A clear waiting screen prevents most of these issues: the amount, the phone number used, a countdown and a retry option.',
            ] },
            { id: 'm-pesa-and-cards', heading: 'Where do Kenyan cards fit next to M-Pesa?', blocks: [
                'Cards are a useful secondary option rather than the primary method. Some Kenyan customers, especially those buying higher-value items from a laptop or paying with a company card, prefer to pay by card. KaazPay supports **Kenya Cards** for pay-in in the same integration, reported in the same dashboard.',
                { table: { head: ['', 'M-Pesa', 'Kenya Cards'], rows: [
                    ['How the customer pays', 'Approves a prompt on their phone with a PIN', 'Enters card details at checkout'],
                    ['What your page collects', 'Phone number', 'Card details through the payment page'],
                    ['Typical buyer', 'Mobile-first, everyday and small purchases', 'Card holders, desktop and larger orders'],
                    ['Role on KaazPay', 'Pay-in', 'Pay-in'],
                ] } },
                'Lead with M-Pesa, keep cards one tap away, and use your own data to decide whether to change that order.',
            ] },
            { id: 'kenya-payouts', heading: 'How do you send payouts in Kenya?', blocks: [
                'Kenya is a two-way market on KaazPay. From the same merchant account that collects M-Pesa and card payments, you can send KES payouts to:',
                { list: [
                    '**Mobile money wallets**, which suit individuals such as players cashing out, creators collecting earnings or customers receiving refunds.',
                    '**Kenyan bank accounts**, which suit suppliers, business partners and larger transfers.',
                ] },
                'Payouts run singly or in batches, and each payout returns its own status, so balances update without manual checks. Validate the recipient’s phone number or account details before submitting to prevent rejections. For running payouts at scale, see [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets); for choosing between wallet and bank payouts, see [mobile money vs bank transfer in Africa](/compare/mobile-money-vs-bank-transfer-africa).',
            ] },
            { id: 'kes-settlement', heading: 'How are Kenyan shilling collections settled?', blocks: [
                'Customers pay in KES, and KaazPay settles the equivalent amount to you in **USDT**. You do not need a Kenyan bank account to receive the money.',
                'Settlement timing is channel by channel: many KaazPay channels settle D+0, others D+1 or later, and your account manager confirms the cycle, rate and fees for each Kenyan channel before go-live. Read the [USDT settlement guide](/guides/usdt-settlement) for details.',
            ] },
            { id: 'kenya-launch-checklist', heading: 'What should you prepare before going live in Kenya?', blocks: [
                { list: [
                    'Phone number validation and normalisation for Kenyan numbers.',
                    'A waiting screen with countdown, retry and a fallback to cards.',
                    'Signature verification and idempotent order updates on every notification.',
                    'Recipient validation for wallet and bank payouts.',
                    'Settlement cycle, rates and fees for Kenya confirmed in writing.',
                ] },
                'For other African markets, the [Africa mobile money guide](/guides/africa-mobile-money) lists what is available country by country.',
            ] },
            { id: 'start-m-pesa-kaazpay', heading: 'How to start accepting M-Pesa with KaazPay', blocks: [
                { steps: [
                    'Open a merchant account and tell us about your product and expected Kenyan volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with engineering support using the [developer documentation](/developers), testing M-Pesa, cards and payouts.',
                    'Go live in Kenya and track results by method in one dashboard.',
                ] },
                'Every Kenyan channel is listed on the [Kenya market page](/payment-methods/kenya). For a channel plan, settlement terms and pricing, contact our business team on Telegram through the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Can international merchants accept M-Pesa through KaazPay?', a: 'Yes. KaazPay offers M-Pesa pay-in in Kenya through the same API used for its other markets. Customers pay in KES and you receive the equivalent in USDT.' },
            { q: 'What does the customer need to pay with M-Pesa?', a: 'A phone with an active M-Pesa wallet and enough balance. They approve the payment on the handset with their M-Pesa PIN; no card is needed.' },
            { q: 'Why did an M-Pesa payment fail when the customer says they saw nothing?', a: 'Common causes are a phone number entered in the wrong format or a prompt that timed out while the phone was locked. Validate the number and offer a resend.' },
            { q: 'Can I pay out to mobile money wallets in Kenya?', a: 'Yes. KaazPay supports Kenyan payouts to mobile money wallets and to bank accounts, as single or batch payouts with a status for each.' },
            { q: 'How quickly are Kenyan collections settled?', a: 'It depends on the channel. Many KaazPay channels settle D+0 and others D+1 or later; the cycle for Kenya is confirmed before go-live.' },
        ],
    },
    zh: {
        title: '肯尼亚 M-Pesa 代收指南：接入、代付与结算',
        description: '面向商户的肯尼亚 M-Pesa 线上收款指南：手机确认付款的完整流程、付款未确认的常见原因、搭配肯尼亚银行卡，以及 KES 银行与钱包代付和 USDT 结算。',
        h1: '如何在肯尼亚接入 M-Pesa 线上收款？',
        summary: '线上受理 M-Pesa 时，支付通道按订单的 KES 金额向顾客手机推送付款请求，顾客在手机上输入 M-Pesa PIN 确认。KaazPay 提供 M-Pesa 与肯尼亚银行卡代收，支持肯尼亚银行账户和移动钱包代付，代收资金以 USDT 结算给商户。',
        queries: [
            '海外线上业务如何收取肯尼亚用户的 M-Pesa 付款？',
            '我们的 M-Pesa 付款请求经常在用户确认前就超时，如何改善？',
            '肯尼亚收银台除了 M-Pesa，还需要接银行卡吗？',
            '能否通过 API 将提现款项代付到肯尼亚用户的移动钱包？',
            '是否有以 USDT 而非肯尼亚先令结算的 M-Pesa 通道？',
        ],
        takeaways: [
            'M-Pesa 由 Safaricom 运营，是许多肯尼亚人付款和转账的主要方式，在肯尼亚收银台应放在第一位。',
            '付款在顾客手机上确认，您的页面只需收集手机号，不涉及卡号。',
            '失败订单多数是请求未被确认：号码格式错误、未看到提示、余额不足，等待页面要针对这些情况设计。',
            'KaazPay 另提供肯尼亚银行卡代收，并支持肯尼亚银行账户和移动钱包代付。',
            'KES 代收以 USDT 结算，各通道周期在上线前确认。',
        ],
        sections: [
            { id: 'why-m-pesa-first', heading: '为什么肯尼亚收银台应优先展示 M-Pesa？', blocks: [
                '**M-Pesa** 是 Safaricom 的移动钱包服务，在肯尼亚是资金往来的默认方式：店内付款、给家人转账、领取工资都使用它。成年人普遍使用，其中许多人很少在网上用卡付款。',
                '这决定了线上收银台的设计起点。如果肯尼亚顾客只看到填卡页面，许多准备付款的顾客可能就此放弃。将以肯尼亚先令（KES）计价的 M-Pesa 放在首位，顾客即可使用日常惯用的方式付款。详见 [M-Pesa 支付方式页面](/methods/m-pesa)。',
            ] },
            { id: 'm-pesa-prompt-flow', heading: '一笔线上 M-Pesa 付款，具体经过哪些步骤？', blocks: [
                '以内罗毕一位观众在您的网站购买 1,000 KES 直播金币为例，经由 KaazPay 的流程如下：',
                { steps: [
                    '观众选择 M-Pesa，输入绑定钱包的 Safaricom 手机号。',
                    '您的后端通过 KaazPay API 创建一笔 1,000 KES 的代收订单，并带上唯一订单号。',
                    '观众手机上弹出付款提示，显示金额和收款方名称。',
                    '观众在手机上输入 M-Pesa PIN 确认。',
                    'KaazPay 向您的服务器推送带签名的最终状态通知，您验签后发放金币。',
                ] },
                '整个过程没有任何敏感信息经过您的页面，确认和 PIN 都留在顾客自己的手机上。',
            ] },
            { id: 'unapproved-prompts', heading: 'M-Pesa 付款为何未被确认？如何挽回？', blocks: [
                '推送式付款需要顾客在短时间内在手机上操作，未及时操作，订单就会失败或过期。常见原因如下：',
                { table: { head: ['原因', '结果', '挽回办法'], rows: [
                    ['手机号格式填错', '付款提示无法送达', '同时接受 07… / 01… 与 254… 格式，提交前统一转换'],
                    ['未看到提示或手机锁屏', '请求超时', '提醒顾客留意手机，并提供"重新发送"按钮'],
                    ['余额不足', '顾客无法确认', '给出清晰的失败提示，充值后可重试，或改用银行卡'],
                    ['顾客重复点击付款', '收到两个提示，有重复扣款风险', '等待期间禁用按钮，并沿用同一订单号'],
                    ['等待时关闭了浏览器', '顾客看不到结果', '以服务器通知为准，顾客回来时展示订单状态'],
                ] } },
                '清晰的等待页面可避免大部分问题：显示金额、所用手机号、倒计时和重试入口。',
            ] },
            { id: 'm-pesa-and-cards', heading: '肯尼亚银行卡与 M-Pesa 如何搭配？', blocks: [
                '银行卡更适合作为辅助选项，而非主要方式。部分肯尼亚顾客，尤其是在电脑上购买较贵商品或使用公司卡付款的顾客，更倾向于刷卡。KaazPay 在同一次对接中提供 **Kenya Cards**（肯尼亚银行卡）代收，数据汇总在同一个后台。',
                { table: { head: ['', 'M-Pesa', '肯尼亚银行卡'], rows: [
                    ['顾客如何付款', '在手机上用 PIN 确认付款提示', '在收银台输入卡信息'],
                    ['您的页面收集什么', '手机号', '通过支付页面收集卡信息'],
                    ['典型顾客', '手机为主，日常小额消费', '持卡人，电脑端、较大金额订单'],
                    ['在 KaazPay 的角色', '代收', '代收'],
                ] } },
                '将 M-Pesa 放在首位，银行卡一键可选，之后根据自身数据决定是否调整。',
            ] },
            { id: 'kenya-payouts', heading: '在肯尼亚如何代付？', blocks: [
                '在 KaazPay 上，肯尼亚同时支持代收与代付。通过代收 M-Pesa 和银行卡的同一商户账户，即可将 KES 代付至：',
                { list: [
                    '**移动钱包**：适合个人收款，如玩家提现、主播领取收益、顾客退款。',
                    '**肯尼亚银行账户**：适合供应商、商业伙伴和较大金额的转账。',
                ] },
                '代付支持单笔和批量，每笔都有独立状态回传，余额可以自动更新，无需人工核对。提交前先校验收款手机号或账户信息，可避免不必要的退回。大规模代付的做法见[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)；如何选择钱包或银行代付，见[非洲移动钱包与银行转账对比](/compare/mobile-money-vs-bank-transfer-africa)。',
            ] },
            { id: 'kes-settlement', heading: '肯尼亚先令代收如何结算？', blocks: [
                '顾客以 KES 付款，KaazPay 将等额 **USDT** 结算给您，您无需开设肯尼亚银行账户。',
                '结算周期按通道而定：KaazPay 许多通道为 D+0，其他通道为 D+1 或更长，肯尼亚各通道的周期、汇率与费率由客户经理在上线前确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'kenya-launch-checklist', heading: '在肯尼亚上线前要准备什么？', blocks: [
                { list: [
                    '针对肯尼亚手机号的校验与格式统一。',
                    '带倒计时、重试和改用银行卡入口的等待页面。',
                    '每条通知都验签，订单更新做幂等处理。',
                    '钱包代付与银行代付的收款信息校验。',
                    '书面确认肯尼亚的结算周期、汇率与费率。',
                ] },
                '如计划进入其他非洲市场，[非洲移动钱包指南](/guides/africa-mobile-money)按国家列出了可用的支付方式。',
            ] },
            { id: 'start-m-pesa-kaazpay', heading: '如何通过 KaazPay 开通 M-Pesa 代收', blocks: [
                { steps: [
                    '开设商户账户，介绍您的产品和肯尼亚预估交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，测试 M-Pesa、银行卡和代付。',
                    '在肯尼亚正式上线，在同一后台按支付方式查看数据。',
                ] },
                '肯尼亚全部通道见[肯尼亚市场页面](/payment-methods/kenya)。如需通道方案、结算条款与报价，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: '海外商户可以通过 KaazPay 收取 M-Pesa 付款吗？', a: '可以。KaazPay 用与其他市场相同的 API 提供肯尼亚 M-Pesa 代收，顾客以 KES 付款，您收到等额 USDT。' },
            { q: '顾客用 M-Pesa 付款需要什么？', a: '一部开通了 M-Pesa 钱包且余额足够的手机。顾客在手机上输入 M-Pesa PIN 确认即可，不需要银行卡。' },
            { q: '顾客表示未收到任何提示，M-Pesa 付款却失败了，原因是什么？', a: '常见原因是手机号格式填错，或手机锁屏导致请求超时。请校验号码并提供重新发送功能。' },
            { q: '在肯尼亚可以代付到移动钱包吗？', a: '可以。KaazPay 支持肯尼亚移动钱包代付和银行账户代付，单笔、批量均可，每笔都有状态回传。' },
            { q: '肯尼亚代收资金多久结算？', a: '视通道而定。KaazPay 许多通道为 D+0，其他通道为 D+1 或更长，肯尼亚的结算周期在上线前确认。' },
        ],
    },
};
