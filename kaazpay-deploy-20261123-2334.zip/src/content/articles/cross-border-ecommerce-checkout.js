export default {
    slug: 'cross-border-ecommerce-checkout',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['united-states', 'global-cards', 'mexico', 'colombia', 'brazil', 'malaysia', 'philippines', 'indonesia', 'kenya'],
        methods: ['apple-pay', 'spei', 'pse', 'pix', 'boleto', 'fpx', 'gcash', 'qris', 'm-pesa'],
        industries: ['e-commerce', 'travel', 'digital-goods'],
        articles: ['local-payment-methods-vs-cards', 'dtc-independent-store-payments', 'pix-vs-boleto', 'usdt-settlement'],
    },
    en: {
        title: 'Cross-Border Checkout: Local Payment Methods by Market',
        description: 'Design a cross-border ecommerce checkout that converts: which local payment method to lead with in each market, currency display, common failures and refunds.',
        h1: 'What payment methods should a cross-border ecommerce checkout offer?',
        summary: "A cross-border checkout should show each shopper their own country's leading payment method first, prices in their currency, and a card option as backup: SPEI in Mexico, PSE in Colombia, Pix in Brazil, FPX in Malaysia, GCash in the Philippines, QRIS in Indonesia, M-Pesa in Kenya. KaazPay connects these local methods and international cards through one integration and settles collected funds in USDT.",
        queries: [
            'We sell online to customers in 10 countries but only accept cards and PayPal. Which local payment methods should our checkout show in each country?',
            'Should my cross-border store show prices in local currency or in USD?',
            'Why do so many Brazilian customers pick Boleto and then never pay?',
            'How do I offer a localized checkout without integrating a different payment provider in every market?',
            'What is the best way to handle refunds when customers paid with local bank transfers?',
        ],
        takeaways: [
            'Lead with the method locals use most, then a backup; three to four options per country is usually enough.',
            'Show prices and totals in local currency where the method charges in local currency, so there is no surprise at the payment step.',
            'Most failed local payments come from expired references, wrong amounts or shoppers leaving the bank app, and each has a fix.',
            'Refunds on push payments are new transfers back to the shopper; check payout coverage per market before launch.',
            'KaazPay runs local pay-in and card acquiring from one account and settles in USDT, with cycles confirmed per channel.',
        ],
        sections: [
            {
                id: 'anatomy-of-a-local-checkout',
                heading: 'What makes a cross-border checkout feel local?',
                blocks: [
                    'Shoppers quickly judge whether a foreign store is safe to pay, based on signals they recognise. A localized checkout has five parts:',
                    {
                        list: [
                            '**The right method on top:** the logo of the payment people in that country use every day.',
                            '**Local currency:** the total in pesos, reais or ringgit, matching what will leave their account.',
                            '**Plain instructions:** what happens after they click, for example "you will be sent to your bank app" or "scan this QR code".',
                            '**A clear wait time:** for vouchers and bank transfers, how long they have to pay and when the order ships.',
                            '**A backup option:** cards or another method, in case the first choice fails.',
                        ],
                    },
                    'A missing element causes hesitation. The payment method matters most and is covered in the next section.',
                ],
            },
            {
                id: 'lead-and-backup-by-market',
                heading: 'Which payment method should lead the checkout in each market?',
                blocks: [
                    'The table shows a lead method and a backup for markets where KaazPay offers pay-in. It is a practical starting point, not the full method list.',
                    {
                        table: {
                            head: ['Market', 'Lead with', 'Add as backup', 'How it confirms'],
                            rows: [
                                ['United States', 'Apple Pay, Google Pay', 'Cash App', 'At checkout'],
                                ['Worldwide', 'Visa, Mastercard', 'UnionPay', 'At checkout'],
                                ['[Mexico](/payment-methods/mexico)', '[SPEI](/methods/spei)', 'Bank transfer, cash payment', 'Instant / when paid'],
                                ['[Colombia](/payment-methods/colombia)', '[PSE](/methods/pse)', 'Bre-B, Bancolombia, cash payment', 'Instant / when paid'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix)', '[Boleto](/methods/boleto), bank transfer', 'Seconds / when voucher is paid'],
                                ['Malaysia', '[FPX](/methods/fpx)', "DuitNow, Touch 'n Go", 'Instant'],
                                ['Philippines', '[GCash](/methods/gcash)', 'Cards', 'Instant'],
                                ['Indonesia', '[QRIS](/methods/qris)', 'Cards', 'Instant'],
                                ['Kenya', '[M-Pesa](/methods/m-pesa)', 'Kenya cards', 'Instant'],
                            ],
                        },
                    },
                    { note: 'Channel availability depends on market and business type and is confirmed with KaazPay before go-live. The full list is in the [payment methods directory](/methods).' },
                    'Detect the country from the shipping address rather than only the IP address: travellers and VPN users would otherwise see the wrong methods. For a deeper look at why local methods outperform cards in many of these markets, read [local payment methods vs cards](/compare/local-payment-methods-vs-cards).',
                ],
            },
            {
                id: 'currency-display',
                heading: 'Should a cross-border store show prices in local currency?',
                blocks: [
                    'In most cases, yes. A shopper paying with Pix or SPEI pays in reais or pesos from their own account. If your product page says USD 49 and the bank app then asks for an unfamiliar local amount, many shoppers stop to check, and some abandon the purchase.',
                    'Show the local currency from the product page onwards, round to amounts that look natural in that currency, and make sure the amount you send to the payment API matches the amount shown. A mismatch of a few cents is one of the most common reasons a bank transfer cannot be matched to an order.',
                ],
            },
            {
                id: 'unbanked-shoppers',
                heading: 'How can a store sell to shoppers without a bank card?',
                blocks: [
                    'In parts of Latin America, many shoppers pay for online orders in cash. Voucher methods let them do it: the shopper receives a reference or barcode and pays it at a store, agent or bank.',
                    'KaazPay supports Boleto and cash payment in Brazil, cash payment in Mexico, Colombia, Chile, Ecuador, Guatemala, El Salvador and Costa Rica, PagoEfectivo in Peru, and Fawry Pay in Egypt. Mobile money in Kenya and other African markets serves a similar group of shoppers who have a phone wallet but no card. The trade-offs of vouchers versus instant payments are covered in [Pix vs Boleto](/compare/pix-vs-boleto).',
                ],
            },
            {
                id: 'failures-and-fixes',
                heading: 'Why do local payments fail at checkout, and how do you fix it?',
                blocks: [
                    'When local payment conversion is low, the cause is usually one of these:',
                    {
                        table: {
                            head: ['What goes wrong', 'Typical cause', 'Fix'],
                            rows: [
                                ['Voucher never paid', 'Shopper forgot or the reference expired', 'Show the expiry clearly and send one reminder before it'],
                                ['Shopper does not return after the bank app', 'No instructions about switching apps', 'Tell the shopper they can close the bank app; credit the order from the server notification'],
                                ['Order paid but still "pending"', 'Store relies on the browser redirect', 'Update the order only from the signed server notification'],
                                ['Amount mismatch', 'Currency conversion done twice or rounding', 'Calculate the local amount once and pass exactly that amount to the API'],
                                ['Wrong methods shown', 'Country detected by IP only', 'Use the shipping or billing country'],
                            ],
                        },
                    },
                    'Fixing these often lifts conversion more than adding another method. Check them before you expand to new markets.',
                ],
            },
            {
                id: 'refunds',
                heading: 'How do refunds work when customers paid with local methods?',
                blocks: [
                    'A card refund reverses the original charge. Local push payments work differently: a refund is normally a new transfer from you to the shopper. That means you need the shopper\'s account or wallet details, and a payout route in their country.',
                    'KaazPay supports payouts that can be used for refunds in the United States (PayPal, Cash App, Chime, cards, ACH), by bank transfer in markets such as Mexico, Colombia, Brazil, Malaysia and the Philippines, by bank transfer or mobile money in Indonesia and several African markets, and in USDT. Some markets, including Peru, Chile and Japan, are pay-in only, so decide on a refund policy for them before you open sales there.',
                ],
            },
            {
                id: 'reconcile-and-settle',
                heading: 'How do you reconcile and settle sales from many countries?',
                blocks: [
                    'Each order should carry your own order ID through the payment request, the notification and the settlement report. With one KaazPay account, all markets, methods, refunds and payouts sit in one dashboard, so reconciliation becomes one export instead of one per provider.',
                    'Collected funds are settled as the equivalent amount in USDT, which removes the need for local bank accounts. Many channels settle D+0, others D+1 or later, confirmed per channel. See [USDT settlement explained](/guides/usdt-settlement), and if you run a brand store, the [DTC independent store payments guide](/guides/dtc-independent-store-payments).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you launch a localized checkout with KaazPay?',
                blocks: [
                    'One integration gives your checkout local methods across the Americas, Asia Pacific and Africa, plus Visa, Mastercard and UnionPay card acquiring and JCB in Japan. Smart routing with automatic failover is used where a market has more than one channel.',
                    {
                        steps: [
                            '**Open a merchant account:** tell us your products and the countries you ship to.',
                            '**Get your API keys:** test in the sandbox with your own order IDs.',
                            '**Integrate with engineer support:** add order creation, signed notifications and refunds; the [developer docs](/developers) cover each call.',
                            '**Go live:** channels are confirmed market by market and switched on in your checkout.',
                        ],
                    },
                    'Send us your market list on Telegram via the [contact page](/contact). We reply within one business day with a suggested method mix for each country.',
                ],
            },
        ],
        faq: [
            { q: 'How many payment methods should a cross-border checkout show per country?', a: 'Usually three or four: the leading local method, one backup local method, and cards. More options rarely help and can slow the shopper down.' },
            { q: 'Which local method should I show first in Latin America?', a: 'SPEI in Mexico, PSE in Colombia and Pix in Brazil are common first choices. Add a voucher or cash option for shoppers without a bank account.' },
            { q: 'Do I need to show local currency at checkout?', a: 'It is strongly recommended when the shopper pays in local currency, so the amount in their bank or wallet app matches what they saw in your store.' },
            { q: 'Can I refund customers who paid by local bank transfer?', a: 'Yes, usually as a payout back to the shopper. KaazPay supports payouts in its payout markets and in USDT; pay-in-only markets such as Peru, Chile and Japan need a separate refund plan.' },
            { q: 'Do I need a bank account in every country I sell to?', a: 'No. KaazPay settles collected funds as the equivalent amount in USDT from one merchant account.' },
        ],
    },
    zh: {
        title: '跨境电商结账页：各市场本地支付方式配置',
        description: '跨境电商结账页如何提升转化：各市场首推哪种本地支付、是否显示本币、常见付款失败原因与解决办法，以及退款方式。',
        h1: '跨境电商结账页应该提供哪些支付方式？',
        summary: '跨境电商结账页应把消费者所在国最常用的支付方式放在第一位，用本币显示价格，再以信用卡作为备选：墨西哥 SPEI、哥伦比亚 PSE、巴西 Pix、马来西亚 FPX、菲律宾 GCash、印尼 QRIS、肯尼亚 M-Pesa。KaazPay 通过一次对接提供这些本地支付和国际信用卡收单，并以 USDT 结算。',
        queries: [
            '我们向 10 个国家的客户在线销售，目前只收信用卡和 PayPal，每个国家的结账页应显示哪些本地支付方式？',
            '跨境独立站要不要用当地货币标价，还是统一用美元？',
            '巴西客户为什么经常选了 Boleto 却一直不付款？',
            '如何在不逐个市场对接支付服务商的情况下，实现本地化结账？',
            '客户以本地银行转账付款时，如何处理退款？',
        ],
        takeaways: [
            '首推当地最常用的支付方式，再提供一个备选，每个国家三到四个选项通常已足够。',
            '付款以本币扣款时，价格和总额也用本币显示，避免到付款环节才出现“意外金额”。',
            '本地支付失败多半源于付款码过期、金额不符或消费者跳出银行 App，每一种都有对应的解决办法。',
            '推式付款的退款是另发一笔转账给消费者，上线前要按市场确认代付覆盖。',
            'KaazPay 在同一账户中提供本地代收与信用卡收单，以 USDT 结算，周期按通道确认。',
        ],
        sections: [
            {
                id: 'anatomy-of-a-local-checkout',
                heading: '什么样的跨境结账页能让消费者感到熟悉？',
                blocks: [
                    '消费者面对外国网店时，会很快根据自己熟悉的信号判断能否放心付款。本地化结账页包括五个要素：',
                    {
                        list: [
                            '**首位放置正确的支付方式**：当地人日常使用的支付方式标识。',
                            '**本币金额**：以比索、雷亚尔或林吉特显示总额，与账户实际扣款一致。',
                            '**简单的说明**：点击后会发生什么，例如“将跳转到您的银行 App”或“请扫描二维码”。',
                            '**明确的等待时间**：凭证和银行转账要写明付款期限和发货时间。',
                            '**备选方式**：信用卡或另一种本地支付，以防首选方式失败。',
                        ],
                    },
                    '缺少任何一项都可能让消费者犹豫。其中支付方式最为关键，下一节将具体说明。',
                ],
            },
            {
                id: 'lead-and-backup-by-market',
                heading: '各市场结账页应首推哪种支付方式？',
                blocks: [
                    '下表列出 KaazPay 支持代收的部分市场的首推方式与备选方式，可作为起步参考，并非完整清单。',
                    {
                        table: {
                            head: ['市场', '首推', '备选', '确认方式'],
                            rows: [
                                ['美国', 'Apple Pay、Google Pay', 'Cash App', '结账时确认'],
                                ['全球', 'Visa、Mastercard', '银联', '结账时确认'],
                                ['[墨西哥](/payment-methods/mexico)', '[SPEI](/methods/spei)', '银行转账、现金支付', '实时 / 付款后确认'],
                                ['[哥伦比亚](/payment-methods/colombia)', '[PSE](/methods/pse)', 'Bre-B、Bancolombia、现金支付', '实时 / 付款后确认'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)', '[Boleto](/methods/boleto)、银行转账', '秒级 / 凭证付款后确认'],
                                ['马来西亚', '[FPX](/methods/fpx)', "DuitNow、Touch 'n Go", '实时'],
                                ['菲律宾', '[GCash](/methods/gcash)', '信用卡', '实时'],
                                ['印度尼西亚', '[QRIS](/methods/qris)', '信用卡', '实时'],
                                ['肯尼亚', '[M-Pesa](/methods/m-pesa)', '肯尼亚银行卡', '实时'],
                            ],
                        },
                    },
                    { note: '通道可用性取决于市场与业务类型，上线前由 KaazPay 确认。完整清单见[支付方式目录](/methods)。' },
                    '建议按收货地址而不仅是 IP 判断国家，否则出差旅客和使用 VPN 的消费者会看到错误的支付方式。为什么这些市场的本地支付往往比信用卡转化更好，可阅读[本地支付 vs 信用卡](/compare/local-payment-methods-vs-cards)。',
                ],
            },
            {
                id: 'currency-display',
                heading: '跨境网店是否应以当地货币标价？',
                blocks: [
                    '大多数情况下应该。用 Pix 或 SPEI 付款的消费者，是从自己的账户支付雷亚尔或比索。如果商品页写着 49 美元，到了银行 App 却出现一个陌生的本币金额，很多人会停下来核对，部分人会就此放弃购买。',
                    '从商品页开始就显示本币，把价格取整成当地看起来自然的数字，并确保传给支付 API 的金额与页面显示一致。金额相差几分，就是银行转账无法匹配订单最常见的原因之一。',
                ],
            },
            {
                id: 'unbanked-shoppers',
                heading: '如何向没有银行卡的消费者销售？',
                blocks: [
                    '在拉美部分地区，不少消费者习惯用现金支付网购订单。凭证类支付可满足这一需求：消费者拿到付款码或条形码，到便利店、代理点或银行付款即可。',
                    'KaazPay 支持巴西 Boleto 和现金支付，墨西哥、哥伦比亚、智利、厄瓜多尔、危地马拉、萨尔瓦多、哥斯达黎加的现金支付，秘鲁 PagoEfectivo，以及埃及 Fawry Pay。肯尼亚等非洲市场的移动钱包则覆盖了“有手机钱包、没有银行卡”的人群。凭证与实时支付的取舍见 [Pix vs Boleto](/compare/pix-vs-boleto)。',
                ],
            },
            {
                id: 'failures-and-fixes',
                heading: '本地支付为什么会在结账环节失败？如何解决？',
                blocks: [
                    '本地支付转化偏低时，原因通常是以下几种：',
                    {
                        table: {
                            head: ['问题', '常见原因', '解决办法'],
                            rows: [
                                ['凭证一直未付', '消费者忘记付款，或付款码已过期', '醒目显示有效期，到期前提醒一次'],
                                ['跳转银行 App 后未返回', '没有说明需要切换 App', '告知消费者可直接关闭银行 App，订单以服务器通知为准入账'],
                                ['已付款但订单仍显示待支付', '依赖浏览器跳转判断', '只以验签通过的服务器通知更新订单状态'],
                                ['金额不符', '重复换汇或四舍五入', '本币金额只计算一次，原样传给 API'],
                                ['显示的支付方式不对', '只按 IP 判断国家', '改用收货或账单国家'],
                            ],
                        },
                    },
                    '解决这些问题带来的转化提升，往往比再加一种支付方式更明显。拓展新市场前，建议先逐项检查。',
                ],
            },
            {
                id: 'refunds',
                heading: '消费者用本地支付付款，如何退款？',
                blocks: [
                    '信用卡退款是把原交易冲回。本地推式付款不同，退款通常是商户另发一笔转账给消费者，因此需要消费者的账户或钱包信息，以及该国的代付通道。',
                    'KaazPay 的代付可用于退款：美国支持 PayPal、Cash App、Chime、银行卡和 ACH；墨西哥、哥伦比亚、巴西、马来西亚、菲律宾等市场支持银行转账；印尼和多个非洲市场支持银行转账或移动钱包；也支持 USDT。秘鲁、智利、日本等市场仅支持代收，开始销售前请先确定这些市场的退款政策。',
                ],
            },
            {
                id: 'reconcile-and-settle',
                heading: '多个国家的销售额如何对账和结算？',
                blocks: [
                    '每笔订单都应把自己的订单号贯穿支付请求、异步通知和结算报表。使用一个 KaazPay 账户，所有市场、支付方式、退款与代付都在同一后台，对账只需一次导出，而不是每家服务商各导一次。',
                    '代收资金按等值 USDT 结算，无需开设当地银行账户。不少通道 D+0 结算，其余 D+1 或更长，按通道确认。详见 [USDT 结算说明](/guides/usdt-settlement)；如果您经营品牌独立站，也可参考 [DTC 独立站收款指南](/guides/dtc-independent-store-payments)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何用 KaazPay 上线本地化结账页？',
                blocks: [
                    '一次对接，即可在结账页提供美洲、亚太和非洲的本地支付，以及 Visa、Mastercard、银联信用卡收单和日本 JCB。在有多条通道的市场，智能路由会自动切换。',
                    {
                        steps: [
                            '**开通商户账户**：告诉我们您的商品和发货国家。',
                            '**获取 API 密钥**：在测试环境中用自己的订单号联调。',
                            '**工程师协助对接**：完成下单、签名通知和退款，每个接口见[开发者文档](/developers)。',
                            '**正式上线**：逐个市场确认通道，并在结账页开启。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 上发来您的市场清单，我们会在一个工作日内回复，给出各国的支付方式组合建议。',
                ],
            },
        ],
        faq: [
            { q: '跨境结账页每个国家放几种支付方式合适？', a: '一般三到四种：当地首选的本地支付、一种备选本地支付，再加信用卡。选项过多通常无益，还可能拖慢付款。' },
            { q: '拉美市场结账页先放哪种本地支付？', a: '墨西哥 SPEI、哥伦比亚 PSE、巴西 Pix 都是常见首选，再为没有银行账户的消费者补充凭证或现金支付。' },
            { q: '结账页一定要显示本币吗？', a: '消费者以本币付款时，强烈建议显示本币，确保银行或钱包 App 里的金额与网店显示一致。' },
            { q: '消费者用本地银行转账付款，可以退款吗？', a: '可以，通常以代付方式退回。KaazPay 在支持代付的市场及通过 USDT 提供退款代付；秘鲁、智利、日本等仅代收市场需另行规划退款。' },
            { q: '每个销售国家都要开银行账户吗？', a: '不需要。KaazPay 通过一个商户账户，将代收资金按等值 USDT 结算。' },
        ],
    },
};
