export default {
    slug: 'west-central-africa-mobile-money',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['cote-d-ivoire', 'senegal', 'cameroon', 'benin', 'guinea', 'burkina-faso', 'mali', 'gabon'],
        methods: ['mobile-money'],
        industries: ['gaming', 'live-streaming', 'digital-goods', 'e-commerce'],
        articles: ['africa-mobile-money', 'mobile-money-vs-bank-transfer-africa', 'mass-payouts-emerging-markets', 'usdt-settlement'],
    },
    en: {
        title: 'Mobile Money in West & Central Africa (XOF, XAF)',
        description: 'Collect mobile money in Côte d’Ivoire, Senegal, Cameroon and five more markets: XOF, XAF and GNF explained, a multi-country checkout, payouts, USDT settlement.',
        h1: 'How to accept mobile money in West and Central Africa',
        summary: 'In Francophone West and Central Africa most online buyers pay from a mobile money wallet, approving on their phone, so checkouts should lead with mobile money and offer local cards as a backup. KaazPay covers Côte d’Ivoire, Senegal, Benin, Burkina Faso, Mali (XOF), Cameroon, Gabon (XAF) and Guinea (GNF) through one API, with payouts in five of the eight markets and USDT settlement.',
        queries: [
            'How do I accept mobile money payments in Côte d’Ivoire and Senegal from a website?',
            'Is there one payment API for all CFA franc countries?',
            'What is the difference between XOF and XAF for online payments?',
            'Can we send mobile money payouts to players in Cameroon and Guinea?',
            'Which West African countries support payouts and which are pay-in only?',
        ],
        takeaways: [
            'Mobile money is the main online payment habit across the eight Francophone markets KaazPay covers; cards are the backup.',
            'XOF (West African CFA franc) and XAF (Central African CFA franc) are separate currencies; Guinea uses its own franc, GNF.',
            'Seven of the eight markets support mobile money pay-in; Gabon is local cards only.',
            'Payouts: bank and mobile money in Côte d’Ivoire, Senegal and Cameroon; mobile money in Benin and Guinea; pay-in only in Burkina Faso, Mali and Gabon.',
            'Collections in XOF, XAF and GNF are settled to you in USDT.',
        ],
        sections: [
            { id: 'why-lead-with-wallets', heading: 'Why lead with mobile money in Francophone West and Central Africa?', blocks: [
                'From Abidjan to Douala, a phone wallet is how most people pay bills, send money home and buy airtime. Paying online works the same way: the customer enters their number, receives a request on their phone and approves it. Many of these customers have never paid by card online.',
                'A checkout that opens with a card form therefore loses buyers at the first step. Put **mobile money** first and keep **local cards** visible for those who prefer them, so the checkout matches how the region already pays. More on the [mobile money method page](/methods/mobile-money).',
            ] },
            { id: 'xof-xaf-gnf', heading: 'XOF, XAF or GNF: which currency does each order use?', blocks: [
                'Two of the region’s currencies share the name “CFA franc”, which causes confusion in integrations. They are different currencies issued by different central banks, and an order created in one cannot be paid in the other.',
                { table: { head: ['Currency', 'Name', 'KaazPay markets'], rows: [
                    ['XOF', 'West African CFA franc', 'Côte d’Ivoire, Senegal, Benin, Burkina Faso, Mali'],
                    ['XAF', 'Central African CFA franc', 'Cameroon, Gabon'],
                    ['GNF', 'Guinean franc', 'Guinea'],
                ] } },
                'The rule for developers: derive the currency from the customer’s country, not from a single “CFA” setting, and create the KaazPay order in that currency.',
            ] },
            { id: 'country-matrix', heading: 'What can you collect and pay out in each market?', blocks: [
                { table: { head: ['Market', 'Currency', 'Pay-in', 'Payouts'], rows: [
                    ['Côte d’Ivoire', 'XOF', 'Mobile money, local cards', 'Bank transfer, mobile money'],
                    ['Senegal', 'XOF', 'Mobile money, local cards', 'Bank transfer, mobile money'],
                    ['Cameroon', 'XAF', 'Mobile money, local cards', 'Bank transfer, mobile money'],
                    ['Benin', 'XOF', 'Mobile money, local cards', 'Mobile money'],
                    ['Guinea', 'GNF', 'Mobile money, local cards', 'Mobile money'],
                    ['Burkina Faso', 'XOF', 'Mobile money, local cards', 'Pay-in only'],
                    ['Mali', 'XOF', 'Mobile money, local cards', 'Pay-in only'],
                    ['Gabon', 'XAF', 'Local cards', 'Pay-in only'],
                ] } },
                { note: 'Channel lists change as new rails launch. See the [Côte d’Ivoire](/payment-methods/cote-d-ivoire), [Senegal](/payment-methods/senegal) and [Cameroon](/payment-methods/cameroon) market pages for current detail.' },
            ] },
            { id: 'multi-country-example', heading: 'Worked example: one checkout serving Abidjan, Dakar and Douala', blocks: [
                'Consider a mobile game with players in Côte d’Ivoire, Senegal and Cameroon. With KaazPay, one checkout serves all three, with the details set by country:',
                { steps: [
                    'Detect or ask for the player’s country. Côte d’Ivoire and Senegal map to XOF; Cameroon maps to XAF.',
                    'Show prices in that currency and list mobile money first, local cards second.',
                    'The player enters their mobile number; your backend creates a KaazPay pay-in order in the right currency with a unique order ID.',
                    'The player approves the request on their phone.',
                    'KaazPay sends a signed notification; you verify it and credit the in-game items.',
                    'When a player later cashes out, you send a mobile money payout in the same currency from the same account.',
                ] },
                'The API calls, notification format and dashboard are identical in all three countries. Only the currency and the method list change.',
            ] },
            { id: 'local-checkout-details', heading: 'What checkout details matter for customers in the region?', blocks: [
                { list: [
                    '**French first:** write button labels, instructions and error messages in French; it is the common business language across all eight markets.',
                    '**Phone numbers with country codes:** accept numbers with or without the international prefix (for example +225, +221 or +237) and normalise them before sending.',
                    '**Whole-number prices:** CFA franc and Guinean franc amounts are normally shown without decimals; display them that way.',
                    '**A clear waiting screen:** tell the customer to check their phone, show a countdown and allow a resend.',
                    '**Server-side truth:** keep unapproved orders pending and decide the outcome from the signed notification only.',
                ] },
            ] },
            { id: 'regional-payouts', heading: 'Where can you send payouts in West and Central Africa?', blocks: [
                'Five of the eight markets support payouts from the same merchant account as your collections:',
                { list: [
                    '**Côte d’Ivoire, Senegal and Cameroon:** payouts to bank accounts and to mobile money wallets.',
                    '**Benin and Guinea:** payouts to mobile money wallets.',
                    '**Burkina Faso, Mali and Gabon:** pay-in only for now.',
                ] },
                'Payouts run singly or in batches with a status notification for each, which suits player withdrawals, creator earnings and partner commission. For the trade-offs between wallet and bank payouts, read [mobile money vs bank transfer in Africa](/compare/mobile-money-vs-bank-transfer-africa); for batch operations, see [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
            ] },
            { id: 'cfa-settlement', heading: 'How are XOF, XAF and GNF collections settled?', blocks: [
                'Whatever currency the customer pays in, KaazPay settles the equivalent amount to you in **USDT**. You do not need CFA franc or Guinean franc accounts, and you avoid managing three separate local balances.',
                'Many KaazPay channels settle D+0 and others D+1 or later; the cycle, rate and fees for each market are confirmed before go-live. See [USDT settlement](/guides/usdt-settlement).',
            ] },
            { id: 'start-region-kaazpay', heading: 'How to launch mobile money in the region with KaazPay', blocks: [
                { steps: [
                    'Open a merchant account and specify which of the eight markets you need and your expected volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with an engineer on hand using the [developer documentation](/developers), testing each currency and the payouts you need.',
                    'Go live and add further markets later without a new integration.',
                ] },
                'For the rest of the continent, from Ghana to Kenya, see the [Africa mobile money guide](/guides/africa-mobile-money). To get a per-country channel plan and pricing, contact our business team on Telegram via the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Which West and Central African countries does KaazPay cover?', a: 'Côte d’Ivoire, Senegal, Benin, Burkina Faso and Mali (XOF), Cameroon and Gabon (XAF), and Guinea (GNF). All support local cards; all except Gabon also support mobile money pay-in.' },
            { q: 'Can I use one integration for every CFA franc country?', a: 'Yes. One KaazPay integration covers all eight markets. You create each order in the customer’s currency, XOF, XAF or GNF, and the rest of the flow is the same.' },
            { q: 'Are XOF and XAF interchangeable?', a: 'No. They share the CFA franc name but are separate currencies used in West and Central Africa respectively. Always create orders in the currency of the customer’s country.' },
            { q: 'Can I send mobile money payouts in Cameroon and Guinea?', a: 'Yes. Cameroon supports payouts to bank accounts and mobile money; Guinea supports mobile money payouts.' },
            { q: 'Which markets in the region are pay-in only?', a: 'Burkina Faso, Mali and Gabon are currently pay-in only on KaazPay.' },
        ],
    },
    zh: {
        title: '西非与中非移动钱包代收：XOF、XAF 指南',
        description: '在科特迪瓦、塞内加尔、喀麦隆等 8 个法语区市场收移动钱包：XOF、XAF、GNF 的区别，一套收银台服务多国的示例，代付覆盖情况与 USDT 结算。',
        h1: '如何在西非和中非接入移动钱包收款？',
        summary: '在西非与中非法语区，多数线上买家用移动钱包付款并在手机上确认，因此收银台应以移动钱包为主、本地银行卡为辅。KaazPay 一次对接覆盖科特迪瓦、塞内加尔、贝宁、布基纳法索、马里（XOF），喀麦隆、加蓬（XAF）和几内亚（GNF），其中 5 个市场支持代付，资金以 USDT 结算。',
        queries: [
            '网站如何收取科特迪瓦和塞内加尔用户的移动钱包付款？',
            '是否有一个支付 API 能覆盖所有 CFA 法郎国家？',
            '线上收款时 XOF 和 XAF 有什么区别？',
            '能否向喀麦隆和几内亚的玩家发起移动钱包代付？',
            '西非哪些国家支持代付，哪些只能代收？',
        ],
        takeaways: [
            '在 KaazPay 覆盖的 8 个法语区市场，移动钱包是主流线上付款方式，银行卡作为补充。',
            'XOF（西非法郎）与 XAF（中非法郎）是两种不同货币，几内亚则使用本国的几内亚法郎（GNF）。',
            '8 个市场中有 7 个支持移动钱包代收，加蓬仅支持本地银行卡。',
            '代付：科特迪瓦、塞内加尔、喀麦隆支持银行和移动钱包；贝宁、几内亚支持移动钱包；布基纳法索、马里、加蓬目前仅代收。',
            'XOF、XAF、GNF 代收均以 USDT 结算。',
        ],
        sections: [
            { id: 'why-lead-with-wallets', heading: '为什么西非、中非法语区要以移动钱包为主？', blocks: [
                '从阿比让到杜阿拉，手机钱包是人们交水电费、往家里汇钱、买话费的主要工具。线上付款也一样：顾客输入手机号，手机上收到付款请求，确认即可。许多顾客从未在网上用银行卡付款。',
                '因此，以填卡页面开头的收银台会在第一步就流失买家。应把**移动钱包**放在首位，同时为偏好用卡的顾客保留**本地银行卡**，使收银台符合当地的付款习惯。详见[移动钱包支付方式页面](/methods/mobile-money)。',
            ] },
            { id: 'xof-xaf-gnf', heading: 'XOF、XAF、GNF：每笔订单该用哪种货币？', blocks: [
                '该地区有两种货币都称为“CFA 法郎（CFA franc）”，对接时容易混淆。它们由不同央行发行，是两种货币，用其中一种创建的订单不能用另一种支付。',
                { table: { head: ['币种', '名称', 'KaazPay 覆盖市场'], rows: [
                    ['XOF', '西非法郎', '科特迪瓦、塞内加尔、贝宁、布基纳法索、马里'],
                    ['XAF', '中非法郎', '喀麦隆、加蓬'],
                    ['GNF', '几内亚法郎', '几内亚'],
                ] } },
                '开发规则：根据顾客所在国家确定币种，不要使用笼统的“CFA”设置，并以该币种创建 KaazPay 订单。',
            ] },
            { id: 'country-matrix', heading: '各市场分别能收什么、付什么？', blocks: [
                { table: { head: ['市场', '币种', '代收', '代付'], rows: [
                    ['科特迪瓦', 'XOF', '移动钱包、本地银行卡', '银行转账、移动钱包'],
                    ['塞内加尔', 'XOF', '移动钱包、本地银行卡', '银行转账、移动钱包'],
                    ['喀麦隆', 'XAF', '移动钱包、本地银行卡', '银行转账、移动钱包'],
                    ['贝宁', 'XOF', '移动钱包、本地银行卡', '移动钱包'],
                    ['几内亚', 'GNF', '移动钱包、本地银行卡', '移动钱包'],
                    ['布基纳法索', 'XOF', '移动钱包、本地银行卡', '仅代收'],
                    ['马里', 'XOF', '移动钱包、本地银行卡', '仅代收'],
                    ['加蓬', 'XAF', '本地银行卡', '仅代收'],
                ] } },
                { note: '通道列表会随新通道上线而变化，最新详情见[科特迪瓦](/payment-methods/cote-d-ivoire)、[塞内加尔](/payment-methods/senegal)和[喀麦隆](/payment-methods/cameroon)市场页面。' },
            ] },
            { id: 'multi-country-example', heading: '实例：一套收银台同时服务阿比让、达喀尔和杜阿拉', blocks: [
                '以一款玩家分布在科特迪瓦、塞内加尔和喀麦隆的手游为例。借助 KaazPay，一套收银台即可服务三国，细节按国家设定：',
                { steps: [
                    '识别或询问玩家所在国家：科特迪瓦、塞内加尔对应 XOF，喀麦隆对应 XAF。',
                    '以该币种显示价格，移动钱包排第一，本地银行卡排第二。',
                    '玩家输入手机号，您的后端以正确币种创建 KaazPay 代收订单，带唯一订单号。',
                    '玩家在手机上确认付款请求。',
                    'KaazPay 推送带签名的通知，您验签后发放游戏道具。',
                    '日后玩家提现时，从同一账户以相同币种发起移动钱包代付。',
                ] },
                '三个国家的 API 调用、通知格式和后台完全一样，变化的只有币种和支付方式列表。',
            ] },
            { id: 'local-checkout-details', heading: '面向当地顾客，收银台有哪些细节要注意？', blocks: [
                { list: [
                    '**法语优先：**按钮、说明和错误提示用法语撰写，这是 8 个市场共同的商务语言。',
                    '**带国家区号的手机号：**无论是否带国际区号（如 +225、+221、+237）都能接受，提交前统一格式。',
                    '**整数价格：**西非法郎、中非法郎和几内亚法郎通常不显示小数，按此展示即可。',
                    '**清晰的等待页面：**提醒顾客查看手机，显示倒计时并允许重新发送。',
                    '**以服务器为准：**未确认的订单保持待支付，结果只以带签名的通知为准。',
                ] },
            ] },
            { id: 'regional-payouts', heading: '西非与中非哪些地方可以代付？', blocks: [
                '8 个市场中有 5 个支持代付，与代收共用同一商户账户：',
                { list: [
                    '**科特迪瓦、塞内加尔、喀麦隆：**可代付到银行账户和移动钱包。',
                    '**贝宁、几内亚：**可代付到移动钱包。',
                    '**布基纳法索、马里、加蓬：**目前仅支持代收。',
                ] },
                '代付支持单笔和批量，每笔都有状态通知，适合玩家提现、主播收益和合作方佣金。钱包代付与银行代付的取舍见[非洲移动钱包与银行转账对比](/compare/mobile-money-vs-bank-transfer-africa)，批量运营见[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)。',
            ] },
            { id: 'cfa-settlement', heading: 'XOF、XAF、GNF 代收如何结算？', blocks: [
                '不论顾客用哪种货币付款，KaazPay 都将等额 **USDT** 结算给您。您不需要西非法郎或几内亚法郎账户，也不必分别管理三种当地余额。',
                'KaazPay 不少通道为 D+0 结算，也有 D+1 或更长的；各市场的周期、汇率与费率在上线前确认。详见 [USDT 结算](/guides/usdt-settlement)。',
            ] },
            { id: 'start-region-kaazpay', heading: '如何通过 KaazPay 在该地区上线移动钱包收款', blocks: [
                { steps: [
                    '开设商户账户，并说明需要开通的市场和预估交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，逐一测试各币种和所需的代付。',
                    '正式上线，以后增加市场也不需要重新对接。',
                ] },
                '非洲其他地区（从加纳到肯尼亚）请看[非洲移动钱包指南](/guides/africa-mobile-money)。如需分国家的通道方案和报价，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'KaazPay 覆盖西非和中非哪些国家？', a: '科特迪瓦、塞内加尔、贝宁、布基纳法索、马里（XOF），喀麦隆、加蓬（XAF），以及几内亚（GNF）。全部支持本地银行卡，除加蓬外都支持移动钱包代收。' },
            { q: '能否一次对接覆盖所有 CFA 法郎国家？', a: '可以。一次对接 KaazPay 即覆盖全部 8 个市场，每笔订单按顾客币种（XOF、XAF 或 GNF）创建，其余流程相同。' },
            { q: 'XOF 和 XAF 能互相通用吗？', a: '不能。两者都叫 CFA 法郎，但分别用于西非和中非，是不同的货币。订单务必按顾客所在国家的币种创建。' },
            { q: '喀麦隆和几内亚支持移动钱包代付吗？', a: '可以。喀麦隆支持银行账户和移动钱包代付，几内亚支持移动钱包代付。' },
            { q: '该地区哪些市场仅支持代收？', a: '目前在 KaazPay 上，布基纳法索、马里和加蓬仅支持代收。' },
        ],
    },
};
