export default {
    slug: 'merchant-onboarding-kyc-checklist',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['global-cards', 'usdt'],
        methods: [],
        industries: ['e-commerce', 'gaming', 'digital-goods', 'web3'],
        articles: ['payment-gateway-integration-checklist', 'usdt-settlement', 'one-gateway-vs-multiple-providers', 'chargebacks-vs-local-payments'],
    },
    en: {
        title: 'Merchant Onboarding and KYC Checklist for Gateways',
        description: 'What to prepare before opening a gateway merchant account: company documents, website, markets and volumes, KYC/AML and risk review, testing and go-live.',
        h1: 'What do you need to open a payment gateway merchant account?',
        summary: 'To open a merchant account with a payment gateway, you typically provide company and ownership documents, a working website or app that clearly describes what you sell, your target markets, methods and expected volumes, and answers to a KYC/AML and risk review; then you integrate, test jointly and go live. KaazPay follows this common industry path, and your account manager confirms the exact document list for your business and markets.',
        queries: [
            'What documents does a payment gateway usually ask for when opening a merchant account?',
            'Why does a payment provider need to know our company’s beneficial owners?',
            'Our website is not finished yet. Can we start merchant onboarding anyway?',
            'How long does KYC review take before we can go live with a payment gateway?',
            'What usually delays merchant account approval?',
        ],
        takeaways: [
            'Onboarding checks who you are, what you sell, where you sell it and how much you expect to process.',
            'Have company, ownership and director documents ready in clear, current copies before you apply.',
            'Your website or app should show products, prices, policies and contact details before review.',
            'Accurate market, method and volume estimates speed up channel setup and pricing.',
            'Requirements vary by business and market; your KaazPay account manager confirms the exact list.',
        ],
        sections: [
            {
                id: 'why-onboarding',
                heading: 'Why do payment gateways run KYC and risk checks?',
                blocks: [
                    'A payment gateway moves money on behalf of its merchants, so it has to know who those merchants are and what their money is for. Know-your-customer (KYC) and anti-money-laundering (AML) checks, plus a review of business risk, are standard across the payments industry. They protect the gateway, its banking and channel partners, and ultimately you, because a well-documented merchant is less likely to face sudden questions later.',
                    { note: 'This guide describes common industry practice. It is not legal advice, and it is not a definitive KaazPay requirements list. The documents and checks that apply to you depend on your business model, jurisdiction and target markets, and your account manager confirms them.' },
                ],
            },
            {
                id: 'stages-overview',
                heading: 'What are the stages of merchant onboarding?',
                blocks: [
                    {
                        table: {
                            head: ['Stage', 'What happens', 'What you usually provide'],
                            rows: [
                                ['1. First conversation', 'You describe your business and needs', 'Business model, markets, methods, rough volumes'],
                                ['2. Documents', 'Company and ownership are verified', 'Registration documents, owner and director IDs'],
                                ['3. Business review', 'Your website or app and products are checked', 'Live site or app, policies, any required licences'],
                                ['4. KYC/AML and risk review', 'Screening and risk assessment', 'Answers to follow-up questions, clarifications'],
                                ['5. Account and API keys', 'Merchant account is set up', 'Technical contacts, server IPs for allow-listing'],
                                ['6. Integration and joint testing', 'You connect and test with an engineer', 'Test cases, notification endpoint'],
                                ['7. Go-live', 'Live processing starts', 'Confirmation of rates, fees and settlement details'],
                            ],
                        },
                    },
                ],
            },
            {
                id: 'company-documents',
                heading: 'Which company documents should you prepare?',
                blocks: [
                    'Across the industry, gateways commonly ask for documents along these lines. Prepare clear, complete and current copies:',
                    {
                        list: [
                            'Certificate of incorporation or business registration.',
                            'Articles or memorandum of association, or the local equivalent.',
                            'A register or official extract showing directors and shareholders.',
                            'Identification for directors and for beneficial owners above the relevant ownership threshold.',
                            'Proof of address for the company and, where requested, for key individuals.',
                            'Details of who is authorised to manage the merchant account.',
                        ],
                    },
                    'Where documents are not in English, ask in advance whether translations are needed. Your KaazPay account manager will tell you exactly which items apply to your company.',
                ],
            },
            {
                id: 'website-and-business-model',
                heading: 'What should your website or app show before review?',
                blocks: [
                    'Reviewers want to see the business the payments will come from. Before you submit, make sure your site or app:',
                    {
                        list: [
                            'Is live, or at least reachable in a reviewable state, on the domain you will process for.',
                            'Describes clearly what you sell, with prices in the currencies you plan to charge.',
                            'Shows terms of service, a refund or cancellation policy and a privacy notice appropriate to your business.',
                            'Gives customers a way to contact you.',
                            'Matches the business model you described: the same products, the same markets.',
                        ],
                    },
                    'If your activity requires a licence or registration in a given market, have it ready. Industries with specific rules, such as gaming, digital goods or Web3, may receive extra questions; [our industry pages](/industries/gaming) describe how KaazPay supports each.',
                ],
            },
            {
                id: 'markets-and-volumes',
                heading: 'Which commercial details speed up channel setup?',
                blocks: [
                    'The more precise your answers, the faster a gateway can propose the right channels and pricing:',
                    {
                        list: [
                            'Target markets, in order of priority. The [payment methods directory](/methods) shows what is available per country.',
                            'Whether you need pay-in only, or payouts too, and to which rails.',
                            'Expected monthly volume and average transaction size per market.',
                            'Peak periods, such as campaigns or events.',
                            'Your preferred USDT network for settlement (see [USDT settlement](/guides/usdt-settlement)).',
                        ],
                    },
                ],
            },
            {
                id: 'kyc-aml-risk-review',
                heading: 'What happens during the KYC/AML and risk review?',
                blocks: [
                    'In general terms, the review confirms that the company and its owners are who they say they are, screens them against relevant sanctions and watch lists, and assesses the risk of the business model, products and markets. It is normal to receive follow-up questions, for example about ownership structure, the origin of your customers, or how you handle refunds and disputes.',
                    'Answer fully and consistently. Inconsistencies between your application, your documents and your website are among the most common reasons for delays across the industry. After approval, ongoing monitoring continues; KaazPay applies real-time risk monitoring to live traffic.',
                ],
            },
            {
                id: 'integration-and-testing',
                heading: 'What happens once the account is approved?',
                blocks: [
                    'You receive your API keys and integration materials, register your server IPs for allow-listing, and build your integration. A KaazPay engineer works with you on joint testing before launch, covering successful, failed and expired payments, duplicate notifications and, if used, payouts. The [integration checklist](/guides/payment-gateway-integration-checklist) lists what to test.',
                    'Before go-live, rates, fees and settlement cycles are confirmed per channel. Many KaazPay channels settle D+0, while others settle D+1 or later.',
                ],
            },
            {
                id: 'avoid-delays',
                heading: 'What usually slows onboarding down, and how do you avoid it?',
                blocks: [
                    {
                        steps: [
                            'Send complete documents in one batch rather than piece by piece.',
                            'Make sure names, addresses and ownership match across every document.',
                            'Have the website or app ready for review before you apply, not after.',
                            'Describe your business model plainly, including every market you plan to serve.',
                            'Name one contact who can answer compliance and technical questions quickly.',
                            'Tell your account manager early about changes in ownership, domain or markets, both during and after onboarding.',
                        ],
                    },
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you open a KaazPay merchant account?',
                blocks: [
                    'With KaazPay, the path from first message to live payments has four steps:',
                    {
                        steps: [
                            'Open a merchant account: tell us your business, markets and volumes, and provide the documents your account manager confirms.',
                            'Receive your API keys once the review is complete.',
                            'Integrate with engineer support and joint testing; see the [developer page](/developers).',
                            'Go live with agreed rates, fees and settlement cycles.',
                        ],
                    },
                    'Start on Telegram via the [contact page](/contact). We reply within one business day. KaazPay staff will never ask for your passwords or private keys.',
                ],
            },
        ],
        faq: [
            { q: 'What documents do I need to open a merchant account?', a: 'Commonly: company registration documents, details of directors and shareholders, identification for directors and beneficial owners, and proof of address. Your KaazPay account manager confirms the exact list for your business.' },
            { q: 'Why does the gateway ask about beneficial owners?', a: 'Identifying the people who ultimately own or control a company is a standard part of KYC and AML checks across the payments industry.' },
            { q: 'Can I start onboarding before my website is finished?', a: 'You can start the conversation, but the business review generally needs a reviewable site or app that shows your products, prices, policies and contact details.' },
            { q: 'How long does onboarding take?', a: 'It depends on your business, markets and how complete your documents are. Complete, consistent information and a ready website are the biggest factors in keeping it short.' },
            { q: 'Do I need a local company in every market I sell to?', a: 'Not to receive funds with KaazPay, because collections are settled in USDT. Whether your activity needs local licences or registrations depends on your business and markets.' },
        ],
    },
    zh: {
        title: '商户开户与 KYC 准备清单：支付网关篇',
        description: '开通支付网关商户账户前要准备什么？公司资料、网站与业务模式、目标市场与交易量、KYC/AML 与风控审核以及联调测试与上线。',
        h1: '开通支付网关商户账户，需要准备哪些资料？',
        summary: '向支付网关申请商户账户，通常需要提供公司与股权资料、能清楚展示所售商品的网站或 App、目标市场、支付方式与预估交易量，并配合 KYC/AML 与风控审核；之后再完成接入、联调并上线。KaazPay 遵循这一行业通行流程，具体需要哪些文件，由客户经理根据您的业务和市场确认。',
        queries: [
            '开支付网关商户账户，一般要交哪些文件？',
            '支付服务商为什么要知道我们公司的最终受益人？',
            '网站还没做完，可以先开始商户开户吗？',
            '支付网关的 KYC 审核一般要多久才能上线？',
            '商户开户审核通常因哪些原因延误？',
        ],
        takeaways: [
            '开户审核核实：商户身份、所售商品、销售市场与预计交易量。',
            '申请前准备好清晰、最新的公司、股东与董事资料。',
            '审核前，网站或 App 应展示商品、价格、政策条款和联系方式。',
            '准确的市场、支付方式与交易量预估，能加快通道配置与报价。',
            '要求因业务和市场而异，具体清单以 KaazPay 客户经理确认为准。',
        ],
        sections: [
            {
                id: 'why-onboarding',
                heading: '支付网关为什么要做 KYC 和风控审核？',
                blocks: [
                    '支付网关替商户收付资金，因此必须了解商户是谁、资金用于什么。了解你的客户（KYC）和反洗钱（AML）审核，加上业务风险评估，是整个支付行业的标准做法。这既保护网关及其银行与通道合作方，最终也保护商户自己：资料完整的商户，日后遇到突发问询的可能性更小。',
                    { note: '本文介绍的是行业通行做法，不构成法律意见，也不是 KaazPay 的正式资料清单。适用于您的文件与审核内容取决于业务模式、注册地和目标市场，以客户经理确认为准。' },
                ],
            },
            {
                id: 'stages-overview',
                heading: '商户开户分为哪几个阶段？',
                blocks: [
                    {
                        table: {
                            head: ['阶段', '主要内容', '商户通常需要提供'],
                            rows: [
                                ['1. 初步沟通', '介绍业务与需求', '业务模式、市场、支付方式、大致交易量'],
                                ['2. 提交资料', '核实公司与股权', '注册文件、股东与董事身份证明'],
                                ['3. 业务审核', '检查网站或 App 及所售商品', '可访问的网站或 App、政策条款、所需牌照'],
                                ['4. KYC/AML 与风控审核', '筛查与风险评估', '回答补充问题、提供说明'],
                                ['5. 开户与 API 密钥', '开通商户账户', '技术联系人、用于白名单的服务器 IP'],
                                ['6. 接入与联调', '在工程师协助下对接测试', '测试用例、回调地址'],
                                ['7. 正式上线', '开始真实交易', '确认费率、费用与结算安排'],
                            ],
                        },
                    },
                ],
            },
            {
                id: 'company-documents',
                heading: '需要准备哪些公司资料？',
                blocks: [
                    '行业内的支付网关通常会要求以下几类文件，请准备清晰、完整、最新的版本：',
                    {
                        list: [
                            '公司注册证书或营业登记证明。',
                            '公司章程或当地同等文件。',
                            '显示董事与股东的登记册或官方摘录。',
                            '董事以及达到相应持股比例的最终受益人的身份证明。',
                            '公司地址证明，以及按要求提供的主要人员地址证明。',
                            '有权管理商户账户的人员资料。',
                        ],
                    },
                    '如果文件不是英文，请事先确认是否需要翻译。具体需要哪些文件，KaazPay 客户经理会根据您的公司情况告知。',
                ],
            },
            {
                id: 'website-and-business-model',
                heading: '审核前，网站或 App 应该具备什么？',
                blocks: [
                    '审核人员需要看到资金所对应的真实业务。提交前请确认网站或 App：',
                    {
                        list: [
                            '已上线，或至少能在您计划收款的域名下以可审核状态访问。',
                            '清楚说明所售商品或服务，并以计划收款的币种标价。',
                            '展示与业务相符的服务条款、退款或取消政策以及隐私说明。',
                            '提供客户联系您的方式。',
                            '与您描述的业务模式一致：同样的商品、同样的市场。',
                        ],
                    },
                    '如果您的业务在某个市场需要牌照或登记，请提前备妥。游戏、数字商品、Web3 等有特定规则的行业可能会收到更多问题，KaazPay 对各行业的支持可参考[行业页面](/industries/gaming)。',
                ],
            },
            {
                id: 'markets-and-volumes',
                heading: '哪些商务信息能加快通道配置？',
                blocks: [
                    '资料越具体，网关越能尽快给出合适的通道与报价：',
                    {
                        list: [
                            '按优先级排列的目标市场，各国可用方式见[支付方式目录](/methods)。',
                            '只做代收，还是也需要代付，以及代付到哪些渠道。',
                            '各市场的月交易量预估与平均客单价。',
                            '高峰时段，例如促销或活动期间。',
                            '结算偏好的 USDT 链（见 [USDT 结算指南](/guides/usdt-settlement)）。',
                        ],
                    },
                ],
            },
            {
                id: 'kyc-aml-risk-review',
                heading: 'KYC/AML 与风控审核会看什么？',
                blocks: [
                    '一般而言，审核会确认公司及其股东身份属实，对照相关制裁名单与观察名单进行筛查，并评估业务模式、商品和市场的风险。收到补充问题很正常，例如股权结构、客户来源，或退款和争议的处理方式。',
                    '请完整、前后一致地回答。申请表、文件和网站之间的信息不一致，是业内审核延误最常见的原因之一。审核通过后仍会持续监控，KaazPay 对线上交易实行实时风险监控。',
                ],
            },
            {
                id: 'integration-and-testing',
                heading: '账户审核通过后会发生什么？',
                blocks: [
                    '您会收到 API 密钥和接入资料，登记服务器 IP 白名单并开始开发。上线前 KaazPay 工程师会与您一起联调，覆盖成功、失败、过期付款、重复回调，以及如有使用的代付。测试内容可参考[支付接入清单](/guides/payment-gateway-integration-checklist)。',
                    '上线前会按通道确认费率、费用和结算周期。KaazPay 不少通道 D+0 结算，也有通道为 D+1 或更长。',
                ],
            },
            {
                id: 'avoid-delays',
                heading: '开户延误的常见原因及应对方法',
                blocks: [
                    {
                        steps: [
                            '一次性提交完整资料，避免分批补交。',
                            '确保所有文件中的名称、地址和股权信息一致。',
                            '申请前就把网站或 App 准备到可审核状态。',
                            '如实、清楚地说明业务模式，包括计划服务的所有市场。',
                            '指定一位能快速回答合规与技术问题的联系人。',
                            '开户期间及开户后，如股权、域名或市场有变动，请尽早告知客户经理。',
                        ],
                    },
                ],
            },
            {
                id: 'get-started',
                heading: '如何开通 KaazPay 商户账户？',
                blocks: [
                    '在 KaazPay，从第一次沟通到正式收款分四步：',
                    {
                        steps: [
                            '开通商户账户：介绍业务、市场与交易量，并提交客户经理确认的资料。',
                            '审核完成后获取 API 密钥。',
                            '在工程师支持下接入并联调，详见[开发者页面](/developers)。',
                            '按约定的费率、费用与结算周期正式上线。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 联系我们，一个工作日内回复。KaazPay 工作人员绝不会索要您的密码或私钥。',
                ],
            },
        ],
        faq: [
            { q: '开商户账户需要哪些文件？', a: '常见的包括：公司注册文件、董事与股东资料、董事和最终受益人的身份证明以及地址证明。具体清单由 KaazPay 客户经理根据您的业务确认。' },
            { q: '支付网关为什么要了解最终受益人？', a: '识别最终拥有或控制公司的人，是支付行业 KYC 与反洗钱审核的标准环节。' },
            { q: '网站还没完成，可以先开户吗？', a: '可以先开始沟通，但业务审核一般需要一个能展示商品、价格、政策条款和联系方式的可审核网站或 App。' },
            { q: '开户审核要多久？', a: '取决于业务、市场以及资料是否完整。资料完整一致、网站准备就绪，是缩短时间最关键的因素。' },
            { q: '每个销售市场都需要当地公司吗？', a: '在 KaazPay 收款不需要，因为代收资金以 USDT 结算。至于业务是否需要当地牌照或登记，取决于您的业务类型和市场。' },
        ],
    },
};
