export default {
    slug: 'fpx-vs-duitnow-vs-touch-n-go',
    kind: 'compare',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['malaysia'],
        methods: ['fpx', 'duitnow', 'touch-n-go'],
        industries: ['gaming', 'e-commerce', 'live-streaming', 'digital-goods'],
        articles: ['malaysia-payment-methods', 'southeast-asia-payment-methods', 'singapore-payment-methods', 'thailand-payment-methods', 'payment-success-rate', 'local-payment-methods-vs-cards'],
    },
    en: {
        title: "FPX vs DuitNow vs Touch 'n Go for Online Checkout",
        description: "Comparing FPX, DuitNow QR and Touch 'n Go eWallet for Malaysian checkouts: how each payment flows, which to show first by business type, drop-off fixes.",
        h1: "FPX vs DuitNow vs Touch 'n Go: which Malaysian payment method should you offer?",
        summary: "FPX is a bank-login payment, DuitNow is PayNet's real-time QR standard paid from bank apps and e-wallets, and Touch 'n Go is one of Malaysia's most widely used e-wallets. They reach overlapping but different shoppers, so most Malaysian checkouts should offer all three and change the order by device and basket size. KaazPay provides all three for MYR pay-in through one API, with payouts to Malaysian bank accounts.",
        queries: [
            "Should my Malaysian online store use FPX or Touch 'n Go?",
            'What is the difference between FPX and DuitNow QR for online payments?',
            "We run a game top-up site in Malaysia. Which payment method should appear first?",
            "Is it worth adding Touch 'n Go if we already accept DuitNow?",
            "Can I pay out to customers through FPX, DuitNow or Touch 'n Go?",
        ],
        takeaways: [
            "FPX approves in the bank, DuitNow approves in whichever bank app or e-wallet scans the QR, and Touch 'n Go approves inside one wallet.",
            "FPX and DuitNow are both run by PayNet; Touch 'n Go eWallet is a separate e-wallet.",
            "Small, frequent mobile purchases favour Touch 'n Go first; larger desktop orders favour FPX first.",
            'Offering all three and ordering them by context usually performs better than offering only one.',
            "On KaazPay all three are pay-in methods; Malaysian payouts go to bank accounts in MYR.",
        ],
        sections: [
            { id: 'quick-verdict', heading: 'The quick verdict: which one should a Malaysian checkout show first?', blocks: [
                "Show all three and order them by context. On a phone with a small basket, put **Touch 'n Go** at the top. On a desktop with a larger order, start with **FPX**. Keep **DuitNow** close to the top in both cases, because it is the option that works for the widest mix of apps.",
                'Each method draws on a different place where Malaysian shoppers keep their money: a bank account, a QR-capable app on their phone, or a specific wallet balance. Shoppers who do not see their preferred method are more likely to abandon checkout.',
            ] },
            { id: 'side-by-side', heading: "How do FPX, DuitNow and Touch 'n Go compare side by side?", blocks: [
                { table: { head: ['Question', 'FPX', 'DuitNow QR', "Touch 'n Go eWallet"], rows: [
                    ['Who runs it', 'PayNet', 'PayNet', 'The e-wallet operator'],
                    ['Where the shopper approves', 'In their online banking session', 'In the bank app or e-wallet they used to scan', "In the Touch 'n Go app"],
                    ['What the shopper has to do', 'Choose a bank, log in, approve', 'Scan the code, check the amount, approve', 'Switch to the wallet (or scan on desktop) and approve'],
                    ['Typed details on your page', 'None (bank selection only)', 'None', 'None'],
                    ['Strongest device', 'Desktop', 'Desktop-to-phone, also works on phone', 'Phone'],
                    ['Typical basket', 'Medium to large', 'Any size', 'Small and frequent'],
                    ['Role on KaazPay', 'Pay-in', 'Pay-in', 'Pay-in'],
                ] } },
                { note: 'None of the three is a payout rail on KaazPay. Refunds and payouts in Malaysia are sent to recipient bank accounts in MYR.' },
            ] },
            { id: 'shopper-journeys', heading: 'What does each payment look like for the shopper?', blocks: [
                { list: [
                    '**FPX:** the shopper picks their bank from a list, is redirected to that bank’s online banking, signs in and authorises the debit, then returns to your site. Shoppers trust it because authorisation happens on the bank’s own pages, but it has the most steps. See the [FPX method page](/methods/fpx).',
                    '**DuitNow QR:** your checkout displays a QR code for the order. The shopper scans it with a banking app or a DuitNow-enabled e-wallet and approves. No bank list is needed, which makes it a neutral option for shoppers of any bank. See [DuitNow](/methods/duitnow).',
                    "**Touch 'n Go eWallet:** on mobile the shopper is handed over to the Touch 'n Go app; on desktop they typically scan with it. Approval is a single confirmation inside an app many shoppers use daily. See [Touch 'n Go](/methods/touch-n-go).",
                ] },
                "A shopper can often pay a DuitNow QR with Touch 'n Go too. Listing Touch 'n Go separately still helps, because wallet users look for the wallet’s own name and recognise it immediately.",
            ] },
            { id: 'order-by-business', heading: 'Which method should lead for your type of business?', blocks: [
                { table: { head: ['Business', 'Put first', 'Then', 'Why'], rows: [
                    ['Mobile game top-ups, live-stream gifts', "Touch 'n Go", 'DuitNow, FPX', 'Small amounts, phone-first buyers, instant delivery expected'],
                    ['Online retail with mixed devices', 'DuitNow', "FPX, Touch 'n Go", 'Works for the broadest set of apps and banks'],
                    ['Higher-value orders, courses, travel', 'FPX', "DuitNow, Touch 'n Go", 'Buyers often pay from desktop and prefer their bank'],
                    ['Subscriptions and digital tools', 'FPX or DuitNow', "Touch 'n Go", 'Account-based payers, mixed devices'],
                ] } },
                'Treat this as a starting point. After a few weeks, use your completion data per method to decide whether to change the order. If some of your buyers still reach for cards, keep them available; [local payment methods vs cards](/compare/local-payment-methods-vs-cards) explains the trade-off.',
            ] },
            { id: 'drop-off-fixes', heading: 'Where do Malaysian shoppers drop off, and how do you prevent it?', blocks: [
                { list: [
                    '**FPX bank list is hard to scan:** sort it by popularity and add search, so the shopper does not scroll through every bank on a phone.',
                    '**Shopper never returns from the bank page:** do not rely on the browser return. Confirm the order from the signed server notification and show the result when the shopper comes back later.',
                    '**DuitNow QR shown on the same phone:** add a save-image option and a one-line instruction for opening it from the app’s scanner.',
                    "**Touch 'n Go app switch interrupted:** keep the order page alive and refresh its status automatically when the shopper switches back.",
                    '**Duplicate credits after retries:** use a unique order ID for every attempt and process each notification once.',
                ] },
                'More conversion tactics are in our [payment success rate guide](/guides/payment-success-rate).',
            ] },
            { id: 'payouts-settlement', heading: 'How do refunds, payouts and settlement work for Malaysia?', blocks: [
                "Collection and payout run on different rails. FPX, DuitNow and Touch 'n Go bring money in; when you need to send money out, such as a withdrawal, a refund or a partner payment, KaazPay pays to the recipient’s **Malaysian bank account** in MYR, singly or in batches, from the same merchant account.",
                'Collections in ringgit are settled to you as the equivalent amount in **USDT**. Many KaazPay channels settle D+0 and others D+1 or later, and the cycle for each Malaysian channel is confirmed before launch. See [USDT settlement](/guides/usdt-settlement).',
            ] },
            { id: 'get-started', heading: "How to launch FPX, DuitNow and Touch 'n Go with KaazPay", blocks: [
                'One KaazPay integration switches on all three methods, and each one reports status in the same signed notification format, so your backend logic does not branch by method.',
                { steps: [
                    'Open a merchant account and share your business model and Malaysian volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with engineer support using the [developer documentation](/developers), and test each method on desktop and mobile.',
                    'Go live and adjust the method order using your own conversion data.',
                ] },
                'For the wider market picture, read the [Malaysia payment methods guide](/guides/malaysia-payment-methods) or open the [Malaysia market page](/payment-methods/malaysia). For pricing or settlement questions, contact our business team on Telegram through the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Are FPX and DuitNow the same thing?', a: 'No. PayNet runs both, but FPX sends the shopper to log in to online banking, while DuitNow QR is scanned and approved in a bank app or e-wallet.' },
            { q: "Do I still need Touch 'n Go if I accept DuitNow QR?", a: "It is usually recommended. Many wallet users look for the Touch 'n Go name at checkout, so listing it as a separate option helps them find it quickly." },
            { q: 'Which method works best for small game top-ups in Malaysia?', a: "Touch 'n Go tends to suit small, frequent mobile purchases, with DuitNow as a close second. Keep FPX available for shoppers who prefer their bank." },
            { q: "Can I refund or pay out through FPX, DuitNow or Touch 'n Go?", a: 'Not through these methods on KaazPay. Malaysian payouts and refunds are sent to recipient bank accounts in MYR.' },
            { q: 'How are Malaysian collections settled?', a: 'KaazPay settles your MYR collections as the equivalent amount in USDT, on a cycle confirmed per channel before go-live.' },
        ],
    },
    zh: {
        title: "FPX、DuitNow、Touch 'n Go 对比：马来西亚收款怎么选",
        description: "对比马来西亚三种主流线上支付：FPX 网银、DuitNow 二维码、Touch 'n Go 电子钱包。讲清付款流程差异、不同业务的排序建议，以及常见流失原因与改进方法。",
        h1: "FPX、DuitNow 和 Touch 'n Go 怎么选？马来西亚支付方式对比",
        summary: "FPX 是跳转网银登录付款，DuitNow 是 PayNet 的实时支付二维码标准，可用银行 App 或电子钱包扫码，Touch 'n Go 则是马来西亚使用最广泛的电子钱包之一。三者覆盖的人群有重叠也有差异，多数商户应三种都接，再按设备和客单价调整排序。KaazPay 一次对接即可提供这三种 MYR 代收，并支持马来西亚银行账户代付。",
        queries: [
            "马来西亚网店应该接 FPX 还是 Touch 'n Go？",
            'FPX 和 DuitNow 二维码在线上收款时有什么区别？',
            '我们在马来西亚做游戏充值，收银台第一个支付方式该放哪个？',
            "已经接了 DuitNow，还有必要再接 Touch 'n Go 吗？",
            "FPX、DuitNow、Touch 'n Go 能用来代付或退款吗？",
        ],
        takeaways: [
            "FPX 在网银里确认，DuitNow 在扫码的银行 App 或钱包里确认，Touch 'n Go 在钱包 App 内确认。",
            "FPX 与 DuitNow 都由 PayNet 运营，Touch 'n Go eWallet 是独立的电子钱包。",
            "手机端小额高频消费，优先展示 Touch 'n Go；电脑端大额订单，优先展示 FPX。",
            '三种都提供、按场景调整顺序，通常比只选一种效果更好。',
            '在 KaazPay 上三者均为代收方式，马来西亚代付打到收款人的银行账户（MYR）。',
        ],
        sections: [
            { id: 'quick-verdict', heading: '一句话结论：马来西亚收银台先放哪个？', blocks: [
                "三种都提供，按场景排序。手机端、小额订单，将 **Touch 'n Go** 置于首位；电脑端、金额较大的订单，优先展示 **FPX**。两种情况下都应将 **DuitNow** 放在靠前位置，因为它适配的 App 最广。",
                '每种方式对应马来西亚买家存放资金的不同位置：银行账户、手机上可扫码的 App，或某个钱包的余额。买家在收银台看不到自己惯用的方式，就更可能放弃付款。',
            ] },
            { id: 'side-by-side', heading: "FPX、DuitNow、Touch 'n Go 逐项对比", blocks: [
                { table: { head: ['对比项', 'FPX', 'DuitNow 二维码', "Touch 'n Go eWallet"], rows: [
                    ['运营方', 'PayNet', 'PayNet', '电子钱包运营商'],
                    ['买家在哪里确认', '网银页面', '用来扫码的银行 App 或电子钱包', "Touch 'n Go App"],
                    ['买家要做什么', '选银行、登录、授权', '扫码、核对金额、确认', '跳转到钱包（电脑端扫码）后确认'],
                    ['需要在您页面输入的信息', '无（仅选择银行）', '无', '无'],
                    ['最适合的设备', '电脑', '电脑扫手机，手机端也可用', '手机'],
                    ['常见客单价', '中到大额', '不限', '小额高频'],
                    ['在 KaazPay 的角色', '代收', '代收', '代收'],
                ] } },
                { note: '三者在 KaazPay 上都不是代付通道。马来西亚的退款与代付以 MYR 打到收款人的银行账户。' },
            ] },
            { id: 'shopper-journeys', heading: '买家用这三种方式付款，体验分别是怎样的？', blocks: [
                { list: [
                    '**FPX：**买家在列表中选择银行，跳转到该行网银，登录并授权扣款，然后返回您的网站。授权在银行自己的页面完成，买家信任度较高，但步骤最多。详见 [FPX 支付方式页面](/methods/fpx)。',
                    '**DuitNow 二维码：**收银台展示该订单的二维码，买家用银行 App 或支持 DuitNow 的电子钱包扫码确认，无需选择银行，适用于任何银行的客户。详见 [DuitNow](/methods/duitnow)。',
                    "**Touch 'n Go eWallet：**手机端直接唤起 Touch 'n Go App，电脑端通常用它扫码。买家在日常使用的 App 内确认一次即可。详见 [Touch 'n Go](/methods/touch-n-go)。",
                ] },
                "买家通常也可以用 Touch 'n Go 扫描 DuitNow 码，但单独列出 Touch 'n Go 仍有必要：钱包用户会寻找钱包本身的名称，单独列出便于快速识别。",
            ] },
            { id: 'order-by-business', heading: '不同业务，哪种方式放在最前面？', blocks: [
                { table: { head: ['业务类型', '第一位', '其次', '理由'], rows: [
                    ['手游充值、直播打赏', "Touch 'n Go", 'DuitNow、FPX', '金额小、手机用户为主、要求即时到账'],
                    ['多设备的综合电商', 'DuitNow', "FPX、Touch 'n Go", '适配的银行和 App 最广'],
                    ['高客单价、课程、旅游', 'FPX', "DuitNow、Touch 'n Go", '买家多在电脑端付款，倾向用银行账户'],
                    ['订阅与数字工具', 'FPX 或 DuitNow', "Touch 'n Go", '账户型付款人、设备混合'],
                ] } },
                '以上仅作为初始配置。上线数周后，可根据各支付方式的完成率决定是否调整顺序。如果仍有买家习惯刷卡，应保留银行卡支付，取舍思路见[本地支付与银行卡对比](/compare/local-payment-methods-vs-cards)。',
            ] },
            { id: 'drop-off-fixes', heading: '马来西亚买家在哪些环节流失？如何避免？', blocks: [
                { list: [
                    '**FPX 银行列表难找：**按使用频率排序并加入搜索框，避免买家在手机上逐一滚动查找。',
                    '**买家从网银页面没有返回：**不要依赖浏览器回跳，以带签名的服务器通知确认订单，买家稍后回来时再展示结果。',
                    '**DuitNow 码出现在同一部手机上：**提供保存图片功能，并用一句话说明如何在 App 扫码界面从相册识别。',
                    "**Touch 'n Go 跳转被打断：**保持订单页不关闭，买家切回时自动刷新状态。",
                    '**重试后重复到账：**每次尝试使用唯一订单号，每条通知只处理一次。',
                ] },
                '更多提升转化的方法见[支付成功率指南](/guides/payment-success-rate)。',
            ] },
            { id: 'payouts-settlement', heading: '马来西亚的退款、代付和结算怎么处理？', blocks: [
                "代收与代付使用不同通道。FPX、DuitNow、Touch 'n Go 用于代收；需要对外付款时（提现、退款、合作方分成），KaazPay 从同一商户账户以 MYR 代付到收款人的**马来西亚银行账户**，单笔、批量均可。",
                '林吉特代收按等额 **USDT** 结算给您。KaazPay 许多通道为 D+0，其余为 D+1 或更长，马来西亚各通道的周期在上线前确认。详见 [USDT 结算](/guides/usdt-settlement)。',
            ] },
            { id: 'get-started', heading: "如何通过 KaazPay 上线 FPX、DuitNow 和 Touch 'n Go", blocks: [
                '一次接入 KaazPay 即可同时开通三种方式，状态都以同一种带签名的通知格式回传，后端不需要按支付方式写不同逻辑。',
                { steps: [
                    '开设商户账户，说明业务模式和马来西亚的交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，并分别在电脑端和手机端测试三种方式。',
                    '正式上线，再根据自己的转化数据调整排序。',
                ] },
                '想了解马来西亚市场全貌，可阅读[马来西亚支付方式指南](/guides/malaysia-payment-methods)或查看[马来西亚市场页面](/payment-methods/malaysia)。关于报价或结算的问题，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'FPX 和 DuitNow 是一回事吗？', a: '不是。两者都由 PayNet 运营，但 FPX 需要买家登录网银付款，DuitNow 二维码则是在银行 App 或电子钱包里扫码确认。' },
            { q: "接了 DuitNow 二维码，还需要 Touch 'n Go 吗？", a: "通常建议接入。很多钱包用户会在收银台寻找 Touch 'n Go 的名称，单独列出便于他们快速找到。" },
            { q: '马来西亚的小额游戏充值，用哪种方式最好？', a: "Touch 'n Go 通常最适合手机端小额高频消费，DuitNow 次之。同时应保留 FPX，供习惯用银行付款的买家使用。" },
            { q: "可以通过 FPX、DuitNow 或 Touch 'n Go 退款或代付吗？", a: '在 KaazPay 上不支持。马来西亚的代付和退款以 MYR 打到收款人的银行账户。' },
            { q: '马来西亚的代收资金如何结算？', a: 'KaazPay 将 MYR 代收按等额 USDT 结算给您，结算周期按通道在上线前确认。' },
        ],
    },
};
