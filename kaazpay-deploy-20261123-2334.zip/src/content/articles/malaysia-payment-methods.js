export default {
    slug: 'malaysia-payment-methods',
    kind: 'guide',
    published: '2026-11-23',
    updated: '2026-11-23',
    related: {
        markets: ['malaysia', 'thailand', 'singapore'],
        methods: ['fpx', 'duitnow', 'touch-n-go'],
        industries: ['gaming', 'e-commerce', 'live-streaming'],
        articles: ['fpx-vs-duitnow-vs-touch-n-go', 'southeast-asia-payment-methods', 'thailand-payment-methods', 'singapore-payment-methods', 'usdt-settlement', 'mass-payouts-emerging-markets'],
    },
    en: {
        title: "Accept Payments in Malaysia: FPX, DuitNow, Touch 'n Go",
        description: "How online businesses accept payments in Malaysia with FPX, DuitNow QR and Touch 'n Go eWallet: checkout flows, MYR bank payouts and USDT settlement explained.",
        h1: 'How do you accept online payments from customers in Malaysia?',
        summary: "To accept online payments in Malaysia, offer FPX for buyers who pay through online banking, DuitNow QR for buyers paying from a bank app or e-wallet, and Touch 'n Go eWallet for buyers who keep a wallet balance. Buyers pay in MYR. KaazPay provides all three through one integration, pays out to Malaysian bank accounts, and settles your ringgit collections in USDT.",
        queries: [
            "We want to sell game credits to Malaysian players. Should we offer FPX, DuitNow or Touch 'n Go?",
            'How does an FPX payment work for a foreign merchant without a Malaysian company?',
            'Can Malaysian customers pay us by scanning a DuitNow QR code on our website?',
            'How can we send refunds or withdrawals to Malaysian bank accounts?',
            'Why do some FPX payments end up pending or abandoned?',
        ],
        takeaways: [
            "Offer all three: FPX, DuitNow and Touch 'n Go each reach buyers the others miss.",
            "FPX and DuitNow are PayNet schemes; Touch 'n Go is a consumer e-wallet.",
            'Match the method to the device: FPX suits desktop; wallet and QR flows suit mobile.',
            'Payouts go to Malaysian bank accounts in MYR, from the same account as your collections.',
            'Ringgit collections are settled to you in USDT, so no Malaysian account is needed to receive funds.',
        ],
        sections: [
            {
                id: 'quick-answer',
                heading: 'Which Malaysian payment method fits which situation?',
                blocks: [
                    {
                        table: {
                            head: ['Situation', 'Lead with', 'Why'],
                            rows: [
                                ['Buyer on a laptop, larger basket', 'FPX', 'Pays straight from online banking at major Malaysian banks'],
                                ['Buyer browses on a laptop but pays by phone', 'DuitNow QR', 'Scan the on-screen code with a bank app or supported e-wallet'],
                                ['Buyer on a phone, small top-up or gift', "Touch 'n Go eWallet", 'Approve in an app the buyer already uses daily'],
                                ['Buyer without a preferred method', 'Show all three', 'Lets the buyer choose a familiar method'],
                            ],
                        },
                    },
                    'The live list of Malaysian channels is on the [Malaysia market page](/payment-methods/malaysia).',
                ],
            },
            {
                id: 'the-three-methods',
                heading: "What are FPX, DuitNow and Touch 'n Go?",
                blocks: [
                    {
                        list: [
                            '**[FPX](/methods/fpx)** is the online banking payment network operated by PayNet. Buyers choose their bank, log in and approve the transfer, with no card details involved.',
                            "**[DuitNow](/methods/duitnow)** is PayNet's national real-time payment and QR standard. Banks and e-wallets accept it, so one DuitNow QR code works for buyers across many apps.",
                            "**[Touch 'n Go eWallet](/methods/touch-n-go)** is a widely used Malaysian e-wallet, accepted both online and in shops. Buyers confirm the payment inside the app.",
                        ],
                    },
                    "For a head-to-head look at the three, see [FPX vs DuitNow vs Touch 'n Go](/compare/fpx-vs-duitnow-vs-touch-n-go).",
                ],
            },
            {
                id: 'checkout-walkthrough',
                heading: 'What does each checkout flow look like for the buyer?',
                blocks: [
                    '**FPX on a laptop:** a buyer in Penang orders a software licence. Your server creates an MYR order through KaazPay, the buyer picks their bank from the list, logs in to online banking, approves, and lands back on your status page while KaazPay posts a signed notification to your server.',
                    '**DuitNow QR across devices:** the same buyer could instead see a DuitNow QR code on screen, scan it with their bank app or a supported e-wallet, and approve on the phone, without entering any details on your page.',
                    "**Touch 'n Go on mobile:** a player in Johor Bahru buys game credits on their phone. They choose Touch 'n Go, the wallet app opens, they confirm, and the credits arrive once your server receives the verified notification.",
                ],
            },
            {
                id: 'common-issues',
                heading: 'Why do Malaysian payments fail, and how do you prevent it?',
                blocks: [
                    {
                        list: [
                            "**Buyer closes the bank window early (FPX):** always confirm from the server notification, and show a status page that updates by itself rather than an empty cart.",
                            '**Bank not found in the list (FPX):** make the bank list searchable and show bank logos or full names.',
                            '**QR scanned too late (DuitNow):** display the expiry time and let the buyer refresh the code in one tap.',
                            "**Buyer lost during the app switch (Touch 'n Go):** tell buyers on screen that the wallet app will open and that they should return after confirming.",
                            '**Unexpected amounts:** show prices in MYR so the buyer sees exactly what the bank or wallet will charge.',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: 'How do payouts to Malaysian bank accounts work?',
                blocks: [
                    "KaazPay sends **payouts to Malaysian bank accounts in MYR**, one at a time or in batches, each with a signed status notification. Typical uses are refunds, player withdrawals, creator earnings and seller settlements. Collect the account holder's full name, bank and account number when the recipient signs up, and validate them before you submit.",
                    { note: "FPX, DuitNow and Touch 'n Go are pay-in methods on KaazPay. Payouts in Malaysia go by bank transfer." },
                    'For running payouts at scale, see [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
                ],
            },
            {
                id: 'settlement',
                heading: 'How are ringgit collections settled to you?',
                blocks: [
                    'Buyers pay in MYR and KaazPay settles the equivalent amount to you in USDT, so you do not need a Malaysian bank account to receive your revenue. Many KaazPay channels settle D+0 and others D+1 or later; your account manager confirms the cycle for each Malaysian channel before go-live. Details in [how USDT settlement works](/guides/usdt-settlement).',
                ],
            },
            {
                id: 'before-go-live',
                heading: 'What should you check before going live in Malaysia?',
                blocks: [
                    {
                        steps: [
                            'Decide the order in which FPX, DuitNow and Touch ’n Go appear on mobile and on desktop.',
                            'Test a successful payment, a cancelled payment and an expired QR for each method.',
                            'Confirm that orders are fulfilled only from verified notifications.',
                            'Test at least one payout to a Malaysian bank account, including a deliberately wrong account number.',
                            'Agree rates, fees and settlement cycles per channel in writing.',
                        ],
                    },
                    'For neighbouring markets, see the [Thailand guide](/guides/thailand-payment-methods) and the [Singapore guide](/guides/singapore-payment-methods); the [Southeast Asia guide](/guides/southeast-asia-payment-methods) adds Indonesia and the Philippines.',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you start accepting Malaysian payments with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your expected Malaysian volumes.',
                            'Receive your API keys.',
                            'Integrate with an engineer on hand for joint testing; see the [developer page](/developers).',
                            "Go live with FPX, DuitNow and Touch 'n Go pay-in plus bank payouts.",
                        ],
                    },
                    'Contact us on Telegram through the [contact page](/contact). We reply within one business day with a channel plan and pricing.',
                ],
            },
        ],
        faq: [
            { q: 'What are the main online payment methods in Malaysia?', a: "FPX online banking, DuitNow real-time payments and QR, and the Touch 'n Go eWallet. KaazPay supports all three for pay-in in MYR." },
            { q: 'Can a foreign company accept FPX through KaazPay?', a: 'KaazPay provides FPX pay-in and settles collections in USDT, so you do not need a Malaysian bank account to receive funds. Your account manager confirms onboarding requirements for your business.' },
            { q: 'What is the difference between FPX and DuitNow?', a: 'With FPX the buyer logs in to online banking to approve a transfer. With DuitNow QR the buyer scans a code with a bank app or e-wallet. Both are run by PayNet.' },
            { q: "Can I send payouts to Touch 'n Go wallets?", a: "No. On KaazPay, Touch 'n Go is a pay-in method. Payouts in Malaysia are sent to bank accounts in MYR." },
            { q: 'How long does settlement take for Malaysian payments?', a: 'It depends on the channel. Many KaazPay channels settle D+0 and others D+1 or later; each cycle is confirmed before you go live.' },
        ],
    },
    zh: {
        title: "马来西亚收款指南：FPX、DuitNow、Touch 'n Go",
        description: "线上商户如何在马来西亚收款：FPX 网银、DuitNow 二维码与 Touch 'n Go 电子钱包的付款流程，以及马币银行代付和 USDT 结算安排。",
        h1: '如何向马来西亚用户收取线上付款？',
        summary: "要在马来西亚线上收款，应同时提供三种方式：习惯网银付款的用户用 FPX，用银行 App 或电子钱包扫码的用户用 DuitNow QR，有钱包余额的用户用 Touch 'n Go eWallet。用户以马币（MYR）付款。KaazPay 一次接入即可提供这三种方式，支持代付到马来西亚银行账户，并把马币代收资金以 USDT 结算给商户。",
        queries: [
            "想卖游戏点数给马来西亚玩家，应该接 FPX、DuitNow 还是 Touch 'n Go？",
            '没有马来西亚公司的海外商户，FPX 付款要怎么收？',
            '马来西亚用户能在我们网站上扫 DuitNow 二维码付款吗？',
            '怎么把退款或提现打到马来西亚的银行账户？',
            '为什么有些 FPX 付款会一直处理中或被放弃？',
        ],
        takeaways: [
            "三种都接：FPX、DuitNow、Touch 'n Go 各自覆盖其他方式照顾不到的用户。",
            "FPX 和 DuitNow 属于 PayNet 体系，Touch 'n Go 是面向消费者的电子钱包。",
            '按设备搭配：电脑端适合 FPX，手机端适合钱包与扫码。',
            '代付以马币打入马来西亚银行账户，与代收共用同一账户。',
            '马币代收以 USDT 结算，收款无需马来西亚银行账户。',
        ],
        sections: [
            {
                id: 'quick-answer',
                heading: '不同情境下，该优先展示哪种马来西亚支付方式？',
                blocks: [
                    {
                        table: {
                            head: ['情境', '优先展示', '原因'],
                            rows: [
                                ['用户用电脑下单，金额较大', 'FPX', '直接通过马来西亚各大银行的网银付款'],
                                ['用户在电脑上浏览，用手机付款', 'DuitNow QR', '用银行 App 或支持的电子钱包扫屏幕上的码'],
                                ['用户用手机，小额充值或打赏', "Touch 'n Go eWallet", '在每天都用的 App 里确认即可'],
                                ['看不出用户偏好', '三种都展示', '让用户选择熟悉的方式'],
                            ],
                        },
                    },
                    '马来西亚的最新通道列表见[马来西亚市场页](/payment-methods/malaysia)。',
                ],
            },
            {
                id: 'the-three-methods',
                heading: "FPX、DuitNow、Touch 'n Go 分别是什么？",
                blocks: [
                    {
                        list: [
                            '**[FPX](/methods/fpx)** 是 PayNet 运营的网银支付网络。用户选择银行、登录网银确认转账，不涉及卡号。',
                            '**[DuitNow](/methods/duitnow)** 是 PayNet 推出的全国实时支付与二维码标准，银行和电子钱包都支持，所以一个 DuitNow 码能覆盖多个 App 的用户。',
                            "**[Touch 'n Go eWallet](/methods/touch-n-go)** 是马来西亚广泛使用的电子钱包，线上线下均可使用，用户在 App 内确认付款。",
                        ],
                    },
                    "三者的逐项对比见 [FPX、DuitNow 与 Touch 'n Go 对比](/compare/fpx-vs-duitnow-vs-touch-n-go)。",
                ],
            },
            {
                id: 'checkout-walkthrough',
                heading: '用户实际付款时，三种流程分别是怎样的？',
                blocks: [
                    '**电脑上用 FPX：** 槟城的一位用户购买软件授权。商户服务器通过 KaazPay 创建马币订单，用户从列表中选择自己的银行、登录网银并确认，随后回到商户的状态页；同时 KaazPay 向商户服务器推送带签名的回调。',
                    '**跨设备用 DuitNow QR：** 同一位用户也可以选择在屏幕上显示 DuitNow 二维码，用银行 App 或支持的电子钱包扫码并在手机上确认，无需在页面上输入任何资料。',
                    "**手机上用 Touch 'n Go：** 新山的一位玩家在手机上购买游戏点数，选择 Touch 'n Go 后钱包 App 自动打开，确认付款；商户服务器收到验签通过的回调后，点数随即到账。",
                ],
            },
            {
                id: 'common-issues',
                heading: '马来西亚的付款为什么会失败？如何预防？',
                blocks: [
                    {
                        list: [
                            '**用户提前关闭银行页面（FPX）：** 一律以服务器回调为准，并提供会自动刷新的状态页，而非空白的购物车。',
                            '**在列表里找不到自己的银行（FPX）：** 银行列表支持搜索，并显示银行标志或全称。',
                            '**扫码太晚（DuitNow）：** 显示有效期，允许一键刷新二维码。',
                            "**切换 App 时中断（Touch 'n Go）：** 在页面上提示用户钱包 App 会打开，确认后请返回。",
                            '**金额与预期不符：** 以马币标价，让用户清楚看到银行或钱包会扣多少。',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: '代付到马来西亚银行账户是怎么运作的？',
                blocks: [
                    'KaazPay 支持以马币**代付到马来西亚银行账户**，可单笔也可批量，每笔都有带签名的状态回调，常用于退款、玩家提现、主播分成和卖家结款。建议在收款人注册时就收集户名全称、银行和账号，并在提交前做好校验。',
                    { note: "在 KaazPay，FPX、DuitNow 和 Touch 'n Go 都是代收方式；马来西亚的代付通过银行转账完成。" },
                    '大规模代付的运营要点，请看[新兴市场批量代付](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'settlement',
                heading: '马币代收资金如何结算给商户？',
                blocks: [
                    '用户以马币付款，KaazPay 以等额 USDT 结算给商户，所以收款不需要马来西亚银行账户。KaazPay 不少通道 D+0 结算，其余 D+1 或更长，马来西亚各通道的周期由客户经理在上线前确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
                ],
            },
            {
                id: 'before-go-live',
                heading: '在马来西亚上线前要检查什么？',
                blocks: [
                    {
                        steps: [
                            "确定 FPX、DuitNow、Touch 'n Go 在手机端和电脑端的排列顺序。",
                            '每种方式都测试成功、取消和二维码过期三种情况。',
                            '确认订单只依据验签通过的回调发货。',
                            '至少测试一笔代付到马来西亚银行账户，并故意用错误账号测一次。',
                            '书面确认各通道的费率、费用和结算周期。',
                        ],
                    },
                    '邻近市场可参考[泰国收款指南](/guides/thailand-payment-methods)和[新加坡收款指南](/guides/singapore-payment-methods)，[东南亚支付方式指南](/guides/southeast-asia-payment-methods)还涵盖印尼和菲律宾。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 开始在马来西亚收款？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，提供马来西亚的预估交易量。',
                            '获取 API 密钥。',
                            '在工程师协助下接入并联调，详见[开发者页面](/developers)。',
                            "上线 FPX、DuitNow、Touch 'n Go 代收以及银行代付。",
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 联系我们，一个工作日内提供通道方案与报价。',
                ],
            },
        ],
        faq: [
            { q: '马来西亚主要的线上支付方式有哪些？', a: "FPX 网银支付、DuitNow 实时支付与二维码，以及 Touch 'n Go 电子钱包。KaazPay 三种都支持以马币代收。" },
            { q: '海外公司能通过 KaazPay 收 FPX 付款吗？', a: 'KaazPay 提供 FPX 代收并以 USDT 结算，所以收款无需马来西亚银行账户。具体开户要求由客户经理根据您的业务确认。' },
            { q: 'FPX 和 DuitNow 有什么区别？', a: 'FPX 需要用户登录网银确认转账；DuitNow QR 则是用户用银行 App 或电子钱包扫码。两者都由 PayNet 运营。' },
            { q: "能代付到 Touch 'n Go 钱包吗？", a: "不能。在 KaazPay，Touch 'n Go 是代收方式，马来西亚的代付以马币打入银行账户。" },
            { q: '马来西亚的付款多久结算？', a: '取决于通道。KaazPay 不少通道 D+0 结算，其余 D+1 或更长，上线前逐个确认。' },
        ],
    },
};
