import { Gamepad2, ShoppingBag, Radio, Coins, AppWindow, Plane, GraduationCap, Banknote } from 'lucide-react';

/**
 * Industry solutions — ids double as #anchors on /industries and as /industries/:id detail pages.
 * methods: payment-method page slugs (data/methods.js) shown as popular methods for the industry.
 * Copy lives in locales (industries.items.<id>); photos in src/assets/industries/<id>.webp (see credits.json).
 */
export const INDUSTRIES = [
    { id: 'gaming', icon: Gamepad2, methods: ['pix', 'spei', 'pse', 'gcash', 'qris', 'm-pesa', 'mobile-money', 'visa', 'mastercard'],
        seo: { en: ['Gaming & Entertainment Payments: Local Deposits and Withdrawals', 'Let players deposit with Pix, SPEI, PSE, GCash, QRIS, M-Pesa, mobile money or cards and withdraw to local accounts. One KaazPay API, settled in USDT.'],
            zh: ['游戏娱乐支付：本地充值与提现', '玩家可通过 Pix、SPEI、PSE、GCash、QRIS、M-Pesa、移动钱包或银行卡充值，并提现至本地账户。一个 KaazPay API 接入，USDT 结算。'] } },
    { id: 'e-commerce', icon: ShoppingBag, methods: ['pix', 'boleto', 'spei', 'pse', 'fpx', 'qris', 'apple-pay', 'google-pay', 'visa', 'mastercard', 'unionpay', 'jcb'],
        seo: { en: ['Cross-border E-commerce Payments: A Local Checkout in Every Market', 'Offer Apple Pay, cards, SPEI, PSE, Pix, Boleto, FPX and QRIS at one checkout, process refunds through local rails and receive revenue in USDT.'],
            zh: ['跨境电商支付：每个市场的本地化收银台', '在同一收银台提供 Apple Pay、信用卡、SPEI、PSE、Pix、Boleto、FPX 与 QRIS，通过本地通道处理退款，收入以 USDT 结算。'] } },
    { id: 'live-streaming', icon: Radio, methods: ['gcash', 'qris', 'touch-n-go', 'pix', 'm-pesa', 'mobile-money', 'visa', 'mastercard'],
        seo: { en: ['Live Streaming & Social Payments: Coin Top-ups and Creator Payouts', 'Fans top up coins with GCash, QRIS, Pix, M-Pesa, mobile money and cards; creators receive payouts to bank accounts, wallets or US payout apps.'],
            zh: ['直播与社交支付：金币充值与主播分成', '粉丝可通过 GCash、QRIS、Pix、M-Pesa、移动钱包与银行卡充值金币，主播分成可代付至银行账户、钱包或美国代付应用。'] } },
    { id: 'web3', icon: Coins, methods: ['pix', 'spei', 'gcash', 'm-pesa', 'visa', 'mastercard'],
        seo: { en: ['Web3 & Crypto Payments: USDT Deposits, Withdrawals and Local Fiat', 'USDT pay-in and payouts on Tron, Ethereum, BSC, Solana and Polygon with real-time callbacks, plus local fiat payment methods for your users.'],
            zh: ['Web3 与加密支付：USDT 充提与本地法币', '支持 Tron、Ethereum、BSC、Solana、Polygon 五条网络的 USDT 充值与提现，实时回调，并为用户提供本地法币支付方式。'] } },
    { id: 'digital-goods', icon: AppWindow, methods: ['visa', 'mastercard', 'jcb', 'apple-pay', 'google-pay', 'pix', 'gcash', 'qris'],
        seo: { en: ['AI Apps & Digital Content Payments: Unlocks, Credits and Subscriptions', 'Sell episode unlocks, AI credits and memberships with cards, Apple Pay, Google Pay and local wallets, and pay studios and creators locally.'],
            zh: ['AI 应用与数字内容支付：解锁、点数与订阅', '通过信用卡、Apple Pay、Google Pay 与本地钱包销售剧集解锁、AI 点数与会员，并在当地向制作方与创作者代付。'] } },
    { id: 'travel', icon: Plane, methods: ['visa', 'mastercard', 'unionpay', 'jcb', 'apple-pay', 'pix', 'spei'],
        seo: { en: ['Travel & Hospitality Payments: Bookings, Refunds and Supplier Payouts', 'Accept bookings with Visa, Mastercard, UnionPay, JCB, Apple Pay, EUR/GBP/AED bank transfers and local methods, with refunds and supplier payouts.'],
            zh: ['旅游与酒店支付：预订收款、退款与供应商代付', '通过 Visa、Mastercard、银联、JCB、Apple Pay、EUR/GBP/AED 银行转账与本地支付方式接受预订，并支持退款与供应商代付。'] } },
    { id: 'education', icon: GraduationCap, methods: ['pix', 'boleto', 'pse', 'fpx', 'gcash', 'm-pesa', 'visa', 'mastercard'],
        seo: { en: ['Education & EdTech Payments: Local Tuition Collection', 'Collect course fees and tuition with bank transfers, mobile money, Boleto, cash vouchers and cards, so students and parents do not need an international card.'],
            zh: ['教育与在线学习支付：本地学费收款', '通过银行转账、移动钱包、Boleto、现金凭证与银行卡收取课程费与学费，学生与家长无需国际信用卡。'] } },
    { id: 'global-payroll', icon: Banknote, methods: ['paypal', 'cash-app', 'mobile-money', 'm-pesa'],
        seo: { en: ['Global Payroll & Mass Payouts: Pay Contractors Worldwide', 'Pay freelancers and partners to bank accounts, mobile money, PayPal, Cash App, Chime, ACH or USDT in 25+ markets from one KaazPay balance.'],
            zh: ['全球薪酬与批量代付：向全球收款人付款', '从一个 KaazPay 余额，向 25+ 个市场的银行账户、移动钱包、PayPal、Cash App、Chime、ACH 或 USDT 钱包代付。'] } },
];

export const getIndustry = (id) => INDUSTRIES.find((i) => i.id === id);

const PHOTOS = import.meta.glob('../assets/industries/*.webp', { eager: true, query: '?url', import: 'default' });
export const industryPhoto = (id) => PHOTOS[`../assets/industries/${id}.webp`] || null;
// 800w copies (scripts/make-variants.mjs) for cards and tiles.
const PHOTOS_SM = import.meta.glob('../assets/industries/sm/*.webp', { eager: true, query: '?url', import: 'default' });
export const industryPhotoSmall = (id) => PHOTOS_SM[`../assets/industries/sm/${id}.webp`] || industryPhoto(id);
export const industryPhotoSrcSet = (id) => (PHOTOS_SM[`../assets/industries/sm/${id}.webp`] && industryPhoto(id)
    ? `${PHOTOS_SM[`../assets/industries/sm/${id}.webp`]} 800w, ${industryPhoto(id)} 1600w` : undefined);

// 96x64 pre-blurred versions of the same photos: an ambient colour field behind each industry section.
const AMBIENT = import.meta.glob('../assets/industries/ambient/*.webp', { eager: true, query: '?url', import: 'default' });
export const industryAmbient = (id) => AMBIENT[`../assets/industries/ambient/${id}.webp`] || null;
