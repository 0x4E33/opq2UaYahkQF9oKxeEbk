import {
    SITE_URL, MARKETS, REGIONS, COVERAGE_STATS, getMarket, hasPayout,
    marketName, regionName, methodType, methodTypeName, methodLabel,
} from './data/channels';
import { METHODS, getMethod, methodMarkets, methodName } from './data/methods';
import { INDUSTRIES, getIndustry } from './data/industries';
import { MILESTONES } from './data/milestones';
import { ARTICLES, KINDS, articleLang, articlePath, articlesOfKind, getArticle, plain } from './content';
import { LANGS, langFromPath, stripLocale, localizePath, normalizePath } from './lib/locale';
import en from './locales/en.json';
import { TG_SALES, TG_CHANNEL, FOUNDED, tgUrl, PORTAL_URL } from './data/contact';
import zhLocale from './locales/zh.json';
import { GLOSSARY } from './content/glossary-view';
import { FAQ_ALL } from './content/faq-view';

const isZh = (l) => !!l && l.startsWith('zh');

const STATIC = {
    '/': {
        en: [`KaazPay | Cross-border Payment Gateway: Pay-in, Payouts & USDT`,
            `One API for ${COVERAGE_STATS.payinMethods}+ local payment methods in ${COVERAGE_STATS.markets} markets worldwide: bank transfers, QR, e-wallets and cards, plus local payouts and USDT settlement.`],
        zh: [`KaazPay | 跨境支付通道：全球代收代付与 USDT 结算`,
            `一个 API 接入全球 ${COVERAGE_STATS.markets} 个市场、${COVERAGE_STATS.payinMethods}+ 种本地支付方式：银行转账、扫码支付、电子钱包与银行卡，同时支持本地代付与 USDT 结算。`],
    },
    '/faq': { en: ['KaazPay FAQ: Coverage, Settlement, Onboarding & Integration', 'Answers to common questions about KaazPay: supported countries and payment methods, USDT settlement, fees, onboarding, integration, payouts and compliance.'], zh: ['KaazPay 常见问题：市场覆盖、结算、开户与接入', '关于 KaazPay 的常见问题解答：支持的国家与支付方式、USDT 结算、费率、开户流程、API 接入、代付与合规。'] },
    '/glossary': { en: ['Payment Glossary: Pay-in, Payout, Settlement & Local Methods | KaazPay', 'Plain definitions of cross-border payment terms: pay-in, payout, settlement cycles, USDT networks, chargebacks, KYC and local methods such as FPX, DuitNow, PayNow, QRIS, Pix and SPEI.'], zh: ['支付术语表：代收、代付、结算与本地支付方式 | KaazPay', '跨境支付常用术语的清晰定义：代收、代付、结算周期、USDT 网络、拒付、KYC，以及 FPX、DuitNow、PayNow、QRIS、Pix、SPEI 等本地支付方式。'] },
    '/industries': { en: ['Payment Solutions by Industry | KaazPay', 'Local pay-in and payouts for gaming, e-commerce, live streaming, Web3, AI and digital content, travel, education and global payroll. One API, USDT settlement.'], zh: ['行业支付方案 | KaazPay', '为游戏、跨境电商、直播社交、Web3、AI 与数字内容、旅游、教育及全球薪酬场景提供本地代收与代付。一个 API 接入，USDT 结算。'] },
    '/capabilities': { en: ['Platform: Collect, Route, Settle & Pay Out | KaazPay', 'Local acquiring, card acquiring, smart routing, USDT settlement, payouts and risk controls, all from one KaazPay merchant account.'], zh: ['平台能力：收款、路由、结算与代付 | KaazPay', '本地收单、国际信用卡收单、智能路由、USDT 结算、本地代付与风控，全部集中在一个 KaazPay 商户账户。'] },
    '/developers': { en: ['Developers: Go Live with the KaazPay API in 4 Steps', 'Open an account, receive API keys, integrate with engineer support and go live. Signed requests, webhooks and joint testing included.'], zh: ['开发者：4 步接入 KaazPay API', '开通账户、获取 API 密钥、工程师协助联调、正式上线。支持请求签名、异步通知与联合测试。'] },
    '/contact': { en: ['Contact Sales on Telegram | KaazPay', 'Message @KaazPayEZ or @KaazPay_BD2 on Telegram with your target markets and expected volume. We reply within one business day.'], zh: ['通过 Telegram 联系商务团队 | KaazPay', '通过 Telegram 联系 @KaazPayEZ 或 @KaazPay_BD2，说明目标市场与预计交易量。我们将在 1 个工作日内回复。'] },
    '/roadmap': { en: ['Roadmap: Milestones Since 2018 and What\'s Next | KaazPay', 'KaazPay milestones since 2018: from the first local payment channels to pay-in across four regions, local payouts and international card acquiring, and what comes next.'], zh: ['发展路线图：2018 年至今的里程碑与规划 | KaazPay', 'KaazPay 自 2018 年以来的里程碑：从首批本地支付通道，到覆盖四大区域的代收、本地代付与国际信用卡收单，以及下一步规划。'] },
    '/methods': { en: ['Payment Methods: DuitNow, FPX, PayNow, QRIS, Cards & More | KaazPay', 'All payment methods KaazPay supports, including DuitNow, FPX, Thai QR, PayNow, QRIS, Visa, Mastercard, UnionPay, JCB, Apple Pay and Cash App, and where each is available.'], zh: ['支付方式：DuitNow、FPX、PayNow、QRIS、信用卡等 | KaazPay', 'KaazPay 支持的全部支付方式，包括 DuitNow、FPX、泰国 QR、PayNow、QRIS、Visa、Mastercard、银联、JCB、Apple Pay 与 Cash App，以及各自的可用市场。'] },
    '/guides': { en: ['Cross-border Payment Guides by Market | KaazPay', 'Guides to local payment methods, payouts and USDT settlement in markets across Asia Pacific, the Americas, Europe, the Middle East and Africa.'], zh: ['跨境支付指南：各市场收款与代付 | KaazPay', '亚太、美洲、欧洲、中东与非洲各市场的本地支付方式、代付与 USDT 结算指南。'] },
    '/compare': { en: ['Payment Comparisons: Methods, Settlement & Gateways | KaazPay', 'Side-by-side comparisons: Apple Pay vs Cash App, Pix vs Boleto, cards vs local methods, USDT vs local-currency settlement and more.'], zh: ['支付对比：支付方式、结算模式与网关选择 | KaazPay', '对比 Apple Pay 与 Cash App、Pix 与 Boleto、信用卡与本地支付方式、USDT 与本币结算等常见选择。'] },
    '/about': { en: ['About KaazPay | Cross-border Payment Gateway', `KaazPay is a cross-border payment gateway: local pay-in in ${COVERAGE_STATS.markets} markets, payouts in ${COVERAGE_STATS.payoutMarkets}, international card acquiring and settlement in USDT.`], zh: ['关于 KaazPay | 跨境支付网关', `KaazPay 是跨境支付网关，在全球 ${COVERAGE_STATS.markets} 个市场提供本地代收、${COVERAGE_STATS.payoutMarkets} 个市场提供本地代付，并支持国际信用卡收单，资金统一以 USDT 结算。`] },
};

const joinList = (arr, zh) => {
    if (zh) return arr.join('、');
    if (arr.length <= 1) return arr.join('');
    return `${arr.slice(0, -1).join(', ')} and ${arr[arr.length - 1]}`;
};

/** Method names for one market's page, shortened ("Brazil Bank Transfer" -> "Bank Transfer") and translated on Chinese pages. */
const marketMethodLabels = (market, l) => [...new Set(market.payin.map((m) => methodLabel(m, l, market)))];
const titleMethods = (market, sep, l) => marketMethodLabels(market, l).slice(0, 2).join(sep);

/** Plain-language facts about one market — reused by the page body, FAQ and JSON-LD. */
export const marketCopy = (market, l) => {
    const zh = isZh(l);
    const name = marketName(market, l);
    const labels = marketMethodLabels(market, l);
    const methods = joinList(labels, zh);
    const methodsShort = labels.length > 4 ? `${joinList(labels.slice(0, 3), zh).replace(/ and /, ', ')}${zh ? '等' : ' and more'}` : methods;
    const payout = hasPayout(market);
    const payoutList = payout ? joinList([...new Set(market.payout.map((m) => methodLabel(m, l, market)))], zh) : '';
    // Method types in brackets only when they add information (not when the method names already say "Bank Transfer"/"QR");
    // lower-case ordinary words but keep acronyms such as QR.
    const types = [...new Set(market.payin.map(methodType))].map((t) => methodTypeName(t, l))
        .filter((n) => !methods.toLowerCase().includes(n.toLowerCase()) && !(zh && methods.includes(n.replace(/支付$/, ''))))
        .map((n) => (zh ? n : n.split(' ').map((w) => (/^[A-Z]{2,}/.test(w) ? w : w.toLowerCase())).join(' ')));
    const typesNote = types.length ? (zh ? `（${joinList(types, true)}）` : ` (${joinList(types, false)})`) : '';
    const isGlobal = !!market.networks; // global USDT (crypto networks)
    const networks = joinList(market.networks || [], zh);

    if (market.cardBrands) return cardCopy(market, zh);

    if (zh) {
        return {
            title: isGlobal ? 'USDT 代收与代付通道（5 条网络）| KaazPay' : `${name}${payout ? '代收代付通道' : '代收通道'}：${titleMethods(market, '、', l)} | KaazPay`,
            h1: isGlobal ? 'USDT 代收与代付，5 条网络' : `在${name}收款${payout ? '与代付' : ''}`,
            description: isGlobal
                ? `通过 KaazPay 在 ${networks} 上收取与代付 USDT，充值与提现实时通知，全球商户均可申请开通。`
                : `KaazPay 在${name}提供${sp(methodsShort)}代收（${market.currency}）${payout ? `与${sp(payoutList)}代付` : ''}，一个 API 接入，资金以 USDT 结算。`.replace(/ +/g, ' '),
            intro: isGlobal
                ? `KaazPay 的 USDT 通道支持 ${networks} 共 ${market.networks.length} 条网络的充值（代收）与提现（代付），适合需要链上收付的全球商户，结算同样以 USDT 进行。`
                : `${name}的顾客可通过${sp(methods).trimEnd()}${typesNote}付款，币种为 ${market.currency}。${payout ? `您还可以通过同一个商户账户，以${sp(payoutList)}方式向${name}的收款人代付。`.replace(/ +/g, ' ') : '该市场目前仅支持代收，代付暂未开通。'}所有收款均按等值 USDT 结算给您。`,
            faq: [
                isGlobal
                    ? { q: 'KaazPay 的 USDT 通道支持哪些区块链网络？', a: `共 ${market.networks.length} 条：${networks}。充值与提现均可使用。` }
                    : { q: `KaazPay 在${name}支持哪些收款方式？`, a: `目前支持 ${market.payin.length} 种代收方式：${methods}，收款币种为 ${market.currency}。` },
                { q: `KaazPay 是否支持${name}代付？`, a: payout ? `支持。您可以通过${sp(payoutList)}向${name}的收款人代付（${market.currency}），支持单笔与批量，具体限额请向商务经理确认。`.replace(/ +/g, ' ') : `${name}目前仅开放代收。如需代付，请通过 Telegram 联系我们，我们将评估开通计划。` },
                { q: `${name}的收款如何结算？`, a: `顾客以 ${market.currency} 付款，KaazPay 按等值 USDT 结算给您。许多通道支持 D+0 结算，其余为 D+1 或更长；各通道的结算周期与费率在上线前逐一确认。` },
                { q: `开通${name}通道需要多久？`, a: '收到您的 Telegram 消息后，我们将在 1 个工作日内回复。完成开户审核、获取 API 密钥并通过联调测试后即可上线。' },
            ],
        };
    }
    return {
        title: isGlobal ? 'USDT Pay-in & Payouts on 5 Networks | KaazPay' : `${name} Payment Gateway: ${titleMethods(market, ' & ', l)}${payout ? ' + Payouts' : ''} | KaazPay`,
        h1: isGlobal ? 'USDT pay-in and payouts on five networks' : `Accept payments${payout ? ' and send payouts' : ''} in ${name}`,
        description: isGlobal
            ? `Collect and pay out USDT on ${networks} with KaazPay. Real-time deposit and withdrawal notifications, open to merchants worldwide.`
            : `Collect ${market.currency} in ${name} with ${methodsShort}${payout ? ` and pay out via ${payoutList}` : ''}. One KaazPay API, with settlement in USDT.`,
        intro: isGlobal
            ? `KaazPay's USDT channel handles deposits (pay-in) and withdrawals (payouts) on ${market.networks.length} networks — ${networks} — for merchants anywhere. Settlement is in USDT as well.`
            : `Customers in ${name} can pay in ${market.currency} through ${methods}${typesNote}.${payout ? ` From the same merchant account, you can also send payouts to recipients in ${name} via ${payoutList}.` : ' This market currently supports pay-in only; payouts are not yet available.'} All collections are settled to you in USDT at the equivalent amount.`,
        faq: [
            isGlobal
                ? { q: 'Which blockchain networks does the KaazPay USDT channel support?', a: `${market.networks.length} networks: ${networks}, for both deposits and withdrawals.` }
                : { q: `Which payment methods does KaazPay support in ${name}?`, a: `${market.payin.length} pay-in method${market.payin.length > 1 ? 's' : ''}: ${methods}, collected in ${market.currency}.` },
            { q: `Does KaazPay support payouts in ${name}?`, a: payout ? `Yes. You can send ${market.currency} payouts to recipients in ${name} via ${payoutList}, individually or in batches. Your account manager confirms the limits.` : `${name} currently supports pay-in only. If you need payouts there, contact us on Telegram and we will assess availability.` },
            { q: `How are collections in ${name} settled?`, a: `Customers pay in ${market.currency}, and KaazPay settles the equivalent amount to you in USDT. Many channels settle D+0, others D+1 or later; the cycle and pricing for each channel are confirmed before go-live.` },
            { q: `How long does it take to go live in ${name}?`, a: 'We reply within one business day of your Telegram message. Once account review, API keys and joint testing are complete, you can go live.' },
        ],
    };
};

/** Copy for the global card-acquiring channel (Visa / Mastercard / UnionPay), which has no single country or currency. */
const cardCopy = (market, zh) => {
    const brands = market.payin.map((p) => p.replace(/ Card$/, ''));
    if (zh) {
        const list = joinList(brands.map((b) => (b === 'UnionPay' ? '银联 UnionPay' : b)), true);
        return {
            title: '国际信用卡收单通道：Visa、Mastercard、银联 | KaazPay',
            h1: '向全球持卡人收款',
            description: `通过 KaazPay 接入 ${list} 国际信用卡与借记卡收单，支持多币种交易，资金以 USDT 结算；日本另支持 JCB 本地收单。`,
            intro: `KaazPay 国际卡通道支持向全球持卡人收取 ${list} 信用卡与借记卡付款，支持多币种交易，收款按等值 USDT 结算。该通道仅支持代收；如需代付，可使用各市场的本地代付或 USDT 代付。`,
            faq: [
                { q: 'KaazPay 支持哪些卡组织？', a: `国际卡通道支持 ${market.payin.length} 个卡组织：${list}；日本市场另支持 JCB 卡代收。` },
                { q: '国际卡通道是否支持代付？', a: '不支持，国际卡通道仅支持代收。代付请使用各市场的本地代付或 USDT 代付。' },
                { q: '哪些业务适合国际卡收单？', a: '面向多国顾客的跨境电商、数字内容订阅、旅游预订、SaaS 与应用内购买等。是否适用，由商务经理在审核时确认。' },
                { q: '如何开通国际卡收单？', a: '请通过 Telegram 告知您的行业、目标地区与交易量，我们将在 1 个工作日内回复。审核开户完成后即可对接上线。' },
            ],
        };
    }
    const list = joinList(brands, false);
    return {
        title: 'International Card Acquiring: Visa, Mastercard & UnionPay | KaazPay',
        h1: 'Accept card payments from cardholders worldwide',
        description: `Accept ${list} credit and debit cards with KaazPay — multi-currency acquiring settled in USDT, plus local JCB acquiring in Japan.`,
        intro: `KaazPay's international card channel lets you accept ${list} credit and debit cards issued worldwide, in multiple currencies, with collections settled to you in USDT at the equivalent amount. The channel supports pay-in only; for payouts, use local payout rails or USDT payouts.`,
        faq: [
            { q: 'Which card networks does KaazPay accept?', a: `${market.payin.length} international networks on this channel: ${list}. JCB is available for pay-in in Japan.` },
            { q: 'Does the international card channel support payouts?', a: 'No. The international card channel supports pay-in only. For payouts, use local payout rails or USDT payouts.' },
            { q: 'Which businesses is international card acquiring suited to?', a: 'Cross-border e-commerce, digital subscriptions, travel bookings, SaaS and in-app purchases serving customers in many countries. Your account manager confirms eligibility during review.' },
            { q: 'How do I start accepting cards?', a: 'Contact us on Telegram with your industry, target regions and expected volume. We reply within one business day; once review is complete, you can integrate and go live.' },
        ],
    };
};

const ORG = {
    '@type': 'Organization',
    '@id': `${SITE_URL}/#org`,
    name: 'KaazPay',
    alternateName: ['Kaaz Pay', 'KaazPay Payments'],
    url: SITE_URL,
    logo: { '@type': 'ImageObject', url: `${SITE_URL}/logo-512.png`, width: 512, height: 512 },
    image: `${SITE_URL}/og-image.png`,
    description: 'KaazPay is a cross-border payment gateway that provides local pay-in (collection) and payout channels across the Americas, Europe, the Middle East, Africa and Asia Pacific, plus international Visa, Mastercard and UnionPay card acquiring and JCB acquiring in Japan, with settlement in USDT.',
    // Topics an answer engine can associate with the brand (GEO).
    knowsAbout: ['Cross-border payments', 'Payment gateway', 'DuitNow', 'Thai QR Payment', 'PromptPay', 'PayNow', 'Local payment methods', 'Pay-in (collection)', 'Payouts', 'Mass payouts', 'Card acquiring',
        'Visa', 'Mastercard', 'UnionPay', 'JCB', 'Apple Pay', 'Google Pay', 'Cash App', 'USDT payments', 'USDT settlement',
        'Pix', 'SPEI', 'PSE', 'M-Pesa', 'Mobile money', 'GCash', 'QRIS', 'FPX', 'DuitNow', 'Smart payment routing'],
    sameAs: [tgUrl(TG_CHANNEL)],
    slogan: 'Get paid globally, like a local.',
    areaServed: ['North America', 'Latin America', 'Europe', 'Middle East', 'Asia Pacific', 'Africa'],
    contactPoint: TG_SALES.map((u) => ({ '@type': 'ContactPoint', contactType: 'sales', url: tgUrl(u), availableLanguage: ['English', 'Chinese'] })),
    potentialAction: { '@type': 'CommunicateAction', target: `${SITE_URL}/contact`, name: 'Contact KaazPay sales on Telegram' },
};

const fill = (str) => str.replace(/{{markets}}/g, COVERAGE_STATS.markets).replace(/{{payout}}/g, COVERAGE_STATS.payoutMarkets);

/** Absolute URL of a (language-neutral) path in language l. */
const abs = (p, l) => `${SITE_URL}${localizePath(p, isZh(l) ? 'zh' : 'en')}`;
const crumbs = (l, items) => ({
    '@type': 'BreadcrumbList',
    itemListElement: [{ name: 'KaazPay', path: '/' }, ...items].map((it, i) => ({ '@type': 'ListItem', position: i + 1, name: it.name, item: abs(it.path, l) })),
});
const faqLd = (faq) => ({ '@type': 'FAQPage', mainEntity: faq.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })) });
const COVERAGE_CRUMB = (l) => ({ name: isZh(l) ? '支付通道' : 'Payment coverage', path: '/#coverage' });
const METHODS_CRUMB = (l) => ({ name: isZh(l) ? '支付方式' : 'Payment methods', path: '/methods' });
const INDUSTRIES_CRUMB = (l) => ({ name: isZh(l) ? '行业方案' : 'Industries', path: '/industries' });

const homeJsonLd = (l) => [{
    '@context': 'https://schema.org',
    '@graph': [
        ORG,
        {
            '@type': 'FAQPage',
            mainEntity: ['countries', 'payout', 'settlement', 'highrisk', 'conversion', 'liquidity', 'integration']
                .map((k) => (isZh(l) ? zhLocale : en).home.faq.questions[k])
                .filter(Boolean)
                .map((f) => ({ '@type': 'Question', name: fill(f.q), acceptedAnswer: { '@type': 'Answer', text: fill(f.a) } })),
        },
        { '@type': 'WebSite', '@id': `${SITE_URL}/#website`, url: SITE_URL, name: 'KaazPay', inLanguage: ['en', 'zh-Hans'], publisher: { '@id': `${SITE_URL}/#org` } },
        {
            '@type': 'Service',
            name: 'KaazPay local payment methods and payouts',
            serviceType: 'Payment gateway',
            provider: { '@id': `${SITE_URL}/#org` },
            areaServed: MARKETS.filter((m) => m.iso && m.iso !== 'eu').map((m) => ({ '@type': 'Country', name: m.name.en })),
            hasOfferCatalog: {
                '@type': 'OfferCatalog',
                name: 'Payment channels by region',
                itemListElement: REGIONS.map((r) => ({
                    '@type': 'OfferCatalog',
                    name: regionName(r.key, l),
                    itemListElement: MARKETS.filter((m) => m.region === r.key).map((m) => ({
                        '@type': 'Offer',
                        url: abs(`/payment-methods/${m.slug}`, l),
                        itemOffered: { '@type': 'Service', name: `${m.name.en} payments: ${m.payin.join(', ')}` },
                    })),
                })),
            },
        },
    ],
}];

const marketJsonLd = (market, l) => {
    const copy = marketCopy(market, l);
    return [{
        '@context': 'https://schema.org',
        '@graph': [
            ORG,
            {
                '@type': 'Service',
                name: copy.h1,
                url: abs(`/payment-methods/${market.slug}`, l),
                serviceType: 'Payment gateway',
                provider: { '@id': `${SITE_URL}/#org` },
                ...(market.iso && market.iso !== 'eu' ? { areaServed: { '@type': 'Country', name: market.name.en } } : {}),
                description: copy.description,
                availableChannel: market.payin.map((p) => ({ '@type': 'ServiceChannel', name: methodLabel(p, l) })),
            },
            faqLd(copy.faq),
            crumbs(l, [COVERAGE_CRUMB(l), { name: marketName(market, l), path: `/payment-methods/${market.slug}` }]),
        ],
    }];
};

/* ---------- Payment-method pages (/methods/:slug) ---------- */

/** Where a method is available, in words: "Brazil", "Kenya and Tanzania", "worldwide". */
const placeList = (markets, l, short = false) => {
    const zh = isZh(l);
    if (markets.some((m) => m.cardBrands)) return zh ? '全球' : 'worldwide';
    if (short && markets.length > 4) return zh ? `${markets.length} 个市场` : `${markets.length} markets`;
    return joinList(markets.map((m) => marketName(m, l)), zh);
};

/** Chinese copy: put spaces around Latin words / numbers ("在 12 个市场接入 Pix 代收"). */
const sp = (x) => `${/^[ -~]/.test(x) ? ' ' : ''}${x}${/[ -~]$/.test(x) ? ' ' : ''}`;

export const methodCopy = (method, l) => {
    const zh = isZh(l);
    const name = methodName(method, l);
    const { payin, payout } = methodMarkets(method);
    const where = placeList(payin, l);
    const whereShort = placeList(payin, l, true);
    const whereOut = placeList(payout, l);
    const payoutOnly = !payin.length;
    const single = payin.length === 1 && !payin[0].cardBrands ? marketName(payin[0], l) : null;
    const about = method.about[zh ? 'zh' : 'en'];
    const steps = (zh ? zhLocale : en).developers?.steps;
    const howTo = steps ? Object.values(steps).map((s, i) => `${i + 1}. ${s.title}`).join(zh ? '；' : '; ') : '';

    if (zh) {
        return {
            title: payoutOnly ? `${name} 代付：向${whereOut}收款人付款 | KaazPay` : `接入 ${name}${single ? `（${single}）` : ''}：代收${payout.length ? '与代付' : ''} API | KaazPay`,
            h1: payoutOnly ? `通过 KaazPay 代付到 ${name}` : `通过 KaazPay 接入 ${name}`,
            description: payoutOnly
                ? `通过 KaazPay 向${whereOut}的 ${name} 账户代付：支持单笔与批量，状态实时回调，资金以 USDT 结算。`
                : `通过一个 KaazPay API，在${sp(whereShort)}接入${sp(name)}代收${payout.length ? '与代付' : ''}，工程师协助联调，资金以 USDT 结算。`.replace(/ +/g, ' '),
            about,
            faq: [
                { q: `${name} 是什么？`, a: about },
                payoutOnly
                    ? { q: `KaazPay 支持向哪些市场的 ${name} 账户代付？`, a: `目前支持向${whereOut}的 ${name} 账户代付。` }
                    : { q: `KaazPay 在哪些市场支持 ${name}？`, a: `目前在${where}支持 ${name} 代收${payin.length > 1 && !payin[0].cardBrands ? `，共 ${payin.length} 个市场` : ''}。` },
                ...(payoutOnly ? [] : [{ q: `${name} 是否支持代付？`, a: payout.length ? `支持。KaazPay 在${whereOut}支持 ${name} 代付。` : `${name} 目前仅支持代收。如需在当地代付，可使用银行转账或 USDT 代付，详情请通过 Telegram 联系我们。` }]),
                { q: `接入 ${name} 需要哪些步骤？`, a: `共 4 步：${howTo}。通过 Telegram 联系我们后，我们将在 1 个工作日内回复。` },
            ],
        };
    }
    return {
        title: payoutOnly ? `${name} Payouts: Pay Recipients in ${whereOut} | KaazPay` : `${name} Payments API${single ? ` for ${single}` : ''}: Pay-in${payout.length ? ' & Payouts' : ''} | KaazPay`,
        h1: payoutOnly ? `Send payouts to ${name} with KaazPay` : `Accept ${name} with KaazPay`,
        description: payoutOnly
            ? `Send payouts to ${name} accounts in ${whereOut} through KaazPay: single or batch payouts, real-time status callbacks and USDT settlement.`
            : `Accept ${name} ${whereShort === 'worldwide' ? whereShort : `in ${whereShort}`}${payout.length ? ' for pay-in and payouts' : ''} through one KaazPay API, with engineer-supported integration and USDT settlement.`,
        about,
        faq: [
            { q: `What is ${name}?`, a: about },
            payoutOnly
                ? { q: `Where can KaazPay send ${name} payouts?`, a: `To ${name} accounts in ${whereOut}.` }
                : { q: `In which markets does KaazPay support ${name}?`, a: `${name} pay-in is available ${where === 'worldwide' ? where : `in ${where}`}${payin.length > 1 && !payin[0].cardBrands ? ` (${payin.length} markets)` : ''}.` },
            ...(payoutOnly ? [] : [{ q: `Does ${name} support payouts?`, a: payout.length ? `Yes. KaazPay supports ${name} payouts in ${whereOut}.` : `${name} supports pay-in only. For local payouts, use bank transfer or USDT payouts; contact us on Telegram for details.` }]),
            { q: `What are the steps to integrate ${name}?`, a: `Four steps: ${howTo}. Contact us on Telegram and we reply within one business day.` },
        ],
    };
};

const methodJsonLd = (method, l) => {
    const copy = methodCopy(method, l);
    const { payin, payout } = methodMarkets(method);
    const countries = [...payin, ...payout].filter((m) => m.iso && m.iso !== 'eu');
    return [{
        '@context': 'https://schema.org',
        '@graph': [
            ORG,
            {
                '@type': 'Service',
                name: copy.h1,
                url: abs(`/methods/${method.slug}`, l),
                serviceType: 'Payment gateway',
                provider: { '@id': `${SITE_URL}/#org` },
                description: copy.description,
                ...(countries.length ? { areaServed: [...new Set(countries.map((m) => m.name.en))].map((n) => ({ '@type': 'Country', name: n })) } : {}),
            },
            faqLd(copy.faq),
            crumbs(l, [METHODS_CRUMB(l), { name: methodName(method, l), path: `/methods/${method.slug}` }]),
        ],
    }];
};

const methodsIndexJsonLd = (l) => [{
    '@context': 'https://schema.org',
    '@graph': [
        ORG,
        {
            '@type': 'ItemList',
            name: isZh(l) ? 'KaazPay 支持的支付方式' : 'Payment methods supported by KaazPay',
            itemListElement: METHODS.map((m, i) => ({ '@type': 'ListItem', position: i + 1, name: methodName(m, l), url: abs(`/methods/${m.slug}`, l) })),
        },
        crumbs(l, [METHODS_CRUMB(l)]),
    ],
}];

/* ---------- Industry pages (/industries/:id) ---------- */

export const industryCopy = (industry, l) => {
    const loc = (isZh(l) ? zhLocale : en).industries.items[industry.id] || {};
    const [title, description] = industry.seo[isZh(l) ? 'zh' : 'en'];
    return { title: `${title} | KaazPay`, description, name: loc.title, tagline: loc.tagline, content: loc.content, features: Object.values(loc.features || {}) };
};

const industryJsonLd = (industry, l) => {
    const copy = industryCopy(industry, l);
    return [{
        '@context': 'https://schema.org',
        '@graph': [
            ORG,
            { '@type': 'Service', name: copy.title.replace(' | KaazPay', ''), url: abs(`/industries/${industry.id}`, l), serviceType: 'Payment gateway', provider: { '@id': `${SITE_URL}/#org` }, audience: { '@type': 'BusinessAudience', name: copy.name }, description: copy.description },
            crumbs(l, [INDUSTRIES_CRUMB(l), { name: copy.name, path: `/industries/${industry.id}` }]),
        ],
    }];
};

/* ---------- Content hub (/guides, /compare) ---------- */

// Full article bodies are registered at build time (entry-server) so the prerendered JSON-LD carries
// the summary and FAQ; the browser never needs them (it only updates title/description on navigation).
let BODIES = {};
export const setArticleBodies = (map) => { BODIES = map || {}; };

const articleJsonLd = (a, l) => {
    const c = articleLang(a, l);
    const body = BODIES[a.slug]?.[isZh(l) ? 'zh' : 'en'];
    const url = abs(articlePath(a), l);
    const kind = KINDS[a.kind];
    return [{
        '@context': 'https://schema.org',
        '@graph': [
            ORG,
            {
                '@type': a.kind === 'compare' ? 'Article' : 'TechArticle',
                '@id': `${url}#article`,
                headline: c.h1,
                description: c.description,
                ...(body ? { abstract: plain(body.summary) } : {}),
                inLanguage: isZh(l) ? 'zh-Hans' : 'en',
                datePublished: a.published,
                dateModified: a.updated || a.published,
                author: { '@id': `${SITE_URL}/#org` },
                publisher: { '@id': `${SITE_URL}/#org` },
                mainEntityOfPage: url,
                image: ogImage(isZh(l) ? 'zh' : 'en'),
                articleSection: kind[isZh(l) ? 'zh' : 'en'],
                about: [...(a.related?.methods || []).map((m) => getMethod(m)).filter(Boolean).map((m) => ({ '@type': 'Thing', name: methodName(m, 'en') })),
                    ...(a.related?.markets || []).map((m) => getMarket(m)).filter((m) => m?.iso && m.iso !== 'eu').map((m) => ({ '@type': 'Country', name: m.name.en }))],
            },
            ...(body ? [faqLd(body.faq.map((f) => ({ q: plain(f.q), a: plain(f.a) })))] : []),
            crumbs(l, [{ name: kind[isZh(l) ? 'zh' : 'en'], path: kind.path }, { name: c.h1, path: articlePath(a) }]),
        ],
    }];
};

const hubJsonLd = (kind, l) => [{
    '@context': 'https://schema.org',
    '@graph': [
        ORG,
        {
            '@type': 'CollectionPage',
            name: KINDS[kind][isZh(l) ? 'zh' : 'en'],
            url: abs(KINDS[kind].path, l),
            mainEntity: { '@type': 'ItemList', itemListElement: articlesOfKind(kind).map((a, i) => ({ '@type': 'ListItem', position: i + 1, name: articleLang(a, l).h1, url: abs(articlePath(a), l) })) },
        },
        crumbs(l, [{ name: KINDS[kind][isZh(l) ? 'zh' : 'en'], path: KINDS[kind].path }]),
    ],
}];

/* ---------- Static pages: page type + breadcrumbs (+ HowTo / milestone list where the page has one) ---------- */
const PAGE_TYPE = { '/faq': 'FAQPage', '/glossary': 'CollectionPage', '/about': 'AboutPage', '/contact': 'ContactPage', '/roadmap': 'WebPage', '/developers': 'WebPage', '/capabilities': 'WebPage', '/industries': 'CollectionPage' };
const staticJsonLd = (path, l, title, description) => {
    const zh = isZh(l);
    const loc = zh ? zhLocale : en;
    const name = title.split(' | ')[0];
    const graph = [
        path === '/roadmap' ? { ...ORG, foundingDate: FOUNDED } : ORG,
        { '@type': PAGE_TYPE[path] || 'WebPage', '@id': `${abs(path, l)}#webpage`, url: abs(path, l), name, description, inLanguage: zh ? 'zh-Hans' : 'en', isPartOf: { '@id': `${SITE_URL}/#website` }, about: { '@id': `${SITE_URL}/#org` } },
        crumbs(l, [{ name, path }]),
    ];
    if (path === '/developers') {
        graph.push({
            '@type': 'HowTo',
            name: zh ? '如何接入 KaazPay' : 'How to integrate KaazPay',
            description: loc.developers.description,
            step: Object.values(loc.developers.steps).map((st, i) => ({ '@type': 'HowToStep', position: i + 1, name: st.title, text: st.desc })),
        });
    }
    if (path === '/roadmap') {
        graph.push({
            '@type': 'ItemList',
            name: zh ? 'KaazPay 发展里程碑' : 'KaazPay milestones since 2018',
            itemListElement: MILESTONES.filter((m) => m.year).map((m, i) => ({ '@type': 'ListItem', position: i + 1, name: `${m.date} — ${loc.roadmap.milestones[m.key].title}`, description: loc.roadmap.milestones[m.key].desc })),
        });
    }
    if (path === '/contact') {
        graph[1].mainEntity = { '@id': `${SITE_URL}/#org` };
    }
    if (path === '/faq') {
        graph[1].mainEntity = FAQ_ALL(zh ? 'zh' : 'en').map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } }));
    }
    if (path === '/glossary') {
        graph.push({
            '@type': 'DefinedTermSet',
            '@id': `${abs(path, l)}#terms`,
            name: name,
            inLanguage: zh ? 'zh-Hans' : 'en',
            hasDefinedTerm: GLOSSARY.map((g) => ({
                '@type': 'DefinedTerm',
                '@id': `${abs(path, l)}#${g.id}`,
                name: g[zh ? 'zh' : 'en'].term,
                ...(g[zh ? 'zh' : 'en'].aka?.length ? { alternateName: g[zh ? 'zh' : 'en'].aka } : {}),
                description: `${g[zh ? 'zh' : 'en'].short} ${g[zh ? 'zh' : 'en'].body}`,
                url: `${abs(path, l)}#${g.id}`,
                inDefinedTermSet: `${abs(path, l)}#terms`,
            })),
        });
    }
    return [{ '@context': 'https://schema.org', '@graph': graph }];
};

/* ---------- Routing ---------- */

/** Language-neutral routes; each is prerendered once per language (/... and /zh/...). */
export const BASE_ROUTES = [
    ...Object.keys(STATIC),
    ...MARKETS.map((m) => `/payment-methods/${m.slug}`),
    ...METHODS.map((m) => `/methods/${m.slug}`),
    ...INDUSTRIES.map((i) => `/industries/${i.id}`),
    ...ARTICLES.map(articlePath),
];

/** Content date per route (articles carry their own), for sitemap lastmod. */
export const ROUTE_DATES = Object.fromEntries(ARTICLES.map((a) => [articlePath(a), a.updated || a.published]));
export const PRERENDER_ROUTES = LANGS.flatMap((lang) => BASE_ROUTES.map((r) => localizePath(r, lang)));

const NOT_FOUND = { en: ['Page not found | KaazPay', 'The page you requested does not exist. Go to KaazPay payment channels, payment methods or guides.'], zh: ['页面不存在 | KaazPay', '您访问的页面不存在。请前往 KaazPay 支付通道、支付方式或支付指南。'] };

const route = (path, l) => {
    let m;
    if ((m = path.match(/^\/payment-methods\/([^/]+)$/)) && getMarket(m[1])) {
        const market = getMarket(m[1]);
        const copy = marketCopy(market, l);
        return { title: copy.title, description: copy.description, jsonLd: marketJsonLd(market, l) };
    }
    if ((m = path.match(/^\/methods\/([^/]+)$/)) && getMethod(m[1])) {
        const method = getMethod(m[1]);
        const copy = methodCopy(method, l);
        return { title: copy.title, description: copy.description, jsonLd: methodJsonLd(method, l) };
    }
    if ((m = path.match(/^\/industries\/([^/]+)$/)) && getIndustry(m[1])) {
        const industry = getIndustry(m[1]);
        const copy = industryCopy(industry, l);
        return { title: copy.title, description: copy.description, jsonLd: industryJsonLd(industry, l) };
    }
    if ((m = path.match(/^\/(guides|compare)\/([^/]+)$/))) {
        const a = getArticle(m[1] === 'guides' ? 'guide' : 'compare', m[2]);
        if (a) {
            const c = articleLang(a, l);
            return { title: `${c.title} | KaazPay`, description: c.description, jsonLd: articleJsonLd(a, l), ogType: 'article' };
        }
    }
    if (STATIC[path]) {
        const [title, description] = STATIC[path][isZh(l) ? 'zh' : 'en'];
        const jsonLd = path === '/' ? homeJsonLd(l) : path === '/methods' ? methodsIndexJsonLd(l)
            : path === '/guides' ? hubJsonLd('guide', l) : path === '/compare' ? hubJsonLd('compare', l)
                : staticJsonLd(path, l, title, description);
        return { title, description, jsonLd };
    }
    return null;
};

/**
 * SEO data for a URL path; the language comes from the path itself (/zh/... = Chinese).
 * Returns { title, description, canonical, alternates: {en, zh}, lang, noindex, jsonLd }
 */
export const getSeo = (pathname) => {
    const full = normalizePath(pathname);
    const lang = langFromPath(full);
    const path = stripLocale(full);
    const hit = route(path, lang);
    if (!hit) {
        const [title, description] = NOT_FOUND[lang];
        return { title, description, canonical: abs('/', lang), alternates: null, lang, noindex: true, jsonLd: [] };
    }
    return { ...hit, canonical: abs(path, lang), alternates: { en: abs(path, 'en'), zh: abs(path, 'zh') }, lang, noindex: false };
};

export const OG_LOCALE = { en: 'en_US', zh: 'zh_CN' };
/** Social share image per language. */
export const ogImage = (lang) => `${SITE_URL}/${lang === 'zh' ? 'og-image-zh.png' : 'og-image.png'}`;

/** Apply SEO data to document.head on the client. */
export const applySeo = (seo) => {
    if (typeof document === 'undefined') return;
    document.title = seo.title;
    const set = (selector, attr, value, create) => {
        let el = document.head.querySelector(selector);
        if (!el && create) { el = create(); document.head.appendChild(el); }
        if (el) el.setAttribute(attr, value);
    };
    const meta = (key, isProp) => () => { const e = document.createElement('meta'); e.setAttribute(isProp ? 'property' : 'name', key); return e; };
    const link = (rel, hreflang) => () => { const e = document.createElement('link'); e.setAttribute('rel', rel); if (hreflang) e.setAttribute('hreflang', hreflang); return e; };
    set('meta[name="description"]', 'content', seo.description, meta('description'));
    set('meta[name="robots"]', 'content', seo.noindex ? 'noindex,follow' : 'index,follow,max-image-preview:large', meta('robots'));
    set('meta[property="og:title"]', 'content', seo.title, meta('og:title', true));
    set('meta[property="og:description"]', 'content', seo.description, meta('og:description', true));
    set('meta[property="og:url"]', 'content', seo.canonical, meta('og:url', true));
    set('meta[property="og:locale"]', 'content', OG_LOCALE[seo.lang], meta('og:locale', true));
    set('meta[property="og:image"]', 'content', ogImage(seo.lang), meta('og:image', true));
    set('meta[property="og:type"]', 'content', seo.ogType || 'website', meta('og:type', true));
    set('meta[name="twitter:image"]', 'content', ogImage(seo.lang), meta('twitter:image'));
    set('meta[name="twitter:title"]', 'content', seo.title, meta('twitter:title'));
    set('meta[name="twitter:description"]', 'content', seo.description, meta('twitter:description'));
    set('link[rel="canonical"]', 'href', seo.canonical, link('canonical'));
    document.head.querySelectorAll('link[rel="alternate"][hreflang]').forEach((e) => e.remove());
    if (seo.alternates) {
        for (const [hl, href] of [['en', seo.alternates.en], ['zh-Hans', seo.alternates.zh], ['x-default', seo.alternates.en]]) {
            const e = link('alternate', hl)();
            e.setAttribute('href', href);
            document.head.appendChild(e);
        }
    }
};

/** <head> tags for a prerendered page (hreflang + og:locale), as HTML. */
export const headTags = (seo) => [
    `<meta property="og:locale" content="${OG_LOCALE[seo.lang]}" />`,
    `<meta property="og:locale:alternate" content="${OG_LOCALE[seo.lang === 'zh' ? 'en' : 'zh']}" />`,
    ...(seo.alternates ? [['en', seo.alternates.en], ['zh-Hans', seo.alternates.zh], ['x-default', seo.alternates.en]]
        .map(([hl, href]) => `<link rel="alternate" hreflang="${hl}" href="${href}" />`) : []),
].join('\n    ');
