// A slow, tilted wall of the payment brands KaazPay supports (white single-colour logos), drifting in alternating
// directions. Decorative only: aria-hidden, paused for reduced motion (see .logo-drift in index.css).
const LOGOS = import.meta.glob('../../assets/marquee/*.png', { eager: true, query: '?url', import: 'default' });
const logo = (k) => LOGOS[`../../assets/marquee/${k}.png`];

const ROWS = [
    ['fpx', 'duitnow', 'thai-qr', 'paynow', 'sgqr', 'qris', 'gcash', 'touch-n-go'],
    ['visa', 'unionpay', 'jcb', 'apple-pay', 'google-pay', 'cash-app', 'paypal', 'usdt'],
    ['spei', 'pse', 'm-pesa', 'qris', 'paynow', 'visa', 'duitnow', 'apple-pay'],
];

const Row = ({ keys, dur, reverse }) => (
    <div className="flex w-max logo-drift" style={{ animationDuration: `${dur}s`, animationDirection: reverse ? 'reverse' : 'normal' }}>
        {[0, 1].map((copy) => (
            <ul key={copy} className="flex shrink-0 gap-4 pr-4">
                {keys.map((k, i) => (
                    <li key={`${k}-${i}`} className="flex h-16 w-36 shrink-0 items-center justify-center rounded-2xl border border-white/[0.08] bg-white/[0.035] backdrop-blur-sm">
                        <img src={logo(k)} alt="" className="max-h-7 w-auto max-w-[96px] object-contain opacity-70" loading="lazy" decoding="async" draggable="false" />
                    </li>
                ))}
            </ul>
        ))}
    </div>
);

const SPEED = [70, 90, 80];

/** rows: how many rows (1–3); tilt: the angled wall (desktop) or a flat strip (phones). */
const LogoField = ({ className = '', rows = 3, tilt = true }) => (
    <div className={`pointer-events-none select-none ${className}`} aria-hidden="true">
        <div className={`flex flex-col gap-4 ${tilt ? '[transform:perspective(1200px)_rotateX(18deg)_rotateZ(-10deg)]' : ''}`}>
            {ROWS.slice(0, rows).map((keys, i) => <Row key={i} keys={keys} dur={SPEED[i]} reverse={i % 2 === 1} />)}
        </div>
    </div>
);

export default LogoField;
