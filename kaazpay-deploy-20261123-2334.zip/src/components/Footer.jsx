import { Link } from './LocaleLink';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Send } from 'lucide-react';
import { PORTAL_URL, TG_CHANNEL, tgUrl } from '../data/contact';
import BrandLogo from './BrandLogo';
import { marketsByRegion, marketName, regionName } from '../data/channels';
import { Flag } from './coverage/shared';

const RegionBlock = ({ region, lang, columns = false }) => {
    const markets = marketsByRegion(region);
    return (
        <div>
            <p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">
                {regionName(region, lang)}
                <span className="rounded-full bg-white/[0.06] px-1.5 py-px font-mono text-[10px] tracking-normal text-text-body">{markets.length}</span>
            </p>
            <ul className={`text-[13px] text-text-body max-sm:flex max-sm:flex-wrap max-sm:gap-x-4 ${columns ? 'grid grid-cols-2 gap-x-6 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3' : 'space-y-0'}`}>
                {markets.map((m) => (
                    <li key={m.slug}>
                        <Link to={`/payment-methods/${m.slug}`} className="group flex items-center gap-2 py-2 transition-colors hover:text-white sm:py-1">
                            <Flag market={m} className="h-3.5 w-3.5 rounded-full" />
                            <span className="truncate">{marketName(m, lang)}</span>
                        </Link>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const Footer = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language;

    return (
        <footer className="relative z-10 border-t border-white/[0.06] bg-background pt-20 pb-10 max-lg:pb-28">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-mint/40" />
            <div className="container mx-auto px-5">
                <div className="grid gap-12 md:grid-cols-[1.4fr_1fr] lg:grid-cols-12">
                    <div className="lg:col-span-6">
                        <Link to="/" className="mb-5 inline-flex items-center gap-2.5" aria-label="KaazPay home">
                            <BrandLogo size="lg" />
                        </Link>
                        <p className="max-w-sm text-sm leading-relaxed text-text-body">
                            {t('footer.description')}
                        </p>
                        <Link to="/contact" className="mt-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-4 py-2 text-sm font-semibold text-white transition-colors hover:border-primary/40 hover:bg-white/[0.08]">
                            {t('nav.contact')} <ArrowRight size={14} />
                        </Link>
                        <a href={tgUrl(TG_CHANNEL)} target="_blank" rel="noopener noreferrer"
                            className="ml-2 mt-6 inline-flex items-center gap-2 rounded-full border border-[#229ED9]/30 bg-[#229ED9]/10 px-4 py-2 text-sm font-semibold text-white transition-colors hover:border-[#229ED9]/60 hover:bg-[#229ED9]/20">
                            <Send size={14} className="text-[#229ED9]" /> {t('footer.follow')}
                        </a>
                    </div>

                    <div className="grid grid-cols-2 gap-10 lg:col-span-6 lg:grid-cols-2">
                        <div>
                            <h4 className="mb-5 text-sm font-semibold text-white">{t('footer.company')}</h4>
                            <ul className="text-sm text-text-body">
                                <li><Link to="/about" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.about')}</Link></li>
                                <li><Link to="/roadmap" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.roadmap')}</Link></li>
                                <li><Link to="/contact" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.contact')}</Link></li>
                                <li><a href={tgUrl(TG_CHANNEL)} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.channel')}</a></li>
                                <li><a href={PORTAL_URL} target="_blank" rel="noopener noreferrer" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('nav.portal')}</a></li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="mb-5 text-sm font-semibold text-white">{t('footer.resources')}</h4>
                            <ul className="text-sm text-text-body">
                                <li><Link to="/#coverage" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('nav.globalCoverage')}</Link></li>
                                <li><Link to="/methods" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.methods')}</Link></li>
                                <li><Link to="/guides" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.guides')}</Link></li>
                                <li><Link to="/compare" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.compare')}</Link></li>
                                <li><Link to="/faq" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.faq')}</Link></li>
                                <li><Link to="/glossary" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.glossary')}</Link></li>
                                <li><Link to="/industries" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('nav.solutions')}</Link></li>
                                <li><Link to="/capabilities" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('nav.capabilities')}</Link></li>
                                <li><Link to="/developers" className="inline-flex min-h-10 items-center transition-colors hover:text-primary">{t('footer.api')}</Link></li>
                            </ul>
                        </div>
                    </div>
                </div>

                {/* Market directory: crawlable links to every country page, grouped by region */}
                <nav aria-label={t('footer.markets')} className="mt-16 [contain-intrinsic-size:auto_640px] [content-visibility:auto] rounded-3xl border border-white/[0.06] bg-surface/40 p-6 max-sm:p-5 md:p-8">
                    <div className="mb-7 flex flex-wrap items-end justify-between gap-2">
                        <h4 className="text-base font-semibold text-white">{t('footer.markets')}</h4>
                        <p className="text-xs text-text-muted">{t('footer.marketsDesc')}</p>
                    </div>
                    <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_2fr]">
                        <RegionBlock region="apac" lang={lang} />
                        <div className="space-y-8">
                            <RegionBlock region="global" lang={lang} />
                            <RegionBlock region="europe_me" lang={lang} />
                        </div>
                        <RegionBlock region="americas" lang={lang} />
                        <RegionBlock region="africa" lang={lang} columns />
                    </div>
                </nav>

                <div className="mt-12 flex flex-col items-center justify-between gap-2 border-t border-white/[0.06] pt-8 text-xs text-text-muted md:flex-row">
                    <p>{t('footer.copyright', { year: new Date().getFullYear() })}</p>
                    <p>kaazpay.info</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
