import { ArrowUpRight, ArrowRight, Clock } from 'lucide-react';
import { Link } from './LocaleLink';
import { KINDS, articleLang, articlePath, readMinutes } from '../content';
import { articleCover, articleCoverSrcSet, articleCoverPosition, articleTopic, topicName } from '../content/covers';

/**
 * Article card with a cover photo. variant="featured" is the wide hero card on the hub page.
 * The whole card is one link (one tab stop, a big click target).
 */
const ArticleCard = ({ article, lang, t, variant = 'default', showKind = false }) => {
    const c = articleLang(article, lang);
    const zh = lang?.startsWith('zh');
    const cover = articleCover(article.slug);
    const coverSet = articleCoverSrcSet(article.slug);
    const pos = { objectPosition: articleCoverPosition(article.slug) };
    const tag = showKind ? KINDS[article.kind][zh ? 'zh' : 'en'] : topicName(articleTopic(article.slug), lang);
    const meta = (
        <span className="inline-flex items-center gap-1.5 text-xs text-text-muted">
            <Clock size={12} /> {t('articles.readTime', { count: readMinutes(article, lang) })}
        </span>
    );

    if (variant === 'featured' || variant === 'wide') {
        return (
            <Link to={articlePath(article)}
                className="group relative grid overflow-hidden rounded-[28px] border border-white/[0.08] bg-surface/80 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.95)] transition-colors duration-300 hover:border-primary/30 md:grid-cols-[1.1fr_1fr]">
                <div className="relative aspect-[16/10] overflow-hidden md:aspect-auto md:min-h-[300px] lg:min-h-[360px]">
                    {cover && <img src={cover} srcSet={coverSet} sizes="(min-width: 768px) 55vw, 100vw" alt="" style={pos} {...(variant === 'wide' ? { loading: 'lazy' } : {})} decoding="async" className="absolute inset-0 h-full w-full object-cover opacity-85 transition-transform duration-[1400ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.04]" />}
                    <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/20 to-transparent md:bg-gradient-to-r md:from-transparent md:via-transparent md:to-surface" />
                    <span className="absolute left-5 top-5 rounded-full border border-white/15 bg-background/60 px-3 py-1 text-xs font-semibold text-white backdrop-blur-md">{variant === 'featured' ? t('articles.featured') : tag}</span>
                </div>
                <div className="relative flex flex-col justify-center p-5 sm:p-6 lg:p-9">
                    <span className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">{tag}</span>
                    {variant === 'featured'
                        ? <h2 className="mt-3 text-xl font-bold leading-tight text-white sm:text-2xl lg:text-[2rem]">{c.h1}</h2>
                        : <h3 className="mt-3 text-xl font-bold leading-tight text-white sm:text-2xl">{c.h1}</h3>}
                    <p className="mt-3 line-clamp-3 leading-relaxed text-text-body sm:mt-4 lg:line-clamp-4">{c.description}</p>
                    <span className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-2">
                        <span className="inline-flex items-center gap-2 font-semibold text-primary">
                            {t(article.kind === 'compare' ? 'articles.readCompare' : 'articles.readGuide')}
                            <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1" />
                        </span>
                        {meta}
                    </span>
                </div>
            </Link>
        );
    }

    return (
        <Link to={articlePath(article)}
            className="group flex h-full flex-col overflow-hidden rounded-2xl border border-white/[0.07] bg-surface/80 transition-[transform,border-color,background-color] duration-300 hover:-translate-y-1 hover:border-primary/30 hover:bg-surface-2">
            <div className="relative aspect-[16/9] overflow-hidden bg-surface-2">
                {cover && <img src={cover} srcSet={coverSet} sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 85vw" alt="" style={pos} loading="lazy" decoding="async" className="absolute inset-0 h-full w-full object-cover opacity-75 transition-[transform,opacity] duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.05] group-hover:opacity-90" />}
                <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/10 to-transparent" />
                <span className="absolute left-4 top-4 rounded-full border border-white/15 bg-background/60 px-2.5 py-0.5 text-[11px] font-semibold text-white backdrop-blur-md">{tag}</span>
            </div>
            <div className="flex flex-1 flex-col p-5 pt-3">
                <h3 className="font-semibold leading-snug text-white transition-colors group-hover:text-primary">{c.h1}</h3>
                <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-text-muted">{c.description}</p>
                <span className="mt-auto flex items-center pt-4">
                    {meta}
                    <ArrowUpRight size={15} className="ml-auto text-text-muted transition-colors group-hover:text-primary" />
                </span>
            </div>
        </Link>
    );
};

export default ArticleCard;
