import React, { useState } from 'react';
import { Plus, Minus, ArrowRight } from 'lucide-react';
import { Link } from '../../components/LocaleLink';
import { Reveal } from '../../components/motion/Reveal';
import { useTranslation } from 'react-i18next';
import { COVERAGE_STATS } from '../../data/channels';

const FAQ = () => {
    const { t } = useTranslation();
    const [activeIndex, setActiveIndex] = useState(null);

    const vars = { markets: COVERAGE_STATS.markets, payout: COVERAGE_STATS.payoutMarkets };
    const faqs = [
        {
            question: t('home.faq.questions.countries.q'),
            answer: t('home.faq.questions.countries.a', vars)
        },
        {
            question: t('home.faq.questions.payout.q'),
            answer: t('home.faq.questions.payout.a')
        },
        {
            question: t('home.faq.questions.settlement.q'),
            answer: t('home.faq.questions.settlement.a')
        },
        {
            question: t('home.faq.questions.highrisk.q'),
            answer: t('home.faq.questions.highrisk.a')
        },
        {
            question: t('home.faq.questions.conversion.q'),
            answer: t('home.faq.questions.conversion.a')
        },
        {
            question: t('home.faq.questions.liquidity.q'),
            answer: t('home.faq.questions.liquidity.a')
        },
        {
            question: t('home.faq.questions.integration.q'),
            answer: t('home.faq.questions.integration.a')
        }
    ];

    return (
        <section id="faq" className="py-24 md:py-32 relative overflow-hidden">
            <div className="pointer-events-none absolute inset-0 [mask-image:linear-gradient(180deg,transparent_0%,black_16%,black_84%,transparent_100%)]" aria-hidden="true">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_55%_at_12%_40%,rgba(244,121,47,0.13),transparent_70%)]" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_45%_45%_at_95%_85%,rgba(129,216,207,0.08),transparent_70%)]" />
            </div>

            <div className="container mx-auto px-6 relative z-10">
                <div className="flex flex-col lg:flex-row gap-16">
                    {/* Left Side: Title */}
                    <div className="lg:w-1/3">
                        <Reveal className="lg:sticky lg:top-32">
                            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                                {t('home.faq.title_prefix')} <br /> {t('home.faq.title_suffix')}
                            </h2>
                            <Link to="/faq" className="btn-ghost text-sm">{t('home.faq.all')} <ArrowRight size={16} /></Link>
                        </Reveal>
                    </div>

                    {/* Right Side: Accordion */}
                    <div className="lg:w-2/3 space-y-4">
                        {faqs.map((faq, index) => (
                            <Reveal
                                key={index}
                                className={`border rounded-xl overflow-hidden transition-colors duration-300 ${activeIndex === index ? 'bg-surface/60 border-white/15' : 'bg-white/[0.025] border-white/[0.08] hover:border-white/15'}`}
                            >
                                <button
                                    aria-expanded={activeIndex === index}
                                    className="w-full px-6 md:px-8 py-5 md:py-6 flex items-center justify-between text-left focus:outline-none"
                                    onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                                >
                                    <span className={`text-lg font-medium transition-colors ${activeIndex === index ? 'text-white' : 'text-text-body group-hover:text-white'}`}>
                                        {faq.question}
                                    </span>
                                    <span className={`transition-transform duration-300 ${activeIndex === index ? 'text-primary rotate-180' : 'text-text-body'}`}>
                                        {activeIndex === index ? <Minus size={24} /> : <Plus size={24} />}
                                    </span>
                                </button>

                                {/* answers stay in the HTML when collapsed, so crawlers read the full FAQ */}
                                <div className={`grid transition-[grid-template-rows,opacity] duration-300 ease-out ${activeIndex === index ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                                    <div className="overflow-hidden">
                                        <div className="px-6 md:px-8 pb-8 pt-2 text-base text-text-body leading-relaxed">
                                            {faq.answer}
                                        </div>
                                    </div>
                                </div>
                            </Reveal>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default FAQ;
