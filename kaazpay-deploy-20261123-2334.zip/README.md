# KaazPay 官网（kaazpay.info）

React 19 + Vite 7 + Tailwind 3 + framer-motion + i18next，所有页面在构建时预渲染为静态 HTML（英文 `/...`，简体中文 `/zh/...`）。

## 常用指令

```bash
npm run dev      # 本地开发
npm run build    # 生成文章目录 → 打包 → SSR 预渲染全部页面 + sitemap/feed/llms.txt
./pack.sh        # 生成上传包（自动排除 node_modules、conapay-website-new 参考目录、logo 原档等）
./deploy.sh      # 服务器上一键部署（Docker + Nginx，零停机）
```

本地用 `vite preview` 查看预渲染页面时，请在网址结尾加 `/`（例如 `/zh/roadmap/`），生产环境 Nginx 会自动处理。

## 改资料只改这里

| 内容 | 文件 |
|---|---|
| 官网域名 `SITE_URL` | `src/data/channels.js` |
| 支付通道、国家、代收/代付方式 | `src/data/channels.js`（首页、国家页、sitemap、llms.txt、JSON-LD 自动同步） |
| 支付方式页说明 | `src/data/methods.js` |
| Telegram 联系人、官方频道、商户后台地址、成立年份 | `src/data/contact.js` |
| 路线图里程碑（2018 起） | `src/data/milestones.js` + 文案 `src/locales/*.json → roadmap.milestones` |
| 页面文案 | `src/locales/en.json`、`src/locales/zh.json` |
| 指南 / 对比文章 | `src/content/articles/<slug>.js`（封面 `src/assets/articles/<slug>.webp`，来源 `credits/<slug>.json`） |

## SEO / GEO

- 每页独立 title / description / canonical / hreflang（en、zh-Hans、x-default）/ Open Graph / JSON-LD
- 结构化资料：Organization、WebSite、Service + OfferCatalog、FAQPage、BreadcrumbList、TechArticle、HowTo（开发者页）、ItemList（路线图）、AboutPage、ContactPage
- `sitemap.xml`（含 hreflang 与图片）、`feed.xml` / `zh/feed.xml`（RSS）、`llms.txt`、`llms-full.txt`、`robots.txt`（欢迎 AI 爬虫）
- 内容哈希决定 sitemap `lastmod`，部署时只把有改动的页面提交 IndexNow（金钥 `public/b7e06e25c774498f410bbb947dfc4c51.txt`）

## 素材来源

所有照片与视频均为可商用授权（Pexels / Mixkit / Wikimedia Commons），来源记录在各 `src/assets/<目录>/credits.json`。CC BY / CC BY-SA 图片会在页面显示署名。
