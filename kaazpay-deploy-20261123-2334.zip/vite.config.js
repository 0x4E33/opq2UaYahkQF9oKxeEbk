import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import viteCompression from 'vite-plugin-compression';
import { ViteImageOptimizer } from 'vite-plugin-image-optimizer';

/** Preload the Latin body + heading fonts so they don't wait for the CSS. */
const preloadFonts = () => ({
  name: 'preload-fonts',
  apply: 'build',
  transformIndexHtml: {
    order: 'post',
    handler(html, ctx) {
      // Inter (body) and Sora (headings — the hero H1 is the LCP element)
      const fonts = Object.keys(ctx.bundle || {}).filter((f) => /(inter|sora)-latin-wght-normal.*\.woff2$/.test(f));
      const tags = fonts.map((f) => `<link rel="preload" href="/${f}" as="font" type="font/woff2" crossorigin />`).join('\n    ');
      return tags ? html.replace('</title>', `</title>\n    ${tags}`) : html;
    },
  },
});

// https://vite.dev/config/
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        // Long-lived vendor chunks: a content deploy doesn't invalidate React / router / i18n in returning visitors' caches.
        manualChunks: (id) => {
          if (!id.includes('node_modules')) return undefined;
          if (/node_modules\/(react|react-dom|scheduler|react-router|react-router-dom)\//.test(id)) return 'vendor-react';
          if (/node_modules\/(i18next|react-i18next|i18next-browser-languagedetector)\//.test(id)) return 'vendor-i18n';
          return undefined;
        },
      },
    },
  },
  plugins: [
    react(),
    preloadFonts(),
    viteCompression({
        algorithm: 'gzip',
        ext: '.gz',
    }),
    viteCompression({
        algorithm: 'brotliCompress',
        ext: '.br',
    }),
    ViteImageOptimizer({
        png: {
            quality: 80,
        },
        jpeg: {
            quality: 80,
        },
        jpg: {
            quality: 80,
        },
    }),
  ],
})
