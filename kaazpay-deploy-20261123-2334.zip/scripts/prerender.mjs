/**
 * Build-time prerender: turns the SPA into crawlable static HTML.
 *
 *   1. `vite build`                         -> dist/ (client bundle + index.html template)
 *   2. `vite build --ssr src/entry-server`  -> dist-ssr/entry-server.js
 *   3. this script renders every route into dist/<route>/index.html with its own
 *      <title>, meta description, canonical, Open Graph and JSON-LD, then writes
 *      sitemap.xml (hreflang + images), RSS feeds, llms.txt and llms-full.txt from the same data.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const ssrDir = path.join(root, 'dist-ssr');

const { render, getSeo, headTags, PRERENDER_ROUTES, BASE_ROUTES, ROUTE_DATES, ARTICLES, ARTICLE_BODIES, articlePath, plain, localizePath, MARKETS, REGIONS, COVERAGE_STATS, SITE_URL, hasPayout,
    marketCopy, methodCopy, industryCopy, METHODS, methodMarkets, methodName, INDUSTRIES, MILESTONES, articleCover,
    getMarket, marketPhoto, industryPhoto, getMethod, stripLocale, GLOSSARY, FAQ_ALL } =
    await import(pathToFileURL(path.join(ssrDir, 'entry-server.js')).href);

const template = await fs.readFile(path.join(dist, 'index.html'), 'utf8');

// ---------- Per-page share images (Open Graph / X): the page's own photo, 1200x630 JPEG with the KaazPay mark ----------
const { default: sharp } = await import('sharp');
const markPng = await sharp(path.join(root, 'src/assets/logo-mark.png')).resize({ height: 64 }).png().toBuffer();
const ogCache = new Map();
const ogSource = (route) => {
    const p = stripLocale(route);
    let m;
    if ((m = p.match(/^\/(?:guides|compare)\/([^/]+)$/))) return [articleCover(m[1]), 'centre'];
    if ((m = p.match(/^\/payment-methods\/([^/]+)$/))) { const mk = getMarket(m[1]); return [mk && marketPhoto(mk), 'right']; }
    if ((m = p.match(/^\/industries\/([^/]+)$/))) return [industryPhoto(m[1]), 'centre'];
    if ((m = p.match(/^\/methods\/([^/]+)$/))) {
        const me = getMethod(m[1]);
        const mk = me && [...methodMarkets(me).payin, ...methodMarkets(me).payout][0];
        return [mk && marketPhoto(mk), 'right'];
    }
    return [null];
};
const ogImageFor = async (route, lang) => {
    const [src, position] = ogSource(route);
    if (!src || !src.startsWith('/assets/')) return `${SITE_URL}/${lang === 'zh' ? 'og-image-zh.png' : 'og-image.png'}`;
    if (!ogCache.has(src)) {
        const name = `og/${path.basename(src).replace(/\.[a-z]+$/, '')}.jpg`;
        const shade = Buffer.from('<svg width="1200" height="630"><defs><linearGradient id="g" x1="0" x2="0" y1="0" y2="1"><stop offset="0.55" stop-color="#0A0908" stop-opacity="0"/><stop offset="1" stop-color="#0A0908" stop-opacity="0.75"/></linearGradient></defs><rect width="1200" height="630" fill="url(#g)"/><text x="112" y="586" font-family="Helvetica, Arial, sans-serif" font-size="34" font-weight="700" fill="#F6F4F1">Kaaz<tspan fill="#F4792F">Pay</tspan></text></svg>');
        const buf = await sharp(path.join(dist, src)).resize(1200, 630, { fit: 'cover', position }).composite([{ input: shade }, { input: markPng, left: 40, top: 532 }]).jpeg({ quality: 82, mozjpeg: true }).toBuffer();
        await fs.mkdir(path.join(dist, 'og'), { recursive: true });
        await fs.writeFile(path.join(dist, name), buf);
        ogCache.set(src, `${SITE_URL}/${name}`);
    }
    return ogCache.get(src);
};

const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const withHead = (html, seo) => {
    const jsonLd = seo.jsonLd
        .map((obj) => `<script type="application/ld+json">${JSON.stringify(obj).replace(/</g, '\\u003c')}</script>`)
        .join('\n    ');
    return html
        .replace('<html lang="en">', `<html lang="${seo.lang === 'zh' ? 'zh-CN' : 'en'}">`)
        .replace(/(<meta name="robots" content=")[^"]*(")/, `$1${seo.noindex ? 'noindex,follow' : 'index,follow,max-image-preview:large'}$2`)
        .replace(/<title>[\s\S]*?<\/title>/, `<title>${esc(seo.title)}</title>`)
        .replace(/(<meta name="description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<meta property="og:title" content=")[^"]*(")/, `$1${esc(seo.title)}$2`)
        .replace(/(<meta property="og:description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<meta property="og:url" content=")[^"]*(")/, `$1${esc(seo.canonical)}$2`)
        .replace(/(<meta name="twitter:title" content=")[^"]*(")/, `$1${esc(seo.title)}$2`)
        .replace(/(<meta name="twitter:description" content=")[^"]*(")/, `$1${esc(seo.description)}$2`)
        .replace(/(<link rel="canonical" href=")[^"]*(")/, `$1${esc(seo.canonical)}$2`)
        .replace(/(<meta property="og:type" content=")[^"]*(")/, `$1${seo.ogType || 'website'}$2`)
        .replace(/(<meta property="og:image" content=")[^"]*(")/, `$1${seo.ogImage || `${SITE_URL}/${seo.lang === 'zh' ? 'og-image-zh.png' : 'og-image.png'}`}$2`)
        .replace(/(<meta name="twitter:image" content=")[^"]*(")/, `$1${seo.ogImage || `${SITE_URL}/${seo.lang === 'zh' ? 'og-image-zh.png' : 'og-image.png'}`}$2`)
        .replace(/(<meta property="og:image:alt" content=")[^"]*(")/, `$1${esc(seo.title)}$2`)
        .replace('</head>', `    ${headTags(seo)}\n    ${jsonLd}\n  </head>`);
};

const writeCompressed = async (file, content) => {
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, content);
    await fs.writeFile(`${file}.gz`, zlib.gzipSync(content, { level: 9 }));
    await fs.writeFile(`${file}.br`, zlib.brotliCompressSync(content));
};

// lastmod that only moves when a page's content changes (Google ignores lastmod that changes on every build).
// State: { route: { hash, date } } — read from the live site (site/lastmod.json) or the last local build, written back to both.
const today = new Date().toISOString().slice(0, 10);
const readJson = async (f) => { try { return JSON.parse(await fs.readFile(f, 'utf8')); } catch { return null; } };
const prevState = (await readJson(process.env.LASTMOD_STATE || path.join(root, 'site', 'lastmod.json'))) || (await readJson(path.join(root, '.lastmod.json'))) || {};
const nextState = {};
const contentHash = (html) => crypto.createHash('sha1').update(html.replace(/\/assets\/[^"')\s]+/g, '/assets/x')).digest('hex').slice(0, 16);

// Content photos on a page (images with real alt text; flags and method logos carry alt=""), for the image sitemap.
const routeImages = {};
const pageImages = (html) => {
    const out = new Map();
    for (const tag of html.match(/<img\b[^>]*>/g) || []) {
        const src = tag.match(/\ssrc="(\/assets\/[^"]+\.(?:webp|jpg|png))"/)?.[1];
        const alt = tag.match(/\salt="([^"]+)"/)?.[1];
        if (src && alt && !out.has(src)) out.set(src, alt);
    }
    return [...out].slice(0, 6);
};

let count = 0;
for (const route of PRERENDER_ROUTES) {
    const appHtml = await render(route);
    const seoData = getSeo(route);
    const hash = contentHash(appHtml + seoData.title + seoData.description);
    const prev = prevState[route];
    nextState[route] = { hash, date: prev && prev.hash === hash ? prev.date : today };
    routeImages[route] = pageImages(appHtml);
    const art = ARTICLES.find((a) => localizePath(articlePath(a), 'en') === route || localizePath(articlePath(a), 'zh') === route);
    if (art) {
        const cover = articleCover(art.slug);
        if (cover && !routeImages[route].some(([src]) => src === cover)) routeImages[route].unshift([cover, art[route.startsWith('/zh') ? 'zh' : 'en'].h1]);
    }
    seoData.ogImage = await ogImageFor(route, seoData.lang);
    const html = withHead(template, seoData)
        .replace('<div id="root"></div>', `<div id="root" data-route="${route}">${appHtml}</div>`);
    const out = route === '/' ? path.join(dist, 'index.html') : path.join(dist, route.slice(1), 'index.html');
    await writeCompressed(out, html);
    count++;
}

// Real 404 page: nginx serves it (with status 404) for any URL that has no prerendered page.
{
    const route = '/404';
    const html = withHead(template, getSeo(route))
        .replace('<div id="root"></div>', `<div id="root" data-route="${route}">${await render(route)}</div>`);
    await writeCompressed(path.join(dist, '404.html'), html);
}

// ---------- sitemap.xml (hreflang pairs + content images) ----------
await fs.writeFile(path.join(dist, 'lastmod.json'), JSON.stringify(nextState));
// Pages whose content changed in this build (or all pages on a first deploy) — deploy.sh submits only these to IndexNow.
const changed = Object.keys(nextState).filter((r) => !prevState[r] || prevState[r].hash !== nextState[r].hash);
await fs.writeFile(path.join(dist, 'indexnow-urls.txt'), changed.map((r) => `${SITE_URL}${r}`).join('\n') + (changed.length ? '\n' : ''));
console.log(`  ${changed.length} page(s) changed since the last build`);
await fs.writeFile(path.join(root, '.lastmod.json'), JSON.stringify(nextState));
const lastmod = (r, l) => {
    const content = ROUTE_DATES[r];
    const built = nextState[localizePath(r, l)]?.date || today;
    return content && content > built ? content : (content || built);
};
const priority = (r) => (r === '/' ? '1.0' : /^\/(payment-methods|methods|guides|compare)\//.test(r) ? '0.9' : /^\/(methods|industries|guides|compare|contact)/.test(r) ? '0.8' : '0.6');
const alt = (r) => [['en', 'en'], ['zh-Hans', 'zh'], ['x-default', 'en']]
    .map(([hl, l]) => `<xhtml:link rel="alternate" hreflang="${hl}" href="${SITE_URL}${localizePath(r, l)}"/>`).join('');
const imgs = (route) => (routeImages[route] || []).map(([src, title]) =>
    `<image:image><image:loc>${SITE_URL}${src}</image:loc><image:title>${esc(title)}</image:title></image:image>`).join('');
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
${BASE_ROUTES.flatMap((r) => ['en', 'zh'].map((l) =>
    `  <url><loc>${SITE_URL}${localizePath(r, l)}</loc><lastmod>${lastmod(r, l)}</lastmod><priority>${priority(r)}</priority>${alt(r)}${imgs(localizePath(r, l))}</url>`)).join('\n')}
</urlset>
`;
await writeCompressed(path.join(dist, 'sitemap.xml'), sitemap);

// ---------- RSS feeds of guides & comparisons (en + zh): fast discovery for aggregators and AI crawlers ----------
for (const l of ['en', 'zh']) {
    const zh = l === 'zh';
    const items = [...ARTICLES].sort((a, b) => (b.updated || b.published).localeCompare(a.updated || a.published)).map((a) => {
        const c = a[l];
        const url = `${SITE_URL}${localizePath(articlePath(a), l)}`;
        const body = ARTICLE_BODIES[a.slug]?.[l];
        return `    <item><title>${esc(c.h1)}</title><link>${url}</link><guid isPermaLink="true">${url}</guid><pubDate>${new Date(`${a.published}T08:00:00Z`).toUTCString()}</pubDate><description>${esc(body ? plain(body.summary) : c.description)}</description></item>`;
    });
    const feed = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${zh ? 'KaazPay 支付指南' : 'KaazPay payment guides'}</title>
    <link>${SITE_URL}${localizePath('/guides', l)}</link>
    <atom:link href="${SITE_URL}${zh ? '/zh' : ''}/feed.xml" rel="self" type="application/rss+xml"/>
    <description>${zh ? '全球本地支付方式、代付与 USDT 结算的指南与对比。' : 'Guides and comparisons on local payment methods, payouts and USDT settlement worldwide.'}</description>
    <language>${zh ? 'zh-Hans' : 'en'}</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
${items.join('\n')}
  </channel>
</rss>
`;
    await writeCompressed(path.join(dist, zh ? 'zh' : '', 'feed.xml'), feed);
}

// ---------- llms.txt (GEO: concise, factual summary for AI assistants / answer engines) ----------
const TG = ['https://t.me/KaazPayEZ', 'https://t.me/KaazPay_BD2'];
const CHANNEL = 'https://t.me/KaazpayOfficial';
const PORTAL = 'https://www.kaazpay.com';
const lines = [
    '# KaazPay',
    '',
    `> KaazPay is a cross-border payment gateway that gives merchants local pay-in (collection) and payout channels in ${COVERAGE_STATS.markets} markets worldwide, across Asia Pacific, the Americas, Europe, the Middle East and Africa. It also offers international Visa, Mastercard and UnionPay card acquiring, JCB acquiring in Japan, and USDT pay-in and payouts. Collected funds are settled to merchants in USDT; many channels settle D+0, others D+1 or later, confirmed per channel.`,
    '',
    `- Pay-in methods: ${COVERAGE_STATS.payinMethods}`,
    `- Markets with payouts: ${COVERAGE_STATS.payoutMarkets}`,
    `- Currencies collected: ${COVERAGE_STATS.currencies}`,
    ...MARKETS.filter((m) => m.cardBrands).map((m) => `- International card acquiring: ${m.payin.join(', ')} (${SITE_URL}/payment-methods/${m.slug})`),
    `- Contact sales (Telegram): ${TG.join(' , ')} — overview at ${SITE_URL}/contact`,
    `- Official Telegram channel: ${CHANNEL}`,
    `- Merchant dashboard (login): ${PORTAL}`,
    `- Integration in 4 steps: ${SITE_URL}/developers`,
    `- All payment methods: ${SITE_URL}/methods`,
    `- FAQ (coverage, settlement, onboarding, integration, compliance): ${SITE_URL}/faq`,
    `- Payment glossary (definitions of payment terms): ${SITE_URL}/glossary`,
    `- Roadmap: ${SITE_URL}/roadmap`,
    `- 中文版 (Simplified Chinese): ${SITE_URL}/zh`,
    `- Full reference for AI assistants: ${SITE_URL}/llms-full.txt`,
    `- RSS: ${SITE_URL}/feed.xml`,
    '',
    '## 中文简介',
    '',
    `KaazPay 是跨境支付网关，在全球 ${COVERAGE_STATS.markets} 个市场（亚太、美洲、欧洲、中东与非洲）提供本地代收与本地代付，支持 DuitNow、FPX、Thai QR、PayNow、QRIS、Apple Pay、Cash App、SPEI、Pix、M-Pesa 等 ${COVERAGE_STATS.payinMethods} 种代收方式，以及 Visa、Mastercard、银联国际信用卡收单与日本 JCB 收单。资金统一以 USDT 结算：许多通道支持 D+0，其余为 D+1 或更长，以各通道确认为准。商务联系 Telegram：@KaazPayEZ、@KaazPay_BD2；官方频道 @KaazpayOfficial。中文网站：${SITE_URL}/zh`,
    '',
];
for (const region of REGIONS) {
    const markets = MARKETS.filter((m) => m.region === region.key);
    if (!markets.length) continue;
    lines.push(`## ${region.en}`, '');
    for (const m of markets) {
        const via = m.networks ? `USDT on ${m.networks.join(', ')}` : m.payin.join(', ');
        lines.push(`- [${m.name.en} (${m.currency})](${SITE_URL}/payment-methods/${m.slug}): pay-in via ${via}; payout ${hasPayout(m) ? `via ${m.payout.join(', ')}` : 'not yet available'}`);
    }
    lines.push('');
}
lines.push('## Payment method pages', '', ...METHODS.map((m) => `- [${methodName(m, 'en')}](${SITE_URL}/methods/${m.slug})`), '');
lines.push('## Guides and comparisons', '', ...ARTICLES.map((a) => `- [${a.en.h1}](${SITE_URL}${articlePath(a)}): ${plain(ARTICLE_BODIES[a.slug].en.summary)}`), '');
lines.push('## Industry pages', '', ...INDUSTRIES.map((i) => `- [${industryCopy(i, 'en').name}](${SITE_URL}/industries/${i.id})`), '');
lines.push('## FAQ', '', ...FAQ_ALL('en').map((f) => `- [${f.q}](${SITE_URL}/faq#${f.id}): ${f.a}`), '');
lines.push('## Glossary', '', ...GLOSSARY.map((g) => `- [${g.en.term}](${SITE_URL}/glossary#${g.id}): ${g.en.short}`), '');
await writeCompressed(path.join(dist, 'llms.txt'), lines.join('\n'));

// ---------- llms-full.txt (GEO: the complete, factual reference an AI assistant can quote) ----------
{
    const en = JSON.parse(await fs.readFile(path.join(root, 'src/locales/en.json'), 'utf8'));
    const fill = (str) => String(str).replace(/\{\{markets\}\}/g, COVERAGE_STATS.markets).replace(/\{\{payout\}\}/g, COVERAGE_STATS.payoutMarkets)
        .replace(/\{\{methods\}\}/g, COVERAGE_STATS.payinMethods).replace(/\{\{currencies\}\}/g, COVERAGE_STATS.currencies);
    const L = [];
    L.push('# KaazPay — complete reference', '');
    L.push(`> KaazPay (${SITE_URL}) is a cross-border payment gateway. It lets merchants accept local payment methods (pay-in / collection) and send local payouts in ${COVERAGE_STATS.markets} markets across Asia Pacific, the Americas, Europe, the Middle East and Africa, plus international Visa, Mastercard and UnionPay card acquiring, JCB acquiring in Japan, and USDT pay-in and payouts. Collected funds are settled to merchants in USDT. Website in English and Simplified Chinese (${SITE_URL}/zh).`, '');
    L.push('## Key facts', '');
    L.push(`- Markets with local pay-in: ${COVERAGE_STATS.markets}`, `- Pay-in methods: ${COVERAGE_STATS.payinMethods}`, `- Markets with local payouts: ${COVERAGE_STATS.payoutMarkets}`, `- Local currencies collected: ${COVERAGE_STATS.currencies}`,
        '- Settlement currency: USDT (equivalent amount); many channels settle D+0, others D+1 or later, confirmed per channel before go-live',
        '- USDT networks: Tron, Ethereum, BSC, Solana, Polygon',
        `- Sales contacts (Telegram): @KaazPayEZ (${TG[0]}), @KaazPay_BD2 (${TG[1]}) — reply within one business day`,
        `- Official Telegram channel (announcements): @KaazpayOfficial (${CHANNEL})`,
        `- Merchant dashboard: ${PORTAL}`,
        '- KaazPay has no public email address; staff never ask for passwords, private keys or transfers to personal accounts.', '');
    L.push('## How KaazPay works', '');
    for (const k of ['acquiring', 'routing', 'settlement', 'transfer']) L.push(`- ${en.capabilities.items[k].title}: ${fill(en.capabilities.items[k].desc)}`);
    L.push('');
    L.push('## Integration', '');
    Object.values(en.developers.steps).forEach((st, i) => L.push(`${i + 1}. ${st.title}: ${st.desc}`));
    L.push('', 'API documentation is shared after onboarding; a KaazPay engineer supports joint testing before launch. Requests are signed, IP allow-listed and encrypted in transit; status callbacks are signed.', '');
    L.push(`## Roadmap milestones (${SITE_URL}/roadmap)`, '');
    for (const m of MILESTONES.filter((x) => x.year)) L.push(`- ${m.date}: ${en.roadmap.milestones[m.key].title} — ${en.roadmap.milestones[m.key].desc}`);
    L.push('');
    L.push('## Markets and payment channels', '');
    for (const region of REGIONS) {
        const ms = MARKETS.filter((m) => m.region === region.key);
        if (!ms.length) continue;
        L.push(`### ${region.en}`, '');
        for (const m of ms) {
            const c = marketCopy(m, 'en');
            L.push(`#### ${m.name.en} (${m.currency}) — ${SITE_URL}/payment-methods/${m.slug}`, '', c.intro, '',
                `- Pay-in: ${m.networks ? `USDT on ${m.networks.join(', ')}` : m.payin.join(', ')}`,
                `- Payout: ${hasPayout(m) ? m.payout.join(', ') : 'not yet available (pay-in only)'}`, '');
        }
    }
    L.push('## Payment methods', '');
    for (const method of METHODS) {
        const c = methodCopy(method, 'en');
        const { payin, payout } = methodMarkets(method);
        L.push(`### ${methodName(method, 'en')} — ${SITE_URL}/methods/${method.slug}`, '', c.about, '');
        if (payin.length) L.push(`- Pay-in available in: ${payin.map((m) => m.name.en).join(', ')}`);
        if (payout.length) L.push(`- Payouts available in: ${payout.map((m) => m.name.en).join(', ')}`);
        L.push('');
    }
    L.push('## Industries', '');
    for (const ind of INDUSTRIES) {
        const c = industryCopy(ind, 'en');
        L.push(`### ${c.name} — ${SITE_URL}/industries/${ind.id}`, '', c.content, '', ...c.features.map((f) => `- ${f}`), '');
    }
    L.push('## Guides and comparisons', '');
    for (const a of ARTICLES) {
        const b = ARTICLE_BODIES[a.slug].en;
        L.push(`### ${a.en.h1} — ${SITE_URL}${articlePath(a)}`, '', plain(b.summary), '', ...(b.takeaways || []).map((k) => `- ${plain(k)}`), '');
        if (b.queries?.length) L.push('Questions this answers:', ...b.queries.map((q) => `- ${q}`), ...(ARTICLE_BODIES[a.slug].zh.queries || []).map((q) => `- ${q}`), '');
        for (const f of b.faq) L.push(`Q: ${plain(f.q)}`, `A: ${plain(f.a)}`, '');
    }
    L.push(`## Frequently asked questions (${SITE_URL}/faq)`, '');
    for (const f of FAQ_ALL('en')) L.push(`### ${f.q}`, '', f.a, '');
    L.push(`## Glossary (${SITE_URL}/glossary)`, '');
    for (const g of GLOSSARY) L.push(`### ${g.en.term}${g.en.aka?.length ? ` (also: ${g.en.aka.join(', ')})` : ''}`, '', `${g.en.short} ${g.en.body}`, '');
    L.push('## 常见问题（中文）', '');
    for (const f of FAQ_ALL('zh')) L.push(`### ${f.q}`, '', f.a, '');
    L.push('## Safety notice', '', en.contact.safety, '');
    await writeCompressed(path.join(dist, 'llms-full.txt'), L.join('\n'));
}

await fs.rm(ssrDir, { recursive: true, force: true });
console.log(`✓ prerendered ${count} routes (en + zh), 404.html, sitemap.xml (with images), feed.xml, llms.txt and llms-full.txt`);
