import { useParams } from 'react-router-dom';
import { ArrowRight, ArrowLeft, ArrowUpRight, Check, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate } from '../components/LocaleLink';
import { MethodIcon } from '../components/coverage/shared';
import { ParallaxImage } from '../components/motion/Reveal';
import { INDUSTRIES, getIndustry, industryPhoto, industryPhotoSrcSet } from '../data/industries';
import { getMethod, methodChannel, methodName } from '../data/methods';
import { industryCopy } from '../seo';
import RelatedArticles from '../components/RelatedArticles';

/** /industries/:id — one industry: what it needs, how KaazPay fits, which methods matter. */
const IndustryPage = () => {
    const { id } = useParams();
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const industry = getIndustry(id);
    if (!industry) return <Navigate to="/industries" replace />;

    const copy = industryCopy(industry, lang);
    const Icon = industry.icon;
    const methods = industry.methods.map(getMethod).filter(Boolean);
    const photo = industryPhoto(industry.id);
    const heading = copy.title.replace(/ \| KaazPay$/, '').split(/[:：]/)[0];
    const others = INDUSTRIES.filter((i) => i.id !== industry.id);

    return (
        <div className="container relative mx-auto px-5 pb-24 pt-10 md:pt-16">
            <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                <Link to="/" className="hover:text-white">KaazPay</Link>
                <ChevronRight size={14} />
                <Link to="/industries" className="hover:text-white">{t('nav.solutions')}</Link>
                <ChevronRight size={14} />
                <span className="text-text-body" aria-current="page">{copy.name}</span>
            </nav>

            <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
                <div>
                    <span className="animate-rise inline-flex items-center gap-2.5 text-sm font-semibold text-primary"><Icon size={16} /> {copy.name}</span>
                    <h1 style={{ animationDelay: '50ms' }} className="animate-rise mt-5 text-4xl font-bold leading-[1.08] text-white md:text-6xl">{heading}</h1>
                    <p style={{ animationDelay: '100ms' }} className="animate-rise mt-5 text-xl font-semibold text-text-heading/90">{copy.tagline}</p>
                    <p style={{ animationDelay: '150ms' }} className="animate-rise mt-5 text-lg leading-relaxed text-text-body">{copy.content}</p>
                    <div style={{ animationDelay: '200ms' }} className="animate-rise mt-8 flex flex-wrap gap-3">
                        <Link to="/contact" className="btn-primary">{t('industries.deployCta')} <ArrowRight size={18} /></Link>
                        <Link to="/developers" className="btn-ghost">{t('nav.developers')}</Link>
                    </div>
                </div>
                {photo && (
                    <ParallaxImage priority src={photo} alt={t(`industries.items.${industry.id}.photoAlt`)} srcSet={industryPhotoSrcSet(industry.id)} sizes="(min-width: 1024px) 45vw, 100vw" zoom={0.1} className="aspect-[4/3] rounded-[28px] border border-white/[0.08] bg-surface-2 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.95)]">
                        <div className="absolute inset-0 bg-gradient-to-t from-background/70 via-transparent to-transparent" />
                    </ParallaxImage>
                )}
            </div>

            <ul className="mt-14 grid gap-3 sm:grid-cols-2">
                {copy.features.map((f) => (
                    <li key={f} className="flex items-start gap-3 rounded-xl border border-white/[0.06] bg-white/[0.025] p-4 text-text-heading/90">
                        <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary"><Check size={12} strokeWidth={3} /></span>
                        {f}
                    </li>
                ))}
            </ul>

            {methods.length > 0 && (
                <section className="mt-20" aria-labelledby="methods-title">
                    <h2 id="methods-title" className="text-2xl font-semibold text-white">{t('industryPage.popular', { name: copy.name })}</h2>
                    <ul className="mt-6 flex flex-wrap gap-2">
                        {methods.map((m) => (
                            <li key={m.slug}>
                                <Link to={`/methods/${m.slug}`} className="inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] py-1.5 pl-1.5 pr-3.5 text-sm text-text-heading/90 transition-colors hover:border-primary/40 hover:text-white">
                                    <MethodIcon method={methodChannel(m)} size={18} />
                                    {methodName(m, lang)}
                                </Link>
                            </li>
                        ))}
                        <li>
                            <Link to="/methods" className="inline-flex items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-semibold text-primary hover:text-primary-hover">
                                {t('methods.all')} <ArrowUpRight size={14} />
                            </Link>
                        </li>
                    </ul>
                </section>
            )}

            <RelatedArticles field="industries" value={industry.id} />

            <section className="mt-20" aria-labelledby="others-title">
                <div className="flex flex-wrap items-end justify-between gap-4">
                    <h2 id="others-title" className="text-2xl font-semibold text-white">{t('industryPage.others')}</h2>
                    <Link to="/industries" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-hover">
                        <ArrowLeft size={14} /> {t('industryPage.back')}
                    </Link>
                </div>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                    {others.map(({ id: oid, icon: OIcon }) => (
                        <li key={oid}>
                            <Link to={`/industries/${oid}`} className="group flex items-center gap-3 rounded-xl border border-white/[0.07] bg-surface/80 p-4 transition-colors hover:border-white/15 hover:bg-surface-2">
                                <OIcon size={18} className="text-primary" />
                                <span className="flex-1 text-sm font-semibold text-white">{t(`industries.items.${oid}.title`)}</span>
                                <ArrowUpRight size={15} className="text-text-muted transition-colors group-hover:text-primary" />
                            </Link>
                        </li>
                    ))}
                </ul>
            </section>
        </div>
    );
};

export default IndustryPage;
