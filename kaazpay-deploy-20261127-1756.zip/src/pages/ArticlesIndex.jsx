import { useMemo, useState } from 'react';
import { ChevronRight, BookOpen, Scale, ArrowUpRight, Send } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../components/LocaleLink';
import ArticleCard from '../components/ArticleCard';
import { Reveal } from '../components/motion/Reveal';
import { ARTICLES, KINDS, articlesOfKind } from '../content';
import { TOPICS, articleCoverSmall, articleTopic, topicName } from '../content/covers';
import { TG_CHANNEL, tgUrl } from '../data/contact';

/** Header backdrop: the articles' own payment scenes, in two rows drifting slowly past each other.
 *  Tiles are at most 360px wide, so they use the 800w copies (about a third of the bytes of the originals). */
const HubDrift = () => {
    const covers = [...new Set(ARTICLES.map((a) => articleCoverSmall(a.slug)).filter(Boolean))];
    const half = Math.ceil(covers.length / 2);
    const row = (list, dir) => (
        <div className={`flex w-max gap-3 ${dir === 'left' ? 'animate-drift-left' : 'animate-drift-right'}`}>
            {[...list, ...list].map((src, i) => (
                <img key={`${src}-${i}`} src={src} alt="" decoding="async"
                    className="h-[190px] w-[300px] shrink-0 rounded-2xl object-cover md:h-[230px] md:w-[360px]" />
            ))}
        </div>
    );
    return (
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[680px] overflow-hidden" aria-hidden="true">
            <div className="absolute left-1/2 top-[46%] flex -translate-x-1/2 -translate-y-1/2 -rotate-[4deg] flex-col gap-3 opacity-50 sm:opacity-80">
                {row(covers.slice(0, half), 'left')}
                {row([...covers.slice(half), ...covers.slice(0, Math.max(0, half - (covers.length - half)))], 'right')}
            </div>
            {/* phones: darker scrim so the subtitle stays readable over the photos */}
            <div className="absolute inset-0 bg-background/70 sm:bg-background/45" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_46%_38%_at_50%_36%,rgba(13,12,11,0.88)_25%,transparent_85%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_40%_35%_at_50%_30%,rgba(244,121,47,0.14),transparent_70%)]" />
            <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-background to-transparent" />
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
    );
};

const FEATURED = { guide: 'us-payment-methods', compare: 'local-payment-methods-vs-cards' };

/** /guides and /compare — the content hub. */
const ArticlesIndex = ({ kind }) => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const zh = lang?.startsWith('zh');
    const all = articlesOfKind(kind);
    const [topic, setTopic] = useState('all');

    const topics = useMemo(() => Object.keys(TOPICS).filter((k) => all.some((a) => articleTopic(a.slug) === k)), [all]);
    // The featured card needs a crisp, full-frame photo; filtered views feature their first article.
    const lead = topic === 'all' ? all.find((a) => a.slug === FEATURED[kind]) : null;
    const list = topic === 'all' ? [lead, ...all.filter((a) => a !== lead)].filter(Boolean) : all.filter((a) => articleTopic(a.slug) === topic);
    const [featured, ...rest] = list;

    return (
        <div className="relative -mt-20 overflow-hidden pt-20">
            <HubDrift />

            <section className="container relative mx-auto px-5 pt-10 text-center md:pt-20">
                <nav aria-label="Breadcrumb" className="mb-6 flex items-center justify-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                    <Link to="/" className="hover:text-white">KaazPay</Link>
                    <ChevronRight size={14} />
                    <span className="text-text-body" aria-current="page">{KINDS[kind][zh ? 'zh' : 'en']}</span>
                </nav>
                <h1 style={{ animationDelay: '50ms' }} className="animate-rise mx-auto max-w-4xl text-4xl font-bold leading-[1.06] text-white md:text-6xl">
                    {t(`articles.${kind}.titlePrefix`)} <span className="inline-block text-ember">{t(`articles.${kind}.titleHighlight`)}</span>
                </h1>
                <p style={{ animationDelay: '110ms' }} className="animate-rise mx-auto mt-6 max-w-2xl text-lg text-text-body">{t(`articles.${kind}.subtitle`)}</p>

                {/* Guides | Comparisons */}
                <div style={{ animationDelay: '170ms' }} className="animate-rise mx-auto mt-9 inline-flex rounded-full border border-white/10 bg-surface/70 p-1 backdrop-blur-md">
                    {['guide', 'compare'].map((k) => {
                        const Icon = k === 'compare' ? Scale : BookOpen;
                        const active = k === kind;
                        return (
                            <Link key={k} to={KINDS[k].path} aria-current={active ? 'page' : undefined}
                                className={`inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-semibold transition-colors ${active ? 'bg-primary text-[#120A00]' : 'text-text-body hover:text-white'}`}>
                                <Icon size={15} /> {KINDS[k][zh ? 'zh' : 'en']}
                                <span className={`rounded-full px-1.5 font-mono text-[11px] ${active ? 'bg-black/15' : 'bg-white/[0.08]'}`}>{articlesOfKind(k).length}</span>
                            </Link>
                        );
                    })}
                </div>
            </section>

            <div className="container relative mx-auto px-5 pb-24">
                {/* Topic filter */}
                {topics.length > 1 && (
                    /* phones: one swipeable row (11 chips would otherwise take three lines); wider screens wrap and centre */
                    <div className="no-scrollbar -mx-5 mt-10 flex gap-2 overflow-x-auto px-5 pb-1 sm:mx-0 sm:mt-14 sm:flex-wrap sm:justify-center sm:overflow-visible sm:px-0" role="group" aria-label={t('articles.filter')}>
                        {['all', ...topics].map((k) => (
                            <button key={k} type="button" onClick={() => setTopic(k)} aria-pressed={topic === k}
                                className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors ${topic === k ? 'bg-white/[0.1] text-white ring-1 ring-primary/50' : 'text-text-body ring-1 ring-white/10 hover:text-white hover:ring-white/25'}`}>
                                {k === 'all' ? t('coverage.all') : topicName(k, lang)}
                            </button>
                        ))}
                    </div>
                )}

                {featured && (
                    <Reveal className="mt-10">
                        <ArticleCard article={featured} lang={lang} t={t} variant="featured" />
                    </Reveal>
                )}

                {rest.length > 0 && (
                    <ul className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                        {rest.map((a, i) => {
                            // a lone card on the last row becomes a wide card, so the grid ends cleanly
                            const lone = rest.length % 3 === 1 && i === rest.length - 1 && rest.length > 1;
                            return (
                                <Reveal as="li" key={a.slug} index={i % 3} className={lone ? 'sm:col-span-2 lg:col-span-3' : ''}>
                                    <ArticleCard article={a} lang={lang} t={t} variant={lone ? 'wide' : 'default'} />
                                </Reveal>
                            );
                        })}
                    </ul>
                )}

                {/* CTA band */}
                <section className="relative mt-20 overflow-hidden rounded-[28px] border border-primary/25 bg-[radial-gradient(ellipse_70%_120%_at_0%_0%,rgba(244,121,47,0.18),transparent_60%)] p-8 md:p-12">
                    <div className="grid items-center gap-8 lg:grid-cols-[1.4fr_1fr]">
                        <div>
                            <h2 className="text-2xl font-bold text-white md:text-4xl">{t('articles.hubCtaTitle')}</h2>
                            <p className="mt-4 max-w-xl text-lg text-text-body">{t('articles.ctaDesc')}</p>
                        </div>
                        <div className="flex flex-wrap gap-3 lg:justify-end">
                            <Link to="/contact" className="btn-primary">{t('coverage.talk')} <ArrowUpRight size={18} /></Link>
                            <a href={tgUrl(TG_CHANNEL)} target="_blank" rel="noopener noreferrer" className="btn-ghost"><Send size={16} /> {t('footer.channel')}</a>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

export default ArticlesIndex;
