import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';

const Footer = () => {
    const { pathname } = useLocation();
    const { t } = useTranslation();

    const handleSamePageScroll = (path) => {
        if (pathname === path) {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    return (
        <footer className="bg-[#0e141b] border-t border-white/5 py-16 px-4 md:px-8">
            <div className="max-w-7xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 lg:gap-8 mb-16">
                    <div className="lg:col-span-2 flex flex-col gap-6">
                        <div className="flex items-center gap-3">
                            <span className="font-bold text-white text-xl uppercase tracking-widest">
                                KaazPay
                            </span>
                        </div>
                        <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
                            {t('footer.description')}
                        </p>
                    </div>
                    <div className="flex flex-col gap-4">
                        <h5 className="font-bold text-white text-sm uppercase tracking-wider mb-2">
                            {t('footer.nav_links_label')}
                        </h5>
                        <Link
                            className="text-sm text-gray-500 hover:text-primary transition-colors"
                            to="/about"
                            onClick={() => handleSamePageScroll('/about')}
                        >
                            {t('footer.about')}
                        </Link>
                        <Link
                            className="text-sm text-gray-500 hover:text-primary transition-colors"
                            to="/contact"
                            onClick={() => handleSamePageScroll('/contact')}
                        >
                            {t('footer.contact')}
                        </Link>
                    </div>
                    <div className="flex flex-col gap-4">
                        <h5 className="font-bold text-white text-sm uppercase tracking-wider mb-2">
                            {t('nav.developers')}
                        </h5>
                        <Link
                            className="text-sm text-gray-500 hover:text-primary transition-colors"
                            to="/developer"
                            onClick={() => handleSamePageScroll('/developer')}
                        >
                            {t('home.hero.api_documentation')}
                        </Link>
                    </div>
                </div>
                <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-xs text-gray-600">
                    <p>{t('footer.copyright')}</p>
                    <div className="flex gap-8">
                        <Link
                            className="hover:text-gray-400 transition-colors"
                            to="/privacy"
                            onClick={() => handleSamePageScroll('/privacy')}
                        >
                            {t('footer.privacy')}
                        </Link>
                        <Link
                            className="hover:text-gray-400 transition-colors"
                            to="/terms"
                            onClick={() => handleSamePageScroll('/terms')}
                        >
                            {t('footer.terms')}
                        </Link>
                        <Link
                            className="hover:text-gray-400 transition-colors"
                            to="/cookies"
                            onClick={() => handleSamePageScroll('/cookies')}
                        >
                            {t('cookies.title')}
                        </Link>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
