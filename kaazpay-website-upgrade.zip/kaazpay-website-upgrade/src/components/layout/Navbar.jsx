import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from '../common/LanguageSwitcher';

const Navbar = () => {
    const { pathname } = useLocation();
    const { t } = useTranslation();
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

    // Lock body scroll when mobile menu is open
    useEffect(() => {
        if (isMobileMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';

        }
        return () => {
            document.body.style.overflow = 'unset';

        };
    }, [isMobileMenuOpen]);

    const handleSamePageScroll = (path) => {
        if (pathname === path) {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        setIsMobileMenuOpen(false);
    };

    return (
        <>
            <header className="glass-nav fixed top-0 z-[999] w-full transition-all duration-300">
                <div className="px-4 md:px-8 py-0 flex items-center justify-between max-w-7xl mx-auto h-20">

                    {/* Mobile Menu Button - Left Aligned */}
                    <div className="flex items-center gap-3 lg:hidden -ml-2">
                        <button
                            onClick={() => setIsMobileMenuOpen(true)}
                            className="text-white p-2 hover:bg-white/10 rounded-lg transition-colors"
                            aria-label="Open Menu"
                        >
                            <span className="material-symbols-outlined text-2xl">menu</span>
                        </button>
                        {/* Mobile Merchant Login - Pill Style */}
                        <a
                            href="https://www.kaazpay.com/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center justify-center rounded-full h-9 px-5 bg-surface-lighter border border-white/20 hover:bg-surface-card hover:border-white text-white text-xs font-bold uppercase tracking-wide transition-all shadow-sm whitespace-nowrap"
                            aria-label="Merchant Login"
                        >
                            {t('nav.login')}
                        </a>
                    </div>

                    <nav className="hidden lg:flex items-center gap-8">
                        <NavLink
                            to="/"
                            onClick={() => handleSamePageScroll('/')}
                            className={({ isActive }) =>
                                `text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'
                                }`
                            }
                        >
                            {t('nav.home')}
                        </NavLink>
                        <NavLink
                            to="/solutions"
                            onClick={() => handleSamePageScroll('/solutions')}
                            className={({ isActive }) =>
                                `text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'
                                }`
                            }
                        >
                            {t('nav.solutions')}
                        </NavLink>
                        <NavLink
                            to="/developer"
                            onClick={() => handleSamePageScroll('/developer')}
                            className={({ isActive }) =>
                                `text-sm font-medium transition-colors ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'
                                }`
                            }
                        >
                            {t('nav.developers')}
                        </NavLink>
                        <NavLink
                            to="/about"
                            onClick={() => handleSamePageScroll('/about')}
                            className={({ isActive }) =>
                                `text-sm font-medium transition-colors ${isActive ? 'text-primary' : 'text-gray-400 hover:text-primary'
                                }`
                            }
                        >
                            {t('nav.about')}
                        </NavLink>
                    </nav>

                    <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
                        <Link
                            to="/"
                            onClick={() => handleSamePageScroll('/')}
                            className="relative w-16 h-16 group cursor-pointer hover:scale-110 transition-transform duration-300 block"
                        >
                            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
                            <img
                                alt="KaazPay Logo"
                                className="relative w-full h-full object-contain drop-shadow-[0_0_15px_rgba(227,110,57,0.6)]"
                                src="/kaazpay-logo.png"
                            />
                        </Link>
                    </div>

                    <div className="flex items-center gap-6 ml-auto lg:ml-0">
                        <div className="hidden sm:block">
                            <LanguageSwitcher />
                        </div>
                        <a
                            className="hidden sm:flex items-center justify-center rounded-full h-9 px-5 bg-surface-lighter hover:bg-surface-card text-gray-300 border border-white/10 hover:border-white/20 text-xs font-bold uppercase tracking-wide transition-all shadow-sm hover:text-white hover:shadow-md whitespace-nowrap"
                            href="https://www.kaazpay.com/"
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            {t('nav.merchant_login')}
                        </a>
                        <Link
                            to="/contact"
                            onClick={() => handleSamePageScroll('/contact')}
                            className="flex items-center justify-center rounded-full h-9 px-6 bg-primary hover:bg-primary-dark text-background-dark text-xs font-bold uppercase tracking-wide transition-all shadow-neon hover:shadow-lg hover:shadow-primary/30"
                        >
                            <span className="hidden sm:inline">{t('footer.contact')}</span>
                            <span className="sm:hidden">{t('footer.contact')}</span>
                            <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor" className="ml-1">
                                <path d="M647-440H160v-80h487L423-744l57-56 320 320-320 320-57-56 224-224Z" />
                            </svg>
                        </Link>
                    </div>
                </div>
            </header>

            {/* Mobile Menu Overlay - OUTSIDE header to avoid backdrop-blur stacking context issues */}
            {isMobileMenuOpen && (
                <>
                    {/* Backdrop */}
                    <div
                        className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[99998] lg:hidden"
                        onClick={() => setIsMobileMenuOpen(false)}
                        aria-hidden="true"
                    />

                    {/* Drawer Menu */}
                    <div
                        className="fixed inset-y-0 left-0 w-[85%] max-w-sm z-[99999] lg:hidden shadow-2xl transition-transform duration-300 transform translate-x-0"
                        style={{ backgroundColor: '#0B1015' }}
                    >
                        <div className="flex flex-col h-full p-6 relative">
                            {/* Close Button */}
                            <button
                                onClick={() => setIsMobileMenuOpen(false)}
                                className="absolute top-5 right-5 text-gray-400 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
                            >
                                <span className="material-symbols-outlined text-3xl">close</span>
                            </button>

                            {/* Mobile Logo */}
                            <div className="w-14 h-14 mb-10 mt-2">
                                <img src="/kaazpay-logo.png" alt="KaazPay" className="w-full h-full object-contain" />
                            </div>

                            <nav className="flex flex-col gap-6 text-xl font-bold">
                                <NavLink
                                    to="/"
                                    onClick={() => handleSamePageScroll('/')}
                                    className={({ isActive }) => `py-2 transition-colors ${isActive ? 'text-primary' : 'text-white hover:text-primary'}`}
                                >
                                    {t('nav.home')}
                                </NavLink>
                                <NavLink
                                    to="/solutions"
                                    onClick={() => handleSamePageScroll('/solutions')}
                                    className={({ isActive }) => `py-2 transition-colors ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'}`}
                                >
                                    {t('nav.solutions')}
                                </NavLink>
                                <NavLink
                                    to="/developer"
                                    onClick={() => handleSamePageScroll('/developer')}
                                    className={({ isActive }) => `py-2 transition-colors ${isActive ? 'text-white' : 'text-gray-400 hover:text-white'}`}
                                >
                                    {t('nav.developers')}
                                </NavLink>
                                <NavLink
                                    to="/about"
                                    onClick={() => handleSamePageScroll('/about')}
                                    className={({ isActive }) => `py-2 transition-colors ${isActive ? 'text-primary' : 'text-gray-400 hover:text-primary'}`}
                                >
                                    {t('nav.about')}
                                </NavLink>
                            </nav>

                            <div className="mt-auto pb-8 border-t border-white/10 pt-8">
                                <LanguageSwitcher isMobile={true} onLanguageSelect={() => setIsMobileMenuOpen(false)} />
                            </div>
                        </div>
                    </div>
                </>
            )}
        </>
    );
};

export default Navbar;
