import React, { useEffect, useState } from 'react';

const LegalPageLayout = ({ title, lastUpdated, children }) => {
    const [activeSection, setActiveSection] = useState('');

    useEffect(() => {
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        setActiveSection(entry.target.id);
                    }
                });
            },
            { rootMargin: '-20% 0px -70% 0px' }
        );

        const sections = document.querySelectorAll('div[id]');
        sections.forEach((section) => {
            observer.observe(section);
        });

        return () => {
            sections.forEach((section) => {
                observer.unobserve(section);
            });
        };
    }, []);

    // Extract headings from children for TOC
    // This assumes children is a single div containing sections with IDs and headings
    // For more complex children structures, we might need to pass tocItems as a prop
    const [tocItems, setTocItems] = useState([]);

    useEffect(() => {
        const items = Array.from(document.querySelectorAll('.legal-content h2')).map((heading, index) => {
            const sectionId = heading.parentElement.id;
            return {
                id: sectionId,
                text: heading.innerText,
            };
        });
        setTocItems(items);
    }, [children]);


    return (
        <div className="bg-[#0B1015] min-h-screen">
            {/* Hero Section */}
            <section className="relative pt-36 pb-20 md:pt-48 md:pb-24 px-4 md:px-8 w-full overflow-hidden bg-[#0B1015]">
                <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
                <div className="absolute inset-0 bg-circuit-board bg-center bg-no-repeat bg-cover opacity-30 pointer-events-none"></div>
                <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>

                <div className="relative z-10 max-w-4xl mx-auto flex flex-col items-center text-center">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-primary mb-6">
                        <span className="material-symbols-outlined text-sm">gavel</span>
                        <span>Compliance Documentation</span>
                    </div>
                    <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-white mb-6 drop-shadow-2xl">
                        {title}
                    </h1>
                    <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed font-light tracking-wide">
                        Last Updated: {lastUpdated} <br />
                    </p>
                </div>
            </section>

            <section className="pb-24 px-4 md:px-8 bg-[#0B1015] relative z-20">
                <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
                    {/* Sidebar TOC */}
                    <aside className="hidden lg:block lg:col-span-3">
                        <div className="sticky top-32 space-y-1 pr-4 border-r border-white/5">
                            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-6 pl-4">
                                Contents
                            </h3>
                            <nav className="flex flex-col space-y-1">
                                {tocItems.map((item) => (
                                    <a
                                        key={item.id}
                                        href={`#${item.id}`}
                                        className={`block py-2 pl-4 border-l-2 text-sm transition-colors ${activeSection === item.id
                                            ? 'text-[#00d4c5] border-[#00d4c5] bg-[rgba(0,212,197,0.05)]'
                                            : 'text-gray-400 border-transparent hover:text-white'
                                            }`}
                                        onClick={(e) => {
                                            e.preventDefault();
                                            document.getElementById(item.id)?.scrollIntoView({ behavior: 'smooth' });
                                        }}
                                    >
                                        {item.text}
                                    </a>
                                ))}
                            </nav>
                        </div>
                    </aside>

                    {/* Content Area */}
                    <div className="col-span-1 lg:col-span-8 lg:col-start-5 prose-custom legal-content">
                        <div className="glass-card-deep rounded-2xl p-8 md:p-12 border border-white/5 bg-[#0e141b]/50">
                            {children}
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default LegalPageLayout;
