import React, { useEffect, useRef } from 'react';

const Globe = ({ className = '', size = 800 }) => {
    const canvasRef = useRef(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        const ctx = canvas.getContext('2d');

        // Handle High DPI displays
        const dpr = window.devicePixelRatio || 1;
        const width = size;
        const height = size;
        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.scale(dpr, dpr);
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;

        const GLOBE_RADIUS = width * 0.4;
        const GLOBE_CENTER = { x: width / 2, y: height / 2 };
        let rotation = 0;

        // Configuration
        const DOT_COLOR = '#3e4c5a';
        const DOT_ACTIVE_COLOR = '#00D4C5';
        const ARC_COLOR = '#00D4C5';
        const ARC_COLOR_SECONDARY = '#EAB308';

        // World Map Data Loader
        const mapImage = new Image();
        mapImage.crossOrigin = "Anonymous";
        mapImage.src = "/images/world-map.jpg";

        // State
        let dots = [];
        let arcs = [];
        let ripples = [];
        let animationId;
        let isMapLoaded = false;

        const generateDots = (image) => {
            const offCanvas = document.createElement('canvas');
            offCanvas.width = image.width;
            offCanvas.height = image.height;
            const offCtx = offCanvas.getContext('2d');
            offCtx.drawImage(image, 0, 0);
            const imageData = offCtx.getImageData(0, 0, image.width, image.height);
            const data = imageData.data;

            const newDots = [];

            // GRID BASED SCANNING for accurate shapes
            // Latitude: -90 to 90
            // Longitude: -180 to 180
            // We step through UV coordinates directly

            const rows = 90; // Reduced from 150 for performance
            const cols = 180; // Reduced from 300 for performance

            for (let latIdx = 0; latIdx < rows; latIdx++) {
                // Normalize 0 to 1
                const v = latIdx / rows;
                // Calculate phi (polar angle): 0 to PI
                const phi = v * Math.PI;

                for (let lonIdx = 0; lonIdx < cols; lonIdx++) {
                    const u = lonIdx / cols;
                    // Calculate theta (azimuthal): 0 to 2PI
                    const theta = u * 2 * Math.PI;

                    // Read Pixel
                    const px = Math.floor(u * image.width);
                    const py = Math.floor(v * image.height);
                    const index = (py * image.width + px) * 4;
                    const brightness = (data[index] + data[index + 1] + data[index + 2]) / 3;

                    if (brightness > 90) {
                        // Land!
                        // Convert spherical coordinates back to Cartesian
                        // x = r sin(phi) cos(theta)
                        // y = r cos(phi)   <-- treating Y as up/down pole
                        // z = r sin(phi) sin(theta)

                        // Our coordinate system matches canvas:
                        // y is Down. phi=0 is North Pole (y = -r).
                        // Wait, in 3D usually Y is up. Canvas Y is down.
                        // Let's stick to standard math and project later.

                        // Let's use:
                        // y = -GlobeRadius * cos(phi)  (phi=0 -> north pole -> y=-R top)
                        const y = -GLOBE_RADIUS * Math.cos(phi);
                        const rRing = GLOBE_RADIUS * Math.sin(phi);
                        const x = rRing * Math.cos(theta);
                        const z = rRing * Math.sin(theta);

                        newDots.push({
                            x, y, z,
                            baseAlpha: Math.random() * 0.4 + 0.1, // slightly uniform alpha
                            isActive: Math.random() > 0.99,
                            neighbors: []
                        });
                    }
                }
            }

            // Pre-calculate neighbors for mesh
            // Optimization: Only nearest grid neighbors? 
            // Brute force is too slow for 150x300 = 45k points potential.
            // But land points will be fewer (~10k?). 
            // Let's limit neighbor calc to "active" nodes or just skip mesh for dense dots?
            // DENSE DOTS don't need mesh to see shape. The shape IS the dots.
            // We'll skip mesh for general dots to save FPS, layout is identifiable by dot density.

            return newDots;
        };

        const createArc = (dotList) => {
            if (dotList.length < 100) return null;
            // Pick two random points
            // Try to pick distant points
            let start, end;
            let dist = 0;
            let tries = 0;
            while (dist < GLOBE_RADIUS && tries < 10) {
                const i1 = Math.floor(Math.random() * dotList.length);
                const i2 = Math.floor(Math.random() * dotList.length);
                start = dotList[i1];
                end = dotList[i2];
                dist = Math.sqrt((start.x - end.x) ** 2 + (start.y - end.y) ** 2 + (start.z - end.z) ** 2);
                tries++;
            }

            return {
                start, end,
                progress: 0,
                speed: 0.005 + Math.random() * 0.005,
                color: Math.random() > 0.5 ? ARC_COLOR : ARC_COLOR_SECONDARY,
                hasRippled: false
            };
        };

        const createRipple = (x, y, color) => {
            ripples.push({ x, y, radius: 1, alpha: 1, color });
        };

        const render = () => {
            ctx.clearRect(0, 0, width, height);
            rotation += 0.002;

            if (!isMapLoaded) {
                return requestAnimationFrame(render);
            }

            const projectedDots = [];

            // Optimization: Process dots in loop
            for (let i = 0; i < dots.length; i++) {
                const dot = dots[i];

                // Rot Y
                let x = dot.x * Math.cos(rotation) - dot.z * Math.sin(rotation);
                let z = dot.x * Math.sin(rotation) + dot.z * Math.cos(rotation);

                // Tilt
                const tilt = 0.3;
                let y = dot.y * Math.cos(tilt) - z * Math.sin(tilt);
                z = dot.y * Math.sin(tilt) + z * Math.cos(tilt);

                if (z > -GLOBE_RADIUS * 0.8) { // Cull back-facing early-ish
                    projectedDots.push({
                        x: x + GLOBE_CENTER.x,
                        y: y + GLOBE_CENTER.y,
                        z,
                        baseAlpha: dot.baseAlpha,
                        isActive: dot.isActive,
                        dotRef: dot
                    });
                }
            }

            // Sort by Z for proper render order (back to front)
            // Not strictly necessary for additive/transparency but good for occlusion if we had it.
            // projectedDots.sort((a,b) => a.z - b.z);

            // Draw Dots
            for (let i = 0; i < projectedDots.length; i++) {
                const dot = projectedDots[i];
                const isFront = dot.z >= 0;
                const alphaRatio = (dot.z + GLOBE_RADIUS) / (GLOBE_RADIUS * 2);

                ctx.beginPath();
                if (!isFront) {
                    // Back dots - optimized rendering
                    ctx.fillStyle = `rgba(62, 76, 90, 0.15)`;
                    ctx.fillRect(dot.x - 0.75, dot.y - 0.75, 1.5, 1.5);
                } else {
                    // Front dots
                    if (dot.isActive) {
                        const glow = ctx.createRadialGradient(dot.x, dot.y, 0, dot.x, dot.y, 4);
                        glow.addColorStop(0, DOT_ACTIVE_COLOR);
                        glow.addColorStop(1, 'transparent');
                        ctx.fillStyle = glow;
                        ctx.beginPath();
                        ctx.arc(dot.x, dot.y, 4, 0, Math.PI * 2);
                        ctx.fill();
                        ctx.fillStyle = '#fff';
                        ctx.beginPath();
                        ctx.arc(dot.x, dot.y, 1.2, 0, Math.PI * 2);
                        ctx.fill();
                    } else {
                        ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0.15, alphaRatio * 0.8)})`;
                        ctx.fillRect(dot.x - 0.75, dot.y - 0.75, 1.5, 1.5);
                    }
                }
            }

            // Update Arcs
            const activeArcs = [];
            arcs.forEach(arc => {
                if (!arc) return;
                arc.progress += arc.speed;
                if (arc.progress >= 1) {
                    if (!arc.hasRippled) {
                        // Project end point to check visibility
                        const d = arc.end;
                        let x = d.x * Math.cos(rotation) - d.z * Math.sin(rotation);
                        let z = d.x * Math.sin(rotation) + d.z * Math.cos(rotation);
                        // Tilt
                        const tilt = 0.3;
                        let y = d.y * Math.cos(tilt) - z * Math.sin(tilt);
                        z = d.y * Math.sin(tilt) + z * Math.cos(tilt);

                        if (z > -GLOBE_RADIUS * 0.2) {
                            createRipple(x + GLOBE_CENTER.x, y + GLOBE_CENTER.y, arc.color);
                        }
                    }
                    arc.hasRippled = true;
                    activeArcs.push(createArc(dots));
                } else {
                    activeArcs.push(arc);
                }
            });
            while (activeArcs.length < 6 && dots.length > 100) {
                const newArc = createArc(dots);
                if (newArc) activeArcs.push(newArc);
                else break;
            }
            arcs = activeArcs;

            // Draw Arcs
            arcs.forEach(arc => {
                if (!arc) return;

                // Project Start/End
                // We need to project freshly every frame due to rotation
                const project = (d) => {
                    let x = d.x * Math.cos(rotation) - d.z * Math.sin(rotation);
                    let z = d.x * Math.sin(rotation) + d.z * Math.cos(rotation);
                    const tilt = 0.3;
                    let y = d.y * Math.cos(tilt) - z * Math.sin(tilt);
                    z = d.y * Math.sin(tilt) + z * Math.cos(tilt);
                    return { x: x + GLOBE_CENTER.x, y: y + GLOBE_CENTER.y, z };
                };

                const start = project(arc.start);
                const end = project(arc.end);

                // if both behind, skip
                if (start.z < -GLOBE_RADIUS * 0.5 && end.z < -GLOBE_RADIUS * 0.5) return;

                const midX = (start.x + end.x) / 2;
                const midY = (start.y + end.y) / 2;
                const dx = midX - GLOBE_CENTER.x;
                const dy = midY - GLOBE_CENTER.y;
                const mag = Math.sqrt(dx * dx + dy * dy);
                const arcHeight = 100;
                const ctrlX = midX + (dx / mag) * arcHeight;
                const ctrlY = midY + (dy / mag) * arcHeight;

                ctx.beginPath();
                ctx.moveTo(start.x, start.y);
                ctx.quadraticCurveTo(ctrlX, ctrlY, end.x, end.y);
                ctx.strokeStyle = `rgba(255, 255, 255, 0.05)`;
                ctx.lineWidth = 1;
                ctx.stroke();

                const t = arc.progress;
                const invT = 1 - t;
                const pX = invT * invT * start.x + 2 * invT * t * ctrlX + t * t * end.x;
                const pY = invT * invT * start.y + 2 * invT * t * ctrlY + t * t * end.y;

                const grad = ctx.createRadialGradient(pX, pY, 0, pX, pY, 6);
                grad.addColorStop(0, arc.color);
                grad.addColorStop(1, 'transparent');
                ctx.fillStyle = grad;
                ctx.beginPath();
                ctx.arc(pX, pY, 6, 0, Math.PI * 2);
                ctx.fill();

                ctx.fillStyle = '#fff';
                ctx.beginPath();
                ctx.arc(pX, pY, 1.5, 0, Math.PI * 2);
                ctx.fill();
            });

            // Ripples
            const activeRipples = [];
            ripples.forEach(rip => {
                rip.radius += 0.5;
                rip.alpha -= 0.02;
                if (rip.alpha > 0) {
                    ctx.beginPath();
                    ctx.strokeStyle = rip.color;
                    ctx.globalAlpha = rip.alpha;
                    ctx.lineWidth = 2;
                    ctx.arc(rip.x, rip.y, rip.radius, 0, Math.PI * 2);
                    ctx.stroke();
                    ctx.globalAlpha = 1;
                    activeRipples.push(rip);
                }
            });
            ripples.length = 0;
            activeRipples.forEach(r => ripples.push(r));

            animationId = requestAnimationFrame(render);
        };

        mapImage.onload = () => {
            dots = generateDots(mapImage);
            arcs = [];
            for (let i = 0; i < 6; i++) {
                const a = createArc(dots);
                if (a) arcs.push(a);
            }
            isMapLoaded = true;
            render();
        };

        return () => {
            cancelAnimationFrame(animationId);
        };

    }, [size]);

    return (
        <canvas ref={canvasRef} className={className} />
    );
};

export default Globe;
