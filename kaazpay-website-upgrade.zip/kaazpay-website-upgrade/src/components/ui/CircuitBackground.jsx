import React from 'react';

const CircuitBackground = ({ className = '' }) => {
    return (
        <div className={`absolute inset-0 overflow-hidden pointer-events-none ${className}`}>

            {/* Defs for Glow Filter - Reduced Intensity */}
            <svg style={{ position: 'absolute', width: 0, height: 0 }}>
                <defs>
                    <filter id="neon-glow" x="-50%" y="-50%" width="200%" height="200%">
                        <feGaussianBlur stdDeviation="1.5" result="coloredBlur" />
                        <feMerge>
                            <feMergeNode in="coloredBlur" />
                            <feMergeNode in="SourceGraphic" />
                        </feMerge>
                    </filter>
                    <linearGradient id="fade-gradient-left" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#00D4C5" stopOpacity="1" />
                        <stop offset="100%" stopColor="#00D4C5" stopOpacity="0" />
                    </linearGradient>
                </defs>
            </svg>

            {/* Left Side Circuit - Adjusted for Text Clearance */}
            <svg className="absolute top-0 left-0 h-full w-[45%] text-[#00D4C5]" viewBox="0 0 500 900" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g filter="url(#neon-glow)">
                    {/* Top Cluster - Pulled back */}
                    <path d="M-50 120 H 80 L 110 150 H 220" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
                    <path d="M-50 140 H 60 L 90 170 H 180" stroke="currentColor" strokeWidth="1" opacity="0.4" />

                    {/* Mid-Top Focus Group - Lower Opacity & Further Left */}
                    <path d="M-50 250 H 100 L 130 220 H 200 L 230 250 H 280" stroke="currentColor" strokeWidth="1.5" opacity="0.6" className="animate-pulse-slow" />
                    <circle cx="280" cy="250" r="3" fill="currentColor" opacity="0.7" />
                    <path d="M-50 270 H 90 L 110 290 H 210" stroke="currentColor" strokeWidth="1" opacity="0.4" />

                    {/* Center Focus Lines - MOVED DOWN & FADED to avoid Title */}
                    {/* The title is roughly at y=300-450. We push lines down or make them very subtle. */}
                    <path d="M-50 480 H 120 L 160 520 H 280" stroke="currentColor" strokeWidth="2" opacity="0.8" />
                    <path d="M280 520 L 310 520" stroke="currentColor" strokeWidth="2" strokeDasharray="4 4" opacity="0.5" />
                    <circle cx="310" cy="520" r="4" fill="currentColor" className="animate-ping-slow" />

                    <path d="M-50 500 H 80 L 120 540 H 200" stroke="currentColor" strokeWidth="1" opacity="0.5" />

                    {/* Lower Cluster */}
                    <path d="M-50 630 H 140 L 180 590 H 300" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />
                    <path d="M-50 660 H 180 L 210 690 H 330" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />

                    {/* Vertical Connectors */}
                    <path d="M110 150 V 180" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                    <path d="M160 520 V 560" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                </g>

                {/* Subtle Background Geometry */}
                <path d="M0 100 H 400" stroke="url(#fade-gradient-left)" strokeWidth="0.5" opacity="0.1" />
                <path d="M0 800 H 400" stroke="url(#fade-gradient-left)" strokeWidth="0.5" opacity="0.1" />
            </svg>

            {/* Right Side Circuit - Mirror & Offset */}
            <svg className="absolute top-0 right-0 h-full w-[45%] text-[#00D4C5]" viewBox="0 0 500 900" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ transform: 'scaleX(-1)' }}>
                <g filter="url(#neon-glow)">
                    {/* Top Focus - Pulled back */}
                    <path d="M-50 180 H 100 L 140 220 H 260" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
                    <circle cx="260" cy="220" r="3" fill="currentColor" className="animate-ping-slow" style={{ animationDelay: '1s', opacity: 0.7 }} />

                    <path d="M-50 200 H 80 L 100 220" stroke="currentColor" strokeWidth="1" opacity="0.4" />
                    <path d="M-50 300 H 120 L 150 270 H 220" stroke="currentColor" strokeWidth="1.5" opacity="0.5" />

                    {/* Center Focus - MOVED DOWN to avoid Title */}
                    <path d="M-50 500 H 140 L 180 540 H 280" stroke="currentColor" strokeWidth="2" opacity="0.8" />
                    <path d="M280 540 L 310 540" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" opacity="0.5" />

                    <path d="M-50 530 H 100 L 130 560 H 200" stroke="currentColor" strokeWidth="1" opacity="0.5" />

                    {/* Bottom Cluster */}
                    <path d="M-50 650 H 150 L 190 610 H 320" stroke="currentColor" strokeWidth="1.5" opacity="0.7" />
                    <circle cx="320" cy="610" r="3" fill="currentColor" opacity="0.7" />

                    <path d="M-50 720 H 100 L 130 750 H 220" stroke="currentColor" strokeWidth="1" opacity="0.5" />

                    {/* Connectors */}
                    <path d="M140 220 V 260" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                    <path d="M180 540 V 580" stroke="currentColor" strokeWidth="1" opacity="0.3" />
                </g>
            </svg>

            {/* Ambient Glows - Reduced */}
            <div className="absolute top-[30%] left-0 w-[300px] h-[300px] bg-[#00D4C5]/5 rounded-full blur-[100px] pointer-events-none"></div>
            <div className="absolute top-[30%] right-0 w-[300px] h-[300px] bg-[#00D4C5]/5 rounded-full blur-[100px] pointer-events-none"></div>
        </div>
    );
};

export default CircuitBackground;
