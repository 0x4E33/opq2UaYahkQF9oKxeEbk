import { useLayoutEffect } from 'react';
import { useLocation } from 'react-router-dom';

const ScrollToTop = () => {
    const { pathname, hash } = useLocation();

    useLayoutEffect(() => {
        const scrollToElement = () => {
            if (hash) {
                const id = hash.replace('#', '');
                const element = document.getElementById(id);
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                } else {
                    // Fallback retry for hash links if element is not yet ready
                    setTimeout(() => {
                        const retryElement = document.getElementById(id);
                        if (retryElement) {
                            retryElement.scrollIntoView({ behavior: 'smooth' });
                        }
                    }, 100);
                }
            } else {
                // Immediate scroll to top for standard navigation to prevent flickering
                window.scrollTo(0, 0);
            }
        };

        scrollToElement();
    }, [pathname, hash]);

    return null;
};

export default ScrollToTop;
