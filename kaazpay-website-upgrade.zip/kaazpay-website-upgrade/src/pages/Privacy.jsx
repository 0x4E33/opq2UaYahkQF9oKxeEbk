import React, { useEffect } from 'react';
import { useTranslation, Trans } from 'react-i18next';
import LegalPageLayout from '../components/layout/LegalPageLayout';

const Privacy = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('privacy.meta.title');
    }, [t]);
    return (
        <LegalPageLayout
            title={<>{t('privacy.title')}</>}
            lastUpdated={t('privacy.last_updated')}
        >
            <div className="mb-8">
                <p>
                    {t('privacy.intro.p1')}
                </p>
                <p className="mt-4">
                    {t('privacy.intro.p2_prefix')} <span className="text-white font-medium"><a href="https://t.me/KaazPayEZ">@KaazPayEZ</a></span> {t('privacy.intro.p2_suffix')} <span className="text-white font-medium"><a href="https://t.me/KaazPay_BD2">@KaazPay BD</a></span>
                </p>
            </div>

            <div className="scroll-mt-32" id="collect">
                <h2>{t('privacy.collect.title')}</h2>
                <p>
                    {t('privacy.collect.intro')}
                </p>

                <h3>{t('privacy.collect.pii.title')}</h3>
                <p>
                    {t('privacy.collect.pii.intro')}
                </p>
                <ul>
                    <li><strong>{t('privacy.collect.pii.list.name.label')}</strong>{t('privacy.collect.pii.list.name.text')}</li>
                    <li><strong>{t('privacy.collect.pii.list.ssn.label')}</strong>{t('privacy.collect.pii.list.ssn.text')}</li>
                    <li><strong>{t('privacy.collect.pii.list.address.label')}</strong>{t('privacy.collect.pii.list.address.text')}</li>
                    <li><strong>{t('privacy.collect.pii.list.dob.label')}</strong>{t('privacy.collect.pii.list.dob.text')}</li>
                    <li><strong>{t('privacy.collect.pii.list.email.label')}</strong>{t('privacy.collect.pii.list.email.text')}</li>
                    <li><strong>{t('privacy.collect.pii.list.phone.label')}</strong>{t('privacy.collect.pii.list.phone.text')}</li>
                </ul>

                <h3>{t('privacy.collect.financial.title')}</h3>
                <ul>
                    <li><strong>{t('privacy.collect.financial.list.bank.label')}</strong>{t('privacy.collect.financial.list.bank.text')}</li>
                    <li><strong>{t('privacy.collect.financial.list.card.label')}</strong>{t('privacy.collect.financial.list.card.text')}</li>
                    <li><strong>{t('privacy.collect.financial.list.records.label')}</strong>{t('privacy.collect.financial.list.records.text')}</li>
                </ul>

                <h3>{t('privacy.collect.technical.title')}</h3>
                <ul>
                    <li><strong>{t('privacy.collect.technical.list.ip.label')}</strong>{t('privacy.collect.technical.list.ip.text')}</li>
                    <li><strong>{t('privacy.collect.technical.list.device.label')}</strong>{t('privacy.collect.technical.list.device.text')}</li>
                    <li><strong>{t('privacy.collect.technical.list.os.label')}</strong>{t('privacy.collect.technical.list.os.text')}</li>
                    <li><strong>{t('privacy.collect.technical.list.cookies.label')}</strong>{t('privacy.collect.technical.list.cookies.text')}</li>
                </ul>

                <h3>{t('privacy.collect.geolocation.title')}</h3>
                <ul>
                    <li><strong>{t('privacy.collect.geolocation.list.realtime.label')}</strong>{t('privacy.collect.geolocation.list.realtime.text')}</li>
                </ul>

                <h3>{t('privacy.collect.communication.title')}</h3>
                <ul>
                    <li><strong>{t('privacy.collect.communication.list.email.label')}</strong>{t('privacy.collect.communication.list.email.text')}</li>
                    <li><strong>{t('privacy.collect.communication.list.calls.label')}</strong>{t('privacy.collect.communication.list.calls.text')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="use">
                <h2>{t('privacy.use.title')}</h2>
                <p>
                    {t('privacy.use.intro')}
                </p>

                <h3>{t('privacy.use.compliance.title')}</h3>
                <p>
                    {t('privacy.use.compliance.intro')}
                </p>
                <ul>
                    <li>{t('privacy.use.compliance.list.aml')}</li>
                    <li>{t('privacy.use.compliance.list.kyc')}</li>
                    <li>{t('privacy.use.compliance.list.sar')}</li>
                    <li>{t('privacy.use.compliance.list.fraud')}</li>
                </ul>

                <h3>{t('privacy.use.services.title')}</h3>
                <p>
                    {t('privacy.use.services.intro')}
                </p>
                <ul>
                    <li><strong>{t('privacy.use.services.list.transaction.label')}</strong>{t('privacy.use.services.list.transaction.text')}</li>
                    <li><strong>{t('privacy.use.services.list.support.label')}</strong>{t('privacy.use.services.list.support.text')}</li>
                    <li><strong>{t('privacy.use.services.list.personalized.label')}</strong>{t('privacy.use.services.list.personalized.text')}</li>
                </ul>

                <h3>{t('privacy.use.prevention.title')}</h3>
                <p>
                    {t('privacy.use.prevention.intro')}
                </p>
                <ul>
                    <li><strong>{t('privacy.use.prevention.list.monitor.label')}</strong>{t('privacy.use.prevention.list.monitor.text')}</li>
                    <li><strong>{t('privacy.use.prevention.list.identity.label')}</strong>{t('privacy.use.prevention.list.identity.text')}</li>
                    <li><strong>{t('privacy.use.prevention.list.detection.label')}</strong>{t('privacy.use.prevention.list.detection.text')}</li>
                </ul>

                <h3>{t('privacy.use.marketing.title')}</h3>
                <ul>
                    <li><strong>{t('privacy.use.marketing.list.promo.label')}</strong>{t('privacy.use.marketing.list.promo.text')}</li>
                    <li><strong>{t('privacy.use.marketing.list.notify.label')}</strong>{t('privacy.use.marketing.list.notify.text')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="sharing">
                <h2>{t('privacy.sharing.title')}</h2>
                <p>
                    {t('privacy.sharing.intro')}
                </p>

                <h3>{t('privacy.sharing.legal.title')}</h3>
                <ul>
                    <li>{t('privacy.sharing.legal.list.reporting')}</li>
                    <li>{t('privacy.sharing.legal.list.court')}</li>
                </ul>

                <h3>{t('privacy.sharing.third_party.title')}</h3>
                <p>{t('privacy.sharing.third_party.intro')}</p>
                <ul>
                    <li><strong>{t('privacy.sharing.third_party.list.processors.label')}</strong>{t('privacy.sharing.third_party.list.processors.text')}</li>
                    <li><strong>{t('privacy.sharing.third_party.list.verification.label')}</strong>{t('privacy.sharing.third_party.list.verification.text')}</li>
                    <li><strong>{t('privacy.sharing.third_party.list.support.label')}</strong>{t('privacy.sharing.third_party.list.support.text')}</li>
                </ul>

                <h3>{t('privacy.sharing.fraud.title')}</h3>
                <p>
                    {t('privacy.sharing.fraud.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="storage">
                <h2>{t('privacy.storage.title')}</h2>

                <h3>{t('privacy.storage.security.title')}</h3>
                <p>
                    {t('privacy.storage.security.intro')}
                </p>
                <ul>
                    <li><strong>{t('privacy.storage.security.list.encryption.label')}</strong>{t('privacy.storage.security.list.encryption.text')}</li>
                    <li><strong>{t('privacy.storage.security.list.access.label')}</strong>{t('privacy.storage.security.list.access.text')}</li>
                    <li><strong>{t('privacy.storage.security.list.network.label')}</strong>{t('privacy.storage.security.list.network.text')}</li>
                </ul>

                <h3>{t('privacy.storage.retention.title')}</h3>
                <ul>
                    <li>{t('privacy.storage.retention.list.legal')}</li>
                    <li>{t('privacy.storage.retention.list.deletion')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="rights">
                <h2>{t('privacy.rights.title')}</h2>

                <h3>{t('privacy.rights.access.title')}</h3>
                <p>
                    {t('privacy.rights.access.desc')}
                </p>

                <h3>{t('privacy.rights.rectification.title')}</h3>
                <p>
                    {t('privacy.rights.rectification.desc')}
                </p>

                <h3>{t('privacy.rights.erasure.title')}</h3>
                <p>
                    {t('privacy.rights.erasure.desc')}
                </p>

                <h3>{t('privacy.rights.objection.title')}</h3>
                <p>
                    {t('privacy.rights.objection.desc')}
                </p>

                <h3>{t('privacy.rights.portability.title')}</h3>
                <p>
                    {t('privacy.rights.portability.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="children">
                <h2>{t('privacy.children.title')}</h2>
                <p>
                    {t('privacy.children.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="transfer">
                <h2>{t('privacy.transfer.title')}</h2>
                <p>
                    {t('privacy.transfer.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="changes">
                <h2>{t('privacy.changes.title')}</h2>
                <p>
                    {t('privacy.changes.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="contact">
                <h2>{t('privacy.contact.title')}</h2>
                <p>
                    {t('privacy.contact.desc_prefix')} <span className="text-white font-medium"><a href="https://t.me/KaazPayEZ">@KaazPayEZ</a></span> {t('privacy.contact.desc_suffix')} <span className="text-white font-medium"><a href="https://t.me/KaazPay_BD2">@KaazPay BD</a></span>
                </p>
            </div>
        </LegalPageLayout>
    );
};

export default Privacy;
