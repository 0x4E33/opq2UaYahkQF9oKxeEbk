import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Globe from '../components/ui/Globe';
import CircuitBackground from '../components/ui/CircuitBackground';
import { useTranslation, Trans } from 'react-i18next';

const Home = () => {
    const { t } = useTranslation();
    const [activeTab, setActiveTab] = useState('global');
    const [globeSize, setGlobeSize] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768 ? 350 : 600);
    const [activeFeatureTab, setActiveFeatureTab] = useState('smart_routing');

    useEffect(() => {
        const handleResize = () => {
            setGlobeSize(window.innerWidth < 768 ? 350 : 600);
        };
        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const features = {
        smart_routing: {
            title: t('home.features.smart_routing.title'),
            cards: [
                {
                    title: t('home.features.smart_routing.card1.title'),
                    icon: "alt_route",
                    iconColor: "text-secondary",
                    iconBg: "bg-secondary/20",
                    desc: t('home.features.smart_routing.card1.desc'),
                    visual: "routing"
                },
                {
                    title: t('home.features.smart_routing.card2.title'),
                    icon: "monitoring",
                    iconColor: "text-primary",
                    iconBg: "bg-primary/20",
                    desc: t('home.features.smart_routing.card2.desc'),
                    visual: "analytics"
                }
            ]
        },
        instant_settlement: {
            title: t('home.features.instant_settlement.title'),
            cards: [
                {
                    title: t('home.features.instant_settlement.card1.title'),
                    icon: "payments",
                    iconColor: "text-green-400",
                    iconBg: "bg-green-500/20",
                    desc: t('home.features.instant_settlement.card1.desc'),
                    visual: "settlement_t0"
                },
                {
                    title: t('home.features.instant_settlement.card2.title'),
                    icon: "trending_up",
                    iconColor: "text-blue-400",
                    iconBg: "bg-blue-500/20",
                    desc: t('home.features.instant_settlement.card2.desc'),
                    visual: "cashflow_chart"
                }
            ]
        },
        risk_control: {
            title: t('home.features.risk_control.title'),
            cards: [
                {
                    title: t('home.features.risk_control.card1.title'),
                    icon: "security",
                    iconColor: "text-red-400",
                    iconBg: "bg-red-500/20",
                    desc: t('home.features.risk_control.card1.desc'),
                    visual: "fraud_scanning"
                },
                {
                    title: t('home.features.risk_control.card2.title'),
                    icon: "gpp_good",
                    iconColor: "text-yellow-400",
                    iconBg: "bg-yellow-500/20",
                    desc: t('home.features.risk_control.card2.desc'),
                    visual: "account_lock"
                }
            ]
        },
        multi_channel: {
            title: t('home.features.multi_channel.title'),
            cards: [
                {
                    title: t('home.features.multi_channel.card1.title'),
                    icon: "public",
                    iconColor: "text-purple-400",
                    iconBg: "bg-purple-500/20",
                    desc: t('home.features.multi_channel.card1.desc'),
                    visual: "global_icons"
                },
                {
                    title: t('home.features.multi_channel.card2.title'),
                    icon: "thumb_up",
                    iconColor: "text-pink-400",
                    iconBg: "bg-pink-500/20",
                    desc: t('home.features.multi_channel.card2.desc'),
                    visual: "payment_methods"
                }
            ]
        }
    };

    useEffect(() => {
        document.title = t('meta.title');
    }, [t]);

    return (
        <div className="bg-[#0B1015]">
            {/* Hero Section */}
            <section className="relative pt-36 pb-20 md:pt-48 md:pb-32 px-4 md:px-8 w-full overflow-hidden bg-[#0B1015]">
                <div className="absolute inset-0 bg-grid-pattern opacity-20 pointer-events-none"></div>
                {/* Circuit Background - Positioned behind all content */}
                <div className="absolute inset-0 -mt-40 md:mt-0 pointer-events-none z-[0]">
                    <CircuitBackground className="opacity-80" />
                </div>
                <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-primary/10 rounded-full blur-[80px] pointer-events-none animate-pulse-slow"></div>

                <div className="relative z-10 max-w-5xl mx-auto flex flex-col items-center text-center">
                    <div className="mb-20 animate-slide-up relative z-20">
                        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-[5.5rem] font-bold leading-[1] tracking-tight text-white mb-8 drop-shadow-2xl">
                            <Trans
                                i18nKey="home.hero.title"
                                components={{
                                    1: <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary via-white to-primary text-glow" />,
                                    3: <span className="text-primary text-glow" />,
                                    br: <br />
                                }}
                            />
                        </h1>
                        <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed mb-10 font-light tracking-wide">
                            <Trans i18nKey="home.hero.description" components={{ 1: <span className="text-white font-medium" />, 3: <span className="text-white font-medium" /> }} />
                        </p>
                        <div className="flex flex-col sm:flex-row justify-center gap-5 relative z-[100]">
                            <Link to="/solutions" className="flex items-center justify-center rounded-full h-12 px-8 bg-primary hover:bg-primary-dark text-background-dark text-base font-bold shadow-neon hover:shadow-neon-strong transition-all duration-200 group relative overflow-hidden">
                                <div className="absolute top-0 left-[-100%] w-[50%] h-full bg-white/30 skew-x-[-20deg] animate-beam pointer-events-none"></div>
                                {t('home.hero.explore_solutions')}
                                <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor" className="ml-2 group-hover:translate-x-1 transition-transform">
                                    <path d="m226-559 78 33q14-28 29-54t33-52l-56-11-84 84Zm142 83 114 113q42-16 90-49t90-75q70-70 109.5-155.5T806-800q-72-5-158 34.5T492-656q-42 42-75 90t-49 90Zm155-121.5q0-33.5 23-56.5t57-23q34 0 57 23t23 56.5q0 33.5-23 56.5t-57 23q-34 0-57-23t-23-56.5ZM565-220l84-84-11-56q-26 18-52 32.5T532-299l33 79Zm313-653q19 121-23.5 235.5T708-419l20 99q4 20-2 39t-20 33L538-80l-84-197-171-171-197-84 167-168q14-14 33.5-20t39.5-2l99 20q104-104 218-147t235-24ZM157-321q35-35 85.5-35.5T328-322q35 35 34.5 85.5T327-151q-25 25-83.5 43T82-76q14-103 32-161.5t43-83.5Zm57 56q-10 10-20 36.5T180-175q27-4 53.5-13.5T270-208q12-12 13-29t-11-29q-12-12-29-11.5T214-265Z" />
                                </svg>

                            </Link>
                            <Link to="/developer" className="flex items-center justify-center rounded-full h-12 px-8 bg-white/5 hover:bg-white/10 text-white border border-white/10 hover:border-white/30 text-base font-medium transition-all backdrop-blur-sm group">
                                {t('home.hero.api_documentation')}
                                <svg xmlns="http://www.w3.org/2000/svg" height="20" viewBox="0 -960 960 960" width="20" fill="currentColor" className="ml-2 text-gray-400 group-hover:text-white transition-colors">
                                    <path d="M320-240 80-480l240-240 57 57-184 184 183 183-56 56Zm320 0-57-57 184-184-183-183 56-56 240 240-240 240Z" />
                                </svg>
                            </Link>
                        </div>
                    </div>

                    <div className="relative w-full max-w-5xl h-[500px] mt-8 perspective-[1500px] group/visuals">
                        {/* Floating Card Left */}
                        <div className="absolute left-0 md:-left-4 top-20 md:top-28 w-[320px] md:w-[380px] z-20 animate-float-delayed">
                            <div className="glass-card-deep rounded-xl p-0 relative overflow-hidden transform rotate-[-5deg] group-hover/visuals:rotate-[-7deg] transition-all duration-700 shadow-card-glow border-t border-l border-white/10">
                                <div className="flex items-center justify-between px-4 py-3 bg-white/5 border-b border-white/5">
                                    <div className="flex items-center gap-2">
                                        <div className="w-2 h-2 rounded-full bg-red-500"></div>
                                        <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                                    </div>
                                    <div className="text-[10px] uppercase tracking-wider text-gray-500 font-mono">
                                        {t('home.visuals.acquiring_node')}
                                    </div>
                                </div>
                                <div className="p-5 dashboard-grid relative">
                                    <div className="flex justify-between items-start mb-6">
                                        <div>
                                            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                                                {t('home.visuals.success_rate')}
                                            </p>
                                            <div className="flex items-baseline gap-2">
                                                <span className="text-3xl font-mono text-white font-medium">
                                                    99.9%
                                                </span>
                                                <span className="text-[10px] text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded border border-green-500/20">
                                                    {t('home.visuals.stable')}
                                                </span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                                                {t('home.visuals.volume_24h')}
                                            </p>
                                            <div className="text-xl font-mono text-primary font-medium">
                                                $8.24M
                                            </div>
                                        </div>
                                    </div>
                                    <div className="h-28 w-full relative">
                                        <div className="absolute bottom-0 left-0 w-full h-full flex items-end justify-between gap-1">
                                            <div className="w-full bg-cyan-900/30 h-[30%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[45%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[35%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[60%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[50%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[75%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-cyan-900/30 h-[65%] rounded-sm hover:bg-cyan-500/50 transition-colors"></div>
                                            <div className="w-full bg-primary/80 h-[85%] rounded-sm shadow-[0_0_15px_rgba(0,212,197,0.4)] relative group cursor-pointer">
                                                <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-surface-dark border border-primary/30 text-primary text-[9px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                                                    {t('home.visuals.peak_time')}
                                                </div>
                                            </div>
                                        </div>
                                        {/* SVG Curve */}
                                        <svg className="absolute inset-0 w-full h-full overflow-visible pointer-events-none">
                                            <path
                                                d="M0 60 C 20 50, 40 70, 60 40 S 100 20, 140 30 S 180 60, 220 20 S 260 10, 300 5"
                                                fill="none"
                                                filter="drop-shadow(0 0 4px #00d4c5)"
                                                stroke="#00d4c5"
                                                strokeLinecap="round"
                                                strokeWidth="2"
                                            ></path>
                                            <path
                                                d="M0 60 C 20 50, 40 70, 60 40 S 100 20, 140 30 S 180 60, 220 20 S 260 10, 300 5 V 120 H 0 Z"
                                                fill="url(#grad1)"
                                                opacity="0.2"
                                            ></path>
                                            <defs>
                                                <linearGradient id="grad1" x1="0%" x2="0%" y1="0%" y2="100%">
                                                    <stop offset="0%" stopColor="#00d4c5" stopOpacity="0.5"></stop>
                                                    <stop offset="100%" stopColor="#00d4c5" stopOpacity="0"></stop>
                                                </linearGradient>
                                            </defs>
                                        </svg>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Main Center Card */}
                        <div className="absolute left-1/2 -translate-x-1/2 top-0 w-[360px] md:w-[460px] z-30">
                            <div className="glass-card-deep rounded-xl p-0 relative overflow-hidden shadow-2xl border border-white/20 bg-[#151c24]">
                                <div className="flex items-center justify-between px-5 py-4 bg-white/5 border-b border-white/10">
                                    <div className="flex items-center gap-3">
                                        <div className="p-1.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/20">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="14" viewBox="0 -960 960 960" width="14" fill="currentColor">
                                                <path d="M200-280v-280h80v280h-80Zm240 0v-280h80v280h-80ZM80-120v-80h800v80H80Zm600-160v-280h80v280h-80ZM80-640v-80l400-200 400 200v80H80Zm178-80h444-444Zm0 0h444L480-830 258-720Z" />
                                            </svg>
                                        </div>
                                        <span className="text-xs font-bold text-gray-200 tracking-wide uppercase">
                                            {t('home.visuals.settlement_dashboard')}
                                        </span>
                                    </div>
                                    <div className="flex items-center gap-2 px-2 py-1 bg-green-500/10 rounded-full border border-green-500/20">
                                        <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                                        <span className="text-[10px] text-green-400 font-bold uppercase">
                                            {t('home.visuals.live_feed')}
                                        </span>
                                    </div>
                                </div>
                                <div className="p-6">
                                    <div className="flex justify-between items-end mb-8 relative">
                                        <div className="absolute -right-4 -top-4 w-20 h-20 bg-blue-500/10 rounded-full blur-xl"></div>
                                        <div>
                                            <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 font-semibold">
                                                {t('home.visuals.settlement_status')}
                                            </div>
                                            <div className="text-4xl font-mono text-white font-bold tracking-tight mb-1">
                                                D0
                                                <span className="text-lg text-gray-500 font-normal">
                                                    / {t('home.visuals.instant')}
                                                </span>
                                            </div>
                                            <div className="text-[10px] text-gray-500">
                                                {t('home.visuals.next_batch')}
                                                <span className="text-white font-mono"> 00:06:23</span>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <div className="text-xs text-primary mb-2 font-bold uppercase tracking-wider">
                                                {t('home.visuals.processing')}
                                            </div>
                                            <div className="w-32 h-1.5 bg-surface-lighter rounded-full overflow-hidden">
                                                <div className="h-full bg-gradient-to-r from-blue-500 to-primary w-[93%] rounded-full shadow-[0_0_10px_#00d4c5] animate-pulse"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        {/* List Items */}
                                        {[
                                            { name: "StarBet International", id: "PO-99281", amount: "$24,500.00", status: t('home.visuals.sent'), color: "indigo" },
                                            { name: "M88 Gaming", id: "PO-99282", amount: "$12,800.00", status: t('home.visuals.sent'), color: "orange" },
                                            { name: "G-Force Esports", id: "PO-99283", amount: "$8,450.50", status: t('home.visuals.sending'), color: "purple", icon: "sync", iconAnimate: true }
                                        ].map((item, i) => (
                                            <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-white/[0.03] border border-white/5 hover:border-primary/30 transition-all group cursor-pointer hover:bg-white/[0.06]">
                                                <div className="flex items-center gap-3">
                                                    <div className={`w-8 h-8 rounded-full bg-gradient-to-br from-${item.color}-500/20 to-transparent flex items-center justify-center border border-${item.color}-500/20 text-${item.color}-300 text-xs font-bold`}>
                                                        {item.name[0]}
                                                    </div>
                                                    <div>
                                                        <div className="text-xs text-white font-bold">{item.name}</div>
                                                        <div className="text-[9px] text-gray-500 font-mono">
                                                            ID: {item.id} • {t('home.visuals.instant')}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-right">
                                                    <div className="text-sm font-mono text-white font-medium">{item.amount}</div>
                                                    <div className={`text-[9px] ${item.status === 'Sent' ? 'text-green-400' : 'text-blue-400'} flex items-center justify-end gap-1`}>
                                                        {item.icon === 'sync' ? (
                                                            <svg xmlns="http://www.w3.org/2000/svg" height="10" viewBox="0 -960 960 960" width="10" fill="currentColor" className="animate-spin">
                                                                <path d="M160-160v-80h110l-16-14q-52-46-73-105t-21-119q0-111 66.5-197.5T400-790v84q-72 26-116 88.5T240-478q0 45 17 87.5t53 78.5l10 10v-98h80v240H160Zm400-10v-84q72-26 116-88.5T720-482q0-45-17-87.5T650-648l-10-10v98h-80v-240h240v80H690l16 14q49 49 71.5 106.5T800-482q0 111-66.5 197.5T560-170Z" />
                                                            </svg>
                                                        ) : (
                                                            <svg xmlns="http://www.w3.org/2000/svg" height="10" viewBox="0 -960 960 960" width="10" fill="currentColor">
                                                                <path d="m424-296 282-282-56-56-226 226-114-114-56 56 170 170Zm56 216q-83 0-156-31.5T197-197q-54-54-85.5-127T80-480q0-83 31.5-156T197-763q54-54 127-85.5T480-880q83 0 156 31.5T763-763q54 54 85.5 127T880-480q0 83-31.5 156T763-197q-54 54-127 85.5T480-80Zm0-80q134 0 227-93t93-227q0-134-93-227t-227-93q-134 0-227 93t-93 227q0 134 93 227t227 93Zm0-320Z" />
                                                            </svg>
                                                        )}
                                                        {item.status}
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                <div className="h-[2px] w-full bg-surface-dark relative overflow-hidden">
                                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary to-transparent w-[50%] animate-[beam_2s_linear_infinite]"></div>
                                </div>
                            </div>
                        </div>

                        {/* Floating Card Right */}
                        <div className="absolute right-0 md:-right-4 top-24 md:top-36 w-[320px] md:w-[380px] z-10 animate-float">
                            <div className="glass-card-deep rounded-xl p-0 relative overflow-hidden transform rotate-[4deg] group-hover/visuals:rotate-[6deg] transition-all duration-700 shadow-2xl border-t border-r border-white/10 bg-surface-dark/95">
                                <div className="flex items-center justify-between px-4 py-3 bg-white/5 border-b border-white/5">
                                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                                        {t('home.visuals.fraud_mitigation')}
                                    </span>
                                    <div className="flex items-center gap-1.5">
                                        <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                        <span className="text-[9px] text-green-500 font-bold uppercase">
                                            {t('home.visuals.active_shield')}
                                        </span>
                                    </div>
                                </div>
                                <div className="p-5 relative">
                                    <div className="flex justify-between items-center mb-6">
                                        <div className="relative w-24 h-24">
                                            <svg className="w-full h-full transform -rotate-90">
                                                <circle cx="48" cy="48" fill="transparent" r="40" stroke="#1e293b" strokeWidth="6"></circle>
                                                <circle cx="48" cy="48" fill="transparent" r="40" stroke="#00d4c5" strokeDasharray="251.2" strokeDashoffset="20" strokeWidth="6"></circle>
                                            </svg>
                                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                                                <span className="text-2xl font-bold text-white">98</span>
                                                <span className="text-[8px] text-gray-400 uppercase">{t('home.visuals.trust_score')}</span>
                                            </div>
                                        </div>
                                        <div className="flex-1 pl-4 space-y-3">
                                            <div className="bg-surface-lighter/50 rounded p-2 border border-white/5 flex justify-between items-center">
                                                <span className="text-[10px] text-gray-400 uppercase">{t('home.visuals.flags')}</span>
                                                <span className="text-xs font-mono text-red-400">0.02%</span>
                                            </div>
                                            <div className="bg-surface-lighter/50 rounded p-2 border border-white/5 flex justify-between items-center">
                                                <span className="text-[10px] text-gray-400 uppercase">{t('home.visuals.chargebacks')}</span>
                                                <span className="text-xs font-mono text-green-400">0.00%</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="space-y-2">
                                        <div className="flex items-center gap-2 text-[10px] text-gray-400 border-b border-dashed border-gray-700 pb-2 mb-2">
                                            <span className="material-symbols-outlined text-[14px] text-red-500">block</span>
                                            <span>{t('home.visuals.blocked_ip')}</span>
                                            <span className="ml-auto text-gray-600">{t('home.visuals.now')}</span>
                                        </div>
                                        <div className="flex items-center gap-2 text-[10px] text-gray-400">
                                            <span className="material-symbols-outlined text-[14px] text-yellow-500">warning</span>
                                            <span>{t('home.visuals.velocity_check')}</span>
                                            <span className="ml-auto text-gray-600">{t('home.visuals.one_min_ago')}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >

            {/* Active Payment Channels */}
            < section className="py-16 border-y border-white/5 bg-[#0e141b] relative" >
                <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col w-full relative z-10">
                    <div className="flex flex-col items-center md:flex-row justify-between md:items-end mb-12">
                        <div className="text-center md:text-left">
                            <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-2">
                                {t('home.payment_channels.title')}
                            </h2>
                            <p className="text-sm font-medium text-gray-400 tracking-wide uppercase">
                            </p>
                        </div>
                        <div className="hidden md:flex gap-2 mt-4 md:mt-0">
                            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs text-gray-300">
                                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                                {t('home.payment_channels.systems_operational')}
                            </div>
                        </div>
                    </div>

                    <div className="w-full">
                        <div className="bg-surface-card/60 backdrop-blur-xl rounded-3xl border border-white/5 overflow-hidden flex flex-col lg:flex-row shadow-2xl shadow-black/50">
                            {/* Sidebar - Control Panel */}
                            <div className="w-full lg:w-72 bg-[#0B1015]/80 border-b lg:border-b-0 lg:border-r border-white/5 relative group/sidebar">
                                <div className="absolute inset-0 bg-grid-pattern opacity-5 pointer-events-none"></div>

                                {/* Scrollable Container */}
                                <div className="p-4 lg:p-6 pb-2 lg:pb-6 flex flex-row lg:flex-col gap-2 overflow-x-auto no-scrollbar relative z-10 w-full">
                                    <div className="hidden lg:block text-xs font-bold text-gray-500 uppercase tracking-widest px-4 mb-2">{t('home.payment_channels.regions_label')}</div>
                                    {['global', 'sea', 'africa', 'latam', 'north_america', 'other'].map((tab) => (
                                        <button
                                            key={tab}
                                            onClick={() => setActiveTab(tab)}
                                            className={`relative min-w-[140px] lg:min-w-0 w-auto lg:w-full px-4 lg:px-6 py-3 lg:py-4 rounded-xl text-left transition-all duration-300 flex items-center justify-between group overflow-hidden shrink-0 ${activeTab === tab
                                                ? 'bg-gradient-to-r from-primary/10 to-transparent text-white shadow-[inset_3px_0_0_0_var(--primary)]'
                                                : 'text-gray-400 hover:text-gray-200 hover:bg-white/5'
                                                }`}
                                        >
                                            <span className={`font-medium text-sm tracking-wide transition-colors ${activeTab === tab ? 'text-primary pl-2' : ''}`}>
                                                {tab === 'sea' ? t('home.payment_channels.sea') :
                                                    tab === 'latam' ? t('home.payment_channels.latam') :
                                                        tab === 'north_america' ? t('home.payment_channels.north_america') :
                                                            tab === 'other' ? t('home.payment_channels.south_asia') :
                                                                tab === 'africa' ? t('home.payment_channels.africa') :
                                                                    t('home.payment_channels.global')}
                                            </span>
                                            {activeTab === tab && (
                                                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-12 h-12 bg-primary/20 blur-xl rounded-full"></div>
                                            )}
                                        </button>
                                    ))}
                                    {/* Spacer for mobile scroll padding */}
                                    <div className="w-8 shrink-0 lg:hidden"></div>
                                </div>

                                {/* Mobile Scroll Fade Indicator - Right Side */}
                                <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#0B1015] via-[#0B1015]/80 to-transparent pointer-events-none z-20 lg:hidden"></div>
                            </div>

                            {/* Content Area - Data Grid */}
                            <div className="flex-1 bg-[#131b24]/50 p-6 lg:p-10 relative h-auto lg:h-[650px] overflow-visible lg:overflow-hidden flex flex-col">
                                <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-50 z-10"></div>

                                <div className="lg:overflow-y-auto lg:custom-scrollbar h-full pr-0 lg:pr-2 -mr-0 lg:-mr-2 pb-0 lg:pb-10">
                                    {/* Global Tab Content */}
                                    {activeTab === 'global' && (
                                        <div className="animate-slide-up grid grid-cols-1 md:grid-cols-2 gap-6">
                                            {[
                                                { title: t('home.payment_channels.global_fiat.title'), subtitle: t('home.payment_channels.global_fiat.subtitle'), icon: 'credit_card', color: 'text-primary', badge: t('home.payment_channels.global_fiat.badge'), desc: t('home.payment_channels.global_fiat.desc') },
                                                { title: t('home.payment_channels.global_usdt.title'), subtitle: t('home.payment_channels.global_usdt.subtitle'), icon: 'currency_bitcoin', color: 'text-secondary', badge: t('home.payment_channels.global_usdt.badge'), desc: t('home.payment_channels.global_usdt.desc') }
                                            ].map((card, idx) => (
                                                <div key={idx} className="group relative bg-[#0f151b] rounded-2xl border border-white/5 hover:border-primary/30 transition-all duration-300 flex flex-col overflow-hidden hover:shadow-[0_0_40px_-10px_rgba(0,212,197,0.1)] min-h-[300px]">
                                                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                                                    <div className="p-8 relative z-10 flex flex-col h-full">
                                                        <div className="flex items-start justify-between mb-8">
                                                            <div>
                                                                <div className="flex items-center gap-2 mb-2">
                                                                    <span className={`w-2 h-2 rounded-full ${idx === 0 ? 'bg-primary' : 'bg-secondary'}`}></span>
                                                                    <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">{card.subtitle}</span>
                                                                </div>
                                                                <h4 className="text-2xl font-bold text-white tracking-tight">{card.title}</h4>
                                                            </div>
                                                            <div className={`w-12 h-12 rounded-2xl bg-[#0B1015] border border-white/10 flex items-center justify-center ${card.color} shadow-lg group-hover:scale-110 transition-transform`}>
                                                                {card.icon === 'credit_card' ? (
                                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                                                                        <path d="M880-720v480q0 33-23.5 56.5T800-160H160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720Zm-720 80h640v-80H160v80Zm0 160v240h640v-240H160Zm0 240v-480 480Z" />
                                                                    </svg>
                                                                ) : (
                                                                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24" fill="currentColor">
                                                                        <path d="M360-120v-80H240v-80h80v-400h-80v-80h120v-80h80v80h80v-80h80v85q52 14 86 56.5t34 98.5q0 29-10 55.5T682-497q35 21 56.5 57t21.5 80q0 66-47 113t-113 47v80h-80v-80h-80v80h-80Zm40-400h160q33 0 56.5-23.5T640-600q0-33-23.5-56.5T560-680H400v160Zm0 240h200q33 0 56.5-23.5T680-360q0-33-23.5-56.5T600-440H400v160Z" />
                                                                    </svg>
                                                                )}
                                                            </div>
                                                        </div>

                                                        <p className="text-gray-400 text-sm leading-relaxed mb-8 border-l-2 border-white/10 pl-4">{card.desc}</p>

                                                        <div className="mt-auto flex items-center justify-between pt-6 border-t border-white/5">
                                                            <span className="px-3 py-1 rounded bg-green-500/10 border border-green-500/20 text-[10px] text-green-400 font-mono font-bold uppercase tracking-wider flex items-center gap-2">
                                                                <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                                                                {card.badge}
                                                            </span>
                                                            <span className="material-symbols-outlined text-gray-600 group-hover:text-primary transition-colors">arrow_forward</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}

                                    {/* Regional Tab Content (Unified Grid) */}
                                    {activeTab !== 'global' && (
                                        <div className="animate-slide-up grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                                            {(activeTab === 'sea' ? [
                                                { code: 'MY', country: t('home.payment_channels.countries.malaysia'), channels: ['FPX', 'DuitNow QR', 'Native DuitNow QR', 'Native FPX', 'Native TNG'], payout: true },
                                                { code: 'TH', country: t('home.payment_channels.countries.thailand'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'PH', country: t('home.payment_channels.countries.philippines'), channels: ['Native GCash'], payout: true },
                                                { code: 'ID', country: t('home.payment_channels.countries.indonesia'), channels: ['QRIS', 'VA'], payout: true },
                                            ] : activeTab === 'africa' ? [
                                                { code: 'ZA', country: t('home.payment_channels.countries.south_africa'), channels: ['ZARduct', 'South Africa Cards', 'Mobile Money', 'BankTransferZA', 'CapitecPay', 'Credit Card'], payout: true },
                                                { code: 'NG', country: t('home.payment_channels.countries.nigeria'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'KE', country: t('home.payment_channels.countries.kenya'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'UG', country: t('home.payment_channels.countries.uganda'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'TZ', country: 'Tanzania', channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'CM', country: 'Cameroon', channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'EG', country: 'Egypt', channels: ['Local Bank Transfer'], payout: true },
                                            ] : activeTab === 'latam' ? [
                                                { code: 'CO', country: t('home.payment_channels.countries.colombia'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'MX', country: t('home.payment_channels.countries.mexico'), channels: ['Local Bank Transfer'], payout: true },
                                                { code: 'BR', country: t('home.payment_channels.countries.brazil'), channels: ['PIX'], payout: true },
                                            ] : activeTab === 'north_america' ? [
                                                { code: 'US', country: t('home.payment_channels.countries.united_states'), channels: ['Apple Pay', 'Google Pay', 'Cash App'], payout: true },
                                            ] : [
                                                { code: 'BD', country: t('home.payment_channels.countries.bangladesh'), channels: ['Local Bank Transfer'], payout: true },
                                            ]).map((item, idx) => (
                                                <div key={idx} className="group relative bg-[#0f151b] rounded-xl border border-white/5 hover:border-white/20 transition-all duration-300 flex flex-col overflow-hidden hover:-translate-y-1 hover:shadow-lg">
                                                    <div className="p-5 flex flex-col h-full relative z-10">
                                                        <div className="flex items-center gap-4 mb-4">
                                                            <div className="w-10 h-10 rounded-lg bg-[#1A2332] border border-white/5 flex items-center justify-center overflow-hidden shadow-inner relative group-hover:scale-105 transition-transform duration-300">
                                                                <img
                                                                    src={`/flags/${item.flag || `${item.code.toLowerCase()}.png`}`}
                                                                    alt={item.country}
                                                                    className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                                                                />
                                                                <div className="absolute inset-0 bg-gradient-to-tr from-black/20 to-transparent"></div>
                                                            </div>
                                                            <div>
                                                                <h4 className="text-white font-bold text-sm tracking-wide group-hover:text-primary transition-colors">{item.country}</h4>
                                                            </div>
                                                        </div>

                                                        <div className="space-y-3 mb-5 flex-1">
                                                            <div>
                                                                <p className="text-[10px] uppercase text-gray-500 font-bold mb-2 tracking-wider flex items-center gap-1.5">
                                                                    <span className="w-1 h-1 rounded-full bg-blue-400"></span>
                                                                    {t('home.payment_channels.payin')}
                                                                </p>
                                                                <div className="flex flex-wrap gap-1.5">
                                                                    {item.channels.map(c => (
                                                                        <span key={c} className="px-2 py-1 rounded bg-white/[0.04] border border-white/5 text-[10px] text-gray-300 group-hover:text-white group-hover:bg-white/[0.08] transition-colors cursor-default">
                                                                            {c}
                                                                        </span>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </div>

                                                        {/* Payout Section */}
                                                        {item.payout && (
                                                            <div className="pt-4 border-t border-white/5 space-y-2">
                                                                <p className="text-[10px] uppercase text-gray-500 font-bold tracking-wider flex items-center gap-1.5">
                                                                    <span className="w-1 h-1 rounded-full bg-green-500"></span>
                                                                    {t('home.payment_channels.payout')}
                                                                </p>
                                                                {/* <div className="flex flex-wrap gap-1.5">
                                                                    <span className="px-2 py-1 rounded bg-green-500/10 border border-green-500/20 text-[10px] text-green-400 font-medium cursor-default">
                                                                        Bank Transfer
                                                                    </span>
                                                                    {['KEN', 'PHL', 'IDN', 'BGD'].includes(item.country) || item.channels.some(c => c.includes('Wallet') || c.includes('Mobile') || c.includes('GCash') || c.includes('M-Pesa')) ? (
                                                                        <span className="px-2 py-1 rounded bg-green-500/10 border border-green-500/20 text-[10px] text-green-400 font-medium cursor-default">
                                                                            E-Wallets
                                                                        </span>
                                                                    ) : null}
                                                                </div> */}
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >

            {/* Solutions Section - Financial Universe */}
            < section className="py-24 md:py-32 bg-surface-dark relative overflow-hidden" >
                <div className="absolute inset-0 bg-mesh-gradient opacity-20 pointer-events-none animate-pulse-slow"></div>
                <div className="absolute inset-0 z-0">
                    <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,_rgba(0,212,197,0.05)_0%,_transparent_50%)] animate-pulse-slow"></div>
                    <div className="absolute w-[200%] h-[200%] top-[-50%] left-[-50%] bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMiIgY3k9IjIiIHI9IjEiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4wNSkiLz48L3N2Zz4=')] animate-spin-slow opacity-30"></div>
                </div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-6">
                            {t('home.solutions.title')}
                        </h2>
                        <p className="text-lg text-gray-400 max-w-2xl mx-auto">
                            {t('home.solutions.description')}
                        </p>
                    </div>

                    {/* Scrollable Tabs Container */}
                    <div className="relative mb-8 md:mb-12">
                        <div className="flex flex-nowrap md:flex-wrap overflow-x-auto no-scrollbar justify-start md:justify-center gap-2 px-4 md:px-0 pb-2">
                            {Object.entries(features).map(([key, feature]) => (
                                <button
                                    key={key}
                                    onClick={() => setActiveFeatureTab(key)}
                                    className={`px-5 md:px-6 py-2 md:py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-all duration-300 flex-shrink-0 ${activeFeatureTab === key
                                        ? 'bg-secondary text-white shadow-lg shadow-secondary/20 scale-105 ring-2 ring-secondary/50'
                                        : 'bg-surface-card hover:bg-surface-lighter text-gray-400 hover:text-white border border-white/5 hover:border-white/10'
                                        }`}
                                >
                                    {feature.title}
                                </button>
                            ))}
                            {/* Spacer for mobile scroll */}
                            <div className="w-4 md:hidden flex-shrink-0"></div>
                        </div>
                        {/* Mobile Scroll Fade Indicator */}
                        <div className="absolute right-0 top-0 bottom-2 w-12 bg-gradient-to-l from-[#161c24] to-transparent pointer-events-none md:hidden"></div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8 px-4 md:px-0">
                        {features[activeFeatureTab].cards.map((card, idx) => (
                            <div key={idx} className="bg-surface-card rounded-2xl border border-white/5 overflow-hidden group hover:border-white/10 transition-all duration-500 relative h-[340px] md:h-[500px]">
                                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40 z-10"></div>
                                <div className="p-6 md:p-12 relative z-20 h-full flex flex-col justify-end">
                                    <div className={`w-10 h-10 md:w-12 md:h-12 rounded-lg flex items-center justify-center mb-4 md:mb-6 border ${card.iconBg} border-opacity-20`}>
                                        <span className={`material-symbols-outlined text-xl md:text-2xl ${card.iconColor}`}>{card.icon}</span>
                                    </div>
                                    <h3 className="text-xl md:text-2xl font-bold text-white mb-2 md:mb-3">{card.title}</h3>
                                    <p className="text-sm md:text-base text-gray-400 mb-2 md:mb-6 max-w-sm leading-relaxed">{card.desc}</p>
                                </div>

                                {/* Dynamic Visuals based on card type */}
                                <div className="absolute top-0 right-0 w-full h-full p-8 md:p-12 opacity-40 group-hover:opacity-60 transition-opacity duration-500">

                                    {/* 1. Smart Routing: Node Graph (Preserved) */}
                                    {card.visual === 'routing' && (
                                        <div className="w-full h-full border border-dashed border-white/10 rounded-lg flex items-center justify-center">
                                            <div className="relative w-40 h-40 md:w-48 md:h-48">
                                                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-white rounded-full flex items-center justify-center z-10 shadow-[0_0_20px_rgba(255,255,255,0.2)]">
                                                    <span className="material-symbols-outlined text-black">hub</span>
                                                </div>
                                                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-surface-dark border border-green-500 rounded-full flex items-center justify-center text-green-500 text-[10px]">99%</div>
                                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-8 bg-surface-dark border border-yellow-500 rounded-full flex items-center justify-center text-yellow-500 text-[10px]">95%</div>
                                                <div className="absolute top-1/2 right-0 -translate-y-1/2 w-8 h-8 bg-surface-dark border border-red-500 rounded-full flex items-center justify-center text-red-500 text-[10px]">80%</div>
                                                <svg className="absolute inset-0 w-full h-full pointer-events-none">
                                                    <line stroke="rgba(74, 222, 128, 0.5)" strokeDasharray="4 2" strokeWidth="1" x1="50%" x2="50%" y1="50%" y2="10%"></line>
                                                    <line stroke="rgba(234, 179, 8, 0.5)" strokeDasharray="4 2" strokeWidth="1" x1="50%" x2="50%" y1="50%" y2="90%"></line>
                                                    <line stroke="rgba(239, 68, 68, 0.5)" strokeDasharray="4 2" strokeWidth="1" x1="50%" x2="90%" y1="50%" y2="50%"></line>
                                                </svg>
                                            </div>
                                        </div>
                                    )}

                                    {/* 2. Real-Time Analytics: Dashboard (Updated) */}
                                    {card.visual === 'analytics' && (
                                        <div className="absolute top-8 right-[-10%] w-[110%] h-full transform transition-all duration-500 group-hover:right-[0%]">
                                            <div className="glass-card-deep rounded-xl p-5 h-full border border-white/10 shadow-2xl relative dashboard-grid">
                                                {/* Metrics Header */}
                                                <div className="flex justify-between items-start mb-6">
                                                    <div>
                                                        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                                                            Success Rate
                                                        </p>
                                                        <div className="flex items-baseline gap-2">
                                                            <span className="text-3xl font-mono text-white font-medium">
                                                                99.9%
                                                            </span>
                                                            <span className="text-[10px] text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded border border-green-500/20">
                                                                {t('home.visuals.stable')}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className="text-right">
                                                        <p className="text-[10px] uppercase tracking-widest text-gray-400 font-semibold mb-1">
                                                            Volume (24h)
                                                        </p>
                                                        <div className="text-xl font-mono text-primary font-medium">
                                                            $8.24M
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Chart Visual */}
                                                <div className="h-40 w-full relative">
                                                    <div className="absolute bottom-0 left-0 w-full h-full flex items-end justify-between gap-1">
                                                        {[30, 45, 35, 60, 50, 75, 65, 85].map((h, i) => (
                                                            <div key={i} className={`w-full rounded-sm transition-all duration-500 ${i === 7 ? 'bg-primary/80 shadow-[0_0_15px_rgba(0,212,197,0.4)]' : 'bg-cyan-900/30 hover:bg-cyan-500/50'}`} style={{ height: `${h}%` }}></div>
                                                        ))}
                                                    </div>
                                                    {/* SVG Curve */}
                                                    <svg className="absolute inset-0 w-full h-full overflow-visible pointer-events-none">
                                                        <path d="M0 80 C 20 70, 40 90, 60 60 S 100 40, 140 50 S 180 80, 220 40 S 260 30, 300 15" fill="none" filter="drop-shadow(0 0 4px #00d4c5)" stroke="#00d4c5" strokeLinecap="round" strokeWidth="2" />
                                                        <path d="M0 80 C 20 70, 40 90, 60 60 S 100 40, 140 50 S 180 80, 220 40 S 260 30, 300 15 V 140 H 0 Z" fill="url(#gradAnalytics)" opacity="0.2" />
                                                        <defs>
                                                            <linearGradient id="gradAnalytics" x1="0%" x2="0%" y1="0%" y2="100%">
                                                                <stop offset="0%" stopColor="#00d4c5" stopOpacity="0.5" />
                                                                <stop offset="100%" stopColor="#00d4c5" stopOpacity="0" />
                                                            </linearGradient>
                                                        </defs>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* ... (settlement_t0, cashflow_chart, fraud_scanning, account_lock skipped for brevity as they are unchanged) ... */}

                                    {/* 3. Instant Settlement - T0 Visual */}
                                    {card.visual === 'settlement_t0' && (
                                        <div className="w-full h-full flex items-center justify-center">
                                            <div className="relative w-40 h-40 rounded-full border-4 border-white/5 flex items-center justify-center">
                                                <div className="absolute inset-0 border-4 border-green-500/30 rounded-full border-t-green-500 animate-spin-slow"></div>
                                                <div className="text-center">
                                                    <div className="text-4xl font-bold text-white mb-1">T+0</div>
                                                    <div className="text-[10px] text-green-400 uppercase tracking-widest font-bold">Instant</div>
                                                </div>
                                                <div className="absolute -top-4 right-0 bg-green-500 text-black text-xs font-bold px-2 py-1 rounded-full shadow-lg shadow-green-500/20">
                                                    {t('home.features.visual_text.d0_ready')}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* 4. Cash Flow - Chart Visual */}
                                    {card.visual === 'cashflow_chart' && (
                                        <div className="absolute bottom-0 right-0 w-[90%] h-[70%]">
                                            <div className="w-full h-full border-l border-b border-white/10 p-4 relative">
                                                {/* Chart Bars */}
                                                <div className="flex items-end justify-between h-full gap-2">
                                                    {[30, 45, 35, 60, 50, 80, 75, 95].map((h, i) => (
                                                        <div key={i} className="w-full bg-blue-500/20 rounded-t-sm relative group" style={{ height: `${h}%` }}>
                                                            <div className="absolute bottom-0 left-0 w-full bg-blue-500 opacity-60 h-0 group-hover:h-full transition-all duration-700" style={{ height: `${h}%` }}></div>
                                                        </div>
                                                    ))}
                                                </div>
                                                {/* Trend Line */}
                                                <svg className="absolute inset-0 w-full h-full px-4 overflow-visible pointer-events-none">
                                                    <path d="M0 70 Q 50 80, 100 40 T 200 10" fill="none" stroke="#60A5FA" strokeWidth="2" strokeDasharray="4 4" className="opacity-50" />
                                                </svg>
                                            </div>
                                        </div>
                                    )}

                                    {/* 5. Fraud Prevention - Radar Visual */}
                                    {card.visual === 'fraud_scanning' && (
                                        <div className="w-full h-full flex items-center justify-center">
                                            <div className="relative w-48 h-48 rounded-full border border-red-500/20 bg-red-500/5 flex items-center justify-center overflow-hidden">
                                                {/* Scanning Line */}
                                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-red-500/20 to-transparent w-[50%] h-full animate-spin-slow origin-right" style={{ transformOrigin: '100% 50%' }}></div>

                                                {/* Shield Icon */}
                                                <div className="relative z-10 w-16 h-16 bg-surface-dark rounded-xl flex items-center justify-center border border-red-500/30 shadow-[0_0_30px_rgba(239,68,68,0.2)]">
                                                    <span className="material-symbols-outlined text-red-500 text-3xl">shield</span>
                                                </div>

                                                {/* Blips */}
                                                <div className="absolute top-10 left-10 w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
                                                <div className="absolute bottom-12 right-12 w-2 h-2 bg-red-500 rounded-full animate-ping" style={{ animationDelay: '1s' }}></div>

                                                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] px-2 py-0.5 rounded">
                                                    {t('home.features.visual_text.threat_blocked')}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* 6. Account Security - Lock Visual */}
                                    {card.visual === 'account_lock' && (
                                        <div className="w-full h-full flex items-center justify-center">
                                            <div className="relative w-full max-w-[240px] bg-surface-dark border border-white/10 rounded-xl p-4 shadow-2xl">
                                                <div className="flex items-center gap-2 mb-4">
                                                    <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                                                    <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
                                                    <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
                                                </div>
                                                <div className="space-y-3">
                                                    <div className="h-8 bg-white/5 rounded border border-white/5 flex items-center px-3 gap-2">
                                                        <span className="material-symbols-outlined text-gray-500 text-xs">lock</span>
                                                        <div className="w-16 h-2 bg-white/20 rounded"></div>
                                                    </div>
                                                    <div className="h-8 bg-white/5 rounded border border-white/5 flex items-center px-3 gap-2">
                                                        <span className="material-symbols-outlined text-gray-500 text-xs">key</span>
                                                        <div className="flex gap-1">
                                                            <div className="w-2 h-2 rounded-full bg-white/40"></div>
                                                            <div className="w-2 h-2 rounded-full bg-white/40"></div>
                                                            <div className="w-2 h-2 rounded-full bg-white/40"></div>
                                                            <div className="w-2 h-2 rounded-full bg-white/40"></div>
                                                        </div>
                                                    </div>
                                                    <div className="mt-2 w-full bg-green-500 hover:bg-green-600 text-white text-xs font-bold py-2 rounded text-center transition-colors">
                                                        {t('home.features.visual_text.login_secure')}
                                                    </div>
                                                </div>

                                                <div className="absolute -right-4 -top-4 bg-yellow-500 text-black text-[10px] font-bold px-2 py-1 rounded shadow-lg">
                                                    {t('home.features.visual_text.2fa_active')}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {/* 7. Global Coverage - Floating Icons Visual (Updated) */}
                                    {card.visual === 'global_icons' && (
                                        <div className="w-full h-full flex items-center justify-center relative">
                                            {/* Center Globe/Map Placeholder */}
                                            <div className="w-32 h-32 rounded-full border border-purple-500/20 bg-purple-500/5 flex items-center justify-center relative z-10 glass-card-tech">
                                                <span className="material-symbols-outlined text-4xl text-purple-500/50 animate-pulse">public</span>
                                            </div>

                                            {/* Orbiting Icons - Ring 1 */}
                                            <div className="absolute top-1/2 left-1/2 w-[80%] h-[80%] -translate-x-1/2 -translate-y-1/2 animate-spin-slow" style={{ animationDuration: '25s' }}>
                                                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3 bg-white/10 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-white border border-white/20 shadow-lg">MYR</div>
                                                <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-3 bg-white/10 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-white border border-white/20 shadow-lg">THA</div>
                                                <div className="absolute left-0 top-1/2 -translate-x-3 -translate-y-1/2 bg-green-500/20 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-green-400 border border-green-500/30 shadow-lg">USDT</div>
                                                <div className="absolute right-0 top-1/2 translate-x-3 -translate-y-1/2 bg-blue-500/20 backdrop-blur-md px-2 py-1 rounded text-[10px] font-bold text-blue-400 border border-blue-500/30 shadow-lg">IDN</div>
                                            </div>

                                            {/* Orbiting Icons - Ring 2 (Reverse) */}
                                            <div className="absolute top-1/2 left-1/2 w-[110%] h-[110%] -translate-x-1/2 -translate-y-1/2 animate-spin-slow" style={{ animationDuration: '35s', animationDirection: 'reverse' }}>
                                                <div className="absolute top-[15%] left-[15%] bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10"></div>
                                                <div className="absolute bottom-[15%] right-[15%] bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10">COL</div>
                                                <div className="absolute top-[15%] right-[15%] bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10">PHL</div>
                                                <div className="absolute bottom-[15%] left-[15%] bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10">MEX</div>
                                                <div className="absolute top-1/2 -right-2 bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10">ZAF</div>
                                                <div className="absolute top-1/2 -left-2 bg-white/5 backdrop-blur-sm px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-300 border border-white/10">NGA</div>
                                            </div>
                                        </div>
                                    )}

                                    {/* 8. User Habits - Payment Methods Visual */}
                                    {card.visual === 'payment_methods' && (
                                        <div className="absolute top-12 right-[-10%] w-[110%] group-hover:right-[0%] transition-all duration-500">
                                            <div className="bg-surface-dark border border-white/10 rounded-l-xl shadow-2xl p-6 space-y-4">
                                                <div className="text-xs text-gray-500 uppercase font-bold tracking-wider mb-2">{t('home.features.visual_text.checkout')}</div>

                                                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10 hover:border-pink-500/50 transition-colors cursor-pointer">
                                                    <div className="flex items-center gap-3">
                                                        <span className="material-symbols-outlined text-white">credit_card</span>
                                                        <span className="text-sm text-gray-300">Apple Pay</span>
                                                    </div>
                                                    <div className="w-4 h-4 rounded-full border border-gray-500"></div>
                                                </div>

                                                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-pink-500/50 hover:border-pink-500 transition-colors cursor-pointer">
                                                    <div className="flex items-center gap-3">
                                                        <span className="material-symbols-outlined text-pink-500">account_balance_wallet</span>
                                                        <span className="text-sm text-white font-medium">{t('home.features.visual_text.local_wallet')}</span>
                                                    </div>
                                                    <div className="w-4 h-4 rounded-full border-4 border-pink-500 bg-transparent"></div>
                                                </div>

                                                <div className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/10 hover:border-pink-500/50 transition-colors cursor-pointer">
                                                    <div className="flex items-center gap-3">
                                                        <span className="material-symbols-outlined text-green-500">currency_bitcoin</span>
                                                        <span className="text-sm text-gray-300">{t('home.features.visual_text.crypto_usdt')}</span>
                                                    </div>
                                                    <div className="w-4 h-4 rounded-full border border-gray-500"></div>
                                                </div>

                                                <button className="w-full py-2 bg-pink-500 hover:bg-pink-600 text-white rounded font-bold text-xs transition-colors mt-2">
                                                    {t('home.features.visual_text.pay_now')}
                                                </button>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section >

            {/* Solutions for Gaming & Live Streaming */}
            < section className="py-20 md:py-32 relative overflow-hidden bg-[#0B1015]" >
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-indigo-900/10 via-[#0B1015] to-[#0B1015] pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="text-center mb-20">
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-4">
                            {t('home.solutions.gaming_streaming_title')}
                        </h2>
                        <p className="text-gray-400 text-lg max-w-2xl mx-auto">
                            {t('home.solutions.gaming_streaming_desc')}
                        </p>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12">
                        {/* Gaming Card */}
                        <div className="group relative overflow-hidden rounded-3xl border border-white/10 h-[400px] md:h-[600px] bg-surface-card transition-all duration-500 hover:border-primary/40 hover:shadow-neon">
                            <div className="absolute inset-0 bg-[url('/images/igaming-card-game.png')] bg-cover bg-center opacity-40 transition-transform duration-700 group-hover:scale-105"></div>
                            <div className="absolute inset-0 bg-gradient-to-t from-[#0B1015] via-[#0B1015]/90 to-transparent"></div>
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <div className="relative z-10 p-6 md:p-12 h-full flex flex-col justify-end">
                                <h3 className="text-2xl md:text-4xl font-bold text-white mb-3 md:mb-4">{t('home.solutions.gaming.title')}</h3>
                                <p className="text-gray-400 text-sm md:text-lg mb-6 md:mb-8 leading-relaxed max-w-md">{t('home.solutions.gaming.desc')}</p>
                                <div className="flex flex-wrap gap-2 md:gap-3 mb-6 md:mb-8">
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-green-400">shield</span> {t('home.solutions.gaming.tag_antifraud')}
                                    </div>
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-blue-400">speed</span> {t('home.solutions.gaming.tag_concurrency')}
                                    </div>
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-purple-400">payments</span> {t('home.solutions.gaming.tag_deposits')}
                                    </div>
                                </div>
                                <div>
                                    <Link to="/solutions#gaming" className="inline-flex items-center text-primary font-bold hover:text-white transition-colors group/link text-sm md:text-base">
                                        {t('home.solutions.gaming.link')}
                                        <span className="material-symbols-outlined ml-2 text-xs md:text-sm group-hover/link:translate-x-1 transition-transform">arrow_forward</span>
                                    </Link>
                                </div>
                            </div>
                        </div>

                        {/* Streaming Card */}
                        <div className="group relative overflow-hidden rounded-3xl border border-white/10 h-[400px] md:h-[600px] bg-surface-card transition-all duration-500 hover:border-primary/40 hover:shadow-neon">
                            <div className="absolute inset-0 bg-[url('/images/live-stream-faceless.png')] bg-cover bg-center opacity-50 transition-transform duration-700 group-hover:scale-105"></div>
                            <div className="absolute inset-0 bg-gradient-to-t from-[#0B1015] via-[#0B1015]/90 to-transparent"></div>
                            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <div className="relative z-10 p-6 md:p-12 h-full flex flex-col justify-end">
                                <h3 className="text-2xl md:text-4xl font-bold text-white mb-3 md:mb-4">{t('home.solutions.streaming.title')}</h3>
                                <p className="text-gray-400 text-sm md:text-lg mb-6 md:mb-8 leading-relaxed max-w-md">{t('home.solutions.streaming.desc')}</p>
                                <div className="flex flex-wrap gap-2 md:gap-3 mb-6 md:mb-8">
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-pink-400">volunteer_activism</span> {t('home.solutions.streaming.tag_micropayments')}
                                    </div>
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-yellow-400">stars</span> {t('home.solutions.streaming.tag_virtual_gifts')}
                                    </div>
                                    <div className="px-2.5 py-1 md:px-3 md:py-1.5 rounded-full bg-white/5 border border-white/10 text-[10px] md:text-xs font-medium text-gray-300 flex items-center gap-1.5 md:gap-2">
                                        <span className="material-symbols-outlined text-xs md:text-sm text-cyan-400">account_balance_wallet</span> {t('home.solutions.streaming.tag_creator_payouts')}
                                    </div>
                                </div>
                                <div>
                                    <Link to="/solutions#streaming" className="inline-flex items-center text-secondary font-bold hover:text-white transition-colors group/link text-sm md:text-base">
                                        {t('home.solutions.streaming.link')}
                                        <span className="material-symbols-outlined ml-2 text-xs md:text-sm group-hover/link:translate-x-1 transition-transform">arrow_forward</span>
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section >

            {/* Local Payment Network */}
            < section className="py-24 bg-surface-lighter relative overflow-hidden" >
                <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#00d4c5 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
                <div className="absolute right-0 top-0 w-1/2 h-full bg-gradient-to-l from-background-dark to-transparent z-10"></div>
                <div className="absolute left-0 top-0 w-1/2 h-full bg-gradient-to-r from-background-dark to-transparent z-10"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-20">
                    <div className="flex flex-col md:flex-row gap-12 items-center">
                        <div className="w-full md:w-1/2">
                            <h2 className="text-4xl font-bold text-white mb-6" dangerouslySetInnerHTML={{ __html: t('home.globe.title') }}></h2>
                            <p className="text-gray-400 text-lg mb-8 leading-relaxed">{t('home.globe.description')}</p>
                        </div>
                        <div className="w-full md:w-1/2 relative h-[400px] md:h-[500px] flex items-center justify-center overflow-hidden">
                            {/* Glow Effects */}
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] md:w-[500px] md:h-[500px] bg-primary/20 rounded-full blur-[80px] md:blur-[120px] pointer-events-none"></div>

                            {/* The Globe */}
                            <Globe key={globeSize} size={globeSize} className="relative z-10" />
                        </div>
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8 mt-8 pt-8 md:mt-16 md:pt-16 border-t border-white/5">
                        <div className="group">
                            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-primary to-white mb-2 transition-all duration-300">10M+</h3>
                            <p className="font-medium text-white mb-1 text-sm sm:text-base">{t('home.globe.stats.transactions_title')}</p>
                            <p className="text-xs sm:text-sm text-gray-500">{t('home.globe.stats.transactions_desc')}</p>
                        </div>
                        <div className="group">
                            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-secondary to-white mb-2 transition-all duration-300">&lt; 200ms</h3>
                            <p className="font-medium text-white mb-1 text-sm sm:text-base">{t('home.globe.stats.response_time_title')}</p>
                            <p className="text-xs sm:text-sm text-gray-500">{t('home.globe.stats.response_time_desc')}</p>
                        </div>
                        <div className="group">
                            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-white mb-2 transition-all duration-300">99.99%</h3>
                            <p className="font-medium text-white mb-1 text-sm sm:text-base">{t('home.globe.stats.stability_title')}</p>
                            <p className="text-xs sm:text-sm text-gray-500">{t('home.globe.stats.stability_desc')}</p>
                        </div>
                        <div className="group">
                            <h3 className="text-2xl sm:text-4xl lg:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-white mb-2 transition-all duration-300">50+</h3>
                            <p className="font-medium text-white mb-1 text-sm sm:text-base">{t('home.globe.stats.types_supported_title')}</p>
                            <p className="text-xs sm:text-sm text-gray-500">{t('home.globe.stats.types_supported_desc')}</p>
                        </div>
                    </div>
                </div>
            </section >

            {/* Trusted by Entertainment Leaders */}
            < section className="py-24 bg-background-dark relative overflow-hidden" >
                <div className="absolute inset-0 bg-gradient-to-b from-surface-dark/50 to-background-dark pointer-events-none"></div>
                <div className="absolute inset-0 opacity-20 bg-[url('/images/home-hero-bg.jpg')] bg-cover bg-center mix-blend-overlay"></div>
                <div className="absolute top-[-50%] left-[-20%] w-[140%] h-[200%] bg-gradient-to-r from-transparent via-primary/5 to-transparent rotate-45 animate-aurora pointer-events-none blur-3xl"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="mb-16 relative">
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-4">{t('home.testimonials.title')}</h2>
                        <p className="text-gray-400"></p>
                        <div className="absolute -left-10 top-0 w-20 h-20 bg-secondary/20 rounded-full blur-2xl -z-10"></div>
                    </div>
                    {/* Mobile Scroll Container */}
                    <div className="relative">
                        <div className="flex flex-nowrap md:grid md:grid-cols-3 gap-4 md:gap-6 overflow-x-auto md:overflow-visible no-scrollbar snap-x snap-mandatory px-4 md:px-0 pb-4 md:pb-0 -mx-4 md:mx-0">
                            {/* Testimonials */}
                            {[
                                {
                                    name: "James Gorman",
                                    role: t('home.testimonials.james.role'),
                                    quote: t('home.testimonials.james.quote'),
                                    img: "/images/avatar-1.jpg",
                                    border: "primary"
                                },
                                {
                                    name: "Sarah Williams",
                                    role: t('home.testimonials.sarah.role'),
                                    quote: t('home.testimonials.sarah.quote'),
                                    img: "/images/avatar-2.jpg",
                                    border: "primary"
                                },
                                {
                                    name: "Michael Ross",
                                    role: t('home.testimonials.michael.role'),
                                    quote: t('home.testimonials.michael.quote'),
                                    img: "/images/avatar-3.jpg",
                                    border: "primary"
                                }
                            ].map((testimonial, idx) => (
                                <div key={idx} className="flex-shrink-0 w-[85vw] md:w-auto snap-center bg-surface-card rounded-2xl p-6 md:p-8 border border-white/5 relative group hover:-translate-y-1 transition-transform duration-300">
                                    <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${testimonial.border === 'primary' ? 'from-primary to-primary/20' : 'from-secondary to-secondary/20'} opacity-50 group-hover:opacity-100 transition-opacity`}></div>
                                    <div className="flex items-center gap-4 mb-6">
                                        <div className="w-14 h-14 rounded-full border-2 border-white/10 p-0.5">
                                            <img src={testimonial.img} alt={testimonial.name} className="w-full h-full rounded-full object-cover grayscale group-hover:grayscale-0 transition-all duration-300" />
                                        </div>
                                        <div>
                                            <h4 className="text-white font-bold text-lg">{testimonial.name}</h4>
                                            <p className={`text-sm ${testimonial.border === 'primary' ? 'text-primary' : 'text-secondary'}`}>{testimonial.role}</p>
                                        </div>
                                    </div>
                                    <p className="text-gray-400 italic leading-relaxed">"{testimonial.quote}"</p>
                                </div>
                            ))}
                        </div>
                        {/* Mobile Scroll Fade Indicator */}
                        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-background-dark to-transparent pointer-events-none md:hidden"></div>
                    </div>
                </div>
            </section >

            {/* CTA Section */}
            < section className="py-32 px-4 md:px-8 bg-surface-dark border-t border-white/5 relative overflow-hidden" >
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-primary/5 pointer-events-none"></div>
                <div className="max-w-4xl mx-auto text-center relative z-10">
                    <h2 className="text-4xl md:text-6xl font-bold text-white tracking-tight mb-8">
                        <Trans i18nKey="home.cta.title" components={{ 1: <span className="text-primary" /> }} />
                    </h2>
                    <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-5 relative z-30">
                        <Link to="/contact" className="flex items-center justify-center rounded-lg h-14 px-10 bg-primary hover:bg-primary-dark text-background-dark text-lg font-bold shadow-[0_0_20px_rgba(0,212,197,0.4)] transition-all transform hover:-translate-y-1">
                            {t('home.cta.contact_sales')}
                        </Link>
                        <Link to="/developer" className="flex items-center justify-center rounded-lg h-14 px-10 bg-transparent border border-white/20 hover:border-white hover:bg-white/5 text-white text-lg font-bold transition-all">
                            {t('home.cta.api_docs')}
                        </Link>
                    </div>
                </div>
            </section >
        </div >
    );
};

export default Home;
