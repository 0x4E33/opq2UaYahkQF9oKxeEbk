import React, { useEffect } from 'react';
import { useTranslation, Trans } from 'react-i18next';
import LegalPageLayout from '../components/layout/LegalPageLayout';

const Cookies = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('cookies.meta.title');
    }, [t]);
    return (
        <LegalPageLayout
            title={<>{t('cookies.title')}</>}
            lastUpdated={t('cookies.last_updated')}
        >
            <div className="scroll-mt-32" id="scope">
                <h2>{t('cookies.scope.title')}</h2>
                <p>
                    {t('cookies.scope.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="collect">
                <h2>{t('cookies.collect.title')}</h2>
                <p>
                    {t('cookies.collect.desc')}
                </p>
                <ul>
                    <li><strong>{t('cookies.collect.list.identity.label')}</strong>{t('cookies.collect.list.identity.text')}</li>
                    <li><strong>{t('cookies.collect.list.contact.label')}</strong>{t('cookies.collect.list.contact.text')}</li>
                    <li><strong>{t('cookies.collect.list.account.label')}</strong>{t('cookies.collect.list.account.text')}</li>
                    <li><strong>{t('cookies.collect.list.usage.label')}</strong>{t('cookies.collect.list.usage.text')}</li>
                    <li><strong>{t('cookies.collect.list.risk.label')}</strong>{t('cookies.collect.list.risk.text')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="use">
                <h2>{t('cookies.use.title')}</h2>
                <ul>
                    <li>{t('cookies.use.list.1')}</li>
                    <li>{t('cookies.use.list.2')}</li>
                    <li>{t('cookies.use.list.3')}</li>
                    <li>{t('cookies.use.list.4')}</li>
                    <li>{t('cookies.use.list.5')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="cookies">
                <h2>{t('cookies.cookies_usage.title')}</h2>
                <p>
                    {t('cookies.cookies_usage.intro')}
                </p>
                <ul>
                    <li>{t('cookies.cookies_usage.list.1')}</li>
                    <li>{t('cookies.cookies_usage.list.2')}</li>
                    <li>{t('cookies.cookies_usage.list.3')}</li>
                </ul>
                <p>
                    {t('cookies.cookies_usage.outro')}
                </p>
            </div>

            <div className="scroll-mt-32" id="share">
                <h2>{t('cookies.share.title')}</h2>
                <p>
                    {t('cookies.share.intro')}
                </p>
                <ul>
                    <li>{t('cookies.share.list.1')}</li>
                    <li>{t('cookies.share.list.2')}</li>
                    <li>{t('cookies.share.list.3')}</li>
                </ul>
                <p>
                    {t('cookies.share.outro')}
                </p>
            </div>

            <div className="scroll-mt-32" id="security">
                <h2>{t('cookies.security.title')}</h2>
                <p>
                    {t('cookies.security.intro')}
                </p>
                <ul>
                    <li>{t('cookies.security.list.1')}</li>
                    <li>{t('cookies.security.list.2')}</li>
                    <li>{t('cookies.security.list.3')}</li>
                    <li>{t('cookies.security.list.4')}</li>
                    <li>{t('cookies.security.list.5')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="rights">
                <h2>{t('cookies.rights.title')}</h2>
                <p>{t('cookies.rights.intro')}</p>
                <ul>
                    <li>{t('cookies.rights.list.1')}</li>
                    <li>{t('cookies.rights.list.2')}</li>
                    <li>{t('cookies.rights.list.3')}</li>
                    <li>{t('cookies.rights.list.4')}</li>
                    <li>{t('cookies.rights.list.5')}</li>
                </ul>
                <p>
                    {t('cookies.rights.contact_prefix')}
                    <span className="text-white font-medium">@KaazPayEZ</span> {t('home.hero.and')} <span className="text-white font-medium">@KaazPay BD</span>
                    {t('cookies.rights.contact_suffix')}
                </p>
            </div>

            <div className="scroll-mt-32" id="minors">
                <h2>{t('cookies.minors.title')}</h2>
                <p>
                    {t('cookies.minors.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="transfer">
                <h2>{t('cookies.transfer.title')}</h2>
                <p>
                    {t('cookies.transfer.intro')}
                </p>
                <ul>
                    <li>{t('cookies.transfer.list.1')}</li>
                    <li>{t('cookies.transfer.list.2')}</li>
                </ul>
            </div>

            <div className="scroll-mt-32" id="changes">
                <h2>{t('cookies.changes.title')}</h2>
                <p>
                    {t('cookies.changes.desc')}
                </p>
            </div>
        </LegalPageLayout>
    );
};

export default Cookies;
