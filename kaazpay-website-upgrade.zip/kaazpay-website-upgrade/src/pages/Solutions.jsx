import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const Solutions = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('solutions_page.meta.title');
    }, [t]);
    return (
        <div className="flex-grow bg-[#0B1015]">
            {/* Hero Section */}
            {/* <section className="relative pt-40 pb-20 md:pt-52 md:pb-32 px-4 md:px-8 w-full overflow-hidden bg-[#0B1015]">
                <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
                <div className="absolute inset-0 bg-circuit-board bg-center bg-no-repeat bg-cover opacity-40 pointer-events-none"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>
                <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-secondary/5 rounded-full blur-[80px] pointer-events-none animate-pulse-slow"></div>

                <div className="relative z-10 max-w-5xl mx-auto flex flex-col items-center text-center">
                    <div className="mb-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm animate-slide-up">
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                        <span className="text-xs font-semibold uppercase tracking-wider text-primary">Vertical Solutions</span>
                    </div>
                    <h1 className="text-4xl md:text-6xl lg:text-[5rem] font-bold leading-[1.1] tracking-tight text-white mb-8 drop-shadow-2xl animate-slide-up" style={{ animationDelay: '100ms' }}>
                        Tailored Infrastructure for <br />
                        <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary via-white to-primary text-glow">Global Entertainment</span>
                    </h1>
                    <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed mb-10 font-light tracking-wide animate-slide-up" style={{ animationDelay: '200ms' }}>
                        Purpose-built payment gateways designed to solve the specific
                        high-velocity challenges of gaming and social ecosystems.
                    </p>
                </div>
            </section> */}

            {/* iGaming & Betting Section */}
            <section id="gaming" className="scroll-mt-32 py-24 bg-surface-dark relative border-y border-white/5 overflow-hidden">
                <div className="absolute inset-0 bg-mesh-gradient opacity-10 pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                        <div className="order-2 lg:order-1">
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-secondary/10 border border-secondary/20 text-xs font-bold text-secondary uppercase tracking-wider mb-6">
                                <span className="material-symbols-outlined text-sm">casino</span>
                                {t('solutions_page.gaming.tag')}
                            </div>
                            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
                                {t('solutions_page.gaming.title')}<br />
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500">{t('solutions_page.gaming.title_highlight')}</span>
                            </h2>
                            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                                {t('solutions_page.gaming.desc')}
                            </p>
                            <ul className="space-y-6 mb-10">
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-primary group-hover:bg-primary/5 group-hover:shadow-[0_0_20px_rgba(0,212,197,0.4)] transition-all duration-300">
                                        <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">payments</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1 group-hover:text-primary transition-colors">{t('solutions_page.gaming.features.deposits.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.gaming.features.deposits.desc')}
                                        </p>
                                    </div>
                                </li>
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-primary group-hover:bg-primary/5 group-hover:shadow-[0_0_20px_rgba(0,212,197,0.4)] transition-all duration-300">
                                        <span className="material-symbols-outlined text-primary group-hover:scale-110 transition-transform">speed</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1 group-hover:text-primary transition-colors">{t('solutions_page.gaming.features.concurrency.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.gaming.features.concurrency.desc')}
                                        </p>
                                    </div>
                                </li>
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-secondary group-hover:bg-secondary/5 group-hover:shadow-[0_0_20px_rgba(227,110,57,0.4)] transition-all duration-300">
                                        <span className="material-symbols-outlined text-secondary group-hover:scale-110 transition-transform">shield_lock</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1 group-hover:text-secondary transition-colors">{t('solutions_page.gaming.features.antifraud.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.gaming.features.antifraud.desc')}
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="order-1 lg:order-2 relative h-[500px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl group">
                            <div className="absolute inset-0 bg-[#0B1015]">
                                <div className="absolute inset-0 bg-[url('/images/igaming-card-game.png')] bg-cover bg-center opacity-60 group-hover:scale-105 transition-transform duration-700"></div>
                                <div className="absolute inset-0 bg-gradient-to-t from-[#0B1015] via-transparent to-transparent"></div>
                                <div className="absolute bottom-8 left-8 right-8 space-y-3">
                                    <div className="glass-card-deep p-4 rounded-xl flex items-center justify-between animate-slide-up" style={{ animationDelay: '0.1s' }}>
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded bg-green-500/20 flex items-center justify-center text-green-400">
                                                <span className="material-symbols-outlined text-sm">attach_money</span>
                                            </div>
                                            <div>
                                                <div className="text-xs text-gray-400 uppercase">{t('solutions_page.gaming.stats.deposit_success')}</div>
                                                <div className="text-white font-mono font-bold">98.4%</div>
                                            </div>
                                        </div>
                                        <div className="h-8 w-[1px] bg-white/10"></div>
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 rounded bg-blue-500/20 flex items-center justify-center text-blue-400">
                                                <span className="material-symbols-outlined text-sm">bolt</span>
                                            </div>
                                            <div>
                                                <div className="text-xs text-gray-400 uppercase">{t('solutions_page.gaming.stats.latency')}</div>
                                                <div className="text-white font-mono font-bold">140ms</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Live Streaming & Social Section */}
            <section id="streaming" className="scroll-mt-32 py-24 bg-[#0B1015] relative overflow-hidden">
                <div className="absolute right-0 top-1/4 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                        <div className="relative h-[500px] rounded-2xl overflow-hidden border border-white/10 shadow-2xl group">
                            <div className="absolute inset-0 bg-[#0B1015]">
                                <div className="absolute inset-0 bg-[url('/images/live-stream-faceless.png')] bg-cover bg-center opacity-60 group-hover:scale-105 transition-transform duration-700"></div>
                                <div className="absolute inset-0 bg-gradient-to-tr from-[#0B1015] via-transparent to-transparent"></div>
                                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm">
                                    <div className="glass-card-tech p-6 rounded-2xl space-y-4 transform group-hover:scale-105 transition-transform duration-500">
                                        <div className="flex items-center justify-between mb-2">
                                            <div className="flex items-center gap-2">
                                                <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
                                                <span className="text-xs font-bold text-white uppercase tracking-wider">{t('solutions_page.streaming.visual.tipping_label')}</span>
                                            </div>
                                            <span className="text-xs text-primary font-mono">{t('solutions_page.streaming.visual.settlement_label')}</span>
                                        </div>
                                        <div className="space-y-2">
                                            <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center text-[10px] text-purple-300 font-bold">U1</div>
                                                    <span className="text-xs text-gray-300">User_882</span>
                                                </div>
                                                <span className="text-xs text-white font-bold">+$5.00</span>
                                            </div>
                                            <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-6 h-6 rounded-full bg-pink-500/20 flex items-center justify-center text-[10px] text-pink-300 font-bold">U2</div>
                                                    <span className="text-xs text-gray-300">Fan_001</span>
                                                </div>
                                                <span className="text-xs text-white font-bold">+$20.00</span>
                                            </div>
                                            <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center text-[10px] text-cyan-300 font-bold">U3</div>
                                                    <span className="text-xs text-gray-300">VIP_316</span>
                                                </div>
                                                <span className="text-xs text-white font-bold">+$2.50</span>
                                            </div>
                                        </div>
                                        <div className="pt-2 border-t border-white/5 flex justify-between items-center">
                                            <span className="text-xs text-gray-400">{t('solutions_page.streaming.visual.total_label')}</span>
                                            <span className="text-lg text-primary font-mono font-bold">$1,245.50</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div className="inline-flex items-center gap-2 px-3 py-1 rounded bg-primary/10 border border-primary/20 text-xs font-bold text-primary uppercase tracking-wider mb-6">
                                <span className="material-symbols-outlined text-sm">live_tv</span>
                                {t('solutions_page.streaming.tag')}
                            </div>
                            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
                                {t('solutions_page.streaming.title')}<br />
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-primary">{t('solutions_page.streaming.title_highlight')}</span>
                            </h2>
                            <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                                {t('solutions_page.streaming.desc')}
                            </p>
                            <ul className="space-y-6 mb-10">
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-primary/50 group-hover:shadow-[0_0_15px_rgba(0,212,197,0.2)] transition-all">
                                        <span className="material-symbols-outlined text-primary">restart_alt</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1">{t('solutions_page.streaming.features.micro_transactions.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.streaming.features.micro_transactions.desc')}
                                        </p>
                                    </div>
                                </li>
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-primary/50 group-hover:shadow-[0_0_15px_rgba(0,212,197,0.2)] transition-all">
                                        <span className="material-symbols-outlined text-primary">savings</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1">{t('solutions_page.streaming.features.tipping.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.streaming.features.tipping.desc')}
                                        </p>
                                    </div>
                                </li>
                                <li className="flex items-start gap-4 group">
                                    <div className="w-10 h-10 rounded-lg bg-surface-card border border-white/10 flex items-center justify-center shrink-0 group-hover:border-secondary/50 group-hover:shadow-[0_0_15px_rgba(227,110,57,0.2)] transition-all">
                                        <span className="material-symbols-outlined text-secondary">devices</span>
                                    </div>
                                    <div>
                                        <h4 className="text-white font-bold text-lg mb-1">{t('solutions_page.streaming.features.sdk.title')}</h4>
                                        <p className="text-sm text-gray-500">
                                            {t('solutions_page.streaming.features.sdk.desc')}
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Solutions;
