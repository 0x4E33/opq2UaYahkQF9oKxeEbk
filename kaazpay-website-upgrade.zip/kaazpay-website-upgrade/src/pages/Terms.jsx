import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import LegalPageLayout from '../components/layout/LegalPageLayout';

const Terms = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('terms.meta.title');
    }, [t]);
    return (
        <LegalPageLayout
            title={<>{t('terms.title')}</>}
            lastUpdated={t('terms.last_updated')}
        >
            <div className="mb-8">
                <p>
                    {t('terms.intro')}
                </p>
            </div>

            <div className="scroll-mt-32" id="regulations">
                <h2>{t('terms.regulations.title')}</h2>
                <p>
                    {t('terms.regulations.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="ownership">
                <h2>{t('terms.ownership.title')}</h2>
                <p>
                    {t('terms.ownership.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="warranties">
                <h2>{t('terms.warranties.title')}</h2>
                <p>
                    {t('terms.warranties.p1')}
                </p>
                <p>
                    {t('terms.warranties.p2')}
                </p>
                <p>
                    {t('terms.warranties.p3')}
                </p>
            </div>

            <div className="scroll-mt-32" id="liability">
                <h2>{t('terms.liability.title')}</h2>
                <p>
                    {t('terms.liability.p1')}
                </p>
                <p>
                    {t('terms.liability.p2')}
                </p>
                <p>
                    {t('terms.liability.p3')}
                </p>
                <p>
                    {t('terms.liability.p4')}
                </p>
            </div>

            <div className="scroll-mt-32" id="confidentiality">
                <h2>{t('terms.confidentiality.title')}</h2>
                <p>
                    {t('terms.confidentiality.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="linked-websites">
                <h2>{t('terms.linked_websites.title')}</h2>
                <p>
                    {t('terms.linked_websites.desc')}
                </p>
            </div>

            <div className="scroll-mt-32" id="third-party">
                <h2>{t('terms.third_party.title')}</h2>
                <p>
                    {t('terms.third_party.desc')}
                </p>
            </div>
        </LegalPageLayout>
    );
};

export default Terms;
