import React, { useEffect } from 'react';
import { useTranslation, Trans } from 'react-i18next';
import { Link } from 'react-router-dom';

const About = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('about.meta.title');
    }, [t]);
    return (
        <div className="flex-grow">
            {/* Who We Are & 3D Visual Section */}
            <section className="py-20 md:py-32 px-4 md:px-8 bg-surface-dark relative border-y border-white/5 pt-36">
                <div className="absolute inset-0 bg-mesh-gradient opacity-10 pointer-events-none"></div>
                <div className="max-w-7xl mx-auto">
                    <div className="grid lg:grid-cols-2 gap-16 items-center">
                        {/* 3D Visual */}
                        {/* 3D Visual - Payment Core */}
                        <div className="relative order-2 lg:order-1 h-[500px] flex items-center justify-center perspective-[1000px] group/scene overflow-hidden">
                            {/* Core Glow */}
                            <div className="absolute w-64 h-64 bg-primary/20 rounded-full blur-[80px] animate-pulse-slow"></div>

                            {/* Orbiting Rings */}
                            <div className="absolute w-[450px] h-[450px] border border-white/5 rounded-full animate-[spin_20s_linear_infinite]"></div>
                            <div className="absolute w-[350px] h-[350px] border border-primary/20 rounded-full animate-[spin_15s_linear_infinite_reverse] border-t-transparent border-l-transparent"></div>
                            <div className="absolute w-[250px] h-[250px] border-2 border-dashed border-secondary/20 rounded-full animate-[spin_10s_linear_infinite]"></div>

                            {/* Central Hub */}
                            <div className="relative w-32 h-32 bg-gradient-to-br from-[#0B1015] to-[#161b22] rounded-full border border-white/10 shadow-[0_0_50px_rgba(0,212,197,0.2)] flex items-center justify-center z-10 group-hover/scene:scale-105 transition-transform duration-500">
                                <div className="absolute inset-0 bg-primary/10 rounded-full animate-ping opacity-20"></div>
                                <span className="material-symbols-outlined text-6xl text-transparent bg-clip-text bg-gradient-to-b from-white to-primary drop-shadow-[0_0_15px_rgba(0,212,197,0.8)]">hub</span>
                            </div>

                            {/* Floating Stats Cards */}
                            <div className="absolute top-[20%] right-[10%] glass-card-tech px-5 py-3 rounded-xl border border-primary/30 animate-float z-20 backdrop-blur-md">
                                <div className="flex items-center gap-2 mb-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                                    <span className="text-xs text-gray-400 uppercase tracking-wider">{t('about.visuals.uptime_label')}</span>
                                </div>
                                <div className="text-xl font-bold text-white font-mono tracking-tight">99.99%</div>
                            </div>

                            <div className="absolute bottom-[20%] left-[5%] glass-card-tech px-5 py-3 rounded-xl border border-secondary/30 animate-float-delayed z-20 backdrop-blur-md">
                                <div className="flex items-center gap-2 mb-1">
                                    <span className="material-symbols-outlined text-sm text-secondary">bolt</span>
                                    <span className="text-xs text-gray-400 uppercase tracking-wider">{t('about.visuals.latency_label')}</span>
                                </div>
                                <div className="text-xl font-bold text-white font-mono tracking-tight">~200ms</div>
                            </div>

                            <div className="absolute top-[70%] right-[5%] glass-card-tech px-4 py-2 rounded-lg border border-white/10 animate-float z-20 backdrop-blur-md">
                                <div className="flex items-center gap-2">
                                    <span className="material-symbols-outlined text-lg text-primary">security</span>
                                    <div className="flex flex-col">
                                        <span className="text-[10px] text-gray-400 uppercase">{t('about.visuals.risk_engine')}</span>
                                        <span className="text-sm font-bold text-white">{t('about.visuals.active')}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Content */}
                        <div className="order-1 lg:order-2">
                            <h2 className="text-sm font-bold text-primary uppercase tracking-widest mb-3">{t('about.hero.who_we_are')}</h2>
                            <h3 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
                                {t('about.hero.title_infrastructure')} <br /><span className="text-gray-500">{t('about.hero.title_performance')}</span>
                            </h3>
                            <p className="text-gray-400 text-lg leading-relaxed mb-6">
                                {t('about.hero.description_1')}
                            </p>
                            <p className="text-gray-400 text-lg leading-relaxed mb-8">
                                {t('about.hero.description_2')}
                            </p>
                            <div className="flex gap-8">
                                <div className="text-center">
                                    <div className="text-3xl font-bold text-white mb-1">{t('about.hero.founded_year')}</div>
                                    <div className="text-sm text-gray-500 uppercase tracking-wider">{t('about.hero.founded_label')}</div>
                                </div>

                                <div className="text-center">
                                    <div className="text-3xl font-bold text-white mb-1">{t('about.hero.engineers_count')}</div>
                                    <div className="text-sm text-gray-500 uppercase tracking-wider">{t('about.hero.engineers_label')}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Core Pillars Section */}
            {/* <section className="py-24 px-4 md:px-8 bg-[#0B1015]">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Core Pillars</h2>
                        <p className="text-gray-400 max-w-2xl mx-auto">
                            Our technology stack is built on three fundamental principles designed for the high-risk, high-reward digital economy.
                        </p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-6">
                        <div className="glass-card-tech rounded-2xl p-8 hover:border-primary/30 transition-colors group relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-2xl -mr-10 -mt-10 transition-opacity opacity-0 group-hover:opacity-100"></div>
                            <div className="w-14 h-14 rounded-xl bg-surface-dark border border-white/10 flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                                <span className="material-symbols-outlined text-3xl text-primary">account_balance</span>
                            </div>
                            <h3 className="text-xl font-bold text-white mb-3">High-Performance Acquiring</h3>
                            <p className="text-gray-400 text-sm leading-relaxed">
                                Direct card schemes and local network access tailored for maximum acceptance rates. We reduce friction at the point of payment to ensure conversion.
                            </p>
                        </div>
                        <div className="glass-card-tech rounded-2xl p-8 hover:border-secondary/30 transition-colors group relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-secondary/5 rounded-full blur-2xl -mr-10 -mt-10 transition-opacity opacity-0 group-hover:opacity-100"></div>
                            <div className="w-14 h-14 rounded-xl bg-surface-dark border border-white/10 flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                                <span className="material-symbols-outlined text-3xl text-secondary">water_drop</span>
                            </div>
                            <h3 className="text-xl font-bold text-white mb-3">Dynamic Liquidity Management</h3>
                            <p className="text-gray-400 text-sm leading-relaxed">
                                Proprietary D0 settlement technology to unlock merchant cash flow. We bridge the gap between transaction and settlement, providing instant capital.
                            </p>
                        </div>
                        <div className="glass-card-tech rounded-2xl p-8 hover:border-blue-500/30 transition-colors group relative overflow-hidden">
                            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl -mr-10 -mt-10 transition-opacity opacity-0 group-hover:opacity-100"></div>
                            <div className="w-14 h-14 rounded-xl bg-surface-dark border border-white/10 flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform">
                                <span className="material-symbols-outlined text-3xl text-blue-400">shield_lock</span>
                            </div>
                            <h3 className="text-xl font-bold text-white mb-3">Intelligent Risk Shield</h3>
                            <p className="text-gray-400 text-sm leading-relaxed">
                                Real-time fraud mitigation and smart routing optimized for high-risk entertainment sectors. We protect your revenue without blocking legitimate users.
                            </p>
                        </div>
                    </div>
                </div>
            </section> */}

            {/* Our Journey Section */}
            <section className="py-24 px-4 md:px-8 bg-[#0B1015] relative overflow-hidden">
                {/* Global Network Background */}
                <div className="absolute inset-0 bg-[#0B1015]">
                    <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width=\'60\'%20height=\'60\'%20viewBox=\'0%200%2060%2060\'%20xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cg%20fill=\'none\'%20fill-rule=\'evenodd\'%3E%3Cg%20fill=\'%23ffffff\'%20fill-opacity=\'0.03\'%3E%3Cpath%20d=\'M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z\'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] bg-center opacity-30"></div>
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none"></div>
                </div>

                <div className="max-w-4xl mx-auto relative z-10">
                    <div className="text-center mb-20">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-medium text-gray-400 mb-4">
                            <span className="w-2 h-2 rounded-full bg-secondary animate-pulse"></span>
                            <span>{t('about.journey.milestones_badge')}</span>
                        </div>
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight">{t('about.journey.title')}</h2>
                    </div>

                    <div className="relative pl-8 md:pl-0">
                        {/* Gradient Timeline Line */}
                        <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-white to-secondary opacity-30"></div>

                        {/* 2018 */}
                        <div className="relative mb-20 md:mb-32 flex flex-col md:flex-row items-center w-full group">
                            <div className="w-full md:w-1/2 md:pr-16 md:text-right pl-12 md:pl-0 text-left">
                                <span className="text-primary font-mono text-xl font-bold mb-2 block drop-shadow-lg">{t('about.journey.2018.year')}</span>
                                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-primary transition-colors">{t('about.journey.2018.title')}</h3>
                                <p className="text-gray-400 text-sm leading-relaxed">
                                    {t('about.journey.2018.desc')}
                                </p>
                            </div>
                            <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#0B1015] border-2 border-primary shadow-[0_0_15px_rgba(0,212,197,0.6)] z-10 group-hover:scale-125 transition-transform duration-300">
                                <div className="absolute inset-0 bg-primary rounded-full animate-ping opacity-20"></div>
                            </div>
                            <div className="hidden md:block w-1/2"></div>
                        </div>

                        {/* 2020 */}
                        <div className="relative mb-20 md:mb-32 flex flex-col md:flex-row items-center w-full group">
                            <div className="hidden md:block w-1/2"></div>
                            <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#0B1015] border-2 border-white shadow-[0_0_15px_rgba(255,255,255,0.4)] z-10 group-hover:scale-125 transition-transform duration-300"></div>
                            <div className="w-full md:w-1/2 md:pl-16 pl-12 text-left">
                                <span className="text-white font-mono text-xl font-bold mb-2 block drop-shadow-lg">{t('about.journey.2020.year')}</span>
                                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-white transition-colors">{t('about.journey.2020.title')}</h3>
                                <p className="text-gray-400 text-sm leading-relaxed">
                                    {t('about.journey.2020.desc')}
                                </p>
                            </div>
                        </div>

                        {/* 2022 */}
                        <div className="relative mb-20 md:mb-32 flex flex-col md:flex-row items-center w-full group">
                            <div className="w-full md:w-1/2 md:pr-16 md:text-right pl-12 md:pl-0 text-left">
                                <span className="text-secondary font-mono text-xl font-bold mb-2 block drop-shadow-lg">{t('about.journey.2022.year')}</span>
                                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-secondary transition-colors">{t('about.journey.2022.title')}</h3>
                                <p className="text-gray-400 text-sm leading-relaxed">
                                    {t('about.journey.2022.desc')}
                                </p>
                            </div>
                            <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-[#0B1015] border-2 border-secondary shadow-[0_0_15px_rgba(227,110,57,0.6)] z-10 group-hover:scale-125 transition-transform duration-300">
                                <div className="absolute inset-0 bg-secondary rounded-full animate-ping opacity-20"></div>
                            </div>
                            <div className="hidden md:block w-1/2"></div>
                        </div>

                        {/* 2025 */}
                        <div className="relative flex flex-col md:flex-row items-center w-full group">
                            <div className="hidden md:block w-1/2"></div>
                            <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-gradient-to-br from-primary to-secondary shadow-[0_0_20px_rgba(0,212,197,0.5)] z-10 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                                <div className="w-2 h-2 bg-white rounded-full"></div>
                            </div>
                            <div className="w-full md:w-1/2 md:pl-16 pl-12 text-left">
                                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary font-mono text-xl font-bold mb-2 block">{t('about.journey.2026.year')}</span>
                                <h3 className="text-2xl font-bold text-white mb-3">{t('about.journey.2026.title')}</h3>
                                <p className="text-gray-400 text-sm leading-relaxed">
                                    {t('about.journey.2026.desc')}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-32 px-4 md:px-8 bg-[#0B1015] border-t border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-primary/5 pointer-events-none"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none"></div>
                <div className="max-w-4xl mx-auto text-center relative z-10">
                    <h2 className="text-4xl md:text-6xl font-bold text-white tracking-tight mb-8">
                        <Trans i18nKey="about.cta.title" />
                    </h2>
                    <p className="text-lg text-gray-400 mb-12 max-w-2xl mx-auto">
                        {t('about.cta.desc')}
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center gap-5">
                        <Link
                            to="/contact"
                            className="flex items-center justify-center rounded-full h-14 px-10 bg-primary hover:bg-primary-dark text-background-dark text-lg font-bold shadow-[0_0_20px_rgba(0,212,197,0.4)] transition-all transform hover:-translate-y-1"
                        >
                            {t('about.cta.button')}
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default About;
