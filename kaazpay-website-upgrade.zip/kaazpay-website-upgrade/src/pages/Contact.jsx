import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const Contact = () => {
    const { t } = useTranslation();
    const [copiedId, setCopiedId] = useState(null);

    const handleCopy = (id) => {
        navigator.clipboard.writeText(id);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    useEffect(() => {
        document.title = t('contact.meta.title');
    }, [t]);

    return (
        <div className="flex-grow flex flex-col justify-center min-h-screen">
            <section className="relative pt-36 pb-20 md:pt-48 md:pb-32 px-4 md:px-8 w-full overflow-hidden bg-[#0B1015]">
                {/* Background Effects */}
                <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width=\'40\'%20height=\'40\'%20viewBox=\'0%200%2040%2040\'%20xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cpath%20d=\'M0%200h40v40H0V0zm1%201h38v38H1V1z\'%20fill=\'%23ffffff\'%20fill-opacity=\'0.02\'%20fill-rule=\'evenodd\'/%3E%3C/svg%3E')] opacity-20 pointer-events-none"></div>
                <div className="absolute inset-0 bg-circuit-board bg-center bg-no-repeat bg-cover opacity-60 pointer-events-none"></div>
                <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-primary/10 rounded-full blur-[80px] pointer-events-none animate-pulse-slow"></div>

                <div className="relative z-10 max-w-6xl mx-auto flex flex-col items-center text-center">
                    <div className="mb-16 relative z-20 max-w-3xl">
                        <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight text-white mb-6 drop-shadow-2xl">
                            {t('contact.header.connect_with')} <br />
                            <span className="text-transparent bg-clip-text bg-gradient-to-r from-secondary via-white to-primary text-glow">
                                {t('contact.header.experts')}
                            </span>
                        </h1>
                        {/* <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed font-light tracking-wide">
                            Tailored payment solutions for high-velocity digital economies.
                            <br className="hidden md:block" />
                            Reach out via our official secure channels.
                        </p> */}
                    </div>

                    <div
                        className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 w-full max-w-4xl mx-auto"
                    >
                        {/* Global Sales Inquiry Card */}
                        <div className="glass-card-deep rounded-2xl p-6 md:p-8 relative group hover:border-primary/50 transition-all duration-300 hover:shadow-neon hover:-translate-y-1 overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <div className="relative z-10 flex flex-col items-center">
                                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-surface-lighter/50 border border-white/10 flex items-center justify-center mb-6 shadow-inner relative group-hover:scale-110 transition-transform duration-300">
                                    <div className="absolute inset-0 bg-primary/10 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                    <svg
                                        className="w-8 h-8 md:w-10 md:h-10 fill-[#229ed9]"
                                        viewBox="0 0 24 24"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"></path>
                                    </svg>
                                </div>
                                <h3 className="text-2xl font-bold text-white mb-2">{t('contact.sales.title')}</h3>
                                <p className="text-gray-400 text-sm mb-6 text-center">
                                    {t('contact.sales.desc')}
                                </p>
                                <div className="w-full bg-surface-dark/50 rounded-lg p-3 border border-white/5 mb-6 flex items-center justify-center gap-2">
                                    <span className="text-gray-500 text-sm font-mono">{t('contact.common.id_label')}</span>
                                    <span className="text-primary font-mono font-medium tracking-wide">@KaazPayEZ</span>
                                    <button
                                        className="ml-2 text-gray-500 hover:text-white transition-colors relative"
                                        title="Copy ID"
                                        onClick={() => handleCopy('@KaazPayEZ')}
                                    >
                                        <span className="material-symbols-outlined text-sm">
                                            {copiedId === '@KaazPayEZ' ? 'check' : 'content_copy'}
                                        </span>
                                        {copiedId === '@KaazPayEZ' && (
                                            <span className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-surface-lighter text-white text-xs rounded shadow-lg whitespace-nowrap">{t('contact.common.copied')}</span>
                                        )}
                                    </button>
                                </div>
                                <a
                                    className="w-full flex items-center justify-center rounded-full h-12 px-8 bg-primary hover:bg-primary-dark text-background-dark text-base font-bold shadow-neon hover:shadow-neon-strong transition-all duration-200 group/btn relative overflow-hidden"
                                    href="https://t.me/KaazPayEZ"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <div className="absolute top-0 left-[-100%] w-[50%] h-full bg-white/30 skew-x-[-20deg] animate-beam pointer-events-none"></div>
                                    {t('contact.sales.button')}
                                    <span className="material-symbols-outlined ml-2 group-hover/btn:translate-x-1 transition-transform text-lg">
                                        send
                                    </span>
                                </a>
                            </div>
                        </div>

                        {/* Technical Support Card */}
                        <div className="glass-card-deep rounded-2xl p-6 md:p-8 relative group hover:border-white/20 transition-all duration-300 hover:shadow-card-glow hover:-translate-y-1 overflow-hidden">
                            <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                            <div className="relative z-10 flex flex-col items-center">
                                <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-surface-lighter/50 border border-white/10 flex items-center justify-center mb-6 shadow-inner relative group-hover:scale-110 transition-transform duration-300">
                                    <div className="absolute inset-0 bg-white/5 rounded-full blur-md opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                    <svg
                                        className="w-8 h-8 md:w-10 md:h-10 fill-[#229ed9] opacity-80"
                                        viewBox="0 0 24 24"
                                        xmlns="http://www.w3.org/2000/svg"
                                    >
                                        <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"></path>
                                    </svg>
                                </div>
                                <h3 className="text-2xl font-bold text-white mb-2">{t('contact.support.title')}</h3>
                                <p className="text-gray-400 text-sm mb-6 text-center">
                                    {t('contact.support.desc')}
                                </p>
                                <div className="w-full bg-surface-dark/50 rounded-lg p-3 border border-white/5 mb-6 flex items-center justify-center gap-2">
                                    <span className="text-gray-500 text-sm font-mono">{t('contact.common.id_label')}</span>
                                    <span className="text-white font-mono font-medium tracking-wide">@KaazPay_BD2</span>
                                    <button
                                        className="ml-2 text-gray-500 hover:text-white transition-colors relative"
                                        title="Copy ID"
                                        onClick={() => handleCopy('@KaazPay_BD2')}
                                    >
                                        <span className="material-symbols-outlined text-sm">
                                            {copiedId === '@KaazPay_BD2' ? 'check' : 'content_copy'}
                                        </span>
                                        {copiedId === '@KaazPay_BD2' && (
                                            <span className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-surface-lighter text-white text-xs rounded shadow-lg whitespace-nowrap">{t('contact.common.copied')}</span>
                                        )}
                                    </button>
                                </div>
                                <a
                                    className="w-full flex items-center justify-center rounded-full h-12 px-8 bg-transparent border border-white/20 hover:border-white hover:bg-white/5 text-white text-base font-bold transition-all backdrop-blur-sm group/btn"
                                    href="https://t.me/KaazPay_BD2"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    {t('contact.support.button')}
                                    <span className="material-symbols-outlined ml-2 text-gray-400 group-hover/btn:text-white transition-colors text-lg">
                                        chat
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div
                        className="mt-12 flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-500/80 text-xs font-medium"
                    >
                        <span className="material-symbols-outlined text-sm">security</span>
                        {t('contact.common.security_warning')}
                    </div>
                </div>
            </section>
        </div>
    );
};

export default Contact;
