import React, { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const Developer = () => {
    const { t } = useTranslation();

    useEffect(() => {
        document.title = t('developer.meta.title');
    }, [t]);
    return (
        <div className="flex-grow">
            {/* Zero to Launch Steps */}
            <section className="relative pt-36 pb-20 md:pt-48 md:pb-32 px-4 md:px-8 w-full overflow-hidden bg-[#0B1015] border-y border-white/5">
                <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>
                <div className="absolute inset-0 bg-circuit-board bg-center bg-no-repeat bg-cover opacity-60 pointer-events-none"></div>
                <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-primary/5 rounded-full blur-[100px] pointer-events-none mix-blend-screen"></div>

                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="text-center mb-20">
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-4">{t('developer.zero_to_launch.title')}</h2>
                    </div>
                    <div className="relative">
                        <div className="hidden lg:block absolute top-12 left-[10%] right-[10%] h-[2px] bg-white/5 z-0">
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/50 to-transparent w-full animate-pulse-slow"></div>
                        </div>
                        <div className="flex flex-nowrap md:grid md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-12 lg:gap-8 overflow-x-auto md:overflow-visible no-scrollbar snap-x snap-mandatory px-4 md:px-0 pb-4 md:pb-0 -mx-4 md:mx-0 relative z-10">
                            {[
                                { icon: 'verified_user', step: 1, title: t('developer.zero_to_launch.steps.1.title'), desc: t('developer.zero_to_launch.steps.1.desc'), borderColor: 'group-hover:border-primary/50', shadowColor: 'group-hover:shadow-neon', iconColor: 'group-hover:text-primary' },
                                { icon: 'vpn_key', step: 2, title: t('developer.zero_to_launch.steps.2.title'), desc: t('developer.zero_to_launch.steps.2.desc'), borderColor: 'group-hover:border-secondary/50', shadowColor: 'group-hover:shadow-[0_0_20px_rgba(227,110,57,0.25)]', iconColor: 'group-hover:text-secondary' },
                                { icon: 'integration_instructions', step: 3, title: t('developer.zero_to_launch.steps.3.title'), desc: t('developer.zero_to_launch.steps.3.desc'), borderColor: 'group-hover:border-primary/50', shadowColor: 'group-hover:shadow-neon', iconColor: 'group-hover:text-primary' },
                                { icon: 'rocket_launch', step: 4, title: t('developer.zero_to_launch.steps.4.title'), desc: t('developer.zero_to_launch.steps.4.desc'), borderColor: 'group-hover:border-green-400/50', shadowColor: 'group-hover:shadow-[0_0_20px_rgba(74,222,128,0.25)]', iconColor: 'group-hover:text-green-400' }
                            ].map((item, index) => (
                                <div key={index} className="flex-shrink-0 w-[70vw] md:w-auto snap-center flex flex-col items-center text-center group bg-surface-card md:bg-transparent rounded-2xl p-6 md:p-0 border border-white/5 md:border-none">
                                    <div className={`w-20 h-20 md:w-24 md:h-24 rounded-2xl bg-surface-card border border-white/10 flex items-center justify-center shadow-lg ${item.borderColor} ${item.shadowColor} transition-all duration-300 relative bg-surface-dark mb-6 md:mb-8`}>
                                        <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-surface-lighter border border-white/10 flex items-center justify-center font-bold text-gray-400 text-sm">{item.step}</div>
                                        <span className={`material-symbols-outlined text-3xl md:text-4xl text-gray-300 ${item.iconColor} transition-colors`}>{item.icon}</span>
                                    </div>
                                    <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                                    <p className="text-sm text-gray-400 leading-relaxed md:max-w-none max-w-[240px]">{item.desc}</p>
                                </div>
                            ))}
                        </div>
                        {/* Mobile Scroll Fade Indicator */}
                        <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-[#0e141b] to-transparent pointer-events-none md:hidden z-20"></div>
                    </div>
                </div>
            </section>

            {/* Developer Experience */}
            <section className="py-24 bg-surface-dark relative overflow-hidden">
                <div className="absolute inset-0 bg-mesh-gradient opacity-20 pointer-events-none animate-pulse-slow"></div>
                <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
                    <div className="mb-12">
                        <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-4">{t('developer.experience.title')}</h2>
                        <p className="text-lg text-gray-400 max-w-2xl">{t('developer.experience.subtitle')}</p>
                    </div>
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 h-auto lg:h-[500px]">
                        {/* Webhook Console */}
                        <div className="lg:col-span-2 bg-surface-card rounded-3xl border border-white/5 overflow-hidden relative group hover:border-white/10 transition-all">
                            <div className="p-6 md:p-8 relative z-10">
                                <div className="flex items-center gap-3 mb-4">
                                    <div className="p-2 rounded-lg bg-primary/10 text-primary border border-primary/20">
                                        <span className="material-symbols-outlined">webhook</span>
                                    </div>
                                    <h3 className="text-lg md:text-xl font-bold text-white">{t('developer.experience.webhook.title')}</h3>
                                </div>
                                <p className="text-gray-400 text-xs md:text-sm max-w-md mb-6 md:mb-8">{t('developer.experience.webhook.desc')}</p>
                                <div className="bg-[#0B1015] rounded-xl border border-white/5 p-4 font-mono text-xs text-gray-400 h-[220px] md:h-[280px] overflow-hidden relative">
                                    <div className="absolute top-0 left-0 w-full h-8 bg-surface-lighter/50 border-b border-white/5 flex items-center px-4 gap-2">
                                        <div className="w-2 h-2 rounded-full bg-red-500"></div>
                                        <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                                        <span className="ml-2 text-[10px] text-gray-500">{t('developer.experience.webhook.live_stream')}</span>
                                    </div>
                                    <div className="mt-8 space-y-2">
                                        {[
                                            { status: '200 OK', type: 'payment.succeeded', id: 'evt_1M...', time: t('developer.experience.webhook.now'), color: 'text-primary', delay: '0.1s' },
                                            { status: '200 OK', type: 'payment.created', id: 'evt_1M...', time: t('developer.experience.webhook.ago_2s'), color: 'text-primary', delay: '0.3s' },
                                            { status: '200 OK', type: 'customer.created', id: 'evt_1M...', time: t('developer.experience.webhook.ago_5s'), color: 'text-secondary', delay: '0.5s' }
                                        ].map((log, i) => (
                                            <div key={i} className="flex items-center gap-4 py-2 border-b border-white/5">
                                                <span className="text-green-400">{log.status}</span>
                                                <span className={`${log.color}`}>{log.type}</span>
                                                <span className="text-gray-600">{log.id}</span>
                                                <span className="ml-auto text-gray-600">{log.time}</span>
                                            </div>
                                        ))}
                                        <div className="flex items-center gap-4 py-2 border-b border-white/5 opacity-50">
                                            <span className="text-green-400">200 OK</span>
                                            <span className="text-gray-400">ping</span>
                                            <span className="text-gray-600">evt_1M...</span>
                                            <span className="ml-auto text-gray-600">{t('developer.experience.webhook.ago_1m')}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="absolute bottom-0 right-0 w-full h-1/2 bg-gradient-to-t from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        </div>

                        {/* Smaller Cards Column */}
                        <div className="flex flex-col gap-4 md:gap-6 h-full">
                            <div className="flex-1 bg-surface-card rounded-3xl border border-white/5 overflow-hidden relative group hover:border-white/10 transition-all p-6 md:p-8 flex flex-col justify-center">
                                <div className="absolute top-0 right-0 p-32 bg-secondary/10 blur-[80px] rounded-full pointer-events-none"></div>
                                <div className="relative z-10">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="p-2 rounded-lg bg-secondary/10 text-secondary border border-secondary/20">
                                            <span className="material-symbols-outlined">science</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-white">{t('developer.experience.sandbox.title')}</h3>
                                    </div>
                                    <p className="text-gray-400 text-sm mb-4">{t('developer.experience.sandbox.desc')}</p>
                                    <div className="flex items-center gap-2">
                                        <span className="px-2 py-1 rounded bg-green-500/10 text-green-400 text-[10px] font-mono border border-green-500/20">{t('developer.experience.sandbox.test_mode')}</span>
                                        <span className="px-2 py-1 rounded bg-surface-lighter text-gray-400 text-[10px] font-mono border border-white/10">sk_test_...</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex-1 bg-surface-card rounded-3xl border border-white/5 overflow-hidden relative group hover:border-white/10 transition-all p-6 md:p-8 flex flex-col justify-center">
                                <div className="relative z-10">
                                    <div className="flex items-center gap-3 mb-2">
                                        <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
                                            <span className="material-symbols-outlined">library_books</span>
                                        </div>
                                        <h3 className="text-lg font-bold text-white">{t('developer.experience.sdks.title')}</h3>
                                    </div>
                                    <p className="text-gray-400 text-sm mb-6">{t('developer.experience.sdks.desc')}</p>
                                    <div className="flex justify-between items-center px-2">
                                        {[
                                            { icon: 'code', label: 'Python', hoverClass: 'group-hover/icon:text-[#3776AB]' },
                                            { icon: 'javascript', label: 'Node', hoverClass: 'group-hover/icon:text-[#339933]' },
                                            { icon: 'terminal', label: 'Go', hoverClass: 'group-hover/icon:text-[#00ADD8]' },
                                            { icon: 'coffee', label: 'Java', hoverClass: 'group-hover/icon:text-[#5382a1]' }
                                        ].map((lang, i) => (
                                            <div key={i} className="flex flex-col items-center gap-1 group/icon">
                                                <span className={`material-symbols-outlined text-3xl text-gray-500 ${lang.hoverClass} transition-colors`}>{lang.icon}</span>
                                                <span className="text-[10px] text-gray-500">{lang.label}</span>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 px-4 md:px-8 bg-[#0B1015] border-t border-white/5 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-primary/5 pointer-events-none"></div>
                <div className="max-w-4xl mx-auto text-center relative z-10">
                    <div className="inline-flex items-center justify-center p-4 rounded-full bg-surface-card border border-white/10 mb-8 shadow-2xl">
                        <div className="flex -space-x-3">
                            {[1, 2, 3].map((i) => (
                                <div key={i} className="w-10 h-10 rounded-full border-2 border-surface-card bg-gray-700 overflow-hidden">
                                    <img alt="Dev" className="w-full h-full object-cover" src={`https://lh3.googleusercontent.com/aida-public/AB6AXu${i === 1 ? 'D7PRObNwNsyq2FHwbsMJ40PAEn1J18E3XHA7GkyoHiwLRakXsZWKOdTA4q5wxIl75ICAZXgto88J_bGzPwfV7aNP9jzDY2UDOFVJdm6Ql7pKL0NDF3cOeOZGhnrGB50jnDPWBZJcWNWj-Jlrc4-Vbb5yC3wp1xiKJ-Lk2v6yOpzPJA9MckJoRovMfY-XFaooiJeF2q2mMbKeGQSwGQ1pSxG1NvOB8gtmxmJLTex6_dmBs7VSTkkDoMikFkMcIqMYjxUM4x-CdTGmH8' : i === 2 ? 'CBAjyA9seyvH4Y8a-STp-2eAyWDTdD7fK7-VoGZU9BsXYFQqu7hOB42wdBQ0EUwZHSaLkuCsop96kqnirXUch8Y2gyerGJJVogRjzbCEO38TSbmPUJsjkoi6Xc7fv0Kyx1x199SQdDT2FNZTXrVHEKpvfV1AZshy7gBjdS3UjS2ytNTYrQ7EZUWz2nztd-Ic0OsEzfLTYujZSm_QBxpgKuMEHPvrc8YLFFC1ulYIhheaCZEWGlL89Ztz0_D0OvjBnLwLEKuq1wr5OS' : 'DXT5KWRUl2SuaomqA2hWiCwRbDM10jaJkuEEB4XjHkbz3PkKDJzqsVgfYIrGPuIoDOmAC0emT7bf8JL5pdoZdoKW9jgFJeV3ao6mq16tj0APgdM6fQrjYVOnDlfbU4Hzhf1CwQYlfnhqKlWIc3lCt4eDVlMVYmuEhPHlhI3MhixFdDNZGmGKx1ElBCmPoxZMbyejDM8rkR3dz9MXMaLxPg01Jq0QWAK9Hu11hPjPFH4n0yFJX7h6nNTicQhealmFY1WrGezTx9Y46P'}`} />
                                </div>
                            ))}
                            <div className="w-10 h-10 rounded-full border-2 border-surface-card bg-primary/20 flex items-center justify-center text-primary text-xs font-bold">+2k</div>
                        </div>
                        <div className="ml-4 pr-2">
                            <span className="text-white font-medium block text-left">{t('developer.cta.support_label')}</span>
                            <span className="text-xs text-gray-400 block text-left">{t('developer.cta.join_community')}</span>
                        </div>
                    </div>
                    <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight mb-6">{t('developer.cta.title')}</h2>
                    <p className="text-lg text-gray-400 mb-10 max-w-xl mx-auto">
                        {t('developer.cta.desc')}
                    </p>
                    <Link
                        to="/contact"
                        className="flex items-center justify-center mx-auto rounded-full h-14 px-8 bg-[#229ED9] hover:bg-[#1e8dbf] text-white text-lg font-bold shadow-lg transition-all transform hover:-translate-y-1 gap-3 w-fit"
                    >
                        <span className="material-symbols-outlined">send</span>
                        {t('developer.cta.button')}
                    </Link>
                </div>
            </section>
        </div>
    );
};

export default Developer;
