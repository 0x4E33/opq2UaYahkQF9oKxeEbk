#!/usr/bin/env bash
set -Eeuo pipefail

APP_NAME="kaazpay"
WEB_ROOT="/var/www/${APP_NAME}"
NODE_MAJOR="22"
MIN_NODE_MAJOR="20"
MIN_NODE_MINOR="19"

log() {
  printf '\n[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

need_root() {
  if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
      exec sudo bash "$0" "$@"
    fi
    echo "Please run this script as root, or install sudo first." >&2
    exit 1
  fi
}

version_ge() {
  local major minor
  major="$(node -v 2>/dev/null | sed -E 's/^v([0-9]+).*/\1/' || true)"
  minor="$(node -v 2>/dev/null | sed -E 's/^v[0-9]+\.([0-9]+).*/\1/' || true)"

  [ -n "${major}" ] || return 1
  [ -n "${minor}" ] || minor=0

  if [ "${major}" -gt "${MIN_NODE_MAJOR}" ]; then
    return 0
  fi

  if [ "${major}" -eq "${MIN_NODE_MAJOR}" ] && [ "${minor}" -ge "${MIN_NODE_MINOR}" ]; then
    return 0
  fi

  return 1
}

install_base_packages() {
  log "Installing base packages"
  export DEBIAN_FRONTEND=noninteractive
  apt-get update
  apt-get install -y ca-certificates curl gnupg nginx unzip
}

install_nodejs() {
  if command -v node >/dev/null 2>&1 && version_ge && command -v npm >/dev/null 2>&1; then
    log "Node.js $(node -v) and npm $(npm -v) are already available"
    return
  fi

  log "Installing Node.js ${NODE_MAJOR}.x"
  install -d -m 0755 /etc/apt/keyrings
  curl -fsSL "https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key" \
    | gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg
  echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_${NODE_MAJOR}.x nodistro main" \
    > /etc/apt/sources.list.d/nodesource.list
  apt-get update
  apt-get install -y nodejs

  log "Installed Node.js $(node -v) and npm $(npm -v)"
}

install_project_dependencies() {
  log "Installing project dependencies"

  # Uploaded zip files may contain macOS/Windows node_modules. Always rebuild dependencies on Ubuntu.
  rm -rf node_modules

  if [ -f package-lock.json ]; then
    npm ci
  else
    npm install
  fi
}

build_project() {
  log "Building production assets"
  npm run build

  if [ ! -f dist/index.html ]; then
    echo "Build failed: dist/index.html was not generated." >&2
    exit 1
  fi
}

publish_assets() {
  log "Publishing assets to ${WEB_ROOT}"
  rm -rf "${WEB_ROOT}"
  install -d -m 0755 "${WEB_ROOT}"
  cp -a dist/. "${WEB_ROOT}/"
  chown -R www-data:www-data "${WEB_ROOT}"
}

configure_nginx() {
  log "Configuring Nginx"

  cat > /etc/nginx/sites-available/${APP_NAME} <<EOF
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    root ${WEB_ROOT};
    index index.html;

    access_log /var/log/nginx/${APP_NAME}.access.log;
    error_log /var/log/nginx/${APP_NAME}.error.log;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml image/svg+xml;

    location /assets/ {
        try_files \$uri =404;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
EOF

  ln -sfn /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/${APP_NAME}
  rm -f /etc/nginx/sites-enabled/default

  nginx -t
  systemctl enable nginx
  systemctl restart nginx
}

allow_firewall_http() {
  if command -v ufw >/dev/null 2>&1; then
    log "Allowing HTTP through UFW"
    ufw allow 80/tcp >/dev/null || true
  fi
}

verify_deploy() {
  log "Verifying local HTTP response"
  if curl -fsSI http://127.0.0.1 >/dev/null; then
    log "Deployment complete. Visit: http://YOUR_SERVER_IP/"
  else
    echo "Nginx did not return a successful response on http://127.0.0.1" >&2
    exit 1
  fi
}

main() {
  need_root "$@"
  cd "$(dirname "$0")"

  install_base_packages
  install_nodejs
  install_project_dependencies
  build_project
  publish_assets
  configure_nginx
  allow_firewall_http
  verify_deploy
}

main "$@"
