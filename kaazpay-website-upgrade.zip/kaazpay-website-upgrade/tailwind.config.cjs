/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: "#00d4c5",
        "primary-dark": "#00a89d",
        secondary: "#e36e39",
        "background-dark": "#0B1015",
        "surface-dark": "#121A23",
        "surface-card": "#1a2432",
        "surface-lighter": "#232e3f",
        "accent-blue": "#1e3a8a",
      },
      fontFamily: {
        display: ["Inter", "sans-serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      backgroundImage: {
        "mesh-gradient":
          "radial-gradient(at 50% 0%, rgba(11, 16, 21, 1) 0px, transparent 100%), radial-gradient(at 0% 50%, rgba(0, 212, 197, 0.03) 0px, transparent 50%), radial-gradient(at 100% 50%, rgba(227, 110, 57, 0.03) 0px, transparent 50%)",
        "circuit-board":
          "url(\"data:image/svg+xml,%3Csvg width='100%25' height='100%25' viewBox='0 0 1600 800' xmlns='http://www.w3.org/2000/svg'%3E%3Cdefs%3E%3ClinearGradient id='line-grad' x1='0%25' y1='0%25' x2='100%25' y2='0%25'%3E%3Cstop offset='0%25' stop-color='%2300d4c5' stop-opacity='0'/%3E%3Cstop offset='50%25' stop-color='%2300d4c5' stop-opacity='0.15'/%3E%3Cstop offset='100%25' stop-color='%2300d4c5' stop-opacity='0'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg fill='none' stroke='url(%23line-grad)' stroke-width='1'%3E%3Cpath d='M0 400 h600 l50 -50 h300 l50 50 h600' /%3E%3Cpath d='M0 450 h580 l50 50 h340 l50 -50 h580' stroke-opacity='0.5' /%3E%3Cpath d='M0 350 h550 l50 -50 h400 l50 50 h550' stroke-opacity='0.3' /%3E%3Cpath d='M0 300 h520 l50 -50 h460 l50 50 h520' stroke-opacity='0.2' /%3E%3Cpath d='M0 500 h520 l50 50 h460 l50 -50 h520' stroke-opacity='0.2' /%3E%3Cpath d='M0 250 h490 l50 -50 h520 l50 50 h490' stroke-opacity='0.1' /%3E%3Cpath d='M0 550 h490 l50 50 h520 l50 -50 h490' stroke-opacity='0.1' /%3E%3Ccircle cx='800' cy='400' r='300' stroke-opacity='0.05' /%3E%3Ccircle cx='800' cy='400' r='400' stroke-opacity='0.03' /%3E%3C/g%3E%3C/svg%3E\")",
        "grid-pattern":
          "url(\"data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h40v40H0V0zm1 1h38v38H1V1z' fill='%23ffffff' fill-opacity='0.02' fill-rule='evenodd'/%3E%3C/svg%3E\")",
      },
      boxShadow: {
        neon: "0 0 20px rgba(0, 212, 197, 0.25)",
        "neon-strong": "0 0 30px rgba(0, 212, 197, 0.5)",
        "card-glow": "0 20px 60px -10px rgba(0,0,0,0.7)",
        "inner-glow": "inset 0 0 20px rgba(0, 212, 197, 0.05)",
        "glass-edge": "inset 0 1px 0 0 rgba(255, 255, 255, 0.1)",
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "float-delayed": "float 6s ease-in-out 3s infinite",
        "pulse-slow": "pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "slide-up": "slideUp 0.8s ease-out forwards",
        beam: "beam 3s infinite linear",
        "spin-slow": "spin 60s linear infinite",
        flow: "flow 15s ease infinite",
        aurora: "aurora 10s ease infinite alternate",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        beam: {
          "0%": { left: "-100%", opacity: "0" },
          "50%": { opacity: "1" },
          "100%": { left: "200%", opacity: "0" },
        },
        flow: {
          "0%, 100%": { backgroundPosition: "0% 50%" },
          "50%": { backgroundPosition: "100% 50%" },
        },
        aurora: {
          "0%": { opacity: "0.3", transform: "scale(1)" },
          "100%": { opacity: "0.6", transform: "scale(1.2)" },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/container-queries'), 
    require('@tailwindcss/forms')
  ],
}
