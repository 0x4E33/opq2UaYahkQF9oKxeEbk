/**
 * FAQ page (/faq) — bilingual questions grouped by topic, for FAQPage JSON-LD and AI answer engines.
 *
 * Shape: { id, en: { title }, zh: { title }, items: [{ id, en: { q, a }, zh: { q, a }, links }] }
 * Answers are answer-first (the first sentence answers the question) and name KaazPay so they stand alone when quoted.
 * Placeholders {{markets}} and {{payout}} are interpolated by the page (market counts from src/data/channels.js).
 *
 * Plain ES module, no imports.
 */

export const FAQ_GROUPS = [
    {
        id: 'about',
        en: { title: 'About KaazPay' },
        zh: { title: '关于 KaazPay' },
        items: [
            {
                id: 'what-is-kaazpay',
                en: {
                    q: 'What is KaazPay?',
                    a: 'KaazPay is a cross-border payment gateway that provides local pay-in, local payouts and settlement in USDT. Merchants collect from customers with the payment methods used in each market and manage everything through one API and one merchant portal.',
                },
                zh: {
                    q: 'KaazPay 是什么？',
                    a: 'KaazPay 是一家跨境支付网关，提供本地代收、本地代付与 USDT 结算。商户可使用各市场的本地支付方式向消费者收款，并通过一套 API 和一个商户后台统一管理。',
                },
                links: ['/about', '/capabilities'],
            },
            {
                id: 'gateway-or-bank',
                en: {
                    q: 'Is KaazPay a payment gateway or a bank?',
                    a: 'KaazPay is a payment gateway, not a bank. It connects merchants to local payment channels for pay-in and payouts and settles collected funds in USDT; it does not offer bank accounts, deposits or loans.',
                },
                zh: {
                    q: 'KaazPay 是支付网关还是银行？',
                    a: 'KaazPay 是支付网关，不是银行。KaazPay 为商户连接各地的代收与代付通道，并以 USDT 结算代收资金，不提供银行账户、存款或贷款服务。',
                },
                links: ['/about', '/compare/one-gateway-vs-multiple-providers'],
            },
            {
                id: 'who-uses-kaazpay',
                en: {
                    q: 'Who is KaazPay for?',
                    a: 'KaazPay serves online businesses that collect from or pay out to customers in other countries, including gaming, e-commerce, live streaming, Web3, digital goods, travel, education and global payroll.',
                },
                zh: {
                    q: 'KaazPay 适合哪些商户？',
                    a: 'KaazPay 服务需要向海外消费者收款或付款的线上企业，包括游戏、电商、直播、Web3、数字商品、旅游、教育和全球薪资发放等行业。',
                },
                links: ['/industries'],
            },
            {
                id: 'contact',
                en: {
                    q: 'How do I contact KaazPay?',
                    a: 'Contact KaazPay on Telegram at @KaazPayEZ or @KaazPay_BD2; official updates are posted on the Telegram channel @KaazpayOfficial. KaazPay replies within one business day and does not use a public email address.',
                },
                zh: {
                    q: '如何联系 KaazPay？',
                    a: '请通过 Telegram 联系 KaazPay：@KaazPayEZ 或 @KaazPay_BD2；官方动态发布在 Telegram 频道 @KaazpayOfficial。KaazPay 在 1 个工作日内回复，不设公开电邮地址。',
                },
                links: ['/contact'],
            },
            {
                id: 'merchant-portal',
                en: {
                    q: 'Where is the KaazPay merchant portal?',
                    a: 'Open the merchant portal with the "Merchant Portal" button at the top of every page. Once your account is open, you can view orders, balances, settlements and payouts there.',
                },
                zh: {
                    q: 'KaazPay 商户后台在哪里？',
                    a: '点击网站每页顶部的“商户后台”按钮即可进入。账户开通后，商户可在后台查看订单、余额、结算与代付记录。',
                },
                links: ['/developers'],
            },
        ],
    },
    {
        id: 'coverage',
        en: { title: 'Coverage & payment methods' },
        zh: { title: '覆盖市场与支付方式' },
        items: [
            {
                id: 'countries',
                en: {
                    q: 'Which countries does KaazPay support?',
                    a: 'KaazPay offers local pay-in in {{markets}} markets across Asia Pacific, the Americas, Europe and the Middle East, and Africa, plus international cards and global USDT. Payouts are available in {{payout}} markets.',
                },
                zh: {
                    q: 'KaazPay 支持哪些国家？',
                    a: 'KaazPay 在亚太、美洲、欧洲与中东、非洲共 {{markets}} 个市场提供本地代收，并支持国际信用卡与全球 USDT。代付已在 {{payout}} 个市场开通。',
                },
                links: ['/methods', '/payment-methods/usdt'],
            },
            {
                id: 'method-types',
                en: {
                    q: 'What payment methods does KaazPay support?',
                    a: 'KaazPay supports local bank transfers, instant payments, QR payments, e-wallets, mobile money, cash payments, international cards and USDT, depending on the market. Each market page lists the methods available for pay-in and payouts.',
                },
                zh: {
                    q: 'KaazPay 支持哪些支付方式？',
                    a: 'KaazPay 按市场支持本地银行转账、实时支付、扫码支付、电子钱包、移动钱包、现金支付、国际信用卡和 USDT。各市场页面列出了可用的代收与代付方式。',
                },
                links: ['/methods', '/compare/local-payment-methods-vs-cards'],
            },
            {
                id: 'payouts-thailand-singapore',
                en: {
                    q: 'Does KaazPay support payouts in Thailand and Singapore?',
                    a: 'Yes. KaazPay payouts in Thailand and Singapore are made by bank transfer only. Pay-in in Thailand supports bank transfer and Thai QR Payment; pay-in in Singapore supports iBanking, PayNow and SGQR.',
                },
                zh: {
                    q: 'KaazPay 支持泰国和新加坡代付吗？',
                    a: '支持。KaazPay 在泰国和新加坡的代付仅支持银行转账。泰国代收支持银行转账和 Thai QR Payment；新加坡代收支持 iBanking、PayNow 和 SGQR。',
                },
                links: ['/payment-methods/thailand', '/payment-methods/singapore'],
            },
            {
                id: 'cards',
                en: {
                    q: 'Does KaazPay accept credit cards?',
                    a: 'Yes. KaazPay accepts international Visa, Mastercard and UnionPay cards, and JCB in Japan. Card pay-in is available alongside local payment methods.',
                },
                zh: {
                    q: 'KaazPay 支持信用卡收款吗？',
                    a: '支持。KaazPay 支持 Visa、Mastercard、银联国际信用卡收款，日本市场支持 JCB。信用卡代收可与本地支付方式同时使用。',
                },
                links: ['/payment-methods/global-cards', '/payment-methods/japan', '/guides/international-card-acquiring'],
            },
            {
                id: 'usdt-payin-payout',
                en: {
                    q: 'Can I collect and pay out in USDT with KaazPay?',
                    a: 'Yes. KaazPay offers global USDT pay-in and payouts on Tron, Ethereum, BSC, Solana and Polygon, in addition to settling merchant balances in USDT.',
                },
                zh: {
                    q: '可以通过 KaazPay 进行 USDT 代收和代付吗？',
                    a: '可以。KaazPay 提供全球 USDT 代收与代付，支持 Tron、Ethereum、BSC、Solana 和 Polygon 网络，商户余额也以 USDT 结算。',
                },
                links: ['/payment-methods/usdt', '/compare/usdt-networks-compared'],
            },
            {
                id: 'new-market',
                en: {
                    q: 'What if the market I need is not listed?',
                    a: 'Contact KaazPay on Telegram with the market and payment methods you need. KaazPay will confirm whether a channel is available or can be opened.',
                },
                zh: {
                    q: '没有找到需要的市场怎么办？',
                    a: '请通过 Telegram 联系 KaazPay，说明所需的市场和支付方式。KaazPay 将确认是否已有可用通道或能否开通。',
                },
                links: ['/contact'],
            },
        ],
    },
    {
        id: 'settlement',
        en: { title: 'Settlement & fees' },
        zh: { title: '结算与费率' },
        items: [
            {
                id: 'settlement-currency',
                en: {
                    q: 'In what currency does KaazPay settle?',
                    a: 'KaazPay settles merchant funds in USDT. Customers pay in their local currency, and the collected amount is settled to the merchant as the equivalent in USDT.',
                },
                zh: {
                    q: 'KaazPay 以什么币种结算？',
                    a: 'KaazPay 以 USDT 为商户结算。消费者以当地货币付款，代收金额按等值 USDT 结算给商户。',
                },
                links: ['/guides/usdt-settlement', '/compare/usdt-vs-local-currency-settlement'],
            },
            {
                id: 'settlement-speed',
                en: {
                    q: 'How fast does KaazPay settle?',
                    a: 'Settlement speed depends on the channel: many KaazPay channels settle D+0, others D+1 or later. The cycle for each channel is confirmed by your account manager before you go live.',
                },
                zh: {
                    q: 'KaazPay 结算需要多久？',
                    a: '结算时间视通道而定：KaazPay 多条通道支持 D+0，其余为 D+1 或更长。每条通道的结算周期在上线前由客户经理确认。',
                },
                links: ['/guides/usdt-settlement'],
            },
            {
                id: 'fees',
                en: {
                    q: 'How are KaazPay fees set?',
                    a: 'KaazPay fees are quoted per channel by your account manager, based on the market, payment method and business model. Rates are confirmed before go-live and every fee is itemised in the merchant portal.',
                },
                zh: {
                    q: 'KaazPay 的费率如何确定？',
                    a: 'KaazPay 的费率由客户经理按通道报价，依据市场、支付方式和业务模式确定。费率在上线前确认，每笔费用均在商户后台列明。',
                },
                links: ['/contact'],
            },
            {
                id: 'currency-conversion',
                en: {
                    q: 'How does currency conversion work at KaazPay?',
                    a: 'KaazPay converts local-currency collections into USDT at settlement. The rates that apply to each channel are confirmed before go-live and shown in the merchant portal.',
                },
                zh: {
                    q: 'KaazPay 如何处理币种换算？',
                    a: 'KaazPay 在结算时将当地货币代收金额换算为 USDT。各通道适用的汇率在上线前确认，并在商户后台显示。',
                },
                links: ['/compare/usdt-vs-local-currency-settlement'],
            },
            {
                id: 'usdt-network-choice',
                en: {
                    q: 'Which USDT networks can I use for settlement?',
                    a: 'KaazPay supports USDT on Tron, Ethereum, BSC, Solana and Polygon. Confirm the network and your wallet address with your account manager before the first settlement, because transfers sent on the wrong network cannot be recovered.',
                },
                zh: {
                    q: '结算可以使用哪些 USDT 网络？',
                    a: 'KaazPay 支持 Tron、Ethereum、BSC、Solana 和 Polygon 网络的 USDT。首次结算前，请与客户经理确认网络和钱包地址，因为通过错误网络发送的转账无法找回。',
                },
                links: ['/compare/usdt-networks-compared'],
            },
            {
                id: 'same-account',
                en: {
                    q: 'Can I collect and pay out with the same KaazPay account?',
                    a: 'Yes. Pay-in and payouts are managed from the same KaazPay merchant account and merchant portal, and balances are settled in USDT.',
                },
                zh: {
                    q: '同一个 KaazPay 账户可以同时代收和代付吗？',
                    a: '可以。代收与代付在同一个 KaazPay 商户账户和商户后台中管理，余额统一以 USDT 结算。',
                },
                links: ['/capabilities'],
            },
        ],
    },
    {
        id: 'onboarding',
        en: { title: 'Onboarding & integration' },
        zh: { title: '开户与接入' },
        items: [
            {
                id: 'open-account',
                en: {
                    q: 'How do I open a KaazPay account?',
                    a: 'Contact KaazPay on Telegram with your target region and product type, product URL and test account, time in operation, daily volume and complaint rate. KaazPay reviews the business model and then opens the merchant account.',
                },
                zh: {
                    q: '如何开通 KaazPay 账户？',
                    a: '请通过 Telegram 联系 KaazPay，并提供接入地区与产品类型、产品网址与测试账户、产品已运营时间、日交易量与投诉率情况。KaazPay 审核业务模式后开通商户账户。',
                },
                links: ['/contact', '/guides/merchant-onboarding-kyc-checklist'],
            },
            {
                id: 'integration-steps',
                en: {
                    q: 'How do I integrate with KaazPay?',
                    a: 'Integration takes four steps: open an account, get your API keys, integrate and test with a KaazPay engineer, then go live. Timing depends on your system and the channels you choose.',
                },
                zh: {
                    q: '如何接入 KaazPay？',
                    a: '接入分为四步：开通账户、获取 API 密钥、在 KaazPay 工程师协助下完成对接与测试，然后上线。所需时间取决于您的系统和所选通道。',
                },
                links: ['/developers', '/guides/payment-gateway-integration-checklist'],
            },
            {
                id: 'api-docs',
                en: {
                    q: 'Where can I find the KaazPay API documentation?',
                    a: 'KaazPay shares its API documentation once your merchant account is open. A dedicated integration engineer supports you on Telegram and runs joint tests before go-live.',
                },
                zh: {
                    q: '在哪里获取 KaazPay API 文档？',
                    a: '商户账户开通后，KaazPay 会提供 API 文档。专属对接工程师通过 Telegram 提供支持，并在上线前进行联合测试。',
                },
                links: ['/developers'],
            },
            {
                id: 'callbacks',
                en: {
                    q: 'Does KaazPay send payment notifications?',
                    a: 'Yes. KaazPay sends real-time signed callbacks for every pay-in and payout. Verify the signature with your key before updating the order status.',
                },
                zh: {
                    q: 'KaazPay 会发送支付通知吗？',
                    a: '会。KaazPay 为每笔代收和代付发送实时签名回调。请先使用密钥验证签名，再更新订单状态。',
                },
                links: ['/developers', '/guides/payment-gateway-integration-checklist'],
            },
            {
                id: 'api-security',
                en: {
                    q: 'How does KaazPay secure API calls?',
                    a: 'KaazPay secures every API call with request signing, IP allow-listing and TLS. Each merchant receives a merchant ID and signing keys when the account is opened.',
                },
                zh: {
                    q: 'KaazPay 如何保障 API 调用安全？',
                    a: 'KaazPay 的每次 API 调用均使用请求签名、IP 白名单和 TLS 加密。账户开通时，商户会获得商户号和签名密钥。',
                },
                links: ['/developers'],
            },
        ],
    },
    {
        id: 'risk',
        en: { title: 'Risk & compliance' },
        zh: { title: '风控与合规' },
        items: [
            {
                id: 'high-risk',
                en: {
                    q: 'Does KaazPay support high-risk industries?',
                    a: 'Yes. KaazPay works with digital entertainment, Web3, live streaming and other sectors that need tailored compliance reviews. Share your business model and KaazPay will confirm which channels apply.',
                },
                zh: {
                    q: 'KaazPay 支持高风险行业吗？',
                    a: '支持。KaazPay 服务数字娱乐、Web3、直播等需要定制合规审核的行业。请提供您的业务模式，KaazPay 将确认适用的通道。',
                },
                links: ['/industries', '/guides/igaming-payments'],
            },
            {
                id: 'business-review',
                en: {
                    q: 'Why does KaazPay review my business before opening an account?',
                    a: 'KaazPay reviews every merchant because channel availability and terms depend on the business model, products and transaction profile. The review is part of standard KYC and KYB requirements in payments.',
                },
                zh: {
                    q: '为什么 KaazPay 开户前要审核业务？',
                    a: 'KaazPay 对每位商户进行审核，因为通道是否可用及相应条件取决于业务模式、产品和交易情况。该审核属于支付行业标准的 KYC 与 KYB 要求。',
                },
                links: ['/guides/merchant-onboarding-kyc-checklist'],
            },
            {
                id: 'chargebacks',
                en: {
                    q: 'Do local payment methods have chargebacks?',
                    a: 'Most local push payments, such as bank transfers, instant payments and many QR and wallet payments, do not have card-style chargebacks because the payer authorises each transfer. Card payments remain subject to card network dispute rules.',
                },
                zh: {
                    q: '本地支付方式会产生拒付吗？',
                    a: '银行转账、实时支付以及多数扫码和钱包支付属于付款人主动授权的推送式支付，一般没有信用卡式的拒付。信用卡支付仍受卡组织争议规则约束。',
                },
                links: ['/compare/chargebacks-vs-local-payments'],
            },
            {
                id: 'success-rate',
                en: {
                    q: 'How does KaazPay keep payment success rates high?',
                    a: 'Where a market has more than one channel, KaazPay routes each payment to the channel performing best at that moment and fails over automatically if a channel slows down.',
                },
                zh: {
                    q: 'KaazPay 如何保持支付成功率？',
                    a: '在有多条通道的市场，KaazPay 会将每笔支付分配至当前表现最佳的通道，并在通道响应变慢时自动切换。',
                },
                links: ['/guides/payment-success-rate', '/capabilities'],
            },
            {
                id: 'staff-requests',
                en: {
                    q: 'Will KaazPay ever ask for my passwords or private keys?',
                    a: 'No. KaazPay staff will never ask for your merchant portal password, wallet private keys or one-time codes, or ask you to send money to a personal account. The test account requested during onboarding is used only to review your product.',
                },
                zh: {
                    q: 'KaazPay 会索取我的密码或私钥吗？',
                    a: '不会。KaazPay 工作人员绝不会索取您的商户后台密码、钱包私钥或验证码，也不会要求您向个人账户转账。开户时提供的测试账户只用于审核您的产品。',
                },
                links: ['/contact'],
            },
        ],
    },
];
