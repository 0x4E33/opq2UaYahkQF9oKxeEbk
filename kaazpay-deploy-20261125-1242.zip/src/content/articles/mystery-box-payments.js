export default {
    slug: 'mystery-box-payments',
    kind: 'guide',
    published: '2026-10-06',
    updated: '2026-10-06',
    related: {
        markets: ['global-cards', 'mexico', 'brazil', 'peru', 'malaysia', 'philippines', 'indonesia'],
        methods: ['visa', 'spei', 'pix', 'pagoefectivo', 'duitnow', 'gcash', 'qris'],
        industries: ['e-commerce', 'digital-goods', 'gaming'],
        articles: ['cross-border-ecommerce-checkout', 'chargebacks-vs-local-payments', 'southeast-asia-payment-methods', 'usdt-settlement'],
    },
    en: {
        title: 'Mystery Box & Blind Box Payments: A Practical Guide',
        description: 'Take payments for mystery boxes, blind boxes and gacha draws: methods that suit single draws vs bundles, refunds via payouts, disclosure and USDT settlement.',
        h1: 'How to accept payments for a mystery box or blind box store',
        summary: 'A mystery box or gacha store should pair instant local methods such as Pix, SPEI, DuitNow, GCash and QRIS for single draws with cards and cash vouchers for larger bundles, and publish contents, odds and refund terms before checkout. KaazPay offers these methods in one account, can return refunds through payouts in payout markets, and settles revenue in USDT after a business review.',
        queries: [
            'Which payment methods should a blind box shop offer to buyers in Brazil, Mexico and the Philippines?',
            'How do we refund a mystery box buyer who paid with Pix or GCash?',
            'Why do payment providers treat gacha and mystery box stores as high risk?',
            'Can customers buy blind boxes with QR codes or cash vouchers instead of cards?',
        ],
        takeaways: [
            'Match the method to order size: single draws need methods that confirm in seconds, while bundles and pre-orders can use slower vouchers and transfers.',
            'Chance-based products draw more "not what I expected" complaints, so disclosure and fast refunds reduce disputes more effectively than changes to the payment flow.',
            'Push methods such as Pix, SPEI, DuitNow, GCash and QRIS are approved by the buyer in their own app, which removes some card-specific dispute routes but not the need for refunds.',
            'Refunds to local-method buyers usually go out as payouts, which are available in payout markets; pay-in-only markets such as Peru need a plan agreed in advance.',
            'Onboarding with KaazPay includes a business review, and collected funds are settled as the equivalent amount in USDT.',
        ],
        sections: [
            {
                id: 'order-size-and-method',
                heading: 'Which methods suit single draws, bundles and pre-orders?',
                blocks: [
                    'A mystery box store usually sells at three price points, and each one fits a different kind of payment method:',
                    {
                        table: {
                            head: ['Order type', 'What the buyer needs', 'Methods that fit'],
                            rows: [
                                ['Single draw or one box', 'Pay in seconds, see the result straight away', 'Pix, SPEI, DuitNow, GCash, QRIS, Bre-B, card wallets'],
                                ['Bundle or full set', 'A bigger, planned purchase', 'Cards, FPX, Touch \'n Go, bank transfer'],
                                ['Pre-order of a new series', 'Can wait for confirmation', 'Boleto, PagoEfectivo, cash payment, bank transfer'],
                            ],
                        },
                    },
                    'For a single draw, the reveal is the product. If the buyer must wait hours for a voucher to clear before opening one box, the purchase loses its appeal. Vouchers and transfers that confirm later fit better where the buyer is already prepared to wait.',
                ],
            },
            {
                id: 'methods-by-market',
                heading: 'Which payment methods does KaazPay support for mystery box sellers?',
                blocks: [
                    'A selection of pay-in options in markets where blind box and gacha sellers are active:',
                    {
                        table: {
                            head: ['Market', 'Pay-in methods', 'Refunds by payout?'],
                            rows: [
                                ['Worldwide', '[Visa](/methods/visa), Mastercard, UnionPay; JCB in Japan', 'Card refunds handled per channel'],
                                ['[Mexico](/payment-methods/mexico)', '[SPEI](/methods/spei), bank transfer, cash payment', 'Yes, bank transfer'],
                                ['Colombia', 'PSE, Bancolombia, Bre-B, bank transfer, cash payment', 'Yes, bank transfer'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix), bank transfer, Boleto, cash payment', 'Yes, bank transfer'],
                                ['[Peru](/payment-methods/peru)', '[PagoEfectivo](/methods/pagoefectivo), bank transfer, cash payment', 'No, pay-in only'],
                                ['[Malaysia](/payment-methods/malaysia)', "FPX, Touch 'n Go, [DuitNow](/methods/duitnow)", 'Yes, bank transfer'],
                                ['[Philippines](/payment-methods/philippines)', '[GCash](/methods/gcash)', 'Yes, bank transfer'],
                                ['[Indonesia](/payment-methods/indonesia)', '[QRIS](/methods/qris)', 'Yes, bank transfer or mobile money'],
                            ],
                        },
                    },
                    { note: 'Channel availability depends on the market and your business model, and is confirmed before go-live.' },
                ],
            },
            {
                id: 'why-higher-risk',
                heading: 'Why do payment providers look closely at mystery box stores?',
                blocks: [
                    'Providers assess the transaction pattern rather than the product category. Buyers pay a fixed price for an outcome they do not choose, many orders are small, and some buyers come back many times in one session. That combination produces more complaints of the "I did not get what I wanted" kind, and on cards some of those become disputes.',
                    'What a reviewer typically wants to see is evidence that you run the store responsibly: what is in each series, how rarity works, what happens when a buyer is unhappy, and which markets you sell into. Having those answers ready speeds up onboarding.',
                ],
            },
            {
                id: 'disclosure-checklist',
                heading: 'What should a mystery box store publish before checkout?',
                blocks: [
                    'As general good practice, and to make reviews and dispute handling easier, show these before the buyer pays:',
                    {
                        list: [
                            'Every possible item in the series, with a photo.',
                            'The odds or rarity tier of each item, stated as plainly as possible.',
                            'The price per draw and per bundle, in local currency.',
                            'Shipping time for physical boxes, or delivery rules for digital items.',
                            'Refund, exchange or buyback terms, including what is not refundable.',
                            'An age limit where it fits your products.',
                        ],
                    },
                    'Consumer protection and loot-box rules differ from country to country and change over time, so confirm the requirements for each market with local advisers.',
                ],
            },
            {
                id: 'refunds-worked-example',
                heading: 'How do you refund a buyer who paid with a local method?',
                blocks: [
                    'Push payments have no "reverse this charge" mechanism. When a buyer in Brazil pays for a box with Pix and the parcel is lost, the usual flow is:',
                    {
                        steps: [
                            'Support approves the refund and records the original order ID.',
                            'Your system collects or confirms the buyer\'s bank details for the refund.',
                            'You create a payout through the KaazPay API or dashboard, referencing the original order.',
                            'KaazPay sends a status notification when the payout completes, and you update the order to refunded.',
                        ],
                    },
                    'Payouts run by bank transfer in Brazil, Mexico, Colombia, Malaysia and the Philippines, and by bank transfer or mobile money in Indonesia. Peru is pay-in only, so agree refund handling there before launch. Exact refund handling is confirmed per channel. For the bigger picture, see [chargebacks vs local payments](/compare/chargebacks-vs-local-payments).',
                ],
            },
            {
                id: 'cards-in-the-mix',
                heading: 'Should a mystery box store still accept cards?',
                blocks: [
                    'Yes, for buyers who prefer them and in markets where cards are common. KaazPay accepts Visa, Mastercard and UnionPay worldwide and JCB in Japan. Card buyers can raise disputes through their issuer, so clear disclosure, quick refunds and good order records matter most on this part of your volume. The trade-offs are laid out in [local payment methods vs cards](/compare/local-payment-methods-vs-cards).',
                ],
            },
            {
                id: 'settlement',
                heading: 'How are mystery box sales in many currencies settled?',
                blocks: [
                    'Buyers pay in reais, pesos, ringgit, rupiah and more. KaazPay settles the collected funds as the equivalent amount in USDT, so one balance covers every market. Many channels settle D+0, others D+1 or later, and the cycle is confirmed per channel before go-live. Read [USDT settlement explained](/guides/usdt-settlement).',
                ],
            },
            {
                id: 'get-started-with-kaazpay',
                heading: 'How do you start taking mystery box payments with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account; the business review covers your products, disclosure and markets.',
                            'Get your API keys from the merchant dashboard.',
                            'Integrate pay-in, notifications and refund payouts with help from our engineers ([developer docs](/developers)).',
                            'Go live once channels for each market are confirmed.',
                        ],
                    },
                    'Tell us what you sell and where. [Message our team on Telegram](/contact) and we reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'Can a mystery box or gacha store open a KaazPay account?', a: 'It can apply. Every account goes through a business review, and the channels available in each market are confirmed before go-live.' },
            { q: 'What is the best way to take payment for a single blind box draw?', a: 'An instant method the buyer approves in seconds, such as Pix in Brazil, SPEI in Mexico, DuitNow in Malaysia, GCash in the Philippines or QRIS in Indonesia.' },
            { q: 'Can buyers pay with cash vouchers?', a: 'Yes, with Boleto in Brazil, PagoEfectivo in Peru and cash payment options in several Latin American markets. They confirm only after the buyer pays, so they suit bundles and pre-orders.' },
            { q: 'How are refunds made to buyers who paid with Pix or GCash?', a: 'Usually by a payout to the buyer\'s bank account in payout markets, linked to the original order. Refund handling is confirmed per channel.' },
            { q: 'Do local methods eliminate disputes?', a: 'No. They remove card-scheme chargebacks, but buyers can still complain to you or their bank. Clear disclosure and fast refunds remain the main defence.' },
        ],
    },
    zh: {
        title: '盲盒与抽卡支付指南：小额高频订单的收款方式',
        description: '盲盒、福袋与抽卡商户收款指南：单抽、整套与预售分别适合哪些本地支付方式，本地支付如何通过代付退款，需要公示哪些内容，以及 USDT 结算。',
        h1: '盲盒和抽卡商户如何接入海外支付？',
        summary: '盲盒和抽卡商户应在单抽场景接入 Pix、SPEI、DuitNow、GCash、QRIS 等秒级确认的本地方式，整套和预售再配合信用卡与现金凭证，并在付款前公示款式、概率与退款规则。KaazPay 在同一账户中提供这些方式，可在代付市场通过代付退款，经业务审核后以 USDT 结算。',
        queries: [
            '盲盒店面向巴西、墨西哥、菲律宾买家，结账页该放哪些支付方式？',
            '买家用 Pix 或 GCash 买了盲盒，要退款怎么操作？',
            '为什么支付公司把抽卡、盲盒归为高风险行业？',
            '没有银行卡的买家能用扫码或现金凭证买盲盒吗？',
        ],
        takeaways: [
            '按金额选方式：单抽要秒级到账，整套和预售可以用确认较慢的凭证和转账。',
            '随机商品更容易引发“抽到的不满意”类投诉，公示与快速退款比调整支付流程更能有效减少争议。',
            'Pix、SPEI、DuitNow、GCash、QRIS 等推式付款由买家在自己 App 中确认，少了部分卡组织拒付途径，但仍需退款机制。',
            '本地支付的退款通常以代付方式退回，适用于代付市场；秘鲁等仅代收市场需提前约定处理方式。',
            '接入 KaazPay 需通过业务审核，代收资金按等值 USDT 结算。',
        ],
        sections: [
            {
                id: 'order-size-and-method',
                heading: '单抽、整套、预售，各适合什么支付方式？',
                blocks: [
                    '盲盒店的订单大致分三档，每档适合的支付方式不同：',
                    {
                        table: {
                            head: ['订单类型', '买家需求', '适合的方式'],
                            rows: [
                                ['单抽或单盒', '数秒内完成付款并立即开盒', 'Pix、SPEI、DuitNow、GCash、QRIS、Bre-B、卡类钱包'],
                                ['整套端盒', '金额较大、有计划的购买', "信用卡、FPX、Touch 'n Go、银行转账"],
                                ['新系列预售', '可接受延后确认', 'Boleto、PagoEfectivo、现金支付、银行转账'],
                            ],
                        },
                    },
                    '对单抽而言，开盒体验本身就是商品。如果单抽要等数小时凭证才确认，购买意愿会明显下降。确认较慢的凭证和转账，放在买家本来就愿意等的场景更合适。',
                ],
            },
            {
                id: 'methods-by-market',
                heading: 'KaazPay 为盲盒商户支持哪些支付方式？',
                blocks: [
                    '盲盒与抽卡商户常见市场的部分代收方式：',
                    {
                        table: {
                            head: ['市场', '代收方式', '能否代付退款'],
                            rows: [
                                ['全球', '[Visa](/methods/visa)、Mastercard、银联；日本支持 JCB', '卡退款按通道处理'],
                                ['[墨西哥](/payment-methods/mexico)', '[SPEI](/methods/spei)、银行转账、现金支付', '可以，银行转账'],
                                ['哥伦比亚', 'PSE、Bancolombia、Bre-B、银行转账、现金支付', '可以，银行转账'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)、银行转账、Boleto、现金支付', '可以，银行转账'],
                                ['[秘鲁](/payment-methods/peru)', '[PagoEfectivo](/methods/pagoefectivo)、银行转账、现金支付', '不可以，仅代收'],
                                ['[马来西亚](/payment-methods/malaysia)', "FPX、Touch 'n Go、[DuitNow](/methods/duitnow)", '可以，银行转账'],
                                ['[菲律宾](/payment-methods/philippines)', '[GCash](/methods/gcash)', '可以，银行转账'],
                                ['[印度尼西亚](/payment-methods/indonesia)', '[QRIS](/methods/qris)', '可以，银行转账或移动钱包'],
                            ],
                        },
                    },
                    { note: '可用通道取决于市场与业务类型，上线前逐一确认。' },
                ],
            },
            {
                id: 'why-higher-risk',
                heading: '支付机构为什么对盲盒商户审核更严格？',
                blocks: [
                    '支付机构关注的是交易形态，而非品类本身：买家花固定价格换一个自己选不了的结果，单笔金额小，同一人一次可能连抽很多回。这样的组合更容易出现“没抽到想要的”投诉，用信用卡支付的，一部分就会变成拒付。',
                    '审核方通常想确认您在规范经营：每个系列有哪些款、稀有度怎么设定、买家不满意怎么处理、卖到哪些国家。提前备妥这些资料，可加快开户审核。',
                ],
            },
            {
                id: 'disclosure-checklist',
                heading: '盲盒店付款前应该公示什么？',
                blocks: [
                    '作为通行做法，也为了审核和处理争议更顺利，建议在付款前展示：',
                    {
                        list: [
                            '系列全部款式及图片。',
                            '每款的概率或稀有度等级，尽量写得直白。',
                            '单抽和整套的本币价格。',
                            '实体盲盒的发货时间，或数字物品的发放规则。',
                            '退款、换货或回收规则，包括哪些情况不退。',
                            '适合设年龄限制的商品，注明年龄要求。',
                        ],
                    },
                    '各国消费者保护和抽奖类商品的规定不同，也会调整，请向当地顾问确认每个市场的要求。',
                ],
            },
            {
                id: 'refunds-worked-example',
                heading: '买家用本地方式付款，怎么退款？',
                blocks: [
                    '推式付款没有“撤销扣款”的机制。例如巴西买家用 Pix 买了一个盲盒，包裹丢失，常见退款流程是：',
                    {
                        steps: [
                            '客服批准退款，并记录原订单号。',
                            '系统收集或确认买家的退款银行信息。',
                            '通过 KaazPay API 或后台发起一笔代付，关联原订单。',
                            '代付完成后 KaazPay 推送状态通知，您将订单标记为已退款。',
                        ],
                    },
                    '巴西、墨西哥、哥伦比亚、马来西亚、菲律宾支持银行转账代付，印度尼西亚支持银行转账或移动钱包代付。秘鲁仅支持代收，上线前需约定退款处理方式。具体退款方式按通道确认，整体对比见[信用卡拒付 vs 本地支付](/compare/chargebacks-vs-local-payments)。',
                ],
            },
            {
                id: 'cards-in-the-mix',
                heading: '盲盒店还要接信用卡吗？',
                blocks: [
                    '需要，用于服务偏好刷卡的买家和信用卡普及的市场。KaazPay 支持全球 Visa、Mastercard、银联，以及日本 JCB。持卡人可以通过发卡行发起争议，所以这部分订单尤其要做好公示、快速退款和订单留档。两者取舍见[本地支付 vs 信用卡](/compare/local-payment-methods-vs-cards)。',
                ],
            },
            {
                id: 'settlement',
                heading: '多币种盲盒收入怎么结算？',
                blocks: [
                    '买家用雷亚尔、比索、林吉特、印尼盾等付款，KaazPay 将代收资金按等值 USDT 结算，所有市场归到一个余额。不少通道 D+0 结算，其余 D+1 或更长，上线前按通道确认。详见 [USDT 结算说明](/guides/usdt-settlement)。',
                ],
            },
            {
                id: 'get-started-with-kaazpay',
                heading: '如何用 KaazPay 开始盲盒收款？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，业务审核会了解您的商品、公示方式与目标市场。',
                            '在商户后台获取 API 密钥。',
                            '在工程师协助下对接代收、回调通知与退款代付（见[开发文档](/developers)）。',
                            '各市场通道确认后正式上线。',
                        ],
                    },
                    '请告知您的商品与目标市场，[通过 Telegram 联系我们](/contact)，一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '盲盒或抽卡商户能开通 KaazPay 吗？', a: '可以申请。所有账户都需通过业务审核，各市场可用通道在上线前确认。' },
            { q: '单抽用什么方式收款最好？', a: '用买家几秒就能确认的实时方式，例如巴西 Pix、墨西哥 SPEI、马来西亚 DuitNow、菲律宾 GCash、印尼 QRIS。' },
            { q: '买家能用现金凭证付款吗？', a: '可以，例如巴西 Boleto、秘鲁 PagoEfectivo，以及多个拉美市场的现金支付。凭证要等买家付款后才确认，更适合整套和预售。' },
            { q: '用 Pix 或 GCash 付款的买家怎么退款？', a: '在代付市场，通常以代付方式退回买家银行账户，并关联原订单。具体退款方式按通道确认。' },
            { q: '用本地支付就不会有争议了吗？', a: '不是。本地支付没有卡组织拒付，但买家仍可向商户或银行投诉。清楚公示和快速退款仍是最重要的防线。' },
        ],
    },
};
