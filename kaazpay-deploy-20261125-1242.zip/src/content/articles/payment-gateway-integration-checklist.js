export default {
    slug: 'payment-gateway-integration-checklist',
    kind: 'guide',
    published: '2025-06-03',
    updated: '2025-06-03',
    related: {
        markets: ['global-cards', 'usdt'],
        methods: [],
        industries: ['e-commerce', 'gaming', 'digital-goods'],
        articles: ['merchant-onboarding-kyc-checklist', 'payment-success-rate', 'mass-payouts-emerging-markets', 'usdt-settlement'],
    },
    en: {
        title: 'Payment Gateway Integration Checklist for Developers',
        description: 'Developer checklist for payment gateway integration: key handling, signatures, IP allow-lists, webhooks, order states, tests, go-live and daily reconciliation.',
        h1: 'Payment gateway integration checklist: what developers need to get right',
        summary: 'A solid payment gateway integration keeps keys on the server, signs every request, allow-lists fixed server IPs, verifies every webhook, models every order and payout state, tests failure cases as carefully as success, and reconciles daily from the first day live. With KaazPay this happens in four steps: open an account, receive API keys, integrate with engineer support and joint testing, then go live.',
        queries: [
            'What should our developers check before integrating a payment gateway API?',
            'How should we handle payment webhooks so customers are never credited twice?',
            'Which test cases should we run before going live with a new payment provider?',
            'Why does a payment gateway need our server IP addresses?',
            'What payment statuses do we need to handle for bank transfers and vouchers?',
        ],
        takeaways: [
            'Creating a payment is straightforward; most issues arise in notifications, status handling and retries.',
            'Keep keys server-side, sign every request and verify every notification signature.',
            'Design for asynchronous methods: some payments complete hours after the buyer leaves.',
            'Write a test matrix that covers failures, duplicates and timeouts for every method you launch.',
            'Plan go-live as a controlled rollout with alerts and daily reconciliation.',
        ],
        sections: [
            {
                id: 'before-you-code',
                heading: 'What should you decide before writing any code?',
                blocks: [
                    'A few decisions shape the whole integration, so settle them with product and finance first:',
                    {
                        list: [
                            'Which markets and methods launch first, and which follow. The [payment methods directory](/methods) shows what is available per country.',
                            'Whether you need pay-in only, or payouts too, and whether payouts are single or batch.',
                            'Where the source of truth for an order lives, and which service owns payment state.',
                            'How refunds, cancellations and expired payments should appear to customers and support staff.',
                            'Which USDT network you want settlements on, agreed during onboarding (see [USDT settlement](/guides/usdt-settlement)).',
                        ],
                    },
                    'Business documents and approvals run in parallel; our [merchant onboarding checklist](/guides/merchant-onboarding-kyc-checklist) lists what to prepare.',
                ],
            },
            {
                id: 'security-basics',
                heading: 'How should you secure keys, requests and network access?',
                blocks: [
                    'KaazPay integrations use **signed requests, IP allow-listing and encrypted transport**. On your side:',
                    {
                        steps: [
                            'Store the merchant ID and keys in a secrets manager or protected environment variables, never in a repository or client app.',
                            'Generate signatures only on your server, exactly as the integration guide specifies.',
                            'Send requests from fixed outbound IPs and register them for allow-listing; update the list before changing hosting.',
                            'Limit who can read or rotate keys, and log every rotation.',
                            'Use HTTPS for every call and for your own notification endpoint.',
                        ],
                    },
                    { note: 'Request formats and signing details come from the integration materials you receive after onboarding. Do not copy signing code from generic examples found online.' },
                ],
            },
            {
                id: 'notifications',
                heading: 'How do you build a reliable notification (webhook) handler?',
                blocks: [
                    'KaazPay posts a real-time, signed notification whenever a payment or payout changes status. Treat this endpoint as critical infrastructure:',
                    {
                        list: [
                            '**Verify first.** Reject any notification whose signature fails, before reading its contents.',
                            '**Cross-check.** Confirm the order ID, amount and currency match what you created.',
                            '**Be idempotent.** The same notification can arrive more than once; credit or release funds only once per order.',
                            '**Acknowledge quickly.** Respond promptly and move slow work, such as emails or game-item delivery, to a queue.',
                            '**Keep a log.** Store every raw notification for support and reconciliation.',
                        ],
                    },
                ],
            },
            {
                id: 'state-model',
                heading: 'Which order and payout states must your system handle?',
                blocks: [
                    'Exact status names come from the integration guide, but your system should be able to represent at least these situations:',
                    {
                        table: {
                            head: ['Situation', 'What your system should do'],
                            rows: [
                                ['Created, awaiting payment', 'Show instructions; do not deliver yet'],
                                ['Pending (transfer, voucher, wallet approval)', 'Keep open; poll status if no notification arrives within your timeout'],
                                ['Succeeded', 'Deliver goods or credit the balance once, after verifying the notification'],
                                ['Failed or cancelled', 'Show a clear reason and offer another method'],
                                ['Expired', 'Close the attempt; let the buyer start a new one'],
                                ['Payout processing / paid / failed', 'Hold funds while processing; release or correct on a final status'],
                            ],
                        },
                    },
                    'Bank transfers and vouchers such as [Boleto](/methods/boleto) can be paid long after the buyer leaves your page, so never time out an order faster than the method allows.',
                ],
            },
            {
                id: 'test-matrix',
                heading: 'What should your test plan cover?',
                blocks: [
                    'KaazPay engineers join you for testing before launch. Bring a written test matrix that includes, for every market and method you will launch:',
                    {
                        list: [
                            'A successful payment, end to end, including delivery.',
                            'A declined or failed payment, and the customer message shown.',
                            'An expired payment, and a retry with the same and with a different method.',
                            'The same notification delivered twice, and a notification that arrives late.',
                            'A request with a bad signature, and one from an IP that is not allow-listed.',
                            'Payouts that succeed and fail, if you use [payouts](/guides/mass-payouts-emerging-markets).',
                            'How each test transaction appears in the merchant dashboard.',
                        ],
                    },
                ],
            },
            {
                id: 'common-mistakes',
                heading: 'Which integration mistakes cause the most problems later?',
                blocks: [
                    {
                        list: [
                            'Marking orders paid when the browser returns from the payment page.',
                            'Creating a new order every time a customer clicks “try again”.',
                            'Retrying a timed-out request without checking whether the first one succeeded.',
                            'Hard-coding one method per country, so adding a second method means a code release.',
                            'Postponing reconciliation until finance raises a question.',
                        ],
                    },
                    'Several of these appear as a falling success rate; [how to raise your payment success rate](/guides/payment-success-rate) explains how to spot them.',
                ],
            },
            {
                id: 'go-live-runbook',
                heading: 'What does a safe go-live look like?',
                blocks: [
                    {
                        steps: [
                            'Confirm rates, fees and settlement cycles for every channel in writing.',
                            'Launch one market, or a share of traffic, before the full rollout.',
                            'Set alerts for failed notification processing and unusual failure rates.',
                            'Reconcile daily: your orders against orders, balances and settlements in the KaazPay dashboard.',
                            'Agree an incident contact with the KaazPay technical team.',
                        ],
                    },
                    'Where a market has several channels, KaazPay routes each payment and fails over automatically, so you integrate once rather than per channel. See [capabilities](/capabilities).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you start integrating with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your markets and business model.',
                            'Receive your API keys and integration materials.',
                            'Build and test with a dedicated KaazPay engineer; start with the [developer overview](/developers).',
                            'Go live with monitoring and reconciliation in place.',
                        ],
                    },
                    'Contact us on Telegram via the [contact page](/contact). We reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'How long does a payment gateway integration take?', a: 'It depends on your stack and how many markets and methods you launch at once. KaazPay assigns an engineer and runs joint tests to keep the path to go-live short.' },
            { q: 'When do I get the API documentation?', a: 'Integration materials are shared once your merchant account is set up and approved.' },
            { q: 'How do I know a notification really came from KaazPay?', a: 'Each notification is signed. Verify the signature, then check the order ID, amount and currency before acting on it.' },
            { q: 'What is IP allow-listing for?', a: 'Only requests from your registered server IPs are accepted, so leaked keys alone are not enough to call the API.' },
            { q: 'Do pay-in and payouts need separate integrations?', a: 'They use the same KaazPay merchant account, dashboard and integration partner, so you build one relationship and one set of security controls.' },
        ],
    },
    zh: {
        title: '支付网关接入清单：开发者必查事项',
        description: '面向开发者的支付网关接入清单：密钥管理、请求签名、IP 白名单、回调处理、订单状态、测试用例、上线步骤与每日对账。',
        h1: '支付网关接入清单：开发者需要做好哪些事？',
        summary: '稳妥的支付网关接入，要把密钥留在服务器端、每个请求都签名、用固定服务器 IP 申请白名单、每条回调都验签、覆盖所有订单与代付状态、像测试成功一样认真测试失败，并从上线第一天起每日对账。在 KaazPay，整个过程分四步：开户、获取 API 密钥、在工程师协助下接入联调、正式上线。',
        queries: [
            '开发在对接支付网关 API 之前，需要检查哪些事项？',
            '支付回调要怎么处理，才能保证不会给用户重复入账？',
            '新支付通道上线前应该跑哪些测试用例？',
            '支付网关为什么要我们提供服务器 IP？',
            '银行转账和凭证类付款需要处理哪些支付状态？',
        ],
        takeaways: [
            '创建支付并不复杂，问题多出现在回调、状态处理和重试环节。',
            '密钥只放服务器端，每个请求都签名，每条回调都验签。',
            '为异步支付方式做好设计：有的付款在用户离开几小时后才完成。',
            '为每种上线的支付方式写测试矩阵，覆盖失败、重复和超时。',
            '把上线当成可控的灰度发布，配好告警并每日对账。',
        ],
        sections: [
            {
                id: 'before-you-code',
                heading: '写代码之前，要先定下哪些事？',
                blocks: [
                    '有几项决定会影响整个接入方案，最好先和产品、财务对齐：',
                    {
                        list: [
                            '首批上线哪些市场和支付方式、后续再加哪些。各国可用方式见[支付方式目录](/methods)。',
                            '只做代收，还是也要代付；代付是单笔还是批量。',
                            '订单的权威数据存在哪里，由哪个服务负责支付状态。',
                            '退款、取消和过期付款在用户端和客服端分别如何呈现。',
                            '结算用哪条 USDT 链，在开户时约定（见 [USDT 结算指南](/guides/usdt-settlement)）。',
                        ],
                    },
                    '公司资料与审核可以同步进行，需要准备什么请看[商户开户清单](/guides/merchant-onboarding-kyc-checklist)。',
                ],
            },
            {
                id: 'security-basics',
                heading: '密钥、请求和网络访问要怎么保护？',
                blocks: [
                    'KaazPay 的接入采用**请求签名、IP 白名单和加密传输**。商户端需要做到：',
                    {
                        steps: [
                            '商户号和密钥存放在密钥管理服务或受保护的环境变量中，绝不放进代码仓库或客户端。',
                            '签名只在服务器端生成，严格遵循接入文档的规则。',
                            '从固定出口 IP 发起请求并登记白名单；更换服务器前先更新名单。',
                            '限制能查看或更换密钥的人员，并记录每次更换。',
                            '所有调用以及自己的回调地址都使用 HTTPS。',
                        ],
                    },
                    { note: '请求格式与签名细节以开户后收到的接入资料为准，不要照搬网上的通用示例代码。' },
                ],
            },
            {
                id: 'notifications',
                heading: '怎样写一个可靠的回调（Webhook）处理程序？',
                blocks: [
                    '每当代收或代付状态变化，KaazPay 都会推送带签名的实时回调。请把这个接口当作核心基础设施来对待：',
                    {
                        list: [
                            '**先验签。** 签名不通过的回调直接拒绝，不读取内容。',
                            '**再核对。** 确认订单号、金额和币种与创建时一致。',
                            '**要幂等。** 同一条回调可能到达多次，每个订单只入账或放款一次。',
                            '**快速响应。** 先及时应答，发邮件、发放游戏道具等耗时操作放进队列。',
                            '**留日志。** 保存每条原始回调，供客服和对账使用。',
                        ],
                    },
                ],
            },
            {
                id: 'state-model',
                heading: '系统需要处理哪些订单与代付状态？',
                blocks: [
                    '具体状态名称以接入文档为准，但系统至少要能表达以下几种情况：',
                    {
                        table: {
                            head: ['情况', '系统应如何处理'],
                            rows: [
                                ['已创建，等待付款', '展示付款说明，暂不发货'],
                                ['处理中（转账、凭证、钱包确认）', '保持订单开启；超时仍无回调时主动查询'],
                                ['成功', '验签后发货或入账，且只做一次'],
                                ['失败或取消', '给出清楚原因，并提供其他支付方式'],
                                ['已过期', '关闭本次尝试，让用户重新发起'],
                                ['代付处理中／已到账／失败', '处理中冻结资金，收到最终状态后放行或修正'],
                            ],
                        },
                    },
                    '银行转账和 [Boleto](/methods/boleto) 等凭证可能在用户离开页面很久之后才付款，订单超时时间不能比该方式允许的更短。',
                ],
            },
            {
                id: 'test-matrix',
                heading: '测试计划应该覆盖哪些内容？',
                blocks: [
                    '上线前 KaazPay 工程师会与您一起联调。请准备一份书面测试矩阵，对每个上线的市场和支付方式都覆盖：',
                    {
                        list: [
                            '一笔完整成功的付款，包括发货环节。',
                            '一笔被拒或失败的付款，以及展示给用户的提示。',
                            '一笔过期的付款，以及用同一方式、不同方式重试。',
                            '同一条回调到达两次，以及延迟到达的回调。',
                            '签名错误的请求，以及来自非白名单 IP 的请求。',
                            '如使用[代付](/guides/mass-payouts-emerging-markets)，测试成功和失败的代付。',
                            '每笔测试交易在商户后台的显示情况。',
                        ],
                    },
                ],
            },
            {
                id: 'common-mistakes',
                heading: '哪些接入错误最容易引发后续问题？',
                blocks: [
                    {
                        list: [
                            '浏览器从支付页跳回就把订单标记为已付款。',
                            '用户每点一次“重试”就新建一个订单。',
                            '请求超时后直接重发，没有先确认第一次是否已成功。',
                            '每个国家写死一种支付方式，新增支付方式就需要发版。',
                            '直到财务提出问题才开始对账。',
                        ],
                    },
                    '这些问题有不少会表现为成功率下降，排查方法见[如何提升支付成功率](/guides/payment-success-rate)。',
                ],
            },
            {
                id: 'go-live-runbook',
                heading: '如何稳妥地上线？',
                blocks: [
                    {
                        steps: [
                            '书面确认每个通道的费率、费用和结算周期。',
                            '先上线一个市场或一部分流量，再全面放开。',
                            '为回调处理失败和异常失败率设置告警。',
                            '每日对账：自己的订单对照 KaazPay 后台的订单、余额和结算。',
                            '与 KaazPay 技术团队约定好故障联系人。',
                        ],
                    },
                    '在有多个通道的市场，KaazPay 会自动路由并在通道异常时切换，商户只需接入一次，而不是逐个通道对接。详见[产品能力](/capabilities)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何开始接入 KaazPay？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，介绍目标市场和业务模式。',
                            '获取 API 密钥与接入资料。',
                            '在专属 KaazPay 工程师协助下开发并联调，可先看[开发者概览](/developers)。',
                            '配好监控与对账后正式上线。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 联系我们，一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '接入支付网关一般要多久？', a: '取决于技术栈以及一次上线多少市场和支付方式。KaazPay 会安排工程师并一起联调，尽量缩短上线时间。' },
            { q: '什么时候能拿到 API 文档？', a: '商户账户开通并审核通过后，我们会提供接入资料。' },
            { q: '怎么确认回调真的来自 KaazPay？', a: '每条回调都带签名。先验签，再核对订单号、金额和币种，然后再处理。' },
            { q: 'IP 白名单有什么作用？', a: '只接受来自已登记服务器 IP 的请求，即使密钥外泄，单凭密钥也无法调用 API。' },
            { q: '代收和代付需要分开对接吗？', a: '两者使用同一个 KaazPay 商户账户、后台和对接团队，只需维护一套合作关系和安全控制。' },
        ],
    },
};
