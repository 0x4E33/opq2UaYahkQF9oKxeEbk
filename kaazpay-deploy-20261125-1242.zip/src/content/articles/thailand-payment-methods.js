export default {
    slug: 'thailand-payment-methods',
    kind: 'guide',
    published: '2025-01-28',
    updated: '2026-11-23',
    related: {
        markets: ['thailand', 'malaysia', 'singapore'],
        methods: ['thai-qr'],
        industries: ['gaming', 'e-commerce', 'live-streaming'],
        articles: ['southeast-asia-payment-methods', 'singapore-payment-methods', 'malaysia-payment-methods', 'mass-payouts-emerging-markets'],
    },
    en: {
        title: 'Thailand Payment Methods: Thai QR and Bank Transfer',
        description: 'How to accept payments in Thailand with Thai QR Payment (PromptPay) and bank transfer, send THB payouts to Thai bank accounts, and get settled in USDT.',
        h1: 'How do you accept online payments from customers in Thailand?',
        summary: 'Most Thai online buyers pay from a mobile banking app, either by scanning a Thai QR Payment code built on PromptPay or by making a bank transfer. KaazPay offers both for pay-in in THB, sends payouts in Thailand by bank transfer, and settles your baht collections in USDT through one integration.',
        queries: [
            'What is the most common way to pay online in Thailand?',
            'Can Thai customers pay our website by scanning a PromptPay QR code?',
            'How do we send withdrawals to Thai bank accounts from abroad?',
            'Do we need a Thai company to accept Thai QR payments?',
        ],
        takeaways: [
            'Thai buyers mostly pay from banking apps: QR scans and transfers, not cards.',
            'Thai QR Payment runs on PromptPay, so one code works across participating Thai banking apps.',
            'Bank transfer suits larger amounts and buyers who prefer to key in the transfer themselves.',
            'KaazPay pays out in THB by bank transfer only, to Thai bank accounts.',
            'Baht collections are settled to you in USDT, with the cycle confirmed per channel.',
        ],
        sections: [
            {
                id: 'how-thailand-pays',
                heading: 'How do Thai shoppers usually pay online?',
                blocks: [
                    'Thailand moved to account-to-account payments early. **PromptPay**, the national real-time payment service backed by the Bank of Thailand and Thai banks, lets people send money using a mobile number or national ID instead of an account number, and almost every Thai banking app can scan a payment QR code. Street stalls, malls and online shops display the same kind of code.',
                    'Online checkout should therefore follow the payment habits Thai buyers already have: show a QR code they can scan with their banking app, and keep a bank transfer option for buyers who prefer it. The current channel list is on the [Thailand market page](/payment-methods/thailand).',
                ],
            },
            {
                id: 'methods-at-a-glance',
                heading: 'Which Thai payment methods does KaazPay support?',
                blocks: [
                    {
                        table: {
                            head: ['Direction', 'Method on KaazPay', 'How it works for the user', 'Good fit for'],
                            rows: [
                                ['Pay-in', 'Thai QR Payment', 'Scans a THB QR code with a Thai banking app and approves', 'Mobile buyers, top-ups, small and mid-size orders'],
                                ['Pay-in', 'Thailand Bank Transfer', 'Transfers the exact amount from mobile or online banking', 'Larger orders, buyers who prefer manual transfers'],
                                ['Payout', 'Bank transfer', 'Receives THB in a Thai bank account', 'Withdrawals, refunds, seller and creator earnings'],
                            ],
                        },
                    },
                ],
            },
            {
                id: 'thai-qr',
                heading: 'What is Thai QR Payment, and why offer it?',
                blocks: [
                    '[Thai QR Payment](/methods/thai-qr) is the Bank of Thailand standard for payment QR codes, built on PromptPay. A code generated for your order carries the amount, so the buyer only scans, checks the figure and approves in their own banking app. There is no card number to type and no account to create.',
                    {
                        list: [
                            '**Works across banks:** participating Thai banking apps can read the same code, so you do not need a separate button per bank.',
                            '**Fits phone and desktop:** on a laptop the buyer scans the on-screen code with their phone; on a phone they can save or screenshot the code and open it in the banking app.',
                            '**Fast confirmation:** the payment is confirmed as soon as the bank processes it, and KaazPay sends your server a signed notification.',
                        ],
                    },
                ],
            },
            {
                id: 'bank-transfer',
                heading: 'When should you offer Thailand Bank Transfer?',
                blocks: [
                    'Some buyers, especially for larger purchases or deposits, prefer to send a transfer themselves from mobile or internet banking. With **Thailand Bank Transfer** the checkout shows the payment details and the exact THB amount; the buyer completes the transfer in their bank and KaazPay matches it to the order.',
                    { note: 'Ask buyers to transfer the exact amount shown. A rounded or partial amount is a common reason a transfer cannot be matched automatically.' },
                ],
            },
            {
                id: 'checkout-example',
                heading: 'What does a Thai checkout look like in practice?',
                blocks: [
                    'Example: a player in Chiang Mai tops up a mobile game on their phone.',
                    {
                        steps: [
                            'Your server creates a THB order through the KaazPay API and receives a Thai QR code for that amount.',
                            'The checkout shows the code with the amount and an expiry timer, plus a short hint: "Save the QR, then open it in your banking app."',
                            'The player opens their banking app, scans or imports the code, checks the amount and approves.',
                            'KaazPay posts a signed notification to your server, and only then do you credit the game currency.',
                            'If the timer runs out, the player can generate a fresh code with one tap instead of starting over.',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: 'How do payouts in Thailand work?',
                blocks: [
                    'KaazPay sends THB payouts by **bank transfer only**, to the recipient’s Thai bank account. QR payment is a pay-in method; it is not used for payouts. Payouts can be sent one by one or in batches, and each payout comes with a status notification. Typical uses are player withdrawals, refunds, affiliate commissions and seller or creator earnings.',
                    'Collect the recipient’s full name, bank and account number when they sign up, check that the name matches the account holder, and keep a record of each payout reference for support. More on running payouts at volume in [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
                ],
            },
            {
                id: 'settlement',
                heading: 'How are baht collections settled to you?',
                blocks: [
                    'Buyers pay in THB and KaazPay settles the equivalent amount to you in USDT, so you can receive Thai revenue without a Thai bank account. Settlement cycles differ by channel: many KaazPay channels settle D+0 and others D+1 or later, and the cycle for each Thai channel is confirmed in writing before go-live. See [how USDT settlement works](/guides/usdt-settlement).',
                ],
            },
            {
                id: 'before-launch',
                heading: 'What should you prepare before launching in Thailand?',
                blocks: [
                    {
                        list: [
                            'Prices displayed in THB, matching the amount inside the QR code.',
                            'A QR page that works on both desktop and mobile, with a visible expiry time and a refresh button.',
                            'Clear instructions for bank transfers, including the exact amount and any reference to include.',
                            'Order fulfilment triggered only by verified server notifications, never by the return page alone.',
                            'Test bank transfer payouts, including one with deliberately wrong account details.',
                        ],
                    },
                    'To compare Thailand with neighbouring markets, see the [Southeast Asia guide](/guides/southeast-asia-payment-methods), the [Singapore guide](/guides/singapore-payment-methods) and the [Malaysia guide](/guides/malaysia-payment-methods).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you start accepting Thai payments with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your product and expected Thai volumes.',
                            'Receive your API keys.',
                            'Integrate with a KaazPay engineer and test QR, transfer and payout flows together; see the [developer page](/developers).',
                            'Go live with Thai QR Payment and bank transfer pay-in plus THB payouts.',
                        ],
                    },
                    'Contact us on Telegram through the [contact page](/contact). We reply within one business day with a channel plan and pricing.',
                ],
            },
        ],
        faq: [
            { q: 'What are the main online payment methods in Thailand?', a: 'Payments from mobile banking apps dominate: scanning a Thai QR Payment code (built on PromptPay) and bank transfers. KaazPay supports both for pay-in in THB.' },
            { q: 'Is Thai QR Payment the same as PromptPay?', a: 'Thai QR Payment is the standard QR code format, and PromptPay is the real-time payment system behind it. When a buyer scans a Thai QR code, the money moves over PromptPay rails between banks.' },
            { q: 'Can KaazPay send payouts in Thailand?', a: 'Yes. KaazPay sends THB payouts by bank transfer only, to Thai bank accounts, singly or in batches, each with a status notification.' },
            { q: 'Do I need a Thai bank account to receive the money?', a: 'No. Baht collections are settled to you in USDT. Your account manager confirms the onboarding requirements for your business.' },
            { q: 'How quickly are Thai payments settled?', a: 'It depends on the channel. Many KaazPay channels settle D+0 and others D+1 or later; each cycle is agreed before you go live.' },
        ],
    },
    zh: {
        title: '泰国收款指南：Thai QR 扫码与银行转账',
        description: '面向泰国用户怎么收款？详解 Thai QR Payment（PromptPay）扫码与银行转账代收、泰铢银行转账代付，以及 USDT 结算安排。',
        h1: '如何向泰国用户收取线上付款？',
        summary: '泰国网购用户大多直接在手机银行 App 里付款：要么扫描基于 PromptPay 的 Thai QR Payment 二维码，要么自行银行转账。KaazPay 一次接入即可提供这两种泰铢（THB）代收方式，代付只走银行转账，并把泰铢代收资金以 USDT 结算给商户。',
        queries: [
            '泰国人网上付款最常用什么方式？',
            '泰国用户能在我们网站上扫 PromptPay 二维码付款吗？',
            '海外商户如何向泰国用户的银行账户发放提现？',
            '没有泰国公司，能否收取 Thai QR 付款？',
        ],
        takeaways: [
            '泰国用户习惯用银行 App 扫码或转账，而不是刷卡。',
            'Thai QR Payment 基于 PromptPay，一个码可被各家参与银行的 App 识别。',
            '银行转账适合金额较大、习惯自己操作转账的用户。',
            'KaazPay 的泰铢代付只走银行转账，打入泰国银行账户。',
            '泰铢代收以 USDT 结算，各通道结算周期上线前逐一确认。',
        ],
        sections: [
            {
                id: 'how-thailand-pays',
                heading: '泰国用户平时怎么在网上付款？',
                blocks: [
                    '泰国很早就普及了账户对账户支付。由泰国央行与各家银行推动的全国实时支付服务 **PromptPay**，让人用手机号或身份证号就能收付款，几乎所有泰国银行 App 都能扫支付二维码。路边摊、商场和网店贴的都是同一类二维码。',
                    '因此，线上收银台应贴近泰国用户的日常付款习惯：展示一个能用银行 App 扫的二维码，同时保留银行转账，照顾偏好手动转账的用户。最新通道见[泰国市场页](/payment-methods/thailand)。',
                ],
            },
            {
                id: 'methods-at-a-glance',
                heading: 'KaazPay 在泰国支持哪些支付方式？',
                blocks: [
                    {
                        table: {
                            head: ['方向', 'KaazPay 支付方式', '用户怎么操作', '适合场景'],
                            rows: [
                                ['代收', 'Thai QR Payment', '用泰国银行 App 扫泰铢二维码并确认', '手机用户、充值、中小额订单'],
                                ['代收', '泰国银行转账', '在手机或网上银行转入准确金额', '大额订单、习惯手动转账的用户'],
                                ['代付', '银行转账', '泰铢打入泰国银行账户', '提现、退款、卖家与主播结款'],
                            ],
                        },
                    },
                ],
            },
            {
                id: 'thai-qr',
                heading: 'Thai QR Payment 是什么？为什么要提供？',
                blocks: [
                    '[Thai QR Payment](/methods/thai-qr) 是泰国央行制定的支付二维码标准，底层是 PromptPay。为订单生成的二维码已带上金额，用户只需扫码、核对金额、在自己的银行 App 里确认，不用输入卡号，也不用注册账户。',
                    {
                        list: [
                            '**跨行通用：** 参与的泰国银行 App 都能识别同一个码，不必为每家银行单独做按钮。',
                            '**手机电脑都适用：** 电脑端用户用手机扫屏幕上的码；手机端用户可保存或截图二维码，再在银行 App 里打开。',
                            '**确认快：** 银行处理完成即确认付款，KaazPay 随即向商户服务器推送带签名的回调。',
                        ],
                    },
                ],
            },
            {
                id: 'bank-transfer',
                heading: '什么时候需要提供泰国银行转账？',
                blocks: [
                    '有些用户在大额消费或入金时，更愿意自己在手机银行或网银里操作转账。使用**泰国银行转账**时，收银台显示收款信息和准确的泰铢金额，用户在自己的银行完成转账，KaazPay 再把款项与订单自动匹配。',
                    { note: '请提醒用户按页面显示的金额准确转账。金额凑整或只转部分，是转账无法自动匹配的常见原因。' },
                ],
            },
            {
                id: 'checkout-example',
                heading: '一笔泰国订单的实际付款流程是怎样的？',
                blocks: [
                    '示例：清迈一位玩家在手机上为手游充值。',
                    {
                        steps: [
                            '商户服务器通过 KaazPay API 创建泰铢订单，拿到对应金额的 Thai QR 二维码。',
                            '收银台显示二维码、金额和倒计时，并提示“保存二维码后在银行 App 中打开”。',
                            '玩家打开银行 App，扫码或导入图片，核对金额后确认。',
                            'KaazPay 向商户服务器推送带签名的回调，商户收到后才发放游戏币。',
                            '若倒计时结束，玩家一键即可生成新码，不必重新下单。',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: '泰国的代付怎么操作？',
                blocks: [
                    'KaazPay 的泰铢代付**只支持银行转账**，打入收款人的泰国银行账户；QR 扫码只用于代收，不用于代付。代付可单笔或批量发起，每笔都有状态回调，常用于玩家提现、退款、推广佣金以及卖家或主播结款。',
                    '建议在收款人注册时就收集全名、银行名称和账号，核对姓名与账户持有人一致，并保存每笔代付的流水号以便客服查询。大批量代付的运营要点，请看[新兴市场批量代付](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'settlement',
                heading: '泰铢代收资金如何结算给商户？',
                blocks: [
                    '用户以泰铢付款，KaazPay 以等额 USDT 结算给商户，没有泰国银行账户也能收到泰国业务的收入。各通道结算周期不同：KaazPay 不少通道 D+0 结算，其余 D+1 或更长，泰国各通道的周期会在上线前书面确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
                ],
            },
            {
                id: 'before-launch',
                heading: '在泰国上线前要准备什么？',
                blocks: [
                    {
                        list: [
                            '以泰铢标价，且与二维码内的金额一致。',
                            '二维码页面在电脑和手机上都能正常使用，显示有效期并提供刷新按钮。',
                            '银行转账说明清楚，包括准确金额和需要填写的附言。',
                            '只依据验签通过的服务器回调发货，不能只看返回页面。',
                            '测试银行转账代付，并故意用错误的账户资料测一次。',
                        ],
                    },
                    '如需对比泰国与周边市场，请参阅[东南亚支付方式指南](/guides/southeast-asia-payment-methods)，以及[新加坡收款指南](/guides/singapore-payment-methods)和[马来西亚收款指南](/guides/malaysia-payment-methods)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 开始在泰国收款？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，说明您的产品和泰国预估交易量。',
                            '获取 API 密钥。',
                            '与 KaazPay 工程师一起接入，联调扫码、转账和代付流程，详见[开发者页面](/developers)。',
                            '上线 Thai QR Payment 与银行转账代收，以及泰铢代付。',
                        ],
                    },
                    '请通过[联系页面](/contact)在 Telegram 联系我们，我们会在一个工作日内提供通道方案与报价。',
                ],
            },
        ],
        faq: [
            { q: '泰国主要的线上支付方式有哪些？', a: '以手机银行 App 付款为主：扫描 Thai QR Payment 二维码（基于 PromptPay）和银行转账。KaazPay 两种都支持以泰铢代收。' },
            { q: 'Thai QR Payment 和 PromptPay 是一回事吗？', a: 'Thai QR Payment 是二维码的标准格式，PromptPay 是背后的实时支付系统。用户扫 Thai QR 码付款时，资金经由 PromptPay 在银行之间转移。' },
            { q: 'KaazPay 能在泰国代付吗？', a: '能。KaazPay 的泰铢代付只走银行转账，打入泰国银行账户，可单笔或批量，每笔都有状态回调。' },
            { q: '需要泰国银行账户才能收款吗？', a: '不需要。泰铢代收资金以 USDT 结算给您。具体开户要求由客户经理根据您的业务确认。' },
            { q: '泰国的付款多久结算？', a: '取决于通道。KaazPay 不少通道 D+0 结算，其余 D+1 或更长，上线前逐一约定。' },
        ],
    },
};
