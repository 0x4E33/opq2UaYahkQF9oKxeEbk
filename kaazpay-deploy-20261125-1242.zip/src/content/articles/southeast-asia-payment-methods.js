export default {
    slug: 'southeast-asia-payment-methods',
    kind: 'guide',
    published: '2025-04-08',
    updated: '2026-11-23',
    related: {
        markets: ['malaysia', 'thailand', 'singapore', 'indonesia', 'philippines', 'japan'],
        methods: ['fpx', 'duitnow', 'touch-n-go', 'thai-qr', 'paynow', 'singapore-qr', 'qris', 'gcash'],
        industries: ['gaming', 'e-commerce', 'live-streaming'],
        articles: ['malaysia-payment-methods', 'thailand-payment-methods', 'singapore-payment-methods', 'indonesia-qris', 'philippines-gcash', 'japan-jcb-payments'],
    },
    en: {
        title: 'Southeast Asia Payment Methods for Online Sellers',
        description: 'Payment methods to offer in Malaysia, Thailand, Singapore, Indonesia and the Philippines: FPX, DuitNow, Thai QR, PayNow, QRIS, GCash, payouts, USDT settlement.',
        h1: 'What payment methods should you offer in Southeast Asia?',
        summary: 'In Southeast Asia, online buyers mostly pay through bank apps, e-wallets and national QR codes rather than international cards. The methods to offer are FPX, DuitNow and Touch ’n Go in Malaysia, Thai QR Payment and bank transfer in Thailand, PayNow, QR payment and iBanking in Singapore, QRIS in Indonesia and GCash in the Philippines. KaazPay connects them through one API, sends local payouts in all five countries and settles collections in USDT.',
        queries: [
            'We sell game top-ups in Malaysia, Thailand, Indonesia and the Philippines. Which payment methods do we need in each country?',
            'Is one payment gateway enough for FPX, Thai QR, PayNow, QRIS and GCash?',
            'Do Southeast Asian customers pay online with credit cards or e-wallets?',
            'Can we send withdrawals to users in Thailand, Singapore, Indonesia and the Philippines?',
            'How should a checkout look different for mobile users in Southeast Asia?',
        ],
        takeaways: [
            'Each country has its own leading method; one card-only checkout misses many buyers.',
            'Malaysia: FPX, DuitNow, Touch ’n Go. Thailand: Thai QR, bank transfer. Singapore: PayNow, QR, iBanking. Indonesia: QRIS. Philippines: GCash.',
            'Mobile-first flows (wallet approval, QR scan) suit the region’s phone-heavy shoppers.',
            'KaazPay offers bank transfer payouts in all five countries, plus mobile money payouts in Indonesia; Thailand and Singapore payouts are bank transfer only.',
            'Collections in MYR, THB, SGD, IDR and PHP are settled to you in USDT from one merchant account.',
        ],
        sections: [
            {
                id: 'how-the-region-pays',
                heading: 'How do online shoppers in Southeast Asia prefer to pay?',
                blocks: [
                    'Across the region, the phone is the main shopping device and the bank app or e-wallet is the main way to pay. National schemes have made account-to-account and QR payments routine, so many card holders still prefer the method they use for everyday purchases and bills.',
                    'Checkout should therefore be adapted by country. A Malaysian buyer looks for their bank or Touch ’n Go, a Thai buyer expects a QR code for their banking app, a Singaporean buyer looks for PayNow, an Indonesian buyer expects a QRIS code, and a Filipino buyer looks for GCash. See [local payment methods vs cards](/compare/local-payment-methods-vs-cards) for the broader trade-off.',
                ],
            },
            {
                id: 'country-table',
                heading: 'Which methods does KaazPay support in each Southeast Asian market?',
                blocks: [
                    {
                        table: {
                            head: ['Country', 'Currency', 'Pay-in on KaazPay', 'Payouts on KaazPay', 'Typical buyer flow'],
                            rows: [
                                ['Malaysia', 'MYR', 'FPX, DuitNow, Touch ’n Go', 'Bank transfer', 'Pick a bank and log in, scan a QR, or approve in the wallet app'],
                                ['Thailand', 'THB', 'Thai QR Payment, bank transfer', 'Bank transfer', 'Scan a Thai QR code with a banking app, or transfer the exact amount'],
                                ['Singapore', 'SGD', 'PayNow, QR payment, iBanking', 'Bank transfer', 'Approve PayNow or scan a QR in the banking app, or transfer via iBanking'],
                                ['Indonesia', 'IDR', 'QRIS', 'Bank transfer, mobile money', 'Scan one QR code with any bank app or e-wallet'],
                                ['Philippines', 'PHP', 'GCash', 'Bank transfer', 'Approve the payment in the GCash app'],
                            ],
                        },
                    },
                    'Live channel lists are on each market page: [Malaysia](/payment-methods/malaysia), [Thailand](/payment-methods/thailand), [Singapore](/payment-methods/singapore), [Indonesia](/payment-methods/indonesia) and [Philippines](/payment-methods/philippines).',
                ],
            },
            {
                id: 'malaysia',
                heading: 'Which methods matter most in Malaysia?',
                blocks: [
                    'In Malaysia, all three local methods are worth offering. [FPX](/methods/fpx) covers buyers who pay from online banking, [DuitNow](/methods/duitnow) QR covers anyone with a bank app or supported e-wallet, and [Touch ’n Go eWallet](/methods/touch-n-go) covers buyers who keep a wallet balance. Our [Malaysia guide](/guides/malaysia-payment-methods) and [FPX vs DuitNow vs Touch ’n Go](/compare/fpx-vs-duitnow-vs-touch-n-go) go deeper.',
                ],
            },
            {
                id: 'thailand',
                heading: 'What do buyers in Thailand expect at checkout?',
                blocks: [
                    'Thai buyers mostly pay from their mobile banking app. [Thai QR Payment](/methods/thai-qr), the Bank of Thailand QR standard built on PromptPay, lets them scan one code with a participating banking app and approve, while bank transfer covers buyers who prefer to send the exact amount themselves. KaazPay supports both for pay-in in THB and pays out by bank transfer only. More in our [Thailand guide](/guides/thailand-payment-methods).',
                ],
            },
            {
                id: 'singapore',
                heading: 'Which methods work best in Singapore?',
                blocks: [
                    'Singapore buyers use cards, but many prefer paying straight from their bank. [PayNow](/methods/paynow) lets them pay from a banking app via mobile number, NRIC/FIN or UEN, [QR payment](/methods/singapore-qr) covers buyers who scan (SGQR is the unified label that carries PayNow and other schemes), and iBanking suits desktop and larger transfers. KaazPay supports all three for pay-in in SGD and pays out by bank transfer only, to Singapore bank accounts. See the [Singapore guide](/guides/singapore-payment-methods).',
                ],
            },
            {
                id: 'indonesia',
                heading: 'Why is QRIS enough to start in Indonesia?',
                blocks: [
                    '[QRIS](/methods/qris) is Bank Indonesia’s national QR standard. A single QRIS code can be paid from Indonesian bank apps and e-wallets such as GoPay, OVO, DANA and ShopeePay, so one method reaches buyers across many apps. KaazPay supports QRIS pay-in in IDR, and payouts by bank transfer and mobile money. More in our [QRIS guide](/guides/indonesia-qris).',
                ],
            },
            {
                id: 'philippines',
                heading: 'What should you offer buyers in the Philippines?',
                blocks: [
                    '[GCash](/methods/gcash) is the leading e-wallet in the Philippines and the method many Filipino shoppers look for first. Buyers approve the amount in the app, which suits small, frequent purchases on a phone. KaazPay supports GCash pay-in in PHP and payouts to Philippine bank accounts; see [accepting GCash](/guides/philippines-gcash).',
                ],
            },
            {
                id: 'checkout-design',
                heading: 'How should checkout adapt to mobile buyers in the region?',
                blocks: [
                    {
                        steps: [
                            'Detect the buyer’s country and show that country’s methods first, rather than one long regional list.',
                            'On phones, put wallet and QR options at the top so buyers approve in an app on the same device.',
                            'On desktop, show a large QR code that buyers can scan with their phone, and keep FPX’s bank list searchable.',
                            'After the buyer leaves for a bank or wallet, bring them back to a status page that updates by itself.',
                            'Release top-ups or digital goods only when the signed server notification confirms payment.',
                        ],
                    },
                    'Keep international cards available for travellers and card-preferring buyers.',
                ],
            },
            {
                id: 'payouts',
                heading: 'Can you pay users and partners in Southeast Asia?',
                blocks: [
                    'Yes. KaazPay sends bank transfer payouts in Malaysia, Thailand, Singapore, Indonesia and the Philippines, and mobile money payouts in Indonesia, singly or in batches, each with a status notification. That covers player withdrawals, creator earnings, affiliate commissions and refunds. Read [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets) for the operational side.',
                    { note: 'FPX, DuitNow, Touch ’n Go, Thai QR, PayNow, Singapore QR, iBanking, QRIS and GCash are pay-in methods on KaazPay. Payouts use bank transfer, plus mobile money in Indonesia.' },
                ],
            },
            {
                id: 'settlement-and-japan',
                heading: 'How are collections settled, and what about Japan?',
                blocks: [
                    'Buyers pay in ringgit, baht, Singapore dollars, rupiah or pesos, and KaazPay settles the equivalent to you in USDT. Many channels settle D+0 and others D+1 or later, confirmed per channel before go-live; see [USDT settlement](/guides/usdt-settlement).',
                    'For merchants also selling in Japan, JCB is the domestic card brand, and KaazPay accepts it for pay-in in JPY. Our [Japan JCB guide](/guides/japan-jcb-payments) covers that market.',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you launch Southeast Asian payments with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your target countries and expected volumes.',
                            'Receive your API keys.',
                            'Integrate with a KaazPay engineer and test each method together; see the [developer page](/developers).',
                            'Go live country by country with agreed cycles and pricing.',
                        ],
                    },
                    'Reach us on Telegram via the [contact page](/contact). We reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'Which payment methods are most important in Southeast Asia?', a: 'In the markets KaazPay covers: FPX, DuitNow and Touch ’n Go in Malaysia, Thai QR Payment and bank transfer in Thailand, PayNow, QR payment and iBanking in Singapore, QRIS in Indonesia and GCash in the Philippines.' },
            { q: 'Can one integration handle FPX, Thai QR, PayNow, QRIS and GCash?', a: 'Yes. KaazPay offers all of them through the same API, notifications and merchant dashboard.' },
            { q: 'Does KaazPay support payouts in Southeast Asia?', a: 'Yes. Bank transfer payouts in all five markets (the only payout option in Thailand and Singapore), plus mobile money payouts in Indonesia.' },
            { q: 'Do I need a local bank account in each country?', a: 'Not to receive funds. Collections are settled to you in USDT. Your account manager confirms onboarding requirements for your business.' },
            { q: 'Should I still accept cards in Southeast Asia?', a: 'Yes, for travellers and buyers who prefer cards, but put the leading local method first in each country.' },
        ],
    },
    zh: {
        title: '东南亚支付方式指南：马来西亚、泰国、新加坡、印尼、菲律宾',
        description: '在马来西亚、泰国、新加坡、印尼和菲律宾该接哪些支付方式？FPX、DuitNow、Thai QR、PayNow、QRIS 与 GCash 逐一说明，并介绍本地代付与 USDT 结算。',
        h1: '东南亚线上收款，应该提供哪些支付方式？',
        summary: '东南亚的网购用户大多通过银行 App、电子钱包和国家统一二维码付款，而不是国际信用卡。需要提供的方式是：马来西亚的 FPX、DuitNow 与 Touch ’n Go，泰国的 Thai QR Payment 与银行转账，新加坡的 PayNow、QR 扫码与网银 iBanking，印尼的 QRIS，以及菲律宾的 GCash。KaazPay 通过一套 API 接入这些方式，在五个国家都支持本地代付，并以 USDT 结算代收资金。',
        queries: [
            '我们在马来西亚、泰国、印尼和菲律宾卖游戏充值，每个国家要接哪些支付方式？',
            '一个支付网关能否同时支持 FPX、Thai QR、PayNow、QRIS 和 GCash？',
            '东南亚用户网购更常用信用卡还是电子钱包？',
            '能给泰国、新加坡、印尼和菲律宾的用户发起提现代付吗？',
            '面向东南亚手机用户，收银台要怎么设计？',
        ],
        takeaways: [
            '每个国家都有自己的主流支付方式，只收银行卡会错失大量买家。',
            '马来西亚：FPX、DuitNow、Touch ’n Go；泰国：Thai QR、银行转账；新加坡：PayNow、QR 扫码、iBanking；印尼：QRIS；菲律宾：GCash。',
            '钱包确认、扫码等以手机为中心的流程，更符合本地用户习惯。',
            'KaazPay 在五国都支持银行转账代付，印尼另有移动钱包代付；泰国和新加坡的代付只走银行转账。',
            '林吉特、泰铢、新元、印尼盾、菲律宾比索的代收资金在同一个商户账户以 USDT 结算。',
        ],
        sections: [
            {
                id: 'how-the-region-pays',
                heading: '东南亚网购用户习惯怎么付款？',
                blocks: [
                    '在这个地区，手机是主要的购物设备，银行 App 和电子钱包是主要的付款工具。各国的国家级支付体系让账户转账和扫码付款成了日常，不少持卡人也更愿意使用日常消费和缴费时常用的方式。',
                    '因此，收银台应按国家调整：马来西亚用户找自己的银行或 Touch ’n Go，泰国用户希望看到能用银行 App 扫的二维码，新加坡用户找 PayNow，印尼用户期待一个 QRIS 码，菲律宾用户找 GCash。更全面的取舍分析见[本地支付方式与银行卡对比](/compare/local-payment-methods-vs-cards)。',
                ],
            },
            {
                id: 'country-table',
                heading: 'KaazPay 在东南亚各市场支持哪些方式？',
                blocks: [
                    {
                        table: {
                            head: ['国家', '币种', 'KaazPay 代收', 'KaazPay 代付', '用户典型付款流程'],
                            rows: [
                                ['马来西亚', 'MYR', 'FPX、DuitNow、Touch ’n Go', '银行转账', '选银行登录网银、扫码，或在钱包 App 内确认'],
                                ['泰国', 'THB', 'Thai QR Payment、银行转账', '银行转账', '用银行 App 扫 Thai QR 码，或按准确金额转账'],
                                ['新加坡', 'SGD', 'PayNow、QR 扫码、网银 iBanking', '银行转账', '在银行 App 内确认 PayNow 或扫码，或通过 iBanking 转账'],
                                ['印度尼西亚', 'IDR', 'QRIS', '银行转账、移动钱包', '用任意银行 App 或电子钱包扫同一个二维码'],
                                ['菲律宾', 'PHP', 'GCash', '银行转账', '在 GCash App 内确认付款'],
                            ],
                        },
                    },
                    '各市场的最新通道列表见：[马来西亚](/payment-methods/malaysia)、[泰国](/payment-methods/thailand)、[新加坡](/payment-methods/singapore)、[印度尼西亚](/payment-methods/indonesia)、[菲律宾](/payment-methods/philippines)。',
                ],
            },
            {
                id: 'malaysia',
                heading: '马来西亚最该接哪些方式？',
                blocks: [
                    '在马来西亚，三种本地方式都值得提供：[FPX](/methods/fpx) 覆盖习惯用网银付款的用户，[DuitNow](/methods/duitnow) 二维码覆盖所有有银行 App 或支持的电子钱包的用户，[Touch ’n Go eWallet](/methods/touch-n-go) 覆盖有钱包余额的用户。详见[马来西亚支付方式指南](/guides/malaysia-payment-methods)和 [FPX、DuitNow、Touch ’n Go 对比](/compare/fpx-vs-duitnow-vs-touch-n-go)。',
                ],
            },
            {
                id: 'thailand',
                heading: '泰国用户在收银台期待什么？',
                blocks: [
                    '泰国用户大多直接用手机银行 App 付款。[Thai QR Payment](/methods/thai-qr) 是泰国央行基于 PromptPay 制定的二维码标准，用户用参与银行的 App 扫同一个码即可确认付款；习惯自己按准确金额转账的用户，则可选择银行转账。KaazPay 两种都支持以泰铢代收，代付则只走银行转账。详见[泰国收款指南](/guides/thailand-payment-methods)。',
                ],
            },
            {
                id: 'singapore',
                heading: '新加坡最适合接哪些方式？',
                blocks: [
                    '新加坡用户也刷卡，但很多人更愿意直接从银行付款。[PayNow](/methods/paynow) 让用户在银行 App 内凭手机号、NRIC/FIN 或 UEN 付款；[QR 扫码支付](/methods/singapore-qr)照顾习惯扫码的用户（统一标识 SGQR 可承载 PayNow 等多种方案）；网银 iBanking 则适合电脑端和较大金额转账。KaazPay 三种都支持以新元代收，代付则只走银行转账，打入新加坡银行账户。详见[新加坡收款指南](/guides/singapore-payment-methods)。',
                ],
            },
            {
                id: 'indonesia',
                heading: '为什么在印尼先接 QRIS 就够了？',
                blocks: [
                    '[QRIS](/methods/qris) 是印尼央行推出的全国统一二维码标准。同一个 QRIS 码可以用印尼各家银行 App 以及 GoPay、OVO、DANA、ShopeePay 等电子钱包支付，一种方式就能触达多个 App 的用户。KaazPay 支持以 IDR 进行 QRIS 代收，并支持银行转账与移动钱包代付。详见 [QRIS 指南](/guides/indonesia-qris)。',
                ],
            },
            {
                id: 'philippines',
                heading: '面向菲律宾用户应提供什么？',
                blocks: [
                    '[GCash](/methods/gcash) 是菲律宾领先的电子钱包，也是很多菲律宾用户在收银台第一个找的方式。用户在 App 内确认金额即可，适合手机上的小额高频消费。KaazPay 支持以 PHP 进行 GCash 代收，并可代付到菲律宾银行账户，详见 [GCash 收款指南](/guides/philippines-gcash)。',
                ],
            },
            {
                id: 'checkout-design',
                heading: '收银台要如何适应本地手机用户？',
                blocks: [
                    {
                        steps: [
                            '识别用户所在国家，先展示该国的支付方式，而不是一长串区域列表。',
                            '手机端把钱包和扫码放在最上面，让用户在同一台手机的 App 内确认。',
                            '电脑端显示大尺寸二维码方便手机扫，FPX 的银行列表要支持搜索。',
                            '用户跳去银行或钱包后，回到一个会自动刷新的状态页。',
                            '充值或数字商品只在收到验签通过的服务器回调后才发放。',
                        ],
                    },
                    '同时保留国际银行卡，照顾游客和偏好用卡的用户。',
                ],
            },
            {
                id: 'payouts',
                heading: '能在东南亚给用户和合作方付款吗？',
                blocks: [
                    '可以。KaazPay 在马来西亚、泰国、新加坡、印尼、菲律宾支持银行转账代付，在印尼还支持移动钱包代付，可单笔或批量，每笔都有状态通知，适用于玩家提现、主播分成、联盟佣金和退款。运营细节请看[新兴市场批量代付](/guides/mass-payouts-emerging-markets)。',
                    { note: '在 KaazPay，FPX、DuitNow、Touch ’n Go、Thai QR、PayNow、新加坡 QR 扫码、网银 iBanking、QRIS 和 GCash 都是代收方式；代付走银行转账，印尼另有移动钱包。' },
                ],
            },
            {
                id: 'settlement-and-japan',
                heading: '代收资金怎么结算？日本市场呢？',
                blocks: [
                    '用户以林吉特、泰铢、新元、印尼盾或菲律宾比索付款，KaazPay 以等额 USDT 结算给商户。不少通道 D+0 结算，其余 D+1 或更长，上线前逐个确认，详见 [USDT 结算指南](/guides/usdt-settlement)。',
                    '如果业务同时面向日本：JCB 是日本本土卡组织，KaazPay 支持以 JPY 进行 JCB 代收，详见[日本 JCB 收款指南](/guides/japan-jcb-payments)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 开通东南亚收款？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，并提供目标国家和预估交易量。',
                            '获取 API 密钥。',
                            '与 KaazPay 工程师一起接入，并逐一联调各支付方式，详见[开发者页面](/developers)。',
                            '按约定的周期与费率逐个国家上线。',
                        ],
                    },
                    '请通过[联系页面](/contact)在 Telegram 联系我们，我们会在一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '东南亚最重要的支付方式有哪些？', a: '在 KaazPay 覆盖的市场中：马来西亚的 FPX、DuitNow、Touch ’n Go，泰国的 Thai QR Payment 与银行转账，新加坡的 PayNow、QR 扫码与 iBanking，印尼的 QRIS，以及菲律宾的 GCash。' },
            { q: '一次接入能同时支持 FPX、Thai QR、PayNow、QRIS 和 GCash 吗？', a: '可以。KaazPay 通过同一套 API、回调和商户后台提供这些方式。' },
            { q: 'KaazPay 在东南亚支持代付吗？', a: '支持。五个市场均可银行转账代付（泰国和新加坡只支持银行转账），印尼另支持移动钱包代付。' },
            { q: '需要在每个国家开银行账户吗？', a: '收款不需要，代收资金以 USDT 结算给您。具体开户要求由客户经理根据您的业务确认。' },
            { q: '在东南亚还需要收银行卡吗？', a: '需要，用来服务游客和偏好用卡的用户，但在每个国家都应把主流本地方式放在前面。' },
        ],
    },
};
