export default {
    slug: 'chargebacks-vs-local-payments',
    kind: 'compare',
    published: '2026-08-11',
    updated: '2026-08-11',
    related: {
        markets: ['global-cards', 'united-states', 'mexico', 'colombia', 'brazil', 'indonesia', 'kenya'],
        methods: ['visa', 'mastercard', 'apple-pay', 'spei', 'pse', 'pix', 'qris', 'm-pesa', 'mobile-money'],
        industries: ['e-commerce', 'gaming', 'digital-goods'],
        articles: ['local-payment-methods-vs-cards', 'international-card-acquiring', 'mass-payouts-emerging-markets', 'payment-success-rate'],
    },
    en: {
        title: 'Card Chargebacks vs Local Payments: How Disputes Differ',
        description: 'How card chargebacks work compared with push payments such as Pix, SPEI, PSE, QRIS and mobile money, how refunds are made by payout, and what disputes remain.',
        h1: 'Card chargebacks vs local payment methods: how disputes and refunds differ',
        summary: 'A card chargeback lets the cardholder\'s bank pull money back from the merchant under card scheme rules, often weeks or months after the sale. Push payments such as Pix, SPEI, PSE, QRIS and mobile money are approved by the payer in their own app and have no card-style chargeback, but banks, operators and some schemes still have complaint or fraud-return processes, and refunds are usually sent back as a separate payout.',
        queries: [
            'Do Pix and SPEI payments have chargebacks like credit cards?',
            'How do I refund a customer who paid with QRIS or M-Pesa?',
            'Will switching from cards to local payment methods reduce our chargebacks?',
            'What is the difference between a refund and a chargeback?',
            'Can a customer reverse a Pix payment?',
        ],
        takeaways: [
            'A chargeback is started by the cardholder\'s issuer, not by the merchant, and follows card scheme rules and time limits.',
            'Push payments (Pix, SPEI, PSE, Bre-B, QRIS, mobile money, bank transfers) are authorised by the payer in their own app and have no card-scheme chargeback.',
            '"No chargeback" does not mean "no disputes": banks, operators and schemes such as Pix\'s MED have their own complaint or fraud-return routes.',
            'Refunds on push payments are usually a new payout to the customer, which works only where payouts are available.',
            'Card-based wallets such as Apple Pay and Google Pay run on card rails, so card dispute rules generally apply to them.',
        ],
        sections: [
            {
                id: 'what-is-a-chargeback',
                heading: 'What is a card chargeback?',
                blocks: [
                    'A chargeback is a forced reversal of a card payment. The cardholder contacts their issuing bank, the issuer raises a dispute through the card network, and the amount is taken back from the merchant through the acquirer. The merchant can usually respond with evidence (often called representment), and the issuer decides based on the network\'s rules.',
                    'Common grounds are unrecognised or fraudulent transactions, goods or services not received, and items significantly different from what was described. Each card network sets its own reason codes, evidence requirements and deadlines, and the window for raising a dispute can extend to several months after the transaction. Disputes may also carry a fee, and a high dispute ratio can put a merchant into network monitoring programmes.',
                    { note: 'A refund and a chargeback are not the same. A refund is initiated by the merchant. A chargeback is initiated by the cardholder\'s bank, whether or not the merchant agrees.' },
                ],
            },
            {
                id: 'how-push-payments-differ',
                heading: 'How do push payments like Pix, SPEI and QRIS work differently?',
                blocks: [
                    'With a card, the merchant pulls money from the cardholder\'s account using card details. With a push payment, the payer sends the money themselves: they open their banking app or wallet, check the amount and recipient, and approve it, often with a PIN or biometrics. Examples on KaazPay include:',
                    {
                        list: [
                            '**Instant bank payments:** [Pix](/methods/pix) in Brazil, [SPEI](/methods/spei) in Mexico, Bre-B in Colombia, DuitNow in Malaysia.',
                            '**Online banking:** [PSE](/methods/pse) in Colombia, FPX in Malaysia, EFT in South Africa.',
                            '**QR payments:** [QRIS](/methods/qris) in Indonesia, Bre-B QR in Colombia.',
                            '**Mobile money:** [M-Pesa](/methods/m-pesa) in Kenya and [mobile money](/methods/mobile-money) across many African markets.',
                            '**Bank transfers and cash vouchers:** EUR, GBP and AED bank transfer, Boleto, PagoEfectivo and cash payment options.',
                        ],
                    },
                    'Because the payer authorised the transfer directly, these rails have no equivalent of the card network chargeback process. Once a push payment is confirmed, it is generally treated as final from the merchant\'s point of view.',
                ],
            },
            {
                id: 'side-by-side',
                heading: 'Cards vs push payments: how do disputes and refunds compare?',
                blocks: [
                    {
                        table: {
                            head: ['Question', 'Card payments', 'Push payments (Pix, SPEI, PSE, QRIS, mobile money)'],
                            rows: [
                                ['Who authorises the payment?', 'Merchant charges the card using card details', 'Payer approves in their own bank or wallet app'],
                                ['Can the payer\'s bank force a reversal?', 'Yes, through a chargeback under network rules', 'No card-style chargeback; limited fraud or error procedures may exist'],
                                ['Typical dispute window', 'Often weeks to months, set by each network', 'Depends on the bank, operator or scheme; usually narrower in scope'],
                                ['How a refund is made', 'Refund back to the original card', 'A new outbound payment (payout) to the customer'],
                                ['What the merchant needs', 'Evidence for representment, low dispute ratio', 'Customer\'s bank or wallet details for the refund'],
                                ['Main risk left for the merchant', 'Disputes long after delivery', 'Complaints, regulator or bank fraud claims, refunds in pay-in-only markets'],
                            ],
                        },
                    },
                    'For the wider trade-offs beyond disputes, such as reach, conversion and cost, see [local payment methods vs cards](/compare/local-payment-methods-vs-cards).',
                ],
            },
            {
                id: 'disputes-that-remain',
                heading: 'Can customers still dispute a local payment?',
                blocks: [
                    'Yes, through other routes. Switching to local methods does not end disputes; it changes where dissatisfied or defrauded customers go to recover their money:',
                    {
                        list: [
                            '**Pix (Brazil):** the Central Bank of Brazil runs a Special Return Mechanism (MED) that lets banks block and return funds in suspected fraud cases or operational failures, within defined time limits.',
                            '**Bank transfers and instant payments elsewhere:** customers can complain to their bank, and in many countries to a consumer protection body or financial regulator.',
                            '**Mobile money:** operators commonly have a procedure for customers to report a transfer sent in error or by fraud, and may hold or reverse funds under their own rules.',
                            '**Card-based wallets:** Apple Pay and Google Pay use the underlying card, so card dispute rights generally still apply.',
                            '**Directly with you:** customers who do not get what they paid for will contact support, leave reviews or report you to the platform they found you on.',
                        ],
                    },
                    'Rules differ by country and change over time, so treat the above as an overview and check specifics for each market you sell in.',
                ],
            },
            {
                id: 'refunds-by-payout',
                heading: 'How do you refund a customer who paid by Pix, SPEI or mobile money?',
                blocks: [
                    'There is no "refund to source" button on most push rails. Instead, the merchant sends a new payment back. With KaazPay the flow is:',
                    {
                        steps: [
                            'Approve the refund in your support tool and note the original order ID.',
                            'Confirm the customer\'s bank account or mobile money number (ideally in the payer\'s own name).',
                            'Create a payout through the KaazPay API or dashboard, referencing the original order.',
                            'Wait for the payout status notification and mark the order as refunded.',
                        ],
                    },
                    'Refund payouts are possible where KaazPay offers payouts: for example bank transfer in Brazil, Mexico, Colombia, Malaysia and the Philippines, bank transfer or mobile money in Kenya and Indonesia, and USDT anywhere. Several markets, including Chile, Peru, Ecuador and Costa Rica, are pay-in only, so agree how refunds will be handled there before you launch. Running refunds at volume is covered in the [mass payouts guide](/guides/mass-payouts-emerging-markets).',
                ],
            },
            {
                id: 'which-to-offer',
                heading: 'Should you drop cards to avoid chargebacks?',
                blocks: [
                    'Usually not. Cards remain the way many customers prefer to pay, especially in the United States and for international buyers, and dropping them can cost more sales than it saves in disputes. A balanced setup looks like this:',
                    {
                        list: [
                            'Keep Visa, Mastercard and UnionPay worldwide, JCB in Japan, and Apple Pay and Google Pay in the US.',
                            'Add local push methods in markets where they are the everyday way to pay, which also shifts part of your volume off card dispute rails.',
                            'Write clear product descriptions, delivery terms and refund policies, since many disputes start with a mismatch of expectations.',
                            'Refund quickly when a complaint is fair; a fast refund is cheaper than a chargeback or a bank complaint.',
                            'Keep order records, delivery proof and customer messages, whichever method was used.',
                        ],
                    },
                    'How card acquiring works end to end is explained in [international card acquiring](/guides/international-card-acquiring).',
                ],
            },
            {
                id: 'reducing-disputes-checklist',
                heading: 'Checklist: reducing disputes across every payment method',
                blocks: [
                    {
                        list: [
                            'Show a recognisable business name on card statements and payment confirmations.',
                            'Send an order confirmation immediately after the signed payment notification.',
                            'Make support easy to reach, so customers contact you before they contact their bank.',
                            'For digital goods, log delivery (credits granted, items unlocked) with timestamps.',
                            'Verify notifications and credit each order only once, to avoid charging customers for goods they did not receive.',
                            'Review dispute and refund reasons monthly and fix the product or wording behind them.',
                        ],
                    },
                ],
            },
            {
                id: 'get-started-with-kaazpay',
                heading: 'How do you set up cards, local methods and refund payouts with KaazPay?',
                blocks: [
                    'KaazPay offers card acquiring, local pay-in and payouts in one merchant account, with collected funds settled in USDT. Getting started takes four steps:',
                    {
                        steps: [
                            'Open a merchant account and complete the business review.',
                            'Get your API keys from the merchant dashboard.',
                            'Integrate pay-in, notifications and refund payouts with engineer support ([developer docs](/developers)).',
                            'Go live once channels, including payout coverage for refunds, are confirmed per market.',
                        ],
                    },
                    'Tell us your markets and current dispute situation. [Contact us on Telegram](/contact) and we reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'Does Pix have chargebacks?', a: 'Not in the card sense. Pix is a push payment approved by the payer. However, the Central Bank of Brazil\'s Special Return Mechanism (MED) allows funds to be blocked and returned in suspected fraud or operational failure cases.' },
            { q: 'Can a customer reverse an SPEI or PSE payment?', a: 'There is no card-style chargeback, but customers can complain to their bank or local authorities, and banks may act under their own procedures. Rules vary by country.' },
            { q: 'Do Apple Pay and Google Pay have chargebacks?', a: 'Generally yes, because they use the customer\'s underlying card, so card network dispute rules apply.' },
            { q: 'How do I refund a customer who paid with QRIS or mobile money?', a: 'By sending a payout to the customer\'s bank account or mobile money wallet where KaazPay offers payouts in that market, linked to the original order. In pay-in-only markets, agree a refund route before launch.' },
            { q: 'Will moving to local payment methods remove all disputes?', a: 'No. It removes card-network chargebacks on that volume, but complaints, bank fraud claims and refund requests remain. Clear policies and fast refunds are still essential.' },
        ],
    },
    zh: {
        title: '信用卡拒付 vs 本地支付：争议与退款有何不同',
        description: '信用卡拒付（Chargeback）如何运作，与 Pix、SPEI、PSE、QRIS、移动钱包等推式付款有何差异，本地支付如何通过代付退款，以及仍然存在哪些争议途径。',
        h1: '信用卡拒付和本地支付方式，在争议与退款上有什么区别？',
        summary: '信用卡拒付是持卡人的发卡行依照卡组织规则，从商户处强制追回款项，往往发生在交易后数周甚至数月。Pix、SPEI、PSE、QRIS、移动钱包等推式付款由付款人在自己的 App 内确认，没有卡式拒付；但银行、运营商和部分支付体系仍设有投诉或欺诈退回机制，退款通常需另行发起一笔代付。',
        queries: [
            'Pix 和 SPEI 付款会像信用卡一样被拒付吗？',
            '客户用 QRIS 或 M-Pesa 付款，如何退款？',
            '从信用卡改成本地支付，拒付会不会减少？',
            '退款和拒付有什么区别？',
            'Pix 付款能被撤回吗？',
        ],
        takeaways: [
            '拒付由持卡人的发卡行发起，而不是商户，遵循卡组织的规则和时限。',
            'Pix、SPEI、PSE、Bre-B、QRIS、移动钱包、银行转账等推式付款由付款人在自己的 App 授权，没有卡组织式拒付。',
            '“没有拒付”不等于“没有争议”：银行、运营商以及 Pix 的 MED 等机制，都有各自的投诉或欺诈退回途径。',
            '推式付款的退款，通常是另发一笔代付给客户，前提是该市场支持代付。',
            'Apple Pay、Google Pay 等卡类钱包底层走的是银行卡，一般仍适用卡争议规则。',
        ],
        sections: [
            {
                id: 'what-is-a-chargeback',
                heading: '什么是信用卡拒付？',
                blocks: [
                    '拒付（Chargeback）是对一笔卡交易的强制撤回。持卡人联系发卡行，发卡行通过卡组织发起争议，款项经收单方从商户处扣回。商户通常可以提交证据申诉（常称为 representment），最终由发卡行依据卡组织规则判定。',
                    '常见理由包括：持卡人不认识或被盗刷的交易、未收到商品或服务、商品与描述严重不符。各卡组织有各自的理由代码、举证要求和时限，发起争议的期限可能长达交易后数月。拒付还可能产生费用，拒付率过高的商户可能被纳入卡组织的监控计划。',
                    { note: '退款和拒付不是一回事。退款由商户主动发起；拒付由持卡人的银行发起，不论商户是否同意。' },
                ],
            },
            {
                id: 'how-push-payments-differ',
                heading: 'Pix、SPEI、QRIS 等推式付款有什么不同？',
                blocks: [
                    '信用卡是商户凭卡信息从持卡人账户“拉”款；推式付款则由付款人主动将款项“推”给商户：打开银行 App 或钱包，核对金额和收款方，再用密码或生物识别确认。KaazPay 支持的推式付款包括：',
                    {
                        list: [
                            '**实时银行支付**：巴西 [Pix](/methods/pix)、墨西哥 [SPEI](/methods/spei)、哥伦比亚 Bre-B、马来西亚 DuitNow。',
                            '**网银支付**：哥伦比亚 [PSE](/methods/pse)、马来西亚 FPX、南非 EFT。',
                            '**扫码支付**：印度尼西亚 [QRIS](/methods/qris)、哥伦比亚 Bre-B 扫码。',
                            '**移动钱包**：肯尼亚 [M-Pesa](/methods/m-pesa)，以及非洲多国的[移动钱包](/methods/mobile-money)。',
                            '**银行转账与现金凭证**：EUR、GBP、AED 银行转账，Boleto、PagoEfectivo 及各类现金支付。',
                        ],
                    },
                    '由于是付款人直接授权转账，这些通道没有类似卡组织拒付的流程。推式付款一旦确认，从商户角度通常视为最终完成。',
                ],
            },
            {
                id: 'side-by-side',
                heading: '信用卡与推式付款：争议和退款对比',
                blocks: [
                    {
                        table: {
                            head: ['对比项', '信用卡', '推式付款（Pix、SPEI、PSE、QRIS、移动钱包）'],
                            rows: [
                                ['谁授权付款？', '商户凭卡信息扣款', '付款人在自己的银行或钱包 App 确认'],
                                ['付款方银行能否强制撤回？', '能，通过卡组织拒付', '没有卡式拒付，可能有有限的欺诈或差错处理'],
                                ['争议期限', '通常数周到数月，由各卡组织规定', '视银行、运营商或支付体系而定，适用范围一般较窄'],
                                ['退款方式', '原路退回到卡上', '另发一笔代付给客户'],
                                ['商户需要准备', '申诉证据、控制拒付率', '客户的银行或钱包信息，用于退款'],
                                ['商户剩余风险', '交付很久之后仍可能被拒付', '投诉、监管或银行欺诈申诉、仅代收市场的退款'],
                            ],
                        },
                    },
                    '覆盖率、转化率、成本等更多方面的取舍，见[本地支付 vs 信用卡](/compare/local-payment-methods-vs-cards)。',
                ],
            },
            {
                id: 'disputes-that-remain',
                heading: '客户还能对本地支付提出争议吗？',
                blocks: [
                    '能，只是途径不同。改用本地支付并不会消除争议，变化的是不满意或受骗的客户追回款项的途径：',
                    {
                        list: [
                            '**Pix（巴西）**：巴西央行设有特别退回机制（MED），银行可在疑似欺诈或操作失误时，在规定时限内冻结并退回资金。',
                            '**其他国家的银行转账与实时支付**：客户可向自己的银行投诉，很多国家还可向消费者保护机构或金融监管部门投诉。',
                            '**移动钱包**：运营商一般设有误转或被骗转账的申报流程，可能依其规则冻结或撤回资金。',
                            '**卡类钱包**：Apple Pay、Google Pay 使用底层银行卡，一般仍享有卡争议权利。',
                            '**直接联系商户**：未收到所购商品或服务的客户会联系客服、留下差评，或向其发现您的平台投诉。',
                        ],
                    },
                    '各国规则不同且会调整，以上仅为概览，请按您销售的每个市场核实细节。',
                ],
            },
            {
                id: 'refunds-by-payout',
                heading: '客户用 Pix、SPEI 或移动钱包付款，如何退款？',
                blocks: [
                    '大多数推式通道没有“原路退回”功能，商户需另行发起一笔付款。通过 KaazPay 的流程是：',
                    {
                        steps: [
                            '在客服系统批准退款，记录原订单号。',
                            '确认客户的银行账户或移动钱包号码（最好是付款人本人名下）。',
                            '通过 KaazPay API 或后台发起代付，关联原订单。',
                            '收到代付状态通知后，将订单标记为已退款。',
                        ],
                    },
                    '只有 KaazPay 支持代付的市场才能这样退款，例如巴西、墨西哥、哥伦比亚、马来西亚、菲律宾支持银行转账，肯尼亚、印度尼西亚支持银行转账或移动钱包，USDT 全球可用。智利、秘鲁、厄瓜多尔、哥斯达黎加等市场仅支持代收，上线前应先约定退款方式。大批量退款见[批量代付指南](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'which-to-offer',
                heading: '为了避免拒付，是否应停用信用卡？',
                blocks: [
                    '通常不建议。很多客户仍偏好刷卡，尤其是美国和跨境买家，停用信用卡造成的销售损失，往往大于减少的拒付损失。比较均衡的做法是：',
                    {
                        list: [
                            '保留全球 Visa、Mastercard、银联，日本 JCB，以及美国 Apple Pay、Google Pay。',
                            '在本地支付是日常主流的市场加上推式付款，同时也让一部分交易量离开卡争议体系。',
                            '写清商品描述、交付条款和退款政策，很多争议都源于预期不一致。',
                            '投诉合理时尽快退款，快速退款的成本低于拒付或银行投诉。',
                            '无论用哪种支付方式，都保存订单记录、交付证明和客户沟通记录。',
                        ],
                    },
                    '卡收单的完整流程见[国际信用卡收单详解](/guides/international-card-acquiring)。',
                ],
            },
            {
                id: 'reducing-disputes-checklist',
                heading: '清单：如何在所有支付方式上减少争议',
                blocks: [
                    {
                        list: [
                            '在账单和付款确认中显示客户认得出的商户名称。',
                            '收到签名付款通知后立刻发送订单确认。',
                            '确保客服易于联系，让客户先联系商户，而不是银行。',
                            '数字商品要记录交付（点数发放、内容解锁）及时间。',
                            '校验通知并确保每笔订单只入账一次，避免客户付了钱却没收到东西。',
                            '每月复盘争议和退款原因，从产品或文案上解决根源。',
                        ],
                    },
                ],
            },
            {
                id: 'get-started-with-kaazpay',
                heading: '如何通过 KaazPay 同时接入信用卡、本地支付和退款代付？',
                blocks: [
                    'KaazPay 在同一商户账户中提供卡收单、本地代收和代付，代收资金以 USDT 结算。接入分为四步：',
                    {
                        steps: [
                            '开通商户账户并完成业务审核。',
                            '在商户后台获取 API 密钥。',
                            '在工程师协助下对接代收、回调通知和退款代付（见[开发文档](/developers)）。',
                            '按市场确认通道（包括退款所需的代付覆盖）后上线。',
                        ],
                    },
                    '请告知您的市场和目前的争议情况。[通过 Telegram 联系我们](/contact)，我们会在一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: 'Pix 会被拒付吗？', a: '没有信用卡意义上的拒付，Pix 是付款人自行确认的推式付款。但巴西央行的特别退回机制（MED）允许在疑似欺诈或操作失误时冻结并退回资金。' },
            { q: 'SPEI 或 PSE 付款能被客户撤回吗？', a: '没有卡式拒付，但客户可向银行或当地主管机构投诉，银行也可能按自身流程处理。各国规则不同。' },
            { q: 'Apple Pay 和 Google Pay 会有拒付吗？', a: '一般会，因为它们使用客户的底层银行卡，适用卡组织的争议规则。' },
            { q: '客户用 QRIS 或移动钱包付款，怎么退款？', a: '在 KaazPay 支持代付的市场，向客户的银行账户或移动钱包发起代付，并关联原订单。仅代收的市场需在上线前约定退款方式。' },
            { q: '改用本地支付就不会再有任何争议了吗？', a: '不会。这部分交易不再有卡组织拒付，但投诉、银行欺诈申诉和退款请求依然存在，清楚的政策和快速退款仍然必不可少。' },
        ],
    },
};
