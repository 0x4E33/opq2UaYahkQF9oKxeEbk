export default {
    slug: 'pix-vs-boleto',
    kind: 'compare',
    published: '2025-07-15',
    updated: '2025-07-15',
    related: { markets: ['brazil'], methods: ['pix', 'boleto'], industries: ['digital-goods', 'e-commerce', 'education'], articles: ['brazil-payment-methods', 'instant-payments-vs-bank-transfer', 'local-payment-methods-vs-cards', 'payment-success-rate'] },
    en: {
        title: 'Pix vs Boleto: Speed, Conversion and Best Use Cases',
        description: 'Pix vs Boleto for merchants selling in Brazil: how each payment works, when you can fulfil, how to handle unpaid vouchers, and which business fits each method.',
        h1: 'Pix vs Boleto: which payment method should you offer in Brazil?',
        summary: "Pix is an instant payment approved in the customer's banking app, so the merchant knows within seconds that the order is paid. Boleto is a barcode voucher the customer pays later in online banking, at a bank branch or at a lottery outlet, so confirmation waits until they do. Lead with Pix and keep Boleto for shoppers who prefer to pay later; KaazPay offers both through one integration.",
        queries: [
            'Pix or Boleto: which one should I use for my online store in Brazil?',
            'Is Boleto still worth offering now that Pix exists?',
            'How do I deal with Boleto orders that customers never pay?',
            'Which Brazilian payment method is better for game top-ups and digital products?',
        ],
        takeaways: [
            'Pix gives you a paid order within seconds; Boleto gives you a pending order that completes only when the voucher is paid.',
            'Instant-delivery businesses (top-ups, credits, downloads) should lead with Pix.',
            'Boleto still serves customers who want to choose when or where they pay, so removing it can lose sales.',
            'Track completion rate and time-to-pay per method on your own traffic before changing the mix.',
            'KaazPay supports both, plus Brazil Bank Transfer and Brazil Cash Payment; payouts in Brazil go to bank accounts.',
        ],
        sections: [
            { id: 'pix-or-boleto-verdict', heading: 'Pix or Boleto: which should lead your Brazil checkout?', blocks: [
                "For most merchants, **Pix** should sit at the top of the payment list and **Boleto** directly beneath it. Pix closes the sale while the customer is still on your page. Boleto serves customers who are not ready, or not willing, to pay instantly.",
                "The right balance depends on what you sell. If the customer expects their item the moment they pay, Boleto's waiting period is a significant cost. If you ship physical goods or run enrolment for a course that starts next month, a few days between ordering and paying matters much less.",
            ] },
            { id: 'pix-boleto-side-by-side', heading: 'How do Pix and Boleto differ side by side?', blocks: [
                { table: { head: ['Factor', 'Pix', 'Boleto'], rows: [
                    ['What it is', 'Instant payment system run by the Central Bank of Brazil', 'Bank payment voucher with a barcode (Boleto Bancário)'],
                    ['Where the customer pays', 'Inside their banking app, by QR code or copy-and-paste code', 'Online banking, a bank branch or a lottery outlet'],
                    ['When you know it is paid', 'Seconds after approval, 24/7', 'After the voucher is paid and the payment is confirmed'],
                    ['Order state right after checkout', 'Usually paid', 'Pending'],
                    ['Main leakage point', 'Customer leaves before approving in the app', 'Voucher issued but never paid'],
                    ['Fit for instant digital delivery', 'Strong', 'Weak'],
                    ['Payouts through KaazPay', 'No, payouts go to bank accounts', 'No, payouts go to bank accounts'],
                ] } },
            ] },
            { id: 'customer-journey', heading: 'What does each payment look like for the customer?', blocks: [
                '**Paying with Pix**',
                { steps: [
                    'Choose Pix at checkout.',
                    'Copy the payment code (on mobile) or scan the QR code (on desktop).',
                    'Approve in the banking app; the order page updates to paid.',
                ] },
                '**Paying with Boleto**',
                { steps: [
                    'Choose Boleto at checkout and receive the voucher.',
                    'Leave the store, often with the voucher saved or emailed.',
                    'Pay it later in online banking, at a bank branch or at a lottery outlet before the due date.',
                    'Wait for the merchant to confirm the order once the payment is recognised.',
                ] },
                'The Pix journey is short and completed in one session. The Boleto journey has a gap between ordering and paying, during which the customer may change their mind or forget.',
            ] },
            { id: 'handling-pending-boleto', heading: 'How should your system handle pending Boleto orders?', blocks: [
                'Treat a Boleto order as pending, not as a completed sale. The following practices matter most:',
                { list: [
                    'Store the order as pending with the voucher due date, and only move it to paid when KaazPay notifies you.',
                    'Make notification handling idempotent, so a repeated notification never delivers twice.',
                    'Hold limited stock or seats only until the due date, then release them automatically.',
                    'Send the customer the voucher again, with the amount and due date, shortly before it expires.',
                    'Report Boleto separately so unpaid vouchers do not distort your overall conversion numbers.',
                ] },
            ] },
            { id: 'pix-vs-boleto-by-business', heading: 'Which method fits your type of business?', blocks: [
                { table: { head: ['Business', 'Lead with', 'Also offer', 'Why'], rows: [
                    ['Game top-ups and in-app credits', 'Pix', 'Brazil Bank Transfer', 'Players expect credits immediately'],
                    ['Live-streaming coins and gifts', 'Pix', 'Boleto for larger packs', 'Viewers buy in the moment'],
                    ['Physical e-commerce', 'Pix', 'Boleto, Brazil Cash Payment', 'Shipping time absorbs the Boleto wait'],
                    ['Online courses and education', 'Pix', 'Boleto', 'Some learners plan payment around payday'],
                    ['High-value one-off orders', 'Pix or Brazil Bank Transfer', 'Boleto', 'Customers like paying larger sums from their own account'],
                ] } },
                'These are starting points, not rules. Your customers may behave differently, so verify with your own data.',
            ] },
            { id: 'measure-pix-and-boleto', heading: 'How do you measure Pix vs Boleto on your own traffic?', blocks: [
                'Before removing or demoting a method, review what it contributes. Metrics to track per method:',
                { list: [
                    '**Completion rate**: paid orders divided by orders where the customer chose that method.',
                    '**Time to pay**: how long it takes from order creation to confirmed payment.',
                    '**Expiry share**: for Boleto, the part of vouchers that pass the due date unpaid.',
                    '**Incremental customers**: buyers who used Boleto and have never paid with Pix on your site.',
                ] },
                { note: 'If a meaningful group of your customers only ever pays by Boleto, removing it does not move them to Pix; it is more likely to lose them.' },
            ] },
            { id: 'transfer-and-cash-in-brazil', heading: 'Where do Brazil Bank Transfer and Brazil Cash Payment fit?', blocks: [
                '**Brazil Bank Transfer** suits customers who want to pay from their own account, especially for larger amounts. **Brazil Cash Payment** lets shoppers without a card or banking app complete an online order by paying in person, with the order confirmed after the payment is reported.',
                'Both sit alongside Pix and Boleto rather than replacing them, and every live channel is listed on the [Brazil market page](/payment-methods/brazil). For the complete Brazil picture, including payouts and settlement, read the [Brazil payment methods guide](/guides/brazil-payment-methods).',
            ] },
            { id: 'offer-pix-and-boleto-with-kaazpay', heading: 'How do you offer Pix and Boleto with KaazPay?', blocks: [
                { steps: [
                    'Open a KaazPay merchant account and share your Brazil volumes and product type.',
                    'Get API keys from the merchant dashboard.',
                    'Integrate [Pix](/methods/pix), [Boleto](/methods/boleto) and any other Brazil methods with help from our engineers and the [developer documentation](/developers).',
                    'Go live, then compare completion by method using your own order data.',
                ] },
                'Collections are settled to you in USDT, and the cycle for each channel is confirmed before launch. For how local methods compare with cards in markets like Brazil, read [local payment methods vs cards](/compare/local-payment-methods-vs-cards). For questions, [message our team on Telegram](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Has Pix replaced Boleto in Brazil?', a: 'Pix is now the most used payment method in Brazil, but Boleto is still used by people who want to pay later or at a bank branch or lottery outlet. Many merchants keep both.' },
            { q: 'How quickly is a Boleto confirmed?', a: 'Only after the customer pays the voucher and the payment is recognised, which is much slower than Pix. Pix is confirmed within seconds, at any hour.' },
            { q: 'Can one integration handle both Pix and Boleto?', a: 'Yes. With KaazPay you get Pix, Boleto, Brazil Bank Transfer and Brazil Cash Payment through one API and one merchant account.' },
            { q: 'Can I pay people out through Pix or Boleto with KaazPay?', a: 'No. On KaazPay both are pay-in methods. Payouts in Brazil are sent to recipient bank accounts.' },
            { q: 'Which is better for selling digital products?', a: 'Pix, in most cases, because you can deliver as soon as the payment is confirmed seconds after the customer approves it.' },
        ],
    },
    zh: {
        title: 'Pix 与 Boleto 对比：到账速度、转化与适用场景',
        description: 'Pix 和 Boleto 怎么选？从付款流程、何时可以发货、未付凭证如何处理到不同业务类型的搭配，帮助在巴西收款的商户做出决定。',
        h1: 'Pix 和 Boleto，巴西收款应该选哪个？',
        summary: 'Pix 是在银行 App 中确认的即时支付，商户几秒内就知道订单已付款；Boleto 是带条形码的付款凭证，用户之后才通过网银、银行网点或彩票站支付，确认要等到用户付款之后。建议以 Pix 为主，为想稍后付款的用户保留 Boleto。KaazPay 一次对接即可同时支持两者。',
        queries: [
            '巴西独立站应该用 Pix 还是 Boleto？',
            '有了 Pix，还有必要接 Boleto 吗？',
            'Boleto 订单用户一直不付款怎么办？',
            '游戏充值和数字商品在巴西用哪种支付方式更好？',
        ],
        takeaways: [
            'Pix 下单后几秒就是已付款订单；Boleto 下单后是待支付订单，凭证付清才算完成。',
            '充值、点券、下载等即时交付业务应以 Pix 为主。',
            'Boleto 仍能服务想自行决定付款时间和地点的用户，贸然下线可能造成订单流失。',
            '调整支付方式之前，先在自己的流量上统计各方式的完成率和付款耗时。',
            'KaazPay 同时支持 Pix、Boleto、巴西银行转账和巴西现金支付；巴西代付打款至银行账户。',
        ],
        sections: [
            { id: 'pix-or-boleto-verdict', heading: 'Pix 和 Boleto，收银台应该以哪个为主？', blocks: [
                '对大多数商户来说，**Pix** 应放在支付列表第一位，**Boleto** 紧随其后。Pix 在用户还停留在页面上时就完成交易；Boleto 则服务暂时不准备、或不愿意立即付款的用户。',
                '具体如何搭配，取决于所售商品。如果用户付款后期望立即拿到商品，Boleto 的等待期就是明显的成本；如果您卖的是需要配送的实物，或是下个月才开课的课程，下单与付款之间隔几天影响就小得多。',
            ] },
            { id: 'pix-boleto-side-by-side', heading: 'Pix 和 Boleto 逐项对比', blocks: [
                { table: { head: ['对比项', 'Pix', 'Boleto'], rows: [
                    ['是什么', '巴西央行运营的即时支付系统', '带条形码的银行付款凭证（Boleto Bancário）'],
                    ['用户在哪里付款', '在银行 App 中扫码或粘贴付款码', '网银、银行网点或彩票站'],
                    ['商户何时知道已付款', '确认后几秒，7×24 小时', '凭证付款并被确认之后'],
                    ['下单后的订单状态', '通常已付款', '待支付'],
                    ['主要流失环节', '用户未在 App 中确认就离开', '凭证开出后一直未付'],
                    ['是否适合即时数字交付', '非常适合', '不太适合'],
                    ['能否通过 KaazPay 代付', '否，代付打款至银行账户', '否，代付打款至银行账户'],
                ] } },
            ] },
            { id: 'customer-journey', heading: '用户用两种方式付款，体验有什么不同？', blocks: [
                '**用 Pix 付款**',
                { steps: [
                    '在收银台选择 Pix。',
                    '手机上复制付款码，电脑上用手机扫二维码。',
                    '在银行 App 中确认，订单页随即变为已付款。',
                ] },
                '**用 Boleto 付款**',
                { steps: [
                    '在收银台选择 Boleto，拿到凭证。',
                    '离开商店，凭证通常保存在手机里或发到邮箱。',
                    '在截止日前通过网银、银行网点或彩票站付款。',
                    '等商户识别到付款后确认订单。',
                ] },
                'Pix 的流程短，一次会话即可完成；Boleto 在下单与付款之间存在间隔，用户可能在此期间改变主意或忘记付款。',
            ] },
            { id: 'handling-pending-boleto', heading: '系统应该如何处理待支付的 Boleto 订单？', blocks: [
                '应把 Boleto 订单视为待支付，而不是已成交。以下几点最为关键：',
                { list: [
                    '订单以待支付状态保存，并记录凭证截止日期；只有收到 KaazPay 通知后才改为已付款。',
                    '通知处理要幂等，重复通知也不会重复发货。',
                    '限量库存或名额只保留到截止日，到期后自动释放。',
                    '凭证快到期时，把金额、截止日期连同凭证再发给用户一次。',
                    '在报表中单独统计 Boleto，避免未付凭证拉低整体转化数据。',
                ] },
            ] },
            { id: 'pix-vs-boleto-by-business', heading: '不同业务类型适合哪种方式？', blocks: [
                { table: { head: ['业务类型', '主推', '同时提供', '原因'], rows: [
                    ['游戏充值与应用内点券', 'Pix', '巴西银行转账', '玩家希望立刻到账'],
                    ['直播金币与礼物', 'Pix', '大额礼包可加 Boleto', '观众多为即兴消费'],
                    ['实物电商', 'Pix', 'Boleto、巴西现金支付', '配送周期可以消化 Boleto 的等待'],
                    ['在线课程与教育', 'Pix', 'Boleto', '部分学员会按发薪日安排付款'],
                    ['大额单笔订单', 'Pix 或巴西银行转账', 'Boleto', '用户更愿意从本人账户支付大额款项'],
                ] } },
                '以上只是参考起点，并非定律。您的用户可能有不同表现，应以自身数据验证。',
            ] },
            { id: 'measure-pix-and-boleto', heading: '如何在自己的流量上衡量 Pix 和 Boleto？', blocks: [
                '在下线或降级某种支付方式之前，应先评估它的实际贡献。建议按支付方式分别统计：',
                { list: [
                    '**完成率**：已付款订单数 ÷ 选择该方式的订单数。',
                    '**付款耗时**：从创建订单到确认收款所用的时间。',
                    '**过期比例**：Boleto 凭证中超过截止日仍未付款的部分。',
                    '**增量用户**：用过 Boleto、但从未在您网站上用 Pix 付款的买家。',
                ] },
                { note: '如果有相当一部分用户只用 Boleto 付款，下线 Boleto 并不会让他们改用 Pix，反而更可能流失这部分用户。' },
            ] },
            { id: 'transfer-and-cash-in-brazil', heading: '巴西银行转账和巴西现金支付放在哪里？', blocks: [
                '**巴西银行转账**适合想从本人账户付款的用户，尤其是金额较大时；**巴西现金支付**让没有银行卡或银行 App 的用户也能线下付款完成网购，付款回传后订单即确认。',
                '两者是 Pix 与 Boleto 的补充，而不是替代，所有在线通道见[巴西市场页面](/payment-methods/brazil)。想全面了解巴西市场（含代付与结算），请阅读[巴西支付方式指南](/guides/brazil-payment-methods)。',
            ] },
            { id: 'offer-pix-and-boleto-with-kaazpay', heading: '如何通过 KaazPay 同时上线 Pix 和 Boleto？', blocks: [
                { steps: [
                    '开设 KaazPay 商户账户，告诉我们您在巴西的交易量和业务类型。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下接入 [Pix](/methods/pix)、[Boleto](/methods/boleto) 及其他巴西支付方式。',
                    '正式上线，并用自己的订单数据按支付方式对比完成率。',
                ] },
                '代收资金以 USDT 结算，各通道结算周期在上线前确认。本地支付方式与信用卡在巴西等市场的比较，请参阅[本地支付方式与信用卡对比](/compare/local-payment-methods-vs-cards)。如有疑问，请[通过 Telegram 联系我们](/contact)，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'Pix 已经取代 Boleto 了吗？', a: 'Pix 已是巴西使用最广泛的支付方式，但想稍后付款、或习惯到银行网点和彩票站付款的人仍在用 Boleto，很多商户两者都保留。' },
            { q: 'Boleto 多久能确认？', a: '要等用户付清凭证、付款被识别之后才能确认，比 Pix 慢得多；Pix 全天候几秒内即可确认。' },
            { q: '一次对接能同时支持 Pix 和 Boleto 吗？', a: '可以。通过 KaazPay，一套 API、一个商户账户即可开通 Pix、Boleto、巴西银行转账和巴西现金支付。' },
            { q: '能通过 KaazPay 用 Pix 或 Boleto 代付吗？', a: '不能。在 KaazPay 上两者都是代收方式，巴西代付打款至收款人银行账户。' },
            { q: '卖数字商品哪个更好？', a: '大多数情况下是 Pix，因为用户确认后几秒就能确认收款，您可以立即交付。' },
        ],
    },
};
