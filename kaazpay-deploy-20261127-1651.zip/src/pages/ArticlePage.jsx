import { use, useEffect, useMemo, useState } from 'react';
import { m, useScroll, useSpring } from 'framer-motion';
import { useParams } from 'react-router-dom';
import { ArrowUpRight, ArrowRight, ChevronRight, ChevronDown, Clock, CalendarDays, Sparkles, CheckCircle2, BookOpen, Scale, MessageCircleQuestion } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate } from '../components/LocaleLink';
import { Block } from '../components/RichText';
import FaqList from '../components/FaqList';
import { Flag, MethodIcon } from '../components/coverage/shared';
import { getMarket, marketName } from '../data/channels';
import { getMethod, methodChannel, methodName } from '../data/methods';
import { getIndustry } from '../data/industries';
import { ARTICLES, KINDS, getArticle, loadArticle, readMinutes } from '../content';
import ArticleCard from '../components/ArticleCard';
import { autolinkArticle } from '../content/autolink';
import { TG_CHANNEL, tgUrl } from '../data/contact';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { articleCover, articleCoverSrcSet, articleCoverAttribution, articleTopic, topicName } from '../content/covers';

// KaazPay's channel priority: US → cards → Europe & Middle East → Japan → Mexico → Colombia → Brazil &
// rest of Latin America → Southeast Asia → Africa → USDT.
const MARKET_RANK = { 'united-states': 0, 'global-cards': 1, eurozone: 2, 'united-kingdom': 3, 'united-arab-emirates': 4, japan: 5, mexico: 6, colombia: 7, brazil: 8 };
const REGION_RANK = { americas: 9, apac: 10, africa: 11, global: 12 };
const marketRank = (m) => MARKET_RANK[m.slug] ?? REGION_RANK[m.region] ?? 13;

/** Thin progress bar under the header while reading. */
const ReadingProgress = ({ label }) => {
    const { scrollYProgress } = useScroll();
    const scaleX = useSpring(scrollYProgress, { stiffness: 160, damping: 30, restDelta: 0.001 });
    return <m.div role="progressbar" aria-label={label} className="fixed inset-x-0 top-20 z-40 h-[3px] origin-left bg-gradient-to-r from-[#FBB383] via-primary to-[#F07A30]" style={{ scaleX }} />;
};

/** Contents list that highlights the section being read. */
const Toc = ({ sections, title }) => {
    const [active, setActive] = useState(sections[0]?.id);
    useEffect(() => {
        const io = new IntersectionObserver((entries) => {
            const hit = entries.filter((e) => e.isIntersecting).sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
            if (hit) setActive(hit.target.id);
        }, { rootMargin: '-20% 0px -65% 0px' });
        sections.forEach(({ id }) => { const el = document.getElementById(id); if (el) io.observe(el); });
        return () => io.disconnect();
    }, [sections]);
    return (
        <nav aria-labelledby="toc-title" className="rounded-2xl border border-white/[0.07] bg-surface/70 p-5 backdrop-blur-md max-lg:hidden">
            <h2 id="toc-title" className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{title}</h2>
            <ol className="mt-4 space-y-1 border-l border-white/[0.08] text-sm">
                {sections.map((s, i) => (
                    <li key={s.id}>
                        <a href={`#${s.id}`} aria-current={active === s.id ? 'true' : undefined}
                            className={`-ml-px flex gap-2.5 border-l-2 py-1.5 pl-3 leading-snug transition-colors ${active === s.id ? 'border-primary text-white' : 'border-transparent text-text-muted hover:text-text-heading'}`}>
                            <span className={`font-mono text-[11px] ${active === s.id ? 'text-primary' : 'text-text-muted/70'}`}>{String(i + 1).padStart(2, '0')}</span>
                            <span>{s.heading}</span>
                        </a>
                    </li>
                ))}
            </ol>
        </nav>
    );
};

const formatDate = (iso, lang) => {
    try {
        return new Intl.DateTimeFormat(lang?.startsWith('zh') ? 'zh-CN' : 'en-GB', { year: 'numeric', month: 'long', day: 'numeric' }).format(new Date(`${iso}T00:00:00Z`));
    } catch {
        return iso;
    }
};

/** /guides/:slug and /compare/:slug — one long-form article. */
const ArticlePage = ({ kind }) => {
    const { slug } = useParams();
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const article = getArticle(kind, slug);
    if (!article) return <Navigate to={KINDS[kind].path} replace />;
    return <ArticleBody article={article} kind={kind} lang={lang} t={t} />;
};

/** Suspends until the article's own chunk is loaded (already inlined in the prerendered HTML). */
const ArticleBody = ({ article, kind, lang, t }) => {
    const full = use(loadArticle(article.slug));
    const langKey = lang?.startsWith('zh') ? 'zh' : 'en';
    // first mention of each payment method links to its page (same rule in every article)
    const c = useMemo(() => autolinkArticle(full[langKey]), [full, langKey]);
    const zh = lang?.startsWith('zh');
    const KindIcon = kind === 'compare' ? Scale : BookOpen;
    const rel = article.related || {};
    // Sidebar order: cross-region articles follow KaazPay's channel priority; single-region articles
    // (e.g. Southeast Asia + Japan, all Asia Pacific) keep the article's own order.
    const listed = (rel.markets || []).map(getMarket).filter(Boolean);
    const singleRegion = new Set(listed.filter((m) => m.region !== 'global').map((m) => m.region)).size <= 1;
    const markets = singleRegion ? listed : [...listed].sort((a, b) => marketRank(a) - marketRank(b));
    const methods = (rel.methods || []).map(getMethod).filter(Boolean);
    const industries = (rel.industries || []).map(getIndustry).filter(Boolean);
    const more = [
        ...(rel.articles || []).map((s) => ARTICLES.find((a) => a.slug === s)).filter(Boolean),
        ...ARTICLES.filter((a) => a.slug !== article.slug && !(rel.articles || []).includes(a.slug) && a.kind === article.kind),
    ].slice(0, 4);

    return (
        <div className="relative -mt-20 overflow-hidden pt-20">
            <ReadingProgress label={t('articles.progress')} />
            <PhotoBackdrop src={articleCover(article.slug)} srcSet={articleCoverSrcSet(article.slug)} side="right" height={720} strength={0.34} caption={articleCoverAttribution(article.slug)} />
            <article className="container relative mx-auto px-5 pb-24 pt-10 md:pt-14">
                <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                    <Link to="/" className="hover:text-white">KaazPay</Link>
                    <ChevronRight size={14} />
                    <Link to={KINDS[kind].path} className="hover:text-white">{KINDS[kind][zh ? 'zh' : 'en']}</Link>
                    <ChevronRight size={14} className="max-sm:hidden" />
                    <span className="line-clamp-1 text-text-body max-sm:hidden" aria-current="page">{c.h1}</span>
                </nav>

                <header className="max-w-3xl lg:min-h-[300px] lg:pt-6">
                    <div className="animate-rise flex flex-wrap items-center gap-2">
                        <span className="eyebrow"><KindIcon size={13} /> {KINDS[kind][zh ? 'zh' : 'en']}</span>
                        <span className="rounded-full border border-white/10 bg-background/50 px-3 py-1 text-xs font-medium text-text-heading backdrop-blur-md">{topicName(articleTopic(article.slug), lang)}</span>
                    </div>
                    <h1 style={{ animationDelay: '50ms' }} className="animate-rise mt-6 text-3xl font-bold leading-[1.1] text-white md:text-[3.25rem]">{c.h1}</h1>
                    <p style={{ animationDelay: '100ms' }} className="animate-rise mt-5 flex flex-wrap items-center gap-x-5 gap-y-1 text-sm text-text-muted">
                        <span className="inline-flex items-center gap-1.5"><CalendarDays size={14} /> {t('articles.published')} <time dateTime={article.published}>{formatDate(article.published, lang)}</time></span>
                        {article.updated && article.updated !== article.published && (
                            <span className="inline-flex items-center gap-1.5">{t('articles.updated')} <time dateTime={article.updated}>{formatDate(article.updated, lang)}</time></span>
                        )}
                        <span className="inline-flex items-center gap-1.5"><Clock size={14} /> {t('articles.readTime', { count: readMinutes(article, lang) })}</span>
                        <span>{t('articles.by')}</span>
                    </p>
                </header>

                <div className="mt-10 grid gap-12 lg:grid-cols-[minmax(0,1fr)_280px] lg:gap-16">
                    <div className="min-w-0 max-w-3xl">
                        {/* Answer first: the passage search snippets and AI answers quote */}
                        <section aria-labelledby="summary-title" className="border-conic rounded-3xl">
                            <div className="rounded-3xl bg-gradient-to-b from-surface-2 to-surface p-6 md:p-7">
                                <h2 id="summary-title" className="flex items-center gap-2 text-sm font-semibold uppercase tracking-[0.14em] text-primary"><Sparkles size={15} /> {t('articles.summary')}</h2>
                                <p className="mt-3 text-lg leading-relaxed text-text-heading">{c.summary}</p>
                                {c.takeaways?.length > 0 && (
                                    <>
                                        <h3 className="mt-6 text-sm font-semibold text-white">{t('articles.takeaways')}</h3>
                                        <ul className="mt-3 space-y-2">
                                            {c.takeaways.map((k) => (
                                                <li key={k} className="flex gap-2.5 text-text-body"><CheckCircle2 size={17} className="mt-0.5 shrink-0 text-payout" /><span>{k}</span></li>
                                            ))}
                                        </ul>
                                    </>
                                )}
                            </div>
                        </section>

                        <details className="group mt-6 rounded-2xl border border-white/[0.07] bg-surface/60 lg:hidden">
                            <summary className="flex cursor-pointer list-none items-center justify-between px-5 py-4 text-sm font-semibold text-white [&::-webkit-details-marker]:hidden">
                                {t('articles.contents')}
                                <ChevronDown size={16} className="text-text-muted transition-transform duration-200 group-open:rotate-180" />
                            </summary>
                            <ol className="space-y-1 border-t border-white/[0.06] px-5 py-3 text-sm">
                                {c.sections.map((s, i) => (
                                    <li key={s.id}>
                                        <a href={`#${s.id}`} className="flex gap-2.5 py-1.5 leading-snug text-text-body hover:text-primary">
                                            <span className="font-mono text-[11px] text-primary/80">{String(i + 1).padStart(2, '0')}</span>
                                            <span>{s.heading}</span>
                                        </a>
                                    </li>
                                ))}
                            </ol>
                        </details>

                        {/* The questions (Query) this article answers — how people ask AI assistants, in their own words */}
                        {c.queries?.length > 0 && (
                            <section aria-labelledby="queries-title" className="mt-8 rounded-2xl border border-white/[0.07] bg-surface/60 p-6">
                                <h2 id="queries-title" className="flex items-center gap-2 text-sm font-semibold text-white"><MessageCircleQuestion size={16} className="text-primary" /> {t('articles.queries')}</h2>
                                <ul className="mt-4 grid gap-2.5 sm:grid-cols-2">
                                    {c.queries.map((q) => (
                                        <li key={q} className="rounded-xl border border-white/[0.06] bg-background/40 px-4 py-3 text-sm leading-relaxed text-text-heading/90">“{q}”</li>
                                    ))}
                                </ul>
                            </section>
                        )}

                        <div className="mt-14 space-y-14">
                            {c.sections.map((s, i) => (
                                <section key={s.id} id={s.id} aria-labelledby={`${s.id}-h`} className="scroll-mt-32 border-t border-white/[0.06] pt-10 first:border-t-0 first:pt-0">
                                    <span className="font-mono text-xs font-semibold text-primary" aria-hidden="true">{String(i + 1).padStart(2, '0')}</span>
                                    <h2 id={`${s.id}-h`} className="mt-2 text-2xl font-bold leading-snug text-white md:text-[1.85rem]">{s.heading}</h2>
                                    <div className="mt-6 space-y-6">
                                        {s.blocks.map((b, i) => <Block key={i} block={b} />)}
                                    </div>
                                </section>
                            ))}
                        </div>

                        <section className="mt-16" aria-labelledby="faq-title">
                            <h2 id="faq-title" className="text-2xl font-semibold text-white">{t('coverage.faqTitle')}</h2>
                            <div className="mt-6"><FaqList faq={c.faq} /></div>
                        </section>

                        {/* CTA */}
                        <section className="mt-16 overflow-hidden rounded-3xl border border-primary/25 bg-[radial-gradient(ellipse_80%_120%_at_0%_0%,rgba(244,121,47,0.16),transparent_60%)] p-7 md:p-9">
                            <h2 className="text-2xl font-bold text-white md:text-3xl">{t('articles.ctaTitle')}</h2>
                            <p className="mt-3 max-w-xl text-text-body">{t('articles.ctaDesc')}</p>
                            <div className="mt-6 flex flex-wrap gap-3">
                                <Link to="/contact" className="btn-primary">{t('coverage.talk')} <ArrowUpRight size={18} /></Link>
                                <a href={tgUrl(TG_CHANNEL)} target="_blank" rel="noopener noreferrer" className="btn-ghost">{t('footer.channel')}</a>
                            </div>
                        </section>
                    </div>

                    {/* Sidebar: contents + related pages */}
                    <aside className="space-y-8 lg:sticky lg:top-28 lg:self-start">
                        <Toc sections={c.sections} title={t('articles.contents')} />
                        {markets.length > 0 && (
                            <div>
                                <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{t('articles.relatedMarkets')}</h2>
                                <ul className="mt-3 grid grid-cols-2 gap-1 sm:grid-cols-3 lg:grid-cols-1">
                                    {markets.map((m) => (
                                        <li key={m.slug}>
                                            <Link to={`/payment-methods/${m.slug}`} className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm text-text-body transition-colors hover:bg-white/[0.04] hover:text-white">
                                                <Flag market={m} className="h-4 w-5" /> {marketName(m, lang)}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        {methods.length > 0 && (
                            <div>
                                <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{t('articles.relatedMethods')}</h2>
                                <ul className="mt-3 flex flex-wrap gap-2">
                                    {methods.map((m) => (
                                        <li key={m.slug}>
                                            <Link to={`/methods/${m.slug}`} className="inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] py-1 pl-1 pr-3 text-xs text-text-heading/90 transition-colors hover:border-primary/40 hover:text-white">
                                                <MethodIcon method={methodChannel(m)} size={14} /> {methodName(m, lang)}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                        {industries.length > 0 && (
                            <div>
                                <h2 className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{t('articles.relatedIndustries')}</h2>
                                <ul className="mt-3 grid grid-cols-2 gap-1 sm:grid-cols-3 lg:grid-cols-1">
                                    {industries.map(({ id, icon: Icon }) => (
                                        <li key={id}>
                                            <Link to={`/industries/${id}`} className="flex items-center gap-2.5 rounded-lg px-2 py-1.5 text-sm text-text-body transition-colors hover:bg-white/[0.04] hover:text-white">
                                                <Icon size={15} className="text-primary" /> {t(`industries.items.${id}.title`)}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </aside>
                </div>

                {more.length > 0 && (
                    <section className="mt-20" aria-labelledby="more-title">
                        <div className="flex flex-wrap items-end justify-between gap-4">
                            <h2 id="more-title" className="text-2xl font-semibold text-white">{t('articles.more')}</h2>
                            <Link to={KINDS[kind].path} className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-hover">{t('articles.all')} <ArrowRight size={14} /></Link>
                        </div>
                        <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                            {more.map((a) => <li key={a.slug}><ArticleCard article={a} lang={lang} t={t} /></li>)}
                        </ul>
                    </section>
                )}
            </article>
        </div>
    );
};

export default ArticlePage;
