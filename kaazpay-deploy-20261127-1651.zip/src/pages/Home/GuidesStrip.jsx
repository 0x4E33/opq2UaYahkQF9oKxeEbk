import { ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../../components/LocaleLink';
import ArticleCard from '../../components/ArticleCard';
import { Reveal } from '../../components/motion/Reveal';
import { ARTICLES } from '../../content';

// Home: a few guides and comparisons — crawlable links from the strongest page into the content hub.
const PICKS = ['malaysia-payment-methods', 'thailand-payment-methods', 'igaming-payments', 'usdt-vs-local-currency-settlement'];

const GuidesStrip = () => {
    const { t, i18n } = useTranslation();
    const list = [...PICKS.map((s) => ARTICLES.find((a) => a.slug === s)), ...ARTICLES].filter(Boolean)
        .filter((a, i, arr) => arr.indexOf(a) === i).slice(0, 4);
    if (!list.length) return null;
    return (
        <section className="relative z-10 py-20 md:py-28" aria-labelledby="home-guides-title">
            <div className="container mx-auto px-5">
                <Reveal className="mb-10 flex flex-col items-start justify-between gap-5 md:flex-row md:items-end">
                    <div>
                        <h2 id="home-guides-title" className="text-3xl font-bold text-white sm:text-4xl">{t('articles.homeTitle')}</h2>
                        <p className="mt-3 max-w-xl text-text-body">{t('articles.homeDesc')}</p>
                    </div>
                    <Link to="/guides" className="btn-ghost shrink-0 text-sm">{t('articles.all')} <ArrowRight size={16} /></Link>
                </Reveal>
                {/* phones: a swipeable row (next card peeks in); tablets and up: grid */}
                <ul className="no-scrollbar -mx-5 flex snap-x snap-mandatory gap-4 overflow-x-auto px-5 pb-2 sm:mx-0 sm:grid sm:grid-cols-2 sm:overflow-visible sm:px-0 sm:pb-0 lg:grid-cols-4">
                    {list.map((a, i) => (
                        <Reveal as="li" key={a.slug} index={i % 4} className="w-[82%] shrink-0 snap-start sm:w-auto">
                            <ArticleCard article={a} lang={i18n.language} t={t} />
                        </Reveal>
                    ))}
                </ul>
            </div>
        </section>
    );
};

export default GuidesStrip;
