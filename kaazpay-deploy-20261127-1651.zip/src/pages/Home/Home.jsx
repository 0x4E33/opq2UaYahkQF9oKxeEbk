import Hero from './Hero';
import Coverage from './Coverage';
import TrustMarquee from '../../components/TrustMarquee';
import SolutionsGrid from './SolutionsGrid';
import FeaturesGrid from './FeaturesGrid';
import GuidesStrip from './GuidesStrip';
import FAQ from './FAQ';

// Coverage sits right under the hero so visitors see the channels after one scroll.
const Home = () => (
    <div className="flex flex-col">
        <Hero />
        <Coverage />
        <TrustMarquee />
        <SolutionsGrid />
        <FeaturesGrid />
        <GuidesStrip />
        <FAQ />
    </div>
);

export default Home;
