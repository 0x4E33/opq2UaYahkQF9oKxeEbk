import { useMemo, useState } from 'react';
import { Link } from '../../components/LocaleLink';
import { m as motion, AnimatePresence } from 'framer-motion';
import { Search, ArrowUpRight, ChevronDown, X, MessageSquarePlus } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
    MARKETS, REGIONS, COVERAGE_STATS, PRIORITY as PRIORITY_SLUGS,
    hasPayout, regionName,
} from '../../data/channels';
import { CountUp, handleSpotlight } from '../../components/coverage/shared';
import { Reveal } from '../../components/motion/Reveal';
import { MarketCard } from '../../components/coverage/MarketCard';
import coverageMap from '../../assets/home/coverage-map.svg';

// "All" view keeps KaazPay's promotion order from channels.js (PRIORITY first), then the rest by region.
const PRIORITY = (m) => { const i = PRIORITY_SLUGS.indexOf(m.slug); return i > -1 ? i : 100 + ({ apac: 0, americas: 1, europe_me: 2, africa: 3, global: 4 }[m.region] ?? 5); };
const INITIAL = 12;
const MOBILE_INITIAL = 6; // phones show fewer cards before "Show all"

const REGION_ORDER = ['apac', 'global', 'americas', 'europe_me', 'africa'];


const Coverage = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const [region, setRegion] = useState('all');
    const [payoutOnly, setPayoutOnly] = useState(false);
    const [query, setQuery] = useState('');
    const [expanded, setExpanded] = useState(false);

    const counts = useMemo(() => Object.fromEntries(REGION_ORDER.map((r) => [r, MARKETS.filter((m) => m.region === r).length])), []);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        let list = MARKETS.filter((m) => {
            if (region !== 'all' && m.region !== region) return false;
            if (payoutOnly && !hasPayout(m)) return false;
            if (!q) return true;
            const hay = [m.name.en, m.name.zh, m.currency, m.slug, ...m.payin, ...(m.payout || []), REGIONS.find((r) => r.key === m.region)?.en, REGIONS.find((r) => r.key === m.region)?.zh]
                .join(' ').toLowerCase();
            return hay.includes(q);
        });
        if (region === 'all' && !q) {
            list = [...list].sort((a, b) => PRIORITY(a) - PRIORITY(b) || MARKETS.indexOf(a) - MARKETS.indexOf(b));
        }
        return list;
    }, [region, payoutOnly, query]);

    const limited = !expanded && !query && filtered.length > INITIAL;
    const visible = limited ? filtered.slice(0, INITIAL) : filtered;
    const showDesktopToggle = limited || (expanded && filtered.length > INITIAL);
    const showMobileToggle = !query && filtered.length > MOBILE_INITIAL;

    const tabs = [{ key: 'all', label: t('coverage.all'), count: MARKETS.length }, ...REGION_ORDER.map((k) => ({ key: k, label: regionName(k, lang), count: counts[k] }))];

    const stats = [
        { value: COVERAGE_STATS.markets, suffix: '', label: t('coverage.stats.markets') },
        { value: COVERAGE_STATS.payinMethods, suffix: '+', label: t('coverage.stats.methods') },
        { value: COVERAGE_STATS.payoutMarkets, suffix: '', label: t('coverage.stats.payout') },
        { value: COVERAGE_STATS.currencies, suffix: '', label: t('coverage.stats.currencies') },
    ];

    return (
        <section id="coverage" aria-labelledby="coverage-title"
            className="relative z-10 pb-24 pt-12 md:pb-32 md:pt-20">
            {/* One continuous warm atmosphere under the home page: each section paints a soft, static field whose
                edges fade out, so neighbours blend instead of meeting at a line. Clipped in its own layer so the
                section can keep its sticky filter bar. */}
            <div className="pointer-events-none absolute inset-x-0 -top-40 bottom-0 overflow-hidden [mask-image:linear-gradient(180deg,transparent_0%,black_16%,black_84%,transparent_100%)]" aria-hidden="true">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_38%_at_50%_14%,rgba(244,121,47,0.16),transparent_72%)]" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_45%_40%_at_92%_42%,rgba(129,216,207,0.09),transparent_70%)]" />
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_50%_45%_at_6%_70%,rgba(244,121,47,0.08),transparent_70%)]" />
                <img src={coverageMap} alt="" loading="lazy" decoding="async"
                    className="absolute -right-[160px] top-[120px] hidden w-[960px] max-w-none opacity-[0.28] [mask-image:linear-gradient(100deg,transparent_20%,black_62%)] lg:block" />
            </div>

            <div className="container relative mx-auto px-5">
                {/* Heading */}
                <Reveal className="mx-auto max-w-3xl text-center">
                    <span className="eyebrow">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                        {t('coverage.eyebrow')}
                    </span>
                    <h2 id="coverage-title" className="mt-5 text-3xl font-bold text-white sm:text-4xl md:text-5xl">
                        {t('coverage.title')} <span className="text-ember whitespace-nowrap">{t('coverage.titleHighlight', { count: COVERAGE_STATS.markets })}</span>
                    </h2>
                    <p className="mt-5 text-base text-text-body md:text-lg">{t('coverage.subtitle')}</p>
                </Reveal>

                {/* Stats */}
                <dl className="mx-auto mt-12 grid max-w-4xl grid-cols-2 overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.02] md:grid-cols-4">
                    {stats.map((s, i) => (
                        <div key={s.label} className={`px-5 py-5 text-center md:py-6 ${i % 2 === 0 ? 'border-r border-white/[0.07]' : ''} ${i < 2 ? 'border-b border-white/[0.07] md:border-b-0' : ''} md:border-r md:last:border-r-0`}>
                            <dt className="sr-only">{s.label}</dt>
                            <dd className="font-display text-3xl font-bold text-white md:text-4xl"><CountUp value={s.value} suffix={s.suffix} /></dd>
                            <dd className="mt-1 text-xs font-medium uppercase tracking-[0.12em] text-text-muted">{s.label}</dd>
                        </div>
                    ))}
                </dl>

                {/* Controls */}
                <div className="sticky top-20 z-20 -mx-5 mt-12 border-y border-white/[0.06] bg-background/85 px-5 py-3 backdrop-blur-xl md:static md:mx-0 md:border-0 md:bg-transparent md:p-0 md:backdrop-blur-0">
                    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                        <div role="tablist" aria-label={t('coverage.region')} className="no-scrollbar -mx-5 flex gap-1 overflow-x-auto px-5 md:mx-0 md:px-0">
                            <div className="flex gap-1 rounded-full border border-white/[0.07] bg-white/[0.03] p-1">
                                {tabs.map((tab) => {
                                    const active = region === tab.key;
                                    return (
                                        <button
                                            key={tab.key}
                                            role="tab"
                                            aria-selected={active}
                                            onClick={() => { setRegion(tab.key); setExpanded(false); }}
                                            className={`relative whitespace-nowrap rounded-full px-4 py-2 text-sm font-medium transition-colors ${active ? 'text-black' : 'text-text-body hover:text-white'}`}
                                        >
                                            {active && (
                                                <motion.span
                                                    layoutId="region-pill"
                                                    className="absolute inset-0 rounded-full bg-gradient-to-r from-primary-soft via-primary to-primary-deep"
                                                    transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                                                />
                                            )}
                                            <span className="relative">{tab.label}</span>
                                            <span className={`relative ml-1.5 text-xs ${active ? 'text-black/60' : 'text-text-muted'}`}>{tab.count}</span>
                                        </button>
                                    );
                                })}
                            </div>
                        </div>

                        <div className="flex items-center gap-2">
                            <label className="relative flex-1 lg:w-72 lg:flex-none">
                                <span className="sr-only">{t('coverage.search')}</span>
                                <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-text-muted" />
                                <input
                                    type="search"
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    placeholder={t('coverage.search')}
                                    className="w-full rounded-full border border-white/10 bg-white/[0.04] py-2.5 pl-10 pr-9 text-sm text-white placeholder:text-text-muted transition-colors focus:border-primary/50 focus:bg-white/[0.06] focus:outline-none [&::-webkit-search-cancel-button]:hidden"
                                />
                                {query && (
                                    <button onClick={() => setQuery('')} aria-label="Clear" className="absolute right-3 top-1/2 -translate-y-1/2 text-text-muted hover:text-white">
                                        <X size={14} />
                                    </button>
                                )}
                            </label>
                            <button
                                role="switch"
                                aria-checked={payoutOnly}
                                onClick={() => setPayoutOnly((v) => !v)}
                                className={`inline-flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2.5 text-sm font-medium transition-colors ${payoutOnly ? 'border-payout/40 bg-payout/10 text-payout' : 'border-white/10 bg-white/[0.04] text-text-body hover:text-white'}`}
                            >
                                <span className={`relative h-4 w-7 rounded-full transition-colors ${payoutOnly ? 'bg-payout' : 'bg-white/15'}`}>
                                    <span className={`absolute top-0.5 h-3 w-3 rounded-full bg-white transition-all ${payoutOnly ? 'left-3.5' : 'left-0.5'}`} />
                                </span>
                                {t('coverage.payout')}
                            </button>
                        </div>
                    </div>
                </div>

                {/* Grid */}
                <motion.ul layout onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    <AnimatePresence mode="popLayout" initial={false}>
                        {visible.map((m, i) => (
                            <motion.li
                                key={m.slug}
                                layout
                                initial={{ opacity: 0, scale: 0.96, y: 8 }}
                                animate={{ opacity: 1, scale: 1, y: 0 }}
                                exit={{ opacity: 0, scale: 0.96 }}
                                transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                                className={`list-none ${!expanded && !query && i >= MOBILE_INITIAL ? 'max-sm:hidden' : ''}`}
                            >
                                <MarketCard market={m} lang={lang} t={t} />
                            </motion.li>
                        ))}
                    </AnimatePresence>
                </motion.ul>

                {filtered.length === 0 && (
                    <div className="mt-6 rounded-2xl border border-dashed border-white/10 p-10 text-center">
                        <p className="text-text-body">{t('coverage.empty', { q: query })}</p>
                        <Link to="/contact" className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary hover:text-primary-hover">
                            {t('coverage.emptyCta')} <ArrowUpRight size={14} />
                        </Link>
                    </div>
                )}

                {(showDesktopToggle || showMobileToggle) && (
                    <div className={`mt-8 flex justify-center ${showDesktopToggle ? '' : 'sm:hidden'} ${showMobileToggle ? '' : 'max-sm:hidden'}`}>
                        <button onClick={() => setExpanded((v) => !v)} className="btn-ghost text-sm">
                            {expanded ? t('coverage.showLess') : t('coverage.showAll', { count: filtered.length })}
                            <ChevronDown size={16} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} />
                        </button>
                    </div>
                )}

                {/* CTA */}
                <div className="border-conic mt-14 rounded-3xl">
                    <div className="relative flex flex-col items-start gap-6 overflow-hidden rounded-3xl bg-gradient-to-br from-surface-2 to-surface p-8 md:flex-row md:items-center md:justify-between md:p-10">
                        <div className="relative flex items-start gap-4">
                            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/30">
                                <MessageSquarePlus size={20} />
                            </span>
                            <div>
                                <h3 className="text-xl font-semibold text-white md:text-2xl">{t('coverage.ctaTitle')}</h3>
                                <p className="mt-1.5 max-w-xl text-text-body">{t('coverage.ctaDesc')}</p>
                            </div>
                        </div>
                        <Link to="/contact" className="btn-primary relative shrink-0 max-sm:w-full">
                            {t('coverage.ctaButton')} <ArrowUpRight size={18} />
                        </Link>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Coverage;
