import { useState } from 'react';
import { Plus, Minus, ArrowUpRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../components/LocaleLink';
import { FAQ_GROUPS, faqText } from '../content/faq-view';
import { glossaryLinkLabel } from '../content/glossary-view';

/** One question: the answer always stays in the HTML (collapsed with CSS), matching the FAQPage JSON-LD. */
const Item = ({ item, lang, open, onToggle }) => {
    const c = faqText(item, lang);
    return (
        <div id={item.id} className="scroll-mt-28">
            <h3>
                <button type="button" onClick={onToggle} aria-expanded={open}
                    className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium text-white">
                    {c.q}
                    <span className={open ? 'text-primary' : 'text-text-muted'}>{open ? <Minus size={18} /> : <Plus size={18} />}</span>
                </button>
            </h3>
            <div className={`grid transition-[grid-template-rows,opacity] duration-300 ease-out ${open ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                <div className="overflow-hidden">
                    <div className="px-5 pb-5">
                        <p className="text-text-body">{c.a}</p>
                        {item.links?.length > 0 && (
                            <p className="mt-3 flex flex-wrap gap-x-4 gap-y-1.5 text-sm">
                                {item.links.map((href) => (
                                    <Link key={href} to={href} className="inline-flex items-center gap-1 text-primary hover:text-primary-hover">
                                        {glossaryLinkLabel(href, lang)} <ArrowUpRight size={13} />
                                    </Link>
                                ))}
                            </p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

/** /faq — every common question in one place, grouped, each with its own #anchor. */
const FaqPage = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language?.startsWith('zh') ? 'zh' : 'en';
    const [open, setOpen] = useState(FAQ_GROUPS[0]?.items[0]?.id);

    return (
        <div className="relative overflow-hidden pb-24">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(244,121,47,0.14),transparent_70%)]" aria-hidden="true" />
            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-20">
                <span className="eyebrow">{t('faqPage.eyebrow')}</span>
                <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-bold leading-[1.08] text-white md:text-6xl">{t('faqPage.title')}</h1>
                <p className="mx-auto mt-5 max-w-2xl text-lg text-text-body">{t('faqPage.subtitle')}</p>
            </section>

            <div className="container relative mx-auto mt-12 grid max-w-6xl gap-10 px-5 lg:grid-cols-[220px_minmax(0,1fr)]">
                <nav aria-label={t('faqPage.eyebrow')} className="lg:sticky lg:top-28 lg:self-start">
                    <ul className="no-scrollbar -mx-5 flex gap-2 overflow-x-auto px-5 lg:mx-0 lg:flex-col lg:gap-1 lg:px-0">
                        {FAQ_GROUPS.map((g) => (
                            <li key={g.id} className="shrink-0">
                                <a href={`#${g.id}`} className="block rounded-xl px-3 py-2 text-sm text-text-body transition-colors hover:bg-white/[0.05] hover:text-white">{g[lang].title}</a>
                            </li>
                        ))}
                    </ul>
                </nav>

                <div className="space-y-12">
                    {FAQ_GROUPS.map((g) => (
                        <section key={g.id} id={g.id} className="scroll-mt-28" aria-labelledby={`${g.id}-title`}>
                            <h2 id={`${g.id}-title`} className="text-2xl font-bold text-white">{g[lang].title}</h2>
                            <div className="mt-5 divide-y divide-white/[0.07] rounded-2xl border border-white/[0.07] bg-surface/60">
                                {g.items.map((it) => (
                                    <Item key={it.id} item={it} lang={lang} open={open === it.id} onToggle={() => setOpen(open === it.id ? null : it.id)} />
                                ))}
                            </div>
                        </section>
                    ))}

                    <div className="rounded-3xl border border-white/[0.07] bg-surface/60 p-8">
                        <p className="text-lg font-semibold text-white">{t('faqPage.ctaTitle')}</p>
                        <p className="mt-2 text-text-body">{t('faqPage.ctaDesc')}</p>
                        <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                            <Link to="/contact" className="btn-primary">{t('nav.contact')}</Link>
                            <Link to="/glossary" className="btn-ghost">{t('faqPage.ctaGlossary')}</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FaqPage;
