import { useParams } from 'react-router-dom';
import { Link, Navigate } from '../components/LocaleLink';
import { Reveal } from '../components/motion/Reveal';
import { ArrowDownLeft, ArrowUpRight, ChevronRight, ArrowLeft, Check, Clock } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import PhotoBackdrop from '../components/visuals/PhotoBackdrop';
import { marketPhoto, marketPhotoSrcSet, marketPhotoAttribution, marketPhotoPosition } from '../data/media';
import { getMarket, marketsByRegion, hasPayout, marketName, regionName, methodType, methodTypeName, methodLabel, currencyLabel } from '../data/channels';
import { marketCopy } from '../seo';
import { Flag, MethodChip, MethodIcon, handleSpotlight } from '../components/coverage/shared';
import { MarketCard } from '../components/coverage/MarketCard';
import FaqList from '../components/FaqList';
import RelatedArticles from '../components/RelatedArticles';
import { methodForChannel } from '../data/methods';

const MarketPage = () => {
    const { slug } = useParams();
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const market = getMarket(slug);
    if (!market) return <Navigate to="/#coverage" replace />;

    const copy = marketCopy(market, lang);
    const name = marketName(market, lang);
    const payout = hasPayout(market);
    const related = marketsByRegion(market.region).filter((m) => m.slug !== market.slug).slice(0, 4);

    const facts = [
        { label: t('coverage.currency'), value: currencyLabel(market, lang), mono: true },
        { label: t('coverage.region'), value: regionName(market.region, lang) },
        { label: t('coverage.payin'), value: t(market.payin.length > 1 ? 'coverage.methods' : 'coverage.method', { count: market.payin.length }) },
        { label: t('coverage.payout'), value: payout ? t('coverage.payoutYes') : t('coverage.payinOnly') },
        { label: t('coverage.settlement'), value: t('coverage.settlementValue') },
    ];
    const QUICK = facts.filter((f) => f.label !== t('coverage.region'));

    return (
        <div className="relative -mt-20 overflow-hidden pt-20">
            <PhotoBackdrop src={marketPhoto(market)} srcSet={marketPhotoSrcSet(market)} position={marketPhotoPosition(market)} side="right" height={820} strength={0.28} caption={marketPhotoAttribution(market)} />

            <div className="container relative mx-auto px-5 pb-24 pt-10 md:pt-16">
                {/* Breadcrumb */}
                <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                    <Link to="/" className="hover:text-white">KaazPay</Link>
                    <ChevronRight size={14} />
                    <Link to="/#coverage" className="hover:text-white">{t('coverage.breadcrumb')}</Link>
                    <ChevronRight size={14} />
                    <span className="text-text-body" aria-current="page">{name}</span>
                </nav>

                <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
                    {/* Left */}
                    <div>
                        <div style={{ animationDelay: '0ms' }} className="animate-rise flex items-center gap-3">
                            <Flag market={market} className="h-9 w-12" />
                            <span className="eyebrow">{regionName(market.region, lang)} · {currencyLabel(market, lang)}</span>
                        </div>
                        <h1 style={{ animationDelay: '50ms' }} className="animate-rise mt-6 text-4xl font-bold leading-[1.08] text-white md:text-6xl">
                            {copy.h1}
                        </h1>
                        <p style={{ animationDelay: '100ms' }} className="animate-rise mt-6 max-w-2xl text-lg leading-relaxed text-text-body">
                            {copy.intro}
                        </p>
                        <div style={{ animationDelay: '150ms' }} className="animate-rise mt-8 flex flex-wrap gap-3">
                            <Link to="/contact" className="btn-primary">{t('coverage.startTitle', { name })} <ArrowUpRight size={18} /></Link>
                            <Link to="/developers" className="btn-ghost">{t('nav.developers')}</Link>
                        </div>


                        {/* phones & tablets: key facts right under the intro (the facts card sits at the very bottom there) */}
                        <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.07] lg:hidden">
                            {QUICK.map((f) => (
                                <div key={f.label} className="bg-surface/90 px-4 py-3.5">
                                    <dt className="text-xs text-text-muted">{f.label}</dt>
                                    <dd className={`mt-1 text-sm font-semibold text-white ${f.mono ? 'font-mono' : ''}`}>{f.value}</dd>
                                </div>
                            ))}
                        </dl>

                        {/* Methods */}
                        <section className="mt-16" aria-labelledby="methods-title">
                            <h2 id="methods-title" className="flex items-center gap-2 text-2xl font-semibold text-white">
                                <ArrowDownLeft className="text-primary" size={22} /> {t('coverage.methodsTitle')}
                            </h2>
                            <ul onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-3 sm:grid-cols-2">
                                {market.payin.map((m, i) => {
                                    const type = methodType(m);
                                    const page = methodForChannel(m);
                                    return (
                                        <Reveal as="li"
                                            key={m}
                                            index={i % 2}
                                            className="spotlight flex items-center gap-4 rounded-2xl border border-white/[0.07] bg-surface/80 p-4"
                                        >
                                            <MethodIcon method={m} size={36} />
                                            <div>
                                                <h3 className="font-semibold text-white">
                                                    {page ? <Link to={`/methods/${page.slug}`} className="underline decoration-white/20 underline-offset-4 transition-colors hover:text-primary hover:decoration-primary/60">{methodLabel(m, lang, market)}</Link> : methodLabel(m, lang, market)}
                                                </h3>
                                                <p className="text-sm text-text-muted">{methodTypeName(type, lang)}</p>
                                            </div>
                                        </Reveal>
                                    );
                                })}
                            </ul>
                            {market.networks && (
                                <p className="mt-4 flex flex-wrap items-center gap-2 text-sm text-text-muted">
                                    {t('coverage.networks')}:
                                    {market.networks.map((n) => <span key={n} className="rounded-md bg-white/[0.05] px-2 py-0.5 text-text-heading/85">{n}</span>)}
                                </p>
                            )}
                        </section>

                        {/* Payout */}
                        <section className="mt-12" aria-labelledby="payout-title">
                            <h2 id="payout-title" className="flex items-center gap-2 text-2xl font-semibold text-white">
                                <ArrowUpRight className="text-payout" size={22} /> {t('coverage.payoutTitle')}
                            </h2>
                            <div className={`mt-6 flex items-start gap-4 rounded-2xl border p-5 ${payout ? 'border-payout/25 bg-payout/[0.06]' : 'border-white/[0.07] bg-surface/60'}`}>
                                <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${payout ? 'bg-payout/15 text-payout' : 'bg-white/5 text-text-muted'}`}>
                                    {payout ? <Check size={18} /> : <Clock size={18} />}
                                </span>
                                <div>
                                    <h3 className="font-semibold text-white">{payout ? t('coverage.payoutYes') : t('coverage.payoutNo')}</h3>
                                    <p className="mt-1 text-sm text-text-body">
                                        {payout ? t('coverage.payoutYesDesc', { currency: market.currency }) : t('coverage.payoutNoDesc')}
                                    </p>
                                    {payout && (
                                        <div className="mt-4 flex flex-wrap gap-2">
                                            {market.payout.map((m) => <MethodChip key={m} method={m} label={methodLabel(m, lang, market)} size="lg" />)}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </section>

                        {/* FAQ */}
                        <section className="mt-16" aria-labelledby="faq-title">
                            <h2 id="faq-title" className="text-2xl font-semibold text-white">{t('coverage.faqTitle')}</h2>
                            <div className="mt-6"><FaqList faq={copy.faq} /></div>
                        </section>
                    </div>

                    {/* Right: sticky facts + CTA */}
                    <aside className="lg:pt-[300px]">
                        <div className="lg:sticky lg:top-28">
                            <div style={{ animationDelay: '200ms' }} className="animate-rise border-conic rounded-3xl">
                                <div className="rounded-3xl bg-gradient-to-b from-surface-2 to-surface p-6">
                                    <dl className="divide-y divide-white/[0.07]">
                                        {facts.map((f) => (
                                            <div key={f.label} className="flex items-center justify-between gap-4 py-3.5">
                                                <dt className="text-sm text-text-muted">{f.label}</dt>
                                                <dd className={`text-right text-sm font-semibold text-white ${f.mono ? 'font-mono' : ''}`}>{f.value}</dd>
                                            </div>
                                        ))}
                                    </dl>
                                    <div className="mt-6 rounded-2xl bg-white/[0.03] p-5 ring-1 ring-white/[0.06]">
                                        <p className="font-semibold text-white">{t('coverage.startTitle', { name })}</p>
                                        <p className="mt-1.5 text-sm text-text-body">{t('coverage.startDesc')}</p>
                                        <Link to="/contact" className="btn-primary mt-4 w-full text-sm">{t('coverage.talk')} <ArrowUpRight size={16} /></Link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>

                <RelatedArticles field="markets" value={market.slug} />

                {/* Related */}
                {related.length > 0 && (
                    <section className="mt-24" aria-labelledby="related-title">
                        <div className="flex items-end justify-between gap-4">
                            <h2 id="related-title" className="text-2xl font-semibold text-white">{t('coverage.related', { region: regionName(market.region, lang) })}</h2>
                            <Link to="/#coverage" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-hover">
                                <ArrowLeft size={14} /> {t('coverage.back')}
                            </Link>
                        </div>
                        <ul onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                            {related.map((m) => <li key={m.slug}><MarketCard market={m} lang={lang} t={t} /></li>)}
                        </ul>
                    </section>
                )}
            </div>
        </div>
    );
};

export default MarketPage;
