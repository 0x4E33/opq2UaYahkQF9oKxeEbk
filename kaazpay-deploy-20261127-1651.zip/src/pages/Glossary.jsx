import { useMemo, useState } from 'react';
import { ArrowUpRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../components/LocaleLink';
import { GLOSSARY, GLOSSARY_CATEGORIES, glossaryLinkLabel } from '../content/glossary-view';

/** /glossary — plain definitions of payment terms; every term has its own #anchor for deep links and citations. */
const Glossary = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language?.startsWith('zh') ? 'zh' : 'en';
    const [cat, setCat] = useState('all');
    const list = useMemo(() => GLOSSARY.filter((g) => cat === 'all' || g.category === cat)
        .sort((a, b) => a[lang].term.localeCompare(b[lang].term, lang === 'zh' ? 'zh-Hans-CN' : 'en')), [cat, lang]);

    return (
        <div className="relative overflow-hidden pb-24">
            <div className="pointer-events-none absolute inset-x-0 top-0 h-[520px] bg-[radial-gradient(ellipse_60%_60%_at_50%_0%,rgba(244,121,47,0.14),transparent_70%)]" aria-hidden="true" />
            <section className="container relative mx-auto px-5 pt-14 text-center md:pt-20">
                <span className="eyebrow">{t('glossary.eyebrow')}</span>
                <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-bold leading-[1.08] text-white md:text-6xl">{t('glossary.title')}</h1>
                <p className="mx-auto mt-5 max-w-2xl text-lg text-text-body">{t('glossary.subtitle', { count: GLOSSARY.length })}</p>
            </section>

            <div className="container relative mx-auto mt-12 px-5">
                <div role="tablist" aria-label={t('glossary.filter')} className="no-scrollbar -mx-5 flex justify-start gap-2 overflow-x-auto px-5 md:justify-center">
                    {['all', ...GLOSSARY_CATEGORIES].map((c) => (
                        <button key={c} role="tab" aria-selected={cat === c} onClick={() => setCat(c)}
                            className={`shrink-0 rounded-full px-4 py-2 text-sm font-medium transition-colors ${cat === c ? 'bg-gradient-to-r from-primary-soft via-primary to-primary-deep text-black' : 'border border-white/10 bg-white/[0.03] text-text-body hover:text-white'}`}>
                            {t(`glossary.categories.${c}`)}
                        </button>
                    ))}
                </div>

                <dl className="mx-auto mt-10 grid max-w-5xl gap-4 md:grid-cols-2">
                    {list.map((g) => {
                        const c = g[lang];
                        return (
                            <div key={g.id} id={g.id} className="scroll-mt-28 rounded-2xl border border-white/[0.07] bg-surface/70 p-6">
                                <dt>
                                    <h2 className="text-lg font-semibold text-white">{c.term}</h2>
                                    {c.aka?.length > 0 && <p className="mt-1 text-xs text-text-muted">{t('glossary.aka')}{c.aka.join(lang === 'zh' ? '、' : ', ')}</p>}
                                </dt>
                                <dd className="mt-3">
                                    <p className="font-medium text-text-heading">{c.short}</p>
                                    <p className="mt-2 text-[15px] leading-relaxed text-text-body">{c.body}</p>
                                    {g.links?.length > 0 && (
                                        <p className="mt-4 flex flex-wrap gap-x-4 gap-y-1.5 text-sm">
                                            {g.links.map((href) => (
                                                <Link key={href} to={href} className="inline-flex items-center gap-1 text-primary hover:text-primary-hover">
                                                    {glossaryLinkLabel(href, lang)} <ArrowUpRight size={13} />
                                                </Link>
                                            ))}
                                        </p>
                                    )}
                                </dd>
                            </div>
                        );
                    })}
                </dl>

                <div className="mx-auto mt-14 max-w-5xl rounded-3xl border border-white/[0.07] bg-surface/60 p-8 text-center">
                    <p className="text-lg font-semibold text-white">{t('glossary.ctaTitle')}</p>
                    <p className="mt-2 text-text-body">{t('glossary.ctaDesc')}</p>
                    <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
                        <Link to="/faq" className="btn-ghost">{t('glossary.ctaFaq')}</Link>
                        <Link to="/contact" className="btn-primary">{t('nav.contact')}</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Glossary;
