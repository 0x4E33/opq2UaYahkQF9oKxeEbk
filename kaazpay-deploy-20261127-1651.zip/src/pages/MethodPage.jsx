import { useParams } from 'react-router-dom';
import { ArrowUpRight, ArrowDownLeft, ChevronRight, ArrowLeft } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link, Navigate } from '../components/LocaleLink';
import { Flag, MethodIcon, handleSpotlight } from '../components/coverage/shared';
import FaqList from '../components/FaqList';
import RelatedArticles from '../components/RelatedArticles';
import { currencyLabel, hasPayout, marketName, methodTypeName } from '../data/channels';
import { METHODS, getMethod, methodChannel, methodKind, methodMarkets, methodName } from '../data/methods';
import { methodCopy } from '../seo';

/** One market where the method is available, linking to that market's page. */
const MarketRow = ({ market, lang, t }) => (
    <li>
        <Link to={`/payment-methods/${market.slug}`}
            className="spotlight group flex items-center gap-3 rounded-xl border border-white/[0.07] bg-surface/80 p-3.5 transition-colors hover:border-white/15 hover:bg-surface-2">
            <Flag market={market} className="h-6 w-8" />
            <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-white">{marketName(market, lang)}</span>
                <span className="block text-xs text-text-muted">
                    <span className="font-mono">{currencyLabel(market, lang)}</span> · {hasPayout(market) ? `${t('coverage.payin')} + ${t('coverage.payout')}` : t('coverage.payinOnly')}
                </span>
            </span>
            <ArrowUpRight size={15} className="shrink-0 text-text-muted transition-colors group-hover:text-primary" />
        </Link>
    </li>
);

const MethodPage = () => {
    const { slug } = useParams();
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    const method = getMethod(slug);
    if (!method) return <Navigate to="/methods" replace />;

    const copy = methodCopy(method, lang);
    const name = methodName(method, lang);
    const kind = methodKind(method);
    const { payin, payout } = methodMarkets(method);
    const worldwide = payin.some((m) => m.cardBrands);
    const related = METHODS.filter((m) => m.slug !== method.slug && methodKind(m) === kind).slice(0, 8);

    const facts = [
        { label: t('methods.type'), value: methodTypeName(kind, lang) },
        { label: t('methods.payinMarkets'), value: worldwide ? t('methods.worldwide') : payin.length || '—' },
        { label: t('methods.payoutMarkets'), value: payout.length || '—' },
        { label: t('coverage.settlement'), value: t('coverage.settlementValue') },
    ];

    return (
        <div className="container relative mx-auto px-5 pb-24 pt-10 md:pt-16">
            <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                <Link to="/" className="hover:text-white">KaazPay</Link>
                <ChevronRight size={14} />
                <Link to="/methods" className="hover:text-white">{t('methods.eyebrow')}</Link>
                <ChevronRight size={14} />
                <span className="text-text-body" aria-current="page">{name}</span>
            </nav>

            <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:gap-16">
                <div>
                    <div className="animate-rise flex items-center gap-3">
                        <MethodIcon method={methodChannel(method)} size={36} />
                        <span className="eyebrow">{methodTypeName(kind, lang)}</span>
                    </div>
                    <h1 style={{ animationDelay: '50ms' }} className="animate-rise mt-6 text-4xl font-bold leading-[1.08] text-white md:text-6xl">{copy.h1}</h1>
                    <p style={{ animationDelay: '100ms' }} className="animate-rise mt-6 max-w-2xl text-lg leading-relaxed text-text-body">{copy.lead || copy.description}</p>
                    <div style={{ animationDelay: '150ms' }} className="animate-rise mt-8 flex flex-wrap gap-3">
                        <Link to="/contact" className="btn-primary">{t('methods.integrateTitle', { name })} <ArrowUpRight size={18} /></Link>
                        <Link to="/developers" className="btn-ghost">{t('nav.developers')}</Link>
                    </div>


                    {/* phones & tablets: key facts right under the intro (the facts card sits at the very bottom there) */}
                    <dl className="mt-8 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-white/[0.07] bg-white/[0.07] lg:hidden">
                        {facts.map((f) => (
                            <div key={f.label} className="bg-surface/90 px-4 py-3.5">
                                <dt className="text-xs text-text-muted">{f.label}</dt>
                                <dd className={`mt-1 text-sm font-semibold text-white ${f.mono ? 'font-mono' : ''}`}>{f.value}</dd>
                            </div>
                        ))}
                    </dl>

                    <section className="mt-16" aria-labelledby="about-title">
                        <h2 id="about-title" className="text-2xl font-semibold text-white">{t('methods.about', { name })}</h2>
                        <p className="mt-4 max-w-2xl leading-relaxed text-text-body">{copy.about}</p>
                    </section>

                    {payin.length > 0 && (
                        <section className="mt-12" aria-labelledby="payin-title">
                            <h2 id="payin-title" className="flex items-center gap-2 text-2xl font-semibold text-white">
                                <ArrowDownLeft className="text-primary" size={22} /> {t('methods.payinWhere', { name })}
                            </h2>
                            <ul onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-3 sm:grid-cols-2">
                                {payin.map((m) => <MarketRow key={m.slug} market={m} lang={lang} t={t} />)}
                            </ul>
                        </section>
                    )}

                    {payout.length > 0 && (
                        <section className="mt-12" aria-labelledby="payout-title">
                            <h2 id="payout-title" className="flex items-center gap-2 text-2xl font-semibold text-white">
                                <ArrowUpRight className="text-payout" size={22} /> {t('methods.payoutWhere', { name })}
                            </h2>
                            <ul onMouseMove={handleSpotlight} className="spotlight-group mt-6 grid gap-3 sm:grid-cols-2">
                                {payout.map((m) => <MarketRow key={m.slug} market={m} lang={lang} t={t} />)}
                            </ul>
                        </section>
                    )}

                    <section className="mt-16" aria-labelledby="faq-title">
                        <h2 id="faq-title" className="text-2xl font-semibold text-white">{t('coverage.faqTitle')}</h2>
                        <div className="mt-6"><FaqList faq={copy.faq} /></div>
                    </section>
                </div>

                <aside className="lg:pt-[220px]">
                    <div className="lg:sticky lg:top-28">
                        <div className="animate-rise border-conic rounded-3xl">
                            <div className="rounded-3xl bg-gradient-to-b from-surface-2 to-surface p-6">
                                <dl className="divide-y divide-white/[0.07]">
                                    {facts.map((f) => (
                                        <div key={f.label} className="flex items-center justify-between gap-4 py-3.5">
                                            <dt className="text-sm text-text-muted">{f.label}</dt>
                                            <dd className="text-right text-sm font-semibold text-white">{f.value}</dd>
                                        </div>
                                    ))}
                                </dl>
                                <div className="mt-6 rounded-2xl bg-white/[0.03] p-5 ring-1 ring-white/[0.06]">
                                    <p className="font-semibold text-white">{t('methods.integrateTitle', { name })}</p>
                                    <p className="mt-1.5 text-sm text-text-body">{t('methods.integrateDesc', { name })}</p>
                                    <Link to="/contact" className="btn-primary mt-4 w-full text-sm">{t('coverage.talk')} <ArrowUpRight size={16} /></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>

            <RelatedArticles field="methods" value={method.slug} />

            <section className="mt-24" aria-labelledby="related-title">
                <div className="flex flex-wrap items-end justify-between gap-4">
                    <h2 id="related-title" className="text-2xl font-semibold text-white">
                        {related.length ? t('methods.related', { type: methodTypeName(kind, lang) }) : t('methods.all')}
                    </h2>
                    <Link to="/methods" className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-hover">
                        <ArrowLeft size={14} /> {t('methods.all')}
                    </Link>
                </div>
                {related.length > 0 && (
                    <ul className="mt-6 flex flex-wrap gap-2">
                        {related.map((m) => (
                            <li key={m.slug}>
                                <Link to={`/methods/${m.slug}`} className="inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] py-1.5 pl-1.5 pr-3.5 text-sm text-text-heading/90 transition-colors hover:border-primary/40 hover:text-white">
                                    <MethodIcon method={methodChannel(m)} size={18} />
                                    {methodName(m, lang)}
                                </Link>
                            </li>
                        ))}
                    </ul>
                )}
            </section>
        </div>
    );
};

export default MethodPage;
