import { ArrowUpRight, ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../components/LocaleLink';
import { Flag, MethodIcon, handleSpotlight } from '../components/coverage/shared';
import { Reveal } from '../components/motion/Reveal';
import LogoField from '../components/visuals/LogoField';
import { METHOD_TYPES, getMarket, methodTypeName } from '../data/channels';
import { METHODS, methodChannel, methodKind, methodMarkets, methodName } from '../data/methods';

/** /methods — every payment method, grouped by type, each linking to its own page. */
const GROUPS = Object.keys(METHOD_TYPES)
    .map((type) => [type, METHODS.filter((m) => methodKind(m) === type)])
    .filter(([, list]) => list.length);

const MethodCard = ({ method, lang, t }) => {
    const { payin, payout } = methodMarkets(method);
    const markets = [...new Map([...payin, ...payout].map((m) => [m.slug, m])).values()];
    const worldwide = markets.some((m) => m.cardBrands);
    return (
        <Link to={`/methods/${method.slug}`}
            className="spotlight group flex h-full items-center gap-4 rounded-2xl border border-white/[0.07] bg-surface/80 p-4 transition-[transform,border-color,background-color] duration-300 hover:-translate-y-0.5 hover:border-white/15 hover:bg-surface-2">
            <MethodIcon method={methodChannel(method)} size={36} />
            <div className="min-w-0 flex-1">
                <h3 className="truncate font-semibold text-white">{methodName(method, lang)}</h3>
                <p className="mt-0.5 flex items-center gap-1.5 text-xs text-text-muted">
                    {worldwide ? t('methods.worldwide') : t('methods.markets', { count: markets.length })}
                    {!worldwide && (
                        <span className="flex -space-x-1">
                            {markets.slice(0, 5).map((m) => <Flag key={m.slug} market={m} className="h-3.5 w-3.5 rounded-full" />)}
                        </span>
                    )}
                </p>
            </div>
            <ArrowUpRight size={16} className="shrink-0 text-text-muted transition-colors group-hover:text-primary" />
        </Link>
    );
};

const MethodsIndex = () => {
    const { t, i18n } = useTranslation();
    const lang = i18n.language;
    return (
        <div className="relative overflow-hidden">
        {/* backdrop: brand glows, a faint iso grid and a drifting wall of supported payment brands */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[900px]" aria-hidden="true">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_60%_at_85%_10%,rgba(244,121,47,0.16),transparent_70%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_40%_45%_at_5%_55%,rgba(129,216,207,0.08),transparent_70%)]" />
            <div className="absolute inset-0 bg-[repeating-linear-gradient(30deg,rgba(255,255,255,0.025)_0_1px,transparent_1px_44px),repeating-linear-gradient(150deg,rgba(255,255,255,0.025)_0_1px,transparent_1px_44px)] [mask-image:radial-gradient(ellipse_70%_60%_at_70%_20%,black,transparent_75%)]" />
            <LogoField className="absolute right-[-6%] top-[90px] hidden w-[58%] overflow-hidden [mask-image:linear-gradient(90deg,transparent_0%,black_30%,black_80%,transparent_100%),linear-gradient(180deg,black_60%,transparent)] [mask-composite:intersect] lg:block" />
            <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-background to-transparent" />
        </div>
        <div className="container relative mx-auto px-5 pb-24 pt-10 md:pt-16">
            <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-1.5 text-sm text-text-muted [&_a]:py-2">
                <Link to="/" className="hover:text-white">KaazPay</Link>
                <ChevronRight size={14} />
                <span className="text-text-body" aria-current="page">{t('methods.eyebrow')}</span>
            </nav>
            <span className="eyebrow animate-rise">{t('methods.eyebrow')}</span>
            <h1 style={{ animationDelay: '50ms' }} className="animate-rise mt-6 max-w-4xl text-4xl font-bold leading-[1.08] text-white md:text-6xl">
                {/* keep the brand and the Chinese phrase whole when the line breaks ("KaazPay" / "支持的全部支付方式") */}
                {t('methods.title').split(/(?<=KaazPay)\s+(?=[^\x00-\x7F])/).map((part) => <span key={part} className="inline-block">{part}&nbsp;</span>)}
            </h1>
            <p style={{ animationDelay: '100ms' }} className="animate-rise mt-6 max-w-2xl text-lg text-text-body">{t('methods.subtitle', { count: METHODS.length })}</p>
            <LogoField rows={2} tilt={false} className="-mx-5 mt-10 overflow-hidden opacity-70 [mask-image:linear-gradient(90deg,transparent,black_15%,black_85%,transparent)] lg:hidden" />

            <div className="mt-16 space-y-14">
                {GROUPS.map(([type, list]) => (
                    <section key={type} aria-labelledby={`type-${type}`}>
                        <h2 id={`type-${type}`} className="text-xl font-semibold text-white">{methodTypeName(type, lang)}</h2>
                        <ul onMouseMove={handleSpotlight} className="spotlight-group mt-5 grid grid-cols-[minmax(0,1fr)] gap-3 sm:grid-cols-2 lg:grid-cols-3">
                            {list.map((m, i) => (
                                <Reveal as="li" key={m.slug} index={i % 3}><MethodCard method={m} lang={lang} t={t} /></Reveal>
                            ))}
                        </ul>
                    </section>
                ))}
                <section aria-labelledby="type-crypto">
                    <h2 id="type-crypto" className="text-xl font-semibold text-white">{t('methods.alsoUsdt')}</h2>
                    <div className="mt-5 grid grid-cols-[minmax(0,1fr)] gap-3 sm:grid-cols-2 lg:grid-cols-3">
                        <Link to="/payment-methods/usdt" className="group flex items-center gap-4 rounded-2xl border border-[#7FD8CF]/40 bg-surface/80 p-4 transition-colors hover:bg-surface-2">
                            <Flag market={getMarket('usdt')} className="h-11 w-11 rounded-xl" />
                            <div className="min-w-0 flex-1">
                                <h3 className="font-semibold text-white">USDT</h3>
                                <p className="mt-0.5 text-xs text-text-muted">{t('methods.usdtDesc')}</p>
                            </div>
                            <ArrowUpRight size={16} className="shrink-0 text-text-muted transition-colors group-hover:text-primary" />
                        </Link>
                    </div>
                </section>
            </div>
        </div>
        </div>
    );
};

export default MethodsIndex;
