import { useLocation } from 'react-router-dom';
import { ArrowRight, ArrowUpRight, Globe2, CreditCard, Layers, Code2, MessageSquare, XCircle } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Link } from '../components/LocaleLink';
import { MethodIcon } from '../components/coverage/shared';
import { getMethod, methodChannel, methodName } from '../data/methods';

/**
 * Unknown URLs (served with HTTP 404 by nginx). Framed as a payment route that didn't go through:
 * a declined "receipt" for the requested path, then the routes that do work.
 */
const DESTINATIONS = [
    { to: '/#coverage', icon: Globe2, label: 'nav.globalCoverage', desc: 'coverage' },
    { to: '/methods', icon: CreditCard, label: 'footer.methods', desc: 'methods' },
    { to: '/industries', icon: Layers, label: 'nav.solutions', desc: 'industries' },
    { to: '/developers', icon: Code2, label: 'nav.developers', desc: 'developers' },
    { to: '/contact', icon: MessageSquare, label: 'nav.contact', desc: 'contact' },
];
const POPULAR_METHODS = ['pix', 'spei', 'm-pesa', 'gcash', 'qris', 'fpx', 'visa', 'mastercard', 'unionpay', 'jcb'];

const NotFound = () => {
    const { t, i18n } = useTranslation();
    const { pathname } = useLocation();
    const lang = i18n.language;

    return (
        <div className="relative -mt-20 overflow-hidden pt-20">
            {/* backdrop: faint grid + warm glow behind the number */}
            <div className="pointer-events-none absolute inset-0 bg-grid-pattern [mask-image:radial-gradient(ellipse_70%_60%_at_50%_30%,black,transparent)]" aria-hidden="true" />
            <div className="pointer-events-none absolute left-1/2 top-24 h-[420px] w-[720px] -translate-x-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(244,121,47,0.22),transparent)] blur-2xl" aria-hidden="true" />

            <div className="container relative mx-auto px-5 pb-24 pt-12 md:pt-20">
                <div className="grid items-center gap-12 lg:grid-cols-[1.15fr_1fr] lg:gap-16">
                    <div>
                        <p className="animate-rise select-none font-display text-[clamp(6rem,18vw,11rem)] font-extrabold leading-none tracking-tight">
                            <span className="text-ember">404</span>
                        </p>
                        <h1 style={{ animationDelay: '60ms' }} className="animate-rise mt-4 text-3xl font-bold leading-tight text-white md:text-5xl">{t('notFound.title')}</h1>
                        <p style={{ animationDelay: '120ms' }} className="animate-rise mt-5 max-w-xl text-lg text-text-body">{t('notFound.desc')}</p>
                        <div style={{ animationDelay: '180ms' }} className="animate-rise mt-8 flex flex-wrap gap-3">
                            <Link to="/" className="btn-primary">{t('notFound.home')} <ArrowRight size={18} /></Link>
                            <Link to="/methods" className="btn-ghost">{t('notFound.methods')}</Link>
                        </div>
                    </div>

                    {/* declined "receipt" for the requested URL */}
                    <div style={{ animationDelay: '220ms' }} className="animate-rise border-conic mx-auto w-full max-w-md rounded-3xl">
                        <div className="rounded-3xl bg-gradient-to-b from-surface-2 to-surface p-6 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.9)]">
                            <div className="flex items-center justify-between">
                                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-text-muted">{t('notFound.receipt')}</p>
                                <span className="inline-flex items-center gap-1.5 rounded-full bg-[#F87171]/10 px-2.5 py-1 text-xs font-semibold text-[#F87171] ring-1 ring-[#F87171]/30">
                                    <XCircle size={13} /> {t('notFound.declined')}
                                </span>
                            </div>
                            <dl className="mt-5 divide-y divide-dashed divide-white/[0.1] font-mono text-sm">
                                <div className="flex justify-between gap-4 py-3"><dt className="text-text-muted">{t('notFound.status')}</dt><dd className="text-white">{t('notFound.declined')}</dd></div>
                                <div className="flex justify-between gap-4 py-3"><dt className="text-text-muted">{t('notFound.code')}</dt><dd className="text-white">HTTP 404</dd></div>
                                <div className="flex justify-between gap-4 py-3"><dt className="shrink-0 text-text-muted">{t('notFound.path')}</dt><dd className="min-w-0 truncate text-right text-primary">{pathname}</dd></div>
                            </dl>
                            {/* perforated edge */}
                            <div className="relative -mx-6 my-4 h-4" aria-hidden="true">
                                <span className="absolute -left-2 top-0 h-4 w-4 rounded-full bg-background" />
                                <span className="absolute -right-2 top-0 h-4 w-4 rounded-full bg-background" />
                                <span className="absolute inset-x-4 top-1/2 border-t border-dashed border-white/15" />
                            </div>
                            <p className="text-sm text-text-body">{t('notFound.retry')}</p>
                        </div>
                    </div>
                </div>

                <section className="mt-20" aria-labelledby="nf-popular">
                    <h2 id="nf-popular" className="text-xl font-semibold text-white">{t('notFound.popular')}</h2>
                    <ul className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
                        {DESTINATIONS.map(({ to, icon: Icon, label, desc }) => (
                            <li key={to}>
                                <Link to={to} className="group flex h-full flex-col rounded-2xl border border-white/[0.07] bg-surface/80 p-5 transition-[transform,border-color,background-color] duration-300 hover:-translate-y-0.5 hover:border-primary/30 hover:bg-surface-2">
                                    <span className="flex items-center justify-between">
                                        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary ring-1 ring-primary/20"><Icon size={18} /></span>
                                        <ArrowUpRight size={16} className="text-text-muted transition-colors group-hover:text-primary" />
                                    </span>
                                    <span className="mt-4 font-semibold text-white">{t(label)}</span>
                                    <span className="mt-1 text-sm text-text-muted">{t(`notFound.dest.${desc}`)}</span>
                                </Link>
                            </li>
                        ))}
                    </ul>
                </section>

                <section className="mt-12" aria-labelledby="nf-methods">
                    <h2 id="nf-methods" className="text-xl font-semibold text-white">{t('notFound.methodsTitle')}</h2>
                    <ul className="mt-5 flex flex-wrap gap-2">
                        {POPULAR_METHODS.map(getMethod).filter(Boolean).map((m) => (
                            <li key={m.slug}>
                                <Link to={`/methods/${m.slug}`} className="inline-flex items-center gap-2 rounded-full border border-white/[0.08] bg-white/[0.03] py-1.5 pl-1.5 pr-3.5 text-sm text-text-heading/90 transition-colors hover:border-primary/40 hover:text-white">
                                    <MethodIcon method={methodChannel(m)} size={18} />
                                    {methodName(m, lang)}
                                </Link>
                            </li>
                        ))}
                    </ul>
                </section>
            </div>
        </div>
    );
};

export default NotFound;
