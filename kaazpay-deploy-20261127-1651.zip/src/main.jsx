import { StrictMode } from 'react'
import { createRoot, hydrateRoot } from 'react-dom/client'
import './index.css'
import i18n from './i18n'; // Initialize i18n
import App from './App.jsx'
import { langFromPath, normalizePath } from './lib/locale';

const container = document.getElementById('root');
const app = (
  <StrictMode>
    <App />
  </StrictMode>
);

// Every page is prerendered in English (/...) and Chinese (/zh/...); the URL decides the language. (A first-visit
// redirect to the Chinese twin happens before paint in an inline script in index.html.) Hydrate only when the HTML
// was rendered for this exact route (a server may fall back to another page's HTML); otherwise render fresh.
const path = normalizePath(window.location.pathname);
i18n.changeLanguage(langFromPath(path));
const canHydrate = container.hasChildNodes() && container.dataset.route === path;

if (canHydrate) {
  hydrateRoot(container, app);
} else {
  container.textContent = '';
  createRoot(container).render(app);
}
