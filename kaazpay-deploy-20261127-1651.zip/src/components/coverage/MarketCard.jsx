import { Link } from '../LocaleLink';
import { ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { hasPayout, marketName, regionName, methodLabel, currencyLabel } from '../../data/channels';
import { Flag, MethodIcon, methodLogo } from './shared';

/** Calm method summary: brand logos (only where a brand exists) + a short text list. */
const MethodSummary = ({ methods, market, lang }) => {
    const names = [...new Set(methods.map((m) => methodLabel(m, lang, market).replace(/^[A-Z]{3} (Bank Transfer|银行转账)$/, '$1')))];
    const logos = methods.filter((m) => methodLogo(m)).slice(0, 4);
    return (
        <div className="min-w-0">
            <p className="text-[13px] leading-5 text-text-heading/85">{names.join(' · ')}</p>
            {logos.length > 0 && (
                <span className="mt-1.5 flex gap-1">
                    {logos.map((m) => <MethodIcon key={m} method={m} size={14} />)}
                </span>
            )}
        </div>
    );
};

const MarketCard = ({ market, lang, t }) => {
    const payout = hasPayout(market);
    const highlight = market.region === 'global';
    return (
        <Link
            to={`/payment-methods/${market.slug}`}
            className={`spotlight group flex h-full flex-col rounded-2xl border bg-surface/80 p-5 shadow-card transition-[transform,border-color,background-color] duration-300 hover:-translate-y-1 hover:bg-surface-2 ${highlight ? (market.cardBrands ? 'border-[#60A5FA]/40' : 'border-[#26A17B]/40') : 'border-white/[0.07] hover:border-white/15'}`}
        >
            <div className="flex items-start gap-3.5">
                <Flag market={market} />
                <div className="min-w-0 flex-1">
                    <h3 className="truncate text-[15px] font-semibold text-text-heading">{marketName(market, lang)}</h3>
                    <p className="mt-0.5 text-xs text-text-muted">
                        <span className="font-mono text-text-body">{currencyLabel(market, lang)}</span>
                        <span className="mx-1.5">·</span>
                        {regionName(market.region, lang)}
                    </p>
                </div>
                <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/10 text-text-muted transition-all duration-300 group-hover:border-primary/50 group-hover:bg-primary group-hover:text-black">
                    <ArrowUpRight size={14} />
                </span>
            </div>

            <dl className="mt-5 space-y-3 border-t border-white/[0.05] pt-4">
                <div className="grid grid-cols-[4.25rem_1fr] items-start gap-2">
                    <dt className="inline-flex items-center gap-1 pt-0.5 text-[11px] font-semibold text-primary"><ArrowDownLeft size={12} />{t('coverage.payin')}</dt>
                    <dd><MethodSummary methods={market.payin} market={market} lang={lang} /></dd>
                </div>
                <div className="grid grid-cols-[4.25rem_1fr] items-start gap-2">
                    <dt className={`inline-flex items-center gap-1 pt-0.5 text-[11px] font-semibold ${payout ? 'text-payout' : 'text-text-muted'}`}><ArrowUpRight size={12} />{t('coverage.payout')}</dt>
                    <dd>{payout ? <MethodSummary methods={market.payout} market={market} lang={lang} /> : <span className="text-[13px] leading-5 text-text-muted">{t('coverage.payinOnly')}</span>}</dd>
                </div>
            </dl>

            {market.networks && (
                <p className="mt-auto pt-4 text-[11px] text-text-muted">{t('coverage.networks')}: {market.networks.join(' · ')}</p>
            )}
        </Link>
    );
};

export { MarketCard };
export default MarketCard;
