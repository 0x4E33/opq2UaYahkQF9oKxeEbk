import { useEffect, useRef } from 'react';
import { useInView } from 'framer-motion';
import { Globe2, CreditCard, Landmark, Zap, Smartphone, Banknote, QrCode, Coins } from 'lucide-react';
import { methodType } from '../../data/channels';

// Flags are self-hosted (src/assets/flags, 120x84 WebP from flagcdn): no third-party request, a few KB each.
const FLAGS = import.meta.glob('../../assets/flags/*.webp', { eager: true, query: '?url', import: 'default' });
export const flagUrl = (iso) => (iso ? FLAGS[`../../assets/flags/${iso}.webp`] || null : null);

export const TYPE_COLORS = {
    card: '#60A5FA',
    bank: '#A78BFA',
    instant: '#34D399',
    wallet: '#FBBF24',
    cash: '#F472B6',
    qr: '#22D3EE',
    crypto: '#26A17B',
};

/** Country flag (an image renders consistently on Windows, unlike emoji flags). */
export const Flag = ({ market, className = 'w-10 h-7' }) => {
    const src = flagUrl(market.iso);
    if (!src) {
        // Non-country channels: global cards get a card badge, global USDT a globe.
        const Icon = market.cardBrands ? CreditCard : Globe2;
        const tint = market.cardBrands ? 'from-[#3B82F6] to-[#1E3A8A]' : 'from-[#26A17B] to-[#1a7a5c]';
        return (
            <span className={`${className} inline-flex items-center justify-center rounded-md bg-gradient-to-br ${tint} text-white ring-1 ring-white/10`}>
                <Icon size={16} />
            </span>
        );
    }
    return (
        <img
            src={src}
            alt=""
            loading="lazy"
            decoding="async"
            width="40"
            height="28"
            className={`${className} ${className.includes('rounded') ? '' : 'rounded-md'} object-cover ring-1 ring-white/15 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.8)]`}
        />
    );
};

// Brand logos live in src/assets/methods/<key>.svg|png (see manifest.json there for sources).
const LOGO_FILES = import.meta.glob('../../assets/methods/*.{svg,png}', { eager: true, query: '?url', import: 'default' });
const LOGOS = Object.fromEntries(Object.entries(LOGO_FILES).map(([path, url]) => [path.split('/').pop().replace(/\.(svg|png)$/, ''), url]));

const METHOD_LOGO = {
    pix: 'pix', spei: 'spei', pse: 'pse', bancolombia: 'bancolombia', 'bre-b (key)': 'bre-b', 'bre-b (qr)': 'bre-b',
    boleto: 'boleto', pagoefectivo: 'pagoefectivo', 'banco nacional': 'banco-nacional', gcash: 'gcash', fpx: 'fpx',
    "touch 'n go": 'touch-n-go', duitnow: 'duitnow', qris: 'qris', opay: 'opay', 'm-pesa': 'm-pesa',
    'capitec pay': 'capitec-pay', 'fawry pay': 'fawry', 'cash app': 'cash-app', 'apple pay': 'apple-pay',
    'google pay': 'google-pay', paypal: 'paypal', chime: 'chime', usdt: 'usdt',
    'visa card': 'visa', mastercard: 'mastercard', 'jcb card': 'jcb', 'unionpay card': 'unionpay',
    paynow: 'paynow', 'thai qr payment': 'thai-qr', 'singapore qr payment': 'sgqr',
    tron: 'tron', ethereum: 'ethereum', bsc: 'bsc', solana: 'solana', polygon: 'polygon',
};
// Generic methods (e.g. "Nigeria Bank Transfer") have no brand — show the method-type icon instead.
const TYPE_ICONS = { card: CreditCard, bank: Landmark, instant: Zap, wallet: Smartphone, cash: Banknote, qr: QrCode, crypto: Coins };

export const methodLogo = (method) => LOGOS[METHOD_LOGO[method.toLowerCase()]] || null;

export const MethodIcon = ({ method, size = 16 }) => {
    const logo = methodLogo(method);
    const radius = size > 24 ? 12 : 5;
    if (logo) {
        return (
            <span className="inline-flex shrink-0 items-center justify-center overflow-hidden bg-white" style={{ width: size + 4, height: size + 4, borderRadius: radius, padding: size > 24 ? 6 : 2 }}>
                <img src={logo} alt="" width={size} height={size} loading="lazy" decoding="async" className="h-full w-full object-contain" />
            </span>
        );
    }
    const type = methodType(method);
    const Icon = TYPE_ICONS[type] || Landmark;
    return (
        <span className="inline-flex shrink-0 items-center justify-center bg-white/[0.06]" style={{ width: size + 4, height: size + 4, borderRadius: radius, color: TYPE_COLORS[type], boxShadow: `inset 0 0 0 1px ${TYPE_COLORS[type]}33` }}>
            <Icon size={size > 24 ? Math.round(size * 0.5) : size - 4} strokeWidth={2} />
        </span>
    );
};

/** label: display text (e.g. a translated name); method: the channel name, for the logo. */
export const MethodChip = ({ method, label, size = 'sm' }) => (
    <span className={`inline-flex items-center gap-1.5 rounded-md border border-white/[0.07] bg-white/[0.035] text-text-heading/85 whitespace-nowrap ${size === 'lg' ? 'py-1.5 pl-1.5 pr-3 text-sm' : 'py-[3px] pl-[3px] pr-2 text-[11px] leading-none'}`}>
        <MethodIcon method={method} size={size === 'lg' ? 18 : 14} />
        {label ?? method}
    </span>
);

/** Counts up from 0 when scrolled into view. Server HTML contains the final value. */
export const CountUp = ({ value, suffix = '', duration = 1.4 }) => {
    const ref = useRef(null);
    const inView = useInView(ref, { once: true, margin: '-40px' });
    useEffect(() => {
        if (!inView || !ref.current) return;
        if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
        // requestAnimationFrame + ease-out-expo (no animation engine needed for a number)
        const start = performance.now();
        const ease = (x) => (x >= 1 ? 1 : 1 - 2 ** (-10 * x));
        let raf;
        const tick = (now) => {
            const p = Math.min(1, (now - start) / (duration * 1000));
            if (ref.current) ref.current.textContent = `${Math.round(ease(p) * value)}${suffix}`;
            if (p < 1) raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(raf);
    }, [inView, value, suffix, duration]);
    return <span ref={ref}>{value}{suffix}</span>;
};

/** Mouse-tracking spotlight: attach to a grid; cards inside need the `spotlight` class. */
export const handleSpotlight = (e) => {
    const cards = e.currentTarget.querySelectorAll('.spotlight');
    for (const card of cards) {
        const r = card.getBoundingClientRect();
        card.style.setProperty('--mx', `${e.clientX - r.left}px`);
        card.style.setProperty('--my', `${e.clientY - r.top}px`);
    }
};
