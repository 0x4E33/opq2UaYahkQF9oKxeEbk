import { useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';

// White single-colour logos (generated from src/assets/methods), in promotion order.
const LOGOS = import.meta.glob('../assets/marquee/*.png', { eager: true, query: '?url', import: 'default' });
const logo = (k) => LOGOS[`../assets/marquee/${k}.png`];

// [file, alt, height in px] — icon-like marks sit a little taller so every logo carries the same visual weight
const ITEMS = [
    ['fpx', 'FPX', 26], ['duitnow', 'DuitNow', 36], ['touch-n-go', "Touch 'n Go", 34], ['thai-qr', 'Thai QR Payment', 30],
    ['paynow', 'PayNow', 30], ['sgqr', 'SGQR', 28], ['qris', 'QRIS', 28], ['visa', 'Visa', 24], ['unionpay', 'UnionPay', 32],
    ['apple-pay', 'Apple Pay', 30], ['google-pay', 'Google Pay', 28], ['cash-app', 'Cash App', 34], ['jcb', 'JCB', 30],
    ['gcash', 'GCash', 26], ['spei', 'SPEI', 26], ['pse', 'PSE', 34], ['m-pesa', 'M-PESA', 24], ['paypal', 'PayPal', 34], ['usdt', 'USDT', 32],
];

// Intrinsic logo sizes (all 80px tall), so each slot is reserved before its lazy image arrives and the strip never jumps.
const RATIO = { 'apple-pay': 123, 'cash-app': 80, duitnow: 90, fpx: 237, gcash: 339, 'google-pay': 200, jcb: 106, 'm-pesa': 219, paynow: 121, paypal: 86, pse: 80, qris: 211, sgqr: 166, spei: 247, 'thai-qr': 264, 'touch-n-go': 80, unionpay: 128, usdt: 91, visa: 246 };

const Row = ({ ariaHidden }) => (
    <ul className="flex shrink-0 items-center gap-16 pr-16" aria-hidden={ariaHidden}>
        {ITEMS.map(([k, alt, h]) => (
            <li key={k} className="flex h-10 shrink-0 items-center opacity-60 transition-opacity duration-500 hover:opacity-100">
                <img src={logo(k)} alt={ariaHidden ? '' : alt} width={Math.round(((RATIO[k] || 80) * h) / 80)} height={h} style={{ height: h }} className="w-auto max-w-[170px] object-contain" loading="lazy" decoding="async" draggable="false" />
            </li>
        ))}
    </ul>
);

/**
 * Payment methods live on KaazPay, as a slow logo strip. Driven by the Web Animations API so hovering
 * eases the strip down to a crawl (and back) instead of stopping it dead; off-screen it doesn't run.
 */
const TrustMarquee = ({ className = 'relative py-12', title }) => {
    const { t } = useTranslation();
    const track = useRef(null);

    useEffect(() => {
        const el = track.current;
        if (!el || !el.animate || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
        const anim = el.animate([{ transform: 'translate3d(0,0,0)' }, { transform: 'translate3d(-50%,0,0)' }], { duration: 70000, iterations: Infinity });
        let rate = 1, target = 1, raf = 0;
        const ease = () => {
            rate += (target - rate) * 0.06;
            if (Math.abs(target - rate) < 0.002) rate = target;
            anim.updatePlaybackRate(rate);
            if (rate !== target) raf = requestAnimationFrame(ease);
        };
        const to = (v) => { target = v; cancelAnimationFrame(raf); raf = requestAnimationFrame(ease); };
        const slow = () => to(0.12);
        const resume = () => to(1);
        const box = el.parentElement;
        box.addEventListener('pointerenter', slow);
        box.addEventListener('pointerleave', resume);
        const io = new IntersectionObserver(([e]) => (e.isIntersecting ? anim.play() : anim.pause()));
        io.observe(box);
        return () => {
            cancelAnimationFrame(raf); io.disconnect(); anim.cancel();
            box.removeEventListener('pointerenter', slow);
            box.removeEventListener('pointerleave', resume);
        };
    }, []);

    return (
        <section className={className} aria-label={title || t('home.trust.title')}>
            <p className="container mx-auto mb-8 px-5 text-center text-xs font-semibold uppercase tracking-[0.2em] text-text-muted">
                {title || t('home.trust.title')}
            </p>
            <div className="marquee-mask flex overflow-hidden">
                <div ref={track} className="flex will-change-transform">
                    <Row />
                    <Row ariaHidden />
                </div>
            </div>
        </section>
    );
};

export default TrustMarquee;
