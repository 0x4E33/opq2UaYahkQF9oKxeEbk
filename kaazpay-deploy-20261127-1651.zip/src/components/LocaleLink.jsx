/* Drop-in replacements for react-router's Link / Navigate that keep the visitor in their language (/zh prefix). */
import { Link as RouterLink, Navigate as RouterNavigate, useLocation } from 'react-router-dom';
import { langFromPath, localizePath } from '../lib/locale';
import { prefetchPage } from '../lib/pages';

const useLang = () => langFromPath(useLocation().pathname);

/** Also prefetches the target page's code on hover / focus / touch, so navigation feels instant. */
export const Link = ({ to, onMouseEnter, onFocus, onTouchStart, ...props }) => {
    const href = localizePath(to, useLang());
    const warm = (handler) => (e) => { prefetchPage(href); handler?.(e); };
    return <RouterLink to={href} onMouseEnter={warm(onMouseEnter)} onFocus={warm(onFocus)} onTouchStart={warm(onTouchStart)} {...props} />;
};

export const Navigate = ({ to, ...props }) => <RouterNavigate to={localizePath(to, useLang())} {...props} />;
