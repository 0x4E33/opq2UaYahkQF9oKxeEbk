import logoMark from '../assets/logo-mark.png';

/** KaazPay lockup: the official cube mark + "KaazPay" wordmark (same proportions as the nav/footer lockup spec). */
const BrandLogo = ({ size = 'md' }) => {
    const lg = size === 'lg';
    return (
        <span className={`inline-flex items-center ${lg ? 'gap-3.5' : 'gap-3'}`}>
            <img src={logoMark} alt="" width="148" height="160" className={lg ? 'h-10 w-auto' : 'h-8 w-auto'} />
            <span className={`font-display font-bold tracking-[0.01em] text-white ${lg ? 'text-2xl' : 'text-xl'}`}>
                Kaaz<span className="text-primary">Pay</span>
            </span>
        </span>
    );
};

export default BrandLogo;
