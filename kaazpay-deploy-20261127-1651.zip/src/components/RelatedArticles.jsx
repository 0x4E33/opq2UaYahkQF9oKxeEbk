import { useTranslation } from 'react-i18next';
import { articlesFor } from '../content';
import ArticleCard from './ArticleCard';

/** "Guides & comparisons" strip for market / method / industry pages (internal links into the content hub). */
const RelatedArticles = ({ field, value, className = 'mt-20' }) => {
    const { t, i18n } = useTranslation();
    const list = articlesFor(field, value).slice(0, 4);
    if (!list.length) return null;
    return (
        <section className={className} aria-labelledby={`rel-articles-${value}`}>
            <h2 id={`rel-articles-${value}`} className="text-2xl font-semibold text-white">{t('articles.relatedGuides')}</h2>
            <ul className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {list.map((a) => <li key={a.slug}><ArticleCard article={a} lang={i18n.language} t={t} /></li>)}
            </ul>
        </section>
    );
};

export default RelatedArticles;
