import { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

/**
 * Accordion FAQ. Every answer stays in the HTML (collapsed with CSS, not unmounted), so
 * prerendered pages show search engines and AI crawlers the full Q&A — matching the FAQPage JSON-LD.
 */
const FaqList = ({ faq, initial = 0 }) => {
    const [open, setOpen] = useState(initial);
    return (
        <div className="divide-y divide-white/[0.07] rounded-2xl border border-white/[0.07] bg-surface/60">
            {faq.map((f, i) => {
                const isOpen = open === i;
                return (
                    <div key={f.q}>
                        <h3>
                            <button type="button" onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen}
                                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left font-medium text-white">
                                {f.q}
                                <span className={isOpen ? 'text-primary' : 'text-text-muted'}>{isOpen ? <Minus size={18} /> : <Plus size={18} />}</span>
                            </button>
                        </h3>
                        <div className={`grid transition-[grid-template-rows,opacity] duration-300 ease-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}>
                            <div className="overflow-hidden">
                                <p className="px-5 pb-5 text-text-body">{f.a}</p>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default FaqList;
