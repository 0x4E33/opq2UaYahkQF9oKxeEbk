import { Fragment } from 'react';
import { useTranslation } from 'react-i18next';
import { Lightbulb } from 'lucide-react';
import { Link } from './LocaleLink';

/**
 * Tiny renderer for article text: **bold** and [link text](/path). Internal links stay in the
 * reader's language (LocaleLink); http(s) links open in a new tab. Payment-method / market links use a
 * quiet dotted style; other links use the orange accent.
 */
const TOKEN = /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;

export const Inline = ({ text }) => (
    <>
        {String(text).split(TOKEN).filter(Boolean).map((part, i) => {
            if (part.startsWith('**') && part.endsWith('**')) return <strong key={i} className="font-semibold text-white">{part.slice(2, -2)}</strong>;
            const link = part.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
            if (link) {
                const [, label, href] = link;
                // Reference links (a payment method / market) stay quiet so text reads cleanly;
                // "go somewhere" links (guides, contact, developers) keep the brand accent.
                const reference = /^\/(methods|payment-methods)\//.test(href);
                const cls = reference
                    ? 'text-text-heading underline decoration-white/30 decoration-dotted underline-offset-[5px] transition-colors hover:text-primary hover:decoration-primary/70'
                    : 'font-medium text-primary underline decoration-primary/30 underline-offset-4 transition-colors hover:decoration-primary';
                return href.startsWith('/')
                    ? <Link key={i} to={href} className={cls}>{label}</Link>
                    : <a key={i} href={href} target="_blank" rel="noopener noreferrer" className={cls}>{label}</a>;
            }
            return <Fragment key={i}>{part}</Fragment>;
        })}
    </>
);

/** One content block: paragraph string, { list }, { steps }, { table }, { note }. */
/** Wide tables scroll sideways on phones: a right-edge fade + one-line hint make that discoverable. */
const TableBlock = ({ table }) => {
    const { t } = useTranslation();
    const wide = table.head.length >= 3;
    return (
        <div>
            <div className="relative">
                <div className="overflow-x-auto rounded-2xl border border-white/[0.08]">
                    <table className="w-full min-w-[520px] border-collapse text-left text-sm">
                        <thead className="bg-white/[0.04]">
                            <tr>{table.head.map((h, i) => <th key={i} scope="col" className="whitespace-nowrap px-4 py-3 font-semibold text-white">{h}</th>)}</tr>
                        </thead>
                        <tbody>
                            {table.rows.map((row, r) => (
                                <tr key={r} className="border-t border-white/[0.06]">
                                    {row.map((cell, c) => (c === 0
                                        ? <th key={c} scope="row" className="whitespace-nowrap px-4 py-3 align-top font-medium text-white"><Inline text={cell} /></th>
                                        : <td key={c} className="px-4 py-3 align-top text-text-body"><Inline text={cell} /></td>))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                {wide && <div className="pointer-events-none absolute inset-y-px right-px w-10 rounded-r-2xl bg-gradient-to-l from-background to-transparent sm:hidden" aria-hidden="true" />}
            </div>
            {wide && <p className="mt-2 text-xs text-text-muted sm:hidden">{t('articles.swipe')}</p>}
        </div>
    );
};

export const Block = ({ block }) => {
    if (typeof block === 'string') return <p className="text-[1.0625rem] leading-[1.85] text-text-body"><Inline text={block} /></p>;
    if (block.list) {
        return (
            <ul className="space-y-2 pl-1">
                {block.list.map((item, i) => (
                    <li key={i} className="flex gap-3 text-[1.0625rem] leading-[1.8] text-text-body">
                        <span className="mt-[0.75rem] h-1.5 w-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
                        <span><Inline text={item} /></span>
                    </li>
                ))}
            </ul>
        );
    }
    if (block.steps) {
        return (
            <ol className="space-y-3">
                {block.steps.map((item, i) => (
                    <li key={i} className="flex gap-3 text-[1.0625rem] leading-[1.8] text-text-body">
                        <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border border-primary/40 bg-primary/10 font-mono text-xs font-bold text-primary">{i + 1}</span>
                        <span><Inline text={item} /></span>
                    </li>
                ))}
            </ol>
        );
    }
    if (block.table) return <TableBlock table={block.table} />;
    if (block.note) {
        return (
            <aside className="flex gap-3 rounded-2xl border border-primary/20 bg-primary/[0.06] p-4 text-sm leading-relaxed text-text-heading/90">
                <Lightbulb size={18} className="mt-0.5 shrink-0 text-primary" />
                <span><Inline text={block.note} /></span>
            </aside>
        );
    }
    return null;
};
