import MARKET_CREDITS from '../assets/markets/credits.json';

/**
 * Page photography & footage (credits in each src/assets/<dir>/credits.json).
 * Globbed so a missing file falls back gracefully instead of breaking the build.
 */
const FILES = import.meta.glob([
    '../assets/{about,capabilities,developers,roadmap,contact,markets}/*.{webp,mp4,webm}',
], { eager: true, query: '?url', import: 'default' });

export const asset = (path) => FILES[`../assets/${path}`] || null;

/** { video: { mp4, webm } | null, poster } for <dir>/<name>.mp4|webm + <name>-poster.webp (or <name>.webp). */
export const heroMedia = (dir, name = 'hero') => {
    const mp4 = asset(`${dir}/${name}.mp4`);
    return {
        // -sm: 640px copies for phones (same footage, a fraction of the bytes)
        video: mp4 ? { mp4, webm: asset(`${dir}/${name}.webm`), mp4Small: asset(`${dir}/${name}-sm.mp4`), webmSmall: asset(`${dir}/${name}-sm.webm`) } : null,
        poster: asset(`${dir}/${name}-poster.webp`) || asset(`${dir}/${name}.webp`),
    };
};

// Regions without a usable local payment photo borrow a location-neutral, hands-only payment scene.
const REGION_PHOTO = { americas: 'brazil', africa: 'apac' };

const marketPhotoKey = (market) => [market.slug, market.region, REGION_PHOTO[market.region]]
    .find((k) => k && asset(`markets/${k}.webp`));

// 1200w copies of the market headers (scripts/make-variants.mjs) for phones.
const MARKETS_SM = import.meta.glob('../assets/markets/sm/*.webp', { eager: true, query: '?url', import: 'default' });
export const marketPhotoSrcSet = (market) => {
    const key = marketPhotoKey(market);
    const sm = key && MARKETS_SM[`../assets/markets/sm/${key}.webp`];
    return sm ? `${sm} 1200w, ${asset(`markets/${key}.webp`)} 2400w` : undefined;
};

/** Header picture for a market page: a market-specific payment scene, else the region's. */
export const marketPhoto = (market) => {
    const key = marketPhotoKey(market);
    return key ? asset(`markets/${key}.webp`) : null;
};

// Where the payment element sits in a photo, so the header crop keeps it in view (CSS object-position).
const PHOTO_FOCUS = { africa: '92% center', malaysia: '62% center', japan: '35% center', 'united-states': '100% center' };
export const marketPhotoPosition = (market) => PHOTO_FOCUS[marketPhotoKey(market)] || 'center';

/** Display credit for that picture when its licence requires one (CC BY / CC BY-SA), else null. */
export const marketPhotoAttribution = (market) => MARKET_CREDITS[marketPhotoKey(market)]?.attribution || null;
