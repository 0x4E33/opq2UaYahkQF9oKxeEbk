/**
 * KaazPay milestones since 2018 (copy in locales: roadmap.milestones.<key>). The last entry is upcoming.
 * `markets`: market slugs that went live, shown as flags on the roadmap.
 */
export const MILESTONES = [
    { key: 'genesis', year: '2018', date: '2018' },
    { key: 'malaysia', year: '2018', date: 'Q4 2018', markets: ['malaysia'] },
    { key: 'apac', year: '2019', date: '2019', markets: ['thailand', 'singapore', 'philippines'] },
    { key: 'settlement', year: '2020', date: '2020', markets: ['usdt', 'indonesia'] },
    { key: 'latam', year: '2021', date: '2021', markets: ['mexico', 'colombia', 'brazil'] },
    { key: 'smartRouting', year: '2022', date: '2022' },
    { key: 'africa', year: '2023', date: '2023', markets: ['kenya', 'nigeria', 'south-africa', 'egypt', 'ghana', 'cote-d-ivoire'] },
    { key: 'europe', year: '2024', date: '2024', markets: ['eurozone', 'united-kingdom', 'united-arab-emirates', 'peru', 'chile'] },
    { key: 'us', year: '2025', date: '2025', markets: ['united-states'] },
    { key: 'cards', year: '2026', date: '2026', markets: ['global-cards', 'japan'] },
    { key: 'next', year: '', date: '', upcoming: true },
];
