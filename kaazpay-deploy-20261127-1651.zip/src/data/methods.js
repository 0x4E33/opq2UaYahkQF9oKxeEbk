/**
 * Payment-method pages (/methods/:slug) — one page per branded method, so merchants searching
 * "Pix payment gateway", "M-Pesa API", "JCB 代收" etc. land on a page about exactly that.
 *
 * Availability (which markets, pay-in / payout) is derived from channels.js — never duplicated here.
 *   match : exact method names as written in channels.js, or a function (name) => boolean
 *   about : one or two factual sentences on what the method is (en / zh)
 */
import { MARKETS, methodType } from './channels';

export const METHODS = [
    // ---------- Cards ----------
    { slug: 'visa', name: 'Visa', match: ['Visa Card'],
        about: { en: "Visa is a global card network. Banks in nearly every country issue Visa credit, debit and prepaid cards, making it one of the most widely accepted ways for international customers to pay.", zh: "Visa 是全球性的卡组织，几乎每个国家的银行都发行 Visa 信用卡、借记卡与预付卡，是国际顾客最常用的付款方式之一。" } },
    { slug: 'mastercard', name: 'Mastercard', match: ['Mastercard'],
        about: { en: "Mastercard is a worldwide card network covering credit, debit and prepaid cards, accepted in more than 200 countries and territories.", zh: "Mastercard（万事达卡）是覆盖信用卡、借记卡与预付卡的全球卡组织，受理范围超过 200 个国家和地区。" } },
    { slug: 'unionpay', name: { en: 'UnionPay', zh: '银联 UnionPay' }, match: ['UnionPay Card'],
        about: { en: "UnionPay is a card network originating in China and one of the largest in the world by cards in circulation. It is widely held by Chinese consumers and travellers.", zh: "银联（UnionPay）是源自中国的卡组织，流通卡量位居全球前列，在中国消费者与旅客中普及率很高。" } },
    { slug: 'jcb', name: 'JCB', match: ['JCB Card'],
        about: { en: "JCB is Japan's domestic card network. It is widely held by Japanese consumers, making it an important option when selling to customers in Japan.", zh: "JCB 是日本本土的卡组织，在日本消费者中普及率很高，是面向日本顾客销售时的重要付款方式。" } },

    // ---------- Latin America ----------
    { slug: 'pix', name: 'Pix', match: ['Pix'],
        about: { en: "Pix is the instant payment system created by Brazil's central bank. Customers pay by scanning a QR code or entering a Pix key, 24/7, and funds arrive in seconds. It is now the most widely used payment method in Brazil.", zh: "Pix 是巴西央行建立的即时支付系统，顾客可扫描二维码或使用 Pix 密钥全天候付款，资金数秒内到账，现已成为巴西使用最广泛的付款方式。" } },
    { slug: 'boleto', name: 'Boleto', match: ['Boleto'],
        about: { en: "Boleto Bancário is a Brazilian payment slip. The customer receives a boleto and pays it in their banking app, at a bank branch or at an authorised outlet, which suits customers who do not use cards.", zh: "Boleto（Boleto Bancário）是巴西的付款单据，顾客收到 Boleto 后可在银行 App、银行网点或授权网点付款，适合不使用银行卡的顾客。" } },
    { slug: 'spei', name: 'SPEI', match: ['SPEI'],
        about: { en: "SPEI is Mexico's real-time interbank transfer network, operated by Banco de México. Customers send money from their own bank account to a CLABE reference generated for the order.", zh: "SPEI 是墨西哥央行运营的实时银行间转账网络，顾客从自己的银行账户向订单生成的 CLABE 账号转账即可。" } },
    { slug: 'pse', name: 'PSE', match: ['PSE'],
        about: { en: "PSE (Pagos Seguros en Línea) is Colombia's online bank payment service, run by ACH Colombia, that lets customers pay straight from an account at almost any Colombian bank.", zh: "PSE（Pagos Seguros en Línea）是 ACH Colombia 运营的哥伦比亚网银支付服务，顾客可从几乎任何哥伦比亚银行账户直接付款。" } },
    { slug: 'bancolombia', name: 'Bancolombia', match: ['Bancolombia'],
        about: { en: "Bancolombia is the largest bank in Colombia. Its customers can pay merchants directly from their Bancolombia account.", zh: "Bancolombia 是哥伦比亚最大的银行，其账户持有人可以直接从 Bancolombia 账户向商户付款。" } },
    { slug: 'bre-b', name: 'Bre-B', match: ['Bre-B (Key)', 'Bre-B (QR)'],
        about: { en: "Bre-B is Colombia's instant payment system from Banco de la República. Customers pay in seconds using a payment key (llave) or by scanning a QR code.", zh: "Bre-B 是哥伦比亚央行推出的即时支付系统，顾客通过支付密钥（llave）或扫描二维码，几秒内即可完成付款。" } },
    { slug: 'pagoefectivo', name: 'PagoEfectivo', match: ['PagoEfectivo'],
        about: { en: "PagoEfectivo is a Peruvian payment method based on a payment code: the customer pays that code through online banking, a mobile wallet or at an agent or store.", zh: "PagoEfectivo 是秘鲁基于付款码的支付方式，顾客可通过网银、手机钱包或代理网点、商店支付该付款码。" } },
    { slug: 'banco-nacional', name: 'Banco Nacional', match: ['Banco Nacional'],
        about: { en: "Banco Nacional de Costa Rica is the country's largest state-owned bank. Its customers can pay merchants directly from their account.", zh: "Banco Nacional 是哥斯达黎加最大的国有银行，其客户可以直接从账户向商户付款。" } },

    // ---------- Asia Pacific ----------
    { slug: 'paynow', name: 'PayNow', match: ['PayNow'],
        about: { en: 'PayNow is Singapore’s real-time payment service, offered by the major Singapore banks. Payers send money instantly from their banking app to a mobile number, NRIC or business UEN, or by scanning a PayNow QR code.', zh: 'PayNow 是新加坡各大银行共同提供的实时支付服务，付款人可在银行 App 中通过手机号、身份证号或企业 UEN 转账，或扫描 PayNow 二维码，资金即时到账。' } },
    { slug: 'singapore-qr', name: { en: 'Singapore QR Payment', zh: '新加坡 QR 扫码支付' }, match: ['Singapore QR Payment'],
        about: { en: 'QR payment in Singapore lets customers scan a merchant QR code — Singapore’s unified SGQR label carries PayNow and other schemes — and approve the payment in their banking or wallet app.', zh: '新加坡的 QR 扫码支付让顾客扫描商户二维码（新加坡统一的 SGQR 标签可承载 PayNow 等多种方案），在银行或钱包 App 中确认付款。' } },
    { slug: 'thai-qr', name: { en: 'Thai QR Payment', zh: '泰国 QR 扫码支付' }, match: ['Thai QR Payment'],
        about: { en: 'Thai QR Payment is Thailand’s standardised QR code for payments, built on the PromptPay infrastructure. Customers scan it with any participating Thai banking app and the payment is confirmed in real time.', zh: 'Thai QR Payment 是泰国基于 PromptPay 基础设施的标准化支付二维码，顾客用任何参与的泰国银行 App 扫码即可付款，实时确认。' } },
    { slug: 'gcash', name: 'GCash', match: ['GCash'],
        about: { en: "GCash is the most widely used e-wallet in the Philippines, with tens of millions of users paying online, settling bills, sending transfers and paying by QR in stores.", zh: "GCash 是菲律宾使用最广泛的电子钱包，数千万人用它进行网购、缴费、转账与门店扫码付款。" } },
    { slug: 'fpx', name: 'FPX', match: ['FPX'],
        about: { en: "FPX is Malaysia's online banking payment network operated by PayNet. At checkout the customer picks their bank and approves the payment in internet or mobile banking.", zh: "FPX 是 PayNet 运营的马来西亚网银支付网络，顾客在收银台选择自己的银行，在网银或手机银行中确认付款。" } },
    { slug: 'duitnow', name: 'DuitNow', match: ['DuitNow'],
        about: { en: "DuitNow is Malaysia's national real-time payment service and common QR standard from PayNet, supported by banks and e-wallets alike.", zh: "DuitNow 是 PayNet 推出的马来西亚全国实时支付服务与统一二维码标准，银行与电子钱包都支持。" } },
    { slug: 'touch-n-go', name: "Touch 'n Go", match: ["Touch 'n Go"],
        about: { en: "Touch 'n Go eWallet is one of the most widely used e-wallets in Malaysia, used for online purchases, in-store QR payments, tolls and public transport.", zh: "Touch 'n Go eWallet 是马来西亚使用最广泛的电子钱包之一，可用于网购、门店扫码付款、过路费与公共交通。" } },
    { slug: 'qris', name: 'QRIS', match: ['QRIS'],
        about: { en: "QRIS is Bank Indonesia's national QR standard. A single QRIS code can be paid from any Indonesian banking app or e-wallet, including GoPay, OVO, DANA and ShopeePay.", zh: "QRIS 是印尼央行推出的全国统一二维码标准，任何印尼银行 App 或电子钱包（包括 GoPay、OVO、DANA、ShopeePay）都能扫同一个 QRIS 码付款。" } },

    // ---------- Africa ----------
    { slug: 'm-pesa', name: 'M-Pesa', match: ['M-Pesa'],
        about: { en: "M-Pesa is Safaricom's mobile money service and the leading way to pay in Kenya. Customers approve payments on their phone, usually by entering a PIN.", zh: "M-Pesa 是 Safaricom 的移动钱包服务，也是肯尼亚最主要的付款方式，顾客通常在手机上输入 PIN 确认付款。" } },
    { slug: 'mobile-money', name: { en: 'Mobile Money', zh: '移动钱包（Mobile Money）' }, match: (n) => n.startsWith('Mobile Money'),
        about: { en: "Mobile money is the main way to pay across much of Africa. Customers confirm payments on their phone, without needing a bank account or card.", zh: "移动钱包（Mobile Money）是非洲大部分地区的主流付款方式，顾客在手机上确认付款，无需银行账户或银行卡。" } },
    { slug: 'opay', name: 'OPay', match: ['OPay'],
        about: { en: "OPay is one of Nigeria's largest mobile wallets and digital banks, widely used for payments and transfers.", zh: "OPay 是尼日利亚规模最大的移动钱包与数字银行之一，广泛用于付款与转账。" } },
    { slug: 'fawry', name: 'Fawry Pay', match: ['Fawry Pay'],
        about: { en: "Fawry is Egypt's largest payments network: customers pay with a reference number at Fawry outlets, ATMs, mobile wallets or online.", zh: "Fawry 是埃及最大的支付网络，顾客凭参考号在 Fawry 网点、ATM、手机钱包或线上付款。" } },
    { slug: 'capitec-pay', name: 'Capitec Pay', match: ['Capitec Pay'],
        about: { en: "Capitec Pay lets clients of Capitec, South Africa's largest retail bank by number of clients, approve a payment inside their banking app without typing card details.", zh: "Capitec 是南非客户数最多的零售银行。通过 Capitec Pay，其客户可在银行 App 内直接确认付款，无需输入卡号。" } },
    { slug: 'eft', name: 'EFT', match: ['EFT'],
        about: { en: "EFT (electronic funds transfer) lets South African customers pay from their bank account through online banking.", zh: "EFT（电子资金转账）让南非顾客通过网银从银行账户付款。" } },

    // ---------- United States ----------
    { slug: 'cash-app', name: 'Cash App', match: ['Cash App'],
        about: { en: "Cash App, from Block, is one of the most popular payment apps in the United States, used to send money, pay online and receive funds.", zh: "Cash App 是 Block 旗下的应用，是美国最受欢迎的转账、线上支付与收款应用之一。" } },
    { slug: 'apple-pay', name: 'Apple Pay', match: ['Apple Pay'],
        about: { en: "Apple Pay is Apple's digital wallet. Customers pay with cards saved on their iPhone or other Apple device and confirm with Face ID or Touch ID.", zh: "Apple Pay 是苹果的数字钱包，顾客使用保存在 iPhone 或其他苹果设备上的银行卡付款，并以 Face ID 或 Touch ID 确认。" } },
    { slug: 'google-pay', name: 'Google Pay', match: ['Google Pay'],
        about: { en: "Google Pay is Google's digital wallet. Customers pay with cards saved to their Google account on Android, in Chrome and across the web.", zh: "Google Pay 是谷歌的数字钱包，顾客使用保存在 Google 账户中的银行卡，在安卓设备、Chrome 与网页上付款。" } },
    { slug: 'paypal', name: 'PayPal', match: ['PayPal'],
        about: { en: "PayPal is one of the world's largest digital wallets. With KaazPay, merchants can send payouts to recipients' PayPal accounts in the United States.", zh: "PayPal 是全球最大的数字钱包之一。通过 KaazPay，商户可以向美国收款人的 PayPal 账户代付。" } },
];

const nameOf = (method, l) => (typeof method.name === 'string' ? method.name : method.name[l && l.startsWith('zh') ? 'zh' : 'en']);
export const methodName = nameOf;

const matches = (method, name) => (typeof method.match === 'function' ? method.match(name) : method.match.includes(name));

/** Markets where this method is available for pay-in and/or payout. */
export const methodMarkets = (method) => ({
    payin: MARKETS.filter((m) => m.payin.some((p) => matches(method, p))),
    payout: MARKETS.filter((m) => Array.isArray(m.payout) && m.payout.some((p) => matches(method, p))),
});

/** The type of method (card / wallet / instant ...), from its first listed channel name. */
export const methodKind = (method) => {
    const { payin, payout } = methodMarkets(method);
    const first = payin[0]?.payin.find((p) => matches(method, p)) || payout[0]?.payout.find((p) => matches(method, p));
    return first ? methodType(first) : 'bank';
};

export const getMethod = (slug) => METHODS.find((m) => m.slug === slug);

/** Method page for a channel name as written in channels.js (e.g. "Bre-B (QR)" -> bre-b), or null. */
export const methodForChannel = (name) => METHODS.find((m) => matches(m, name)) || null;

/** A channel name for this method as written in channels.js (e.g. "Visa Card") — used for its logo/icon. */
export const methodChannel = (method) => {
    const { payin, payout } = methodMarkets(method);
    return payin[0]?.payin.find((p) => matches(method, p)) || payout[0]?.payout.find((p) => matches(method, p)) || methodName(method, 'en');
};
