/**
 * Official KaazPay contact points — single source for the contact page, navbar, footer, mobile bar,
 * JSON-LD and llms.txt. KaazPay has no public email address: business contact is on Telegram.
 */
export const PORTAL_URL = 'https://www.kaazpay.com';   // merchant dashboard (login)
export const TG_SALES = ['KaazPayEZ', 'KaazPay_BD2'];  // business development contacts
export const TG_PRIMARY = TG_SALES[0];
export const TG_CHANNEL = 'KaazpayOfficial';          // official announcement channel
export const tgUrl = (username) => `https://t.me/${username}`;
export const FOUNDED = '2018';
