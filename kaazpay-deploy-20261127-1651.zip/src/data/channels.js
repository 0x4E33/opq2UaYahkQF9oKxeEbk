/**
 * KaazPay payment channel coverage — single source of truth.
 *
 * Used by: home page coverage section, /payment-methods/:slug country pages,
 * footer market directory, sitemap.xml, llms.txt and JSON-LD (via scripts/prerender.mjs).
 *
 * To add / change a channel, edit this file only.
 *   payin  : list of pay-in (collection / 代收) methods
 *   payout : array -> payout (代付) methods
 *            false -> pay-in only
 *
 * Order matters: lists across the site follow this array (see PRIORITY below).
 */

export const SITE_URL = 'https://kaazpay.info';

export const REGIONS = [
    { key: 'apac', en: 'Asia Pacific', zh: '亚太' },
    { key: 'global', en: 'Global', zh: '全球' },
    { key: 'americas', en: 'Americas', zh: '美洲' },
    { key: 'europe_me', en: 'Europe & Middle East', zh: '欧洲及中东' },
    { key: 'africa', en: 'Africa', zh: '非洲' },
];

/** Blockchain networks supported for USDT pay-in, payout and settlement (networks, not payment methods). */
export const USDT_CHAINS = ['Tron', 'Ethereum', 'BSC', 'Solana', 'Polygon'];

// Order = KaazPay promotion priority: Malaysia → Thailand → Singapore → Indonesia → global cards → United States → Japan →
// Europe bank transfers (EUR/GBP/AED), then the rest of Asia Pacific, Latin America, Africa and global USDT.
export const PRIORITY = ['malaysia', 'thailand', 'singapore', 'indonesia', 'global-cards', 'united-states', 'japan', 'eurozone', 'united-kingdom', 'united-arab-emirates'];

export const MARKETS = [
    { slug: 'malaysia', iso: 'my', region: 'apac', currency: 'MYR', name: { en: 'Malaysia', zh: '马来西亚' }, payin: ['FPX', "Touch 'n Go", 'DuitNow'], payout: ['Bank Transfer'] },
    { slug: 'thailand', iso: 'th', region: 'apac', currency: 'THB', name: { en: 'Thailand', zh: '泰国' }, payin: ['Thailand Bank Transfer', 'Thai QR Payment'], payout: ['Bank Transfer'] },
    { slug: 'singapore', iso: 'sg', region: 'apac', currency: 'SGD', name: { en: 'Singapore', zh: '新加坡' }, payin: ['iBanking', 'PayNow', 'Singapore QR Payment'], payout: ['Bank Transfer'] },
    { slug: 'indonesia', iso: 'id', region: 'apac', currency: 'IDR', name: { en: 'Indonesia', zh: '印度尼西亚' }, payin: ['QRIS'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'global-cards', iso: null, region: 'global', currency: 'Multi-currency', name: { en: 'Global Cards', zh: '全球信用卡' }, payin: ['Visa Card', 'Mastercard', 'UnionPay Card'], payout: false, cardBrands: true },
    { slug: 'united-states', iso: 'us', region: 'americas', currency: 'USD', name: { en: 'United States', zh: '美国' }, payin: ['Cash App', 'Apple Pay', 'Google Pay'], payout: ['PayPal', 'Cash App', 'Chime', 'Cards', 'ACH'] },
    { slug: 'japan', iso: 'jp', region: 'apac', currency: 'JPY', name: { en: 'Japan', zh: '日本' }, payin: ['JCB Card'], payout: false },
    { slug: 'eurozone', iso: 'eu', region: 'europe_me', currency: 'EUR', name: { en: 'Eurozone (EUR)', zh: '欧元区 (EUR)' }, payin: ['EUR Bank Transfer'], payout: ['Bank Transfer'] },
    { slug: 'united-kingdom', iso: 'gb', region: 'europe_me', currency: 'GBP', name: { en: 'United Kingdom', zh: '英国' }, payin: ['GBP Bank Transfer'], payout: ['Bank Transfer'] },
    { slug: 'united-arab-emirates', iso: 'ae', region: 'europe_me', currency: 'AED', name: { en: 'United Arab Emirates', zh: '阿联酋' }, payin: ['AED Bank Transfer'], payout: ['Bank Transfer'] },

    { slug: 'philippines', iso: 'ph', region: 'apac', currency: 'PHP', name: { en: 'Philippines', zh: '菲律宾' }, payin: ['GCash'], payout: ['Bank Transfer'] },
    { slug: 'mexico', iso: 'mx', region: 'americas', currency: 'MXN', name: { en: 'Mexico', zh: '墨西哥' }, payin: ['SPEI', 'Mexico Bank Transfer', 'Mexico Cash Payment'], payout: ['Bank Transfer'] },
    { slug: 'colombia', iso: 'co', region: 'americas', currency: 'COP', name: { en: 'Colombia', zh: '哥伦比亚' }, payin: ['PSE', 'Bancolombia', 'Bre-B (Key)', 'Bre-B (QR)', 'Colombia Bank Transfer', 'Colombia Cash Payment'], payout: ['Bank Transfer'] },
    { slug: 'brazil', iso: 'br', region: 'americas', currency: 'BRL', name: { en: 'Brazil', zh: '巴西' }, payin: ['Pix', 'Brazil Bank Transfer', 'Brazil Cash Payment', 'Boleto'], payout: ['Bank Transfer'] },
    { slug: 'costa-rica', iso: 'cr', region: 'americas', currency: 'CRC', name: { en: 'Costa Rica', zh: '哥斯达黎加' }, payin: ['Banco Nacional', 'Costa Rica Cash Payment'], payout: false },
    { slug: 'el-salvador', iso: 'sv', region: 'americas', currency: 'USD', name: { en: 'El Salvador', zh: '萨尔瓦多' }, payin: ['El Salvador Cash Payment'], payout: false },
    { slug: 'guatemala', iso: 'gt', region: 'americas', currency: 'GTQ', name: { en: 'Guatemala', zh: '危地马拉' }, payin: ['Guatemala Bank Transfer', 'Guatemala Cash Payment'], payout: false },
    { slug: 'chile', iso: 'cl', region: 'americas', currency: 'CLP', name: { en: 'Chile', zh: '智利' }, payin: ['Chile Bank Transfer', 'Chile Cash Payment'], payout: false },
    { slug: 'ecuador', iso: 'ec', region: 'americas', currency: 'USD', name: { en: 'Ecuador', zh: '厄瓜多尔' }, payin: ['Ecuador Bank Transfer', 'Ecuador Cash Payment'], payout: false },
    { slug: 'peru', iso: 'pe', region: 'americas', currency: 'PEN', name: { en: 'Peru', zh: '秘鲁' }, payin: ['Peru Bank Transfer', 'Peru Cash Payment', 'PagoEfectivo'], payout: false },
    { slug: 'nigeria', iso: 'ng', region: 'africa', currency: 'NGN', name: { en: 'Nigeria', zh: '尼日利亚' }, payin: ['Nigeria Bank Transfer', 'Nigeria Cards', 'OPay'], payout: ['Bank Transfer'] },
    { slug: 'kenya', iso: 'ke', region: 'africa', currency: 'KES', name: { en: 'Kenya', zh: '肯尼亚' }, payin: ['M-Pesa', 'Kenya Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'south-africa', iso: 'za', region: 'africa', currency: 'ZAR', name: { en: 'South Africa', zh: '南非' }, payin: ['EFT', 'Capitec Pay', 'South Africa Cards'], payout: ['Bank Transfer'] },
    { slug: 'egypt', iso: 'eg', region: 'africa', currency: 'EGP', name: { en: 'Egypt', zh: '埃及' }, payin: ['Fawry Pay'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'ghana', iso: 'gh', region: 'africa', currency: 'GHS', name: { en: 'Ghana', zh: '加纳' }, payin: ['Ghana Bank Transfer', 'Mobile Money GH', 'Ghana Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'tanzania', iso: 'tz', region: 'africa', currency: 'TZS', name: { en: 'Tanzania', zh: '坦桑尼亚' }, payin: ['Mobile Money TZ', 'Tanzania Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'uganda', iso: 'ug', region: 'africa', currency: 'UGX', name: { en: 'Uganda', zh: '乌干达' }, payin: ['Mobile Money UG', 'Uganda Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'rwanda', iso: 'rw', region: 'africa', currency: 'RWF', name: { en: 'Rwanda', zh: '卢旺达' }, payin: ['Mobile Money RW', 'Rwanda Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'cote-d-ivoire', iso: 'ci', region: 'africa', currency: 'XOF', name: { en: "Côte d'Ivoire", zh: '科特迪瓦' }, payin: ['Mobile Money CI', 'Ivory Coast Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'senegal', iso: 'sn', region: 'africa', currency: 'XOF', name: { en: 'Senegal', zh: '塞内加尔' }, payin: ['Mobile Money SN', 'Senegal Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'benin', iso: 'bj', region: 'africa', currency: 'XOF', name: { en: 'Benin', zh: '贝宁' }, payin: ['Mobile Money BJ', 'Benin Cards'], payout: ['Mobile Money'] },
    { slug: 'cameroon', iso: 'cm', region: 'africa', currency: 'XAF', name: { en: 'Cameroon', zh: '喀麦隆' }, payin: ['Mobile Money CM', 'Cameroon Cards'], payout: ['Bank Transfer', 'Mobile Money'] },
    { slug: 'guinea', iso: 'gn', region: 'africa', currency: 'GNF', name: { en: 'Guinea', zh: '几内亚' }, payin: ['Mobile Money GN', 'Guinea Cards'], payout: ['Mobile Money'] },
    { slug: 'zambia', iso: 'zm', region: 'africa', currency: 'ZMW', name: { en: 'Zambia', zh: '赞比亚' }, payin: ['Mobile Money ZM', 'Zambia Cards'], payout: ['Mobile Money'] },
    { slug: 'burkina-faso', iso: 'bf', region: 'africa', currency: 'XOF', name: { en: 'Burkina Faso', zh: '布基纳法索' }, payin: ['Mobile Money BF', 'Burkina Faso Cards'], payout: false },
    { slug: 'mali', iso: 'ml', region: 'africa', currency: 'XOF', name: { en: 'Mali', zh: '马里' }, payin: ['Mobile Money ML', 'Mali Cards'], payout: false },
    { slug: 'morocco', iso: 'ma', region: 'africa', currency: 'MAD', name: { en: 'Morocco', zh: '摩洛哥' }, payin: ['Morocco Cards'], payout: false },
    { slug: 'algeria', iso: 'dz', region: 'africa', currency: 'DZD', name: { en: 'Algeria', zh: '阿尔及利亚' }, payin: ['Algeria Cards'], payout: false },
    { slug: 'gabon', iso: 'ga', region: 'africa', currency: 'XAF', name: { en: 'Gabon', zh: '加蓬' }, payin: ['Gabon Cards'], payout: false },
    { slug: 'usdt', iso: null, region: 'global', currency: 'USDT', name: { en: 'Global USDT', zh: '全球 USDT' }, payin: ['USDT'], payout: ['USDT'], networks: USDT_CHAINS },
];

/** Payment method type, derived from the method name. */
export const METHOD_TYPES = {
    card: { en: 'Cards', zh: '银行卡' },
    bank: { en: 'Bank transfer', zh: '银行转账' },
    instant: { en: 'Instant payment', zh: '实时支付' },
    wallet: { en: 'E-wallet / Mobile money', zh: '电子钱包 / 移动钱包' },
    cash: { en: 'Cash / Voucher', zh: '现金 / 凭证' },
    qr: { en: 'QR payment', zh: '扫码支付' },
    crypto: { en: 'Stablecoin', zh: '稳定币' },
};

export const methodType = (method) => {
    const m = method.toLowerCase();
    if (m === 'usdt' || USDT_CHAINS.some((c) => c.toLowerCase() === m)) return 'crypto';
    if (m.includes('card')) return 'card';
    if (m.includes('qr')) return 'qr';
    if (m.includes('cash payment') || m === 'boleto' || m === 'pagoefectivo' || m === 'fawry pay') return 'cash';
    if (['pix', 'spei', 'duitnow', 'capitec pay', 'bre-b (key)', 'paynow'].includes(m)) return 'instant';
    if (m.includes('mobile money') || ['m-pesa', 'opay', 'gcash', "touch 'n go", 'cash app', 'apple pay', 'google pay', 'paypal', 'chime'].includes(m)) return 'wallet';
    return 'bank';
};

export const hasPayout = (market) => Array.isArray(market.payout) && market.payout.length > 0;

export const marketsByRegion = (regionKey) => MARKETS.filter((m) => m.region === regionKey);

export const getMarket = (slug) => MARKETS.find((m) => m.slug === slug);


const countries = MARKETS.filter((m) => m.iso && m.iso !== 'eu');
export const COVERAGE_STATS = {
    markets: MARKETS.filter((m) => m.region !== 'global').length,
    countries: countries.length,
    // USDT counts as one method no matter how many chains it runs on.
    payinMethods: MARKETS.reduce((n, m) => n + (m.networks ? 1 : m.payin.length), 0),
    payoutMarkets: MARKETS.filter(hasPayout).length,
    currencies: new Set(MARKETS.filter((m) => !m.cardBrands).map((m) => m.currency)).size,
};

const lang = (l) => (l && l.startsWith('zh') ? 'zh' : 'en');
export const marketName = (market, l) => market.name[lang(l)];
export const regionName = (key, l) => REGIONS.find((r) => r.key === key)?.[lang(l)] ?? key;
export const methodTypeName = (type, l) => METHOD_TYPES[type]?.[lang(l)] ?? type;

/** Approximate [lat, lon] of each market's commercial centre — drives the hero globe. */
export const MARKET_GEO = {
    eurozone: [50.1, 8.7], 'united-kingdom': [51.5, -0.1], 'united-arab-emirates': [25.2, 55.3],
    'united-states': [40.7, -74], mexico: [19.4, -99.1], colombia: [4.7, -74.1], brazil: [-23.5, -46.6],
    'costa-rica': [9.9, -84.1], 'el-salvador': [13.7, -89.2], guatemala: [14.6, -90.5], chile: [-33.4, -70.6],
    ecuador: [-0.2, -78.5], peru: [-12.0, -77.0], philippines: [14.6, 121.0], malaysia: [3.1, 101.7],
    indonesia: [-6.2, 106.8], japan: [35.7, 139.7], nigeria: [6.5, 3.4], kenya: [-1.3, 36.8], 'south-africa': [-26.2, 28.0],
    egypt: [30.0, 31.2], ghana: [5.6, -0.2], tanzania: [-6.8, 39.3], uganda: [0.3, 32.6], rwanda: [-1.9, 30.1],
    'cote-d-ivoire': [5.3, -4.0], senegal: [14.7, -17.4], benin: [6.4, 2.4], cameroon: [4.1, 9.7],
    guinea: [9.6, -13.6], zambia: [-15.4, 28.3], 'burkina-faso': [12.4, -1.5], mali: [12.6, -8.0],
    morocco: [33.6, -7.6], algeria: [36.8, 3.1], gabon: [0.4, 9.5],
};

/**
 * Display name of a channel method in a language. Brands stay as they are; generic methods are
 * shortened when the market is already named ("Brazil Bank Transfer" -> "Bank Transfer") and
 * translated for Chinese pages ("Bank Transfer" -> "银行转账", "Mobile Money GH" -> "移动钱包").
 *   market: pass it when the country is already clear from context (market pages, cards)
 */
const ZH_METHOD = { 'Thai QR Payment': '泰国 QR 扫码', 'Singapore QR Payment': '新加坡 QR 扫码', 'QR Payment': 'QR 扫码', iBanking: '网银 iBanking', 'Visa Card': 'Visa 卡', 'UnionPay Card': '银联卡', 'JCB Card': 'JCB 卡', 'Bre-B (Key)': 'Bre-B（密钥）', 'Bre-B (QR)': 'Bre-B（扫码）', 'Fawry Pay': 'Fawry Pay' };
const COUNTRY_ALIASES = { 'cote-d-ivoire': ['Ivory Coast'] };
export const methodLabel = (method, l, market) => {
    const zh = !!l && l.startsWith('zh');
    let m = method;
    if (market) {
        for (const prefix of [market.name.en, ...(COUNTRY_ALIASES[market.slug] || []), market.currency]) {
            if (m.startsWith(`${prefix} `) && !/^[A-Z]{3}$/.test(prefix)) { m = m.slice(prefix.length + 1); break; }
        }
    }
    m = m.replace(/^(Mobile Money) [A-Z]{2}$/, '$1');
    if (!zh) return m;
    if (ZH_METHOD[m]) return ZH_METHOD[m];
    const cur = m.match(/^([A-Z]{3}) Bank Transfer$/);
    if (cur) return `${cur[1]} 银行转账`;
    if (/Bank Transfer$/.test(m)) return m === 'Bank Transfer' ? '银行转账' : `${marketNameFromPrefix(m.replace(/ Bank Transfer$/, ''))}银行转账`;
    if (/Cash Payment$/.test(m)) return m === 'Cash Payment' ? '现金支付' : `${marketNameFromPrefix(m.replace(/ Cash Payment$/, ''))}现金支付`;
    if (/Cards$/.test(m)) return m === 'Cards' ? '银行卡' : `${marketNameFromPrefix(m.replace(/ Cards$/, ''))}银行卡`;
    if (m === 'Mobile Money') return '移动钱包';
    return m;
};
/** "Nigeria" / "Ivory Coast" -> 尼日利亚 / 科特迪瓦 (for un-shortened generic names on Chinese pages). */
const marketNameFromPrefix = (prefix) => {
    const hit = MARKETS.find((x) => x.name.en === prefix || (COUNTRY_ALIASES[x.slug] || []).includes(prefix));
    return hit ? hit.name.zh : `${prefix} `;
};

/** Currency shown to visitors: ISO code, or a translated label for multi-currency channels (global cards). */
export const currencyLabel = (market, l) => (market.currency === 'Multi-currency' && l && l.startsWith('zh') ? '多币种' : market.currency);
