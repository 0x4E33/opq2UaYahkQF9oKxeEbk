/**
 * Consistent in-article linking: the FIRST mention of every payment method in an article's body
 * links to its method page; later mentions stay plain text. Methods the author already linked by
 * hand keep that link and are not auto-linked again. Pure function → identical prerender/client HTML.
 *
 * Only section blocks are processed (paragraphs, lists, steps, tables, notes) — the same places
 * the renderer supports inline links; headings, the summary box and FAQ stay plain.
 */
import { METHODS, methodName } from '../data/methods';

// Extra spellings that appear in article text (en + zh). The generic "mobile money" is left out on purpose.
const ALIASES = {
    unionpay: ['UnionPay', '银联'],
    'touch-n-go': ["Touch 'n Go", 'Touch n Go', 'Touch ‘n Go', 'Touch ’n Go'],
    'm-pesa': ['M-Pesa', 'M-PESA', 'Mpesa'],
    fawry: ['Fawry Pay', 'Fawry'],
    'bre-b': ['Bre-B'],
};
const SKIP = new Set(['mobile-money']);

const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const TERMS = METHODS.filter((m) => !SKIP.has(m.slug)).flatMap((m) => {
    const names = new Set([...(ALIASES[m.slug] || []), methodName(m, 'en'), methodName(m, 'zh')]);
    return [...names].map((name) => ({ slug: m.slug, name }));
}).sort((a, b) => b.name.length - a.name.length); // longest first ("Fawry Pay" before "Fawry")

// One pattern for all terms; Latin names must not be part of a longer word ("Pix" ≠ "Pixel").
const PATTERN = new RegExp(`(?<![A-Za-z0-9])(${TERMS.map((t) => escape(t.name)).join('|')})(?![A-Za-z0-9])`, 'g');
const slugOf = (name) => TERMS.find((t) => t.name === name)?.slug;

const TOKEN = /(\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\))/g;

/** Link the first unlinked method mention in one string; `done` collects slugs already linked. */
const linkText = (text, done) => String(text).split(TOKEN).map((part) => {
    if (!part || part.startsWith('**') || part.startsWith('[')) return part; // keep bold / existing links untouched
    return part.replace(PATTERN, (match) => {
        const slug = slugOf(match);
        if (!slug || done.has(slug)) return match;
        done.add(slug);
        return `[${match}](/methods/${slug})`;
    });
}).join('');

const mapBlock = (block, done) => {
    if (typeof block === 'string') return linkText(block, done);
    if (block.list) return { ...block, list: block.list.map((x) => linkText(x, done)) };
    if (block.steps) return { ...block, steps: block.steps.map((x) => linkText(x, done)) };
    if (block.note) return { ...block, note: linkText(block.note, done) };
    if (block.table) return { ...block, table: { ...block.table, rows: block.table.rows.map((row) => row.map((cell) => linkText(cell, done))) } };
    return block;
};

/** Returns a copy of one language version of an article with method mentions linked. */
export const autolinkArticle = (content) => {
    const all = JSON.stringify(content.sections);
    // methods the author linked by hand anywhere in the body are never auto-linked a second time
    const done = new Set([...all.matchAll(/\]\(\/methods\/([a-z0-9-]+)\)/g)].map((m) => m[1]));
    return { ...content, sections: content.sections.map((s) => ({ ...s, blocks: s.blocks.map((b) => mapBlock(b, done)) })) };
};
