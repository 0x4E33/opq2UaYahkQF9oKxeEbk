/**
 * Cover photo + topic for each article (hub cards, hub header mosaic, article header).
 * Photos are the site's own licensed payment scenes (credits in each src/assets/<dir>/credits.json).
 */
import { asset } from '../data/media';
import { industryPhoto } from '../data/industries';

// Each article's own topic photo (src/assets/articles/<slug>.webp, credits in ./credits/<slug>.json).
const OWN = import.meta.glob('../assets/articles/*.webp', { eager: true, query: '?url', import: 'default' });
const OWN_CREDITS = import.meta.glob('../assets/articles/credits/*.json', { eager: true, import: 'default' });
// 800w copies of the same covers (scripts/make-variants.mjs) for cards.
const OWN_SM = import.meta.glob('../assets/articles/sm/*.webp', { eager: true, query: '?url', import: 'default' });

// Fallbacks: right-hand crops of header photos whose left side is feathered (made for page headers).
const CROPS = import.meta.glob('../assets/covers/*.webp', { eager: true, query: '?url', import: 'default' });

const COVERS = {
    'brazil-payment-methods': ['markets/brazil', 'latam'],
    'mexico-payment-methods': ['markets/mexico', 'latam'],
    'colombia-payment-methods': ['industry:e-commerce', 'latam'],
    'latin-america-payments-overview': ['industry:travel', 'latam'],
    'pix-vs-boleto': ['markets/apac', 'latam'],
    'africa-mobile-money': ['cover:africa', 'africa'],
    'southeast-asia-payment-methods': ['markets/apac', 'apac'],
    'malaysia-payment-methods': ['markets/malaysia', 'apac'],
    'philippines-gcash': ['cover:philippines', 'apac'],
    'indonesia-qris': ['cover:indonesia', 'apac'],
    'fpx-vs-duitnow-vs-touch-n-go': ['markets/malaysia', 'apac'],
    'kenya-m-pesa': ['cover:africa', 'africa'],
    'nigeria-payment-methods': ['industry:e-commerce', 'africa'],
    'south-africa-payment-methods': ['about/story-us', 'africa'],
    'egypt-payment-methods': ['industry:education', 'africa'],
    'west-central-africa-mobile-money': ['industry:live-streaming', 'africa'],
    'mobile-money-vs-bank-transfer-africa': ['cover:africa', 'africa'],
    'europe-uae-bank-transfers': ['markets/europe_me', 'europe'],
    'ai-short-drama-payments': ['industry:digital-goods', 'industry'],
    'cross-border-ecommerce-checkout': ['about/story-europe', 'industry'],
    'payment-success-rate': ['roadmap/hero-poster', 'integration'],
    'igaming-payments': ['industry:gaming', 'scenario'],
    'mystery-box-payments': ['industry:e-commerce', 'scenario'],
    'live-streaming-platform-payments': ['industry:live-streaming', 'scenario'],
    'ai-companion-chat-payments': ['industry:digital-goods', 'scenario'],
    'forex-broker-payments': ['cover:global', 'scenario'],
    'dtc-independent-store-payments': ['about/story-europe', 'scenario'],
    'mobile-game-topup-payments': ['about/story-us', 'scenario'],
    'social-dating-app-payments': ['markets/united-kingdom', 'scenario'],
    'ai-saas-tools-payments': ['developers/hero-poster', 'scenario'],
    'usdt-networks-compared': ['industry:web3', 'settlement'],
    'instant-payments-vs-bank-transfer': ['about/story-mexico', 'latam'],
    'us-payment-methods': ['markets/united-states', 'na'],
    'apple-pay-vs-google-pay-vs-cash-app': ['markets/united-states', 'na'],
    'chargebacks-vs-local-payments': ['markets/global-cards', 'cards'],
    'japan-jcb-payments': ['markets/japan', 'apac'],
    'thailand-payment-methods': ['markets/thailand', 'apac'],
    'singapore-payment-methods': ['markets/singapore', 'apac'],
    'andean-central-america-payments': ['markets/brazil', 'latam'],
    'merchant-onboarding-kyc-checklist': ['developers/hero-poster', 'integration'],
    'ghana-payment-methods': ['cover:africa', 'africa'],
    'international-card-acquiring': ['markets/global-cards', 'cards'],
    'local-payment-methods-vs-cards': ['markets/eurozone', 'cards'],
    'usdt-settlement': ['cover:global', 'settlement'],
    'usdt-vs-local-currency-settlement': ['industry:web3', 'settlement'],
    'mass-payouts-emerging-markets': ['industry:global-payroll', 'settlement'],
    'payment-gateway-integration-checklist': ['developers/hero-poster', 'integration'],
    'one-gateway-vs-multiple-providers': ['capabilities/hero-poster', 'integration'],
};

export const TOPICS = {
    na: { en: 'North America', zh: '北美' },
    cards: { en: 'Cards', zh: '信用卡' },
    europe: { en: 'Europe & Middle East', zh: '欧洲及中东' },
    latam: { en: 'Latin America', zh: '拉丁美洲' },
    scenario: { en: 'Business scenarios', zh: '业务场景' },
    industry: { en: 'Industry playbooks', zh: '行业实践' },
    settlement: { en: 'Settlement & payouts', zh: '结算与代付' },
    integration: { en: 'Integration & selection', zh: '对接与选型' },
    apac: { en: 'Asia Pacific', zh: '亚太' },
    africa: { en: 'Africa', zh: '非洲' },
};

const resolve = (key) => {
    if (key.startsWith('industry:')) return industryPhoto(key.slice(9));
    if (key.startsWith('cover:')) return CROPS[`../assets/covers/${key.slice(6)}.webp`];
    return asset(`${key}.webp`);
};

const own = (slug) => OWN[`../assets/articles/${slug}.webp`] || null;

export const articleCover = (slug) => {
    if (own(slug)) return own(slug);
    const [key] = COVERS[slug] || ['home/night-lights'];
    return resolve(key) || asset('markets/global.webp');
};
/** srcset for an article's own cover (800w card copy + 1600w original), else undefined. */
export const articleCoverSrcSet = (slug) => {
    const sm = OWN_SM[`../assets/articles/sm/${slug}.webp`];
    return sm && own(slug) ? `${sm} 800w, ${own(slug)} 1600w` : undefined;
};
/** Credit line for the cover when its licence requires one (CC BY / CC BY-SA), else null. */
export const articleCoverAttribution = (slug) => (own(slug) ? OWN_CREDITS[`../assets/articles/credits/${slug}.json`]?.attribution || null : null);
/** Market header photos keep their subject on the right (the left is feathered for page headers). */
export const articleCoverPosition = (slug) => (!own(slug) && (COVERS[slug]?.[0] || '').startsWith('markets/') ? '78% center' : 'center');
export const articleTopic = (slug) => (COVERS[slug] || [null, 'integration'])[1];
export const topicName = (topic, l) => TOPICS[topic]?.[l && l.startsWith('zh') ? 'zh' : 'en'] || '';
