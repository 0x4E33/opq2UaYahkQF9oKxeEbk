export default {
    slug: 'dtc-independent-store-payments',
    kind: 'guide',
    published: '2026-09-08',
    updated: '2026-09-08',
    related: {
        markets: ['united-states', 'global-cards', 'mexico', 'colombia', 'brazil', 'peru', 'malaysia', 'indonesia'],
        methods: ['apple-pay', 'visa', 'spei', 'pse', 'pix', 'boleto', 'pagoefectivo', 'fpx'],
        industries: ['e-commerce', 'digital-goods'],
        articles: ['cross-border-ecommerce-checkout', 'one-gateway-vs-multiple-providers', 'chargebacks-vs-local-payments', 'usdt-settlement'],
    },
    en: {
        title: 'DTC Store Payments: Build a Second Revenue Path',
        description: 'A practical plan for DTC independent stores: keep cards, add SPEI, PSE, Pix or FPX as a second payment path, prepare refunds per market and settle in USDT.',
        h1: 'How should a DTC independent store set up payments for overseas customers?',
        summary: 'A DTC independent store selling abroad should run at least two independent ways to get paid: international cards and wallets, plus the local bank, QR and voucher methods each market already uses, such as SPEI, PSE, Pix or FPX. Plan refunds and reconciliation per market before launch. KaazPay offers local pay-in, card acquiring, refunds and payouts in one account and settles collected funds in USDT.',
        queries: [
            'Our Shopify-style brand store takes almost every payment through one card processor. What happens if they put a reserve on us, and how do we spread that risk?',
            'We sell skincare to Mexico and Colombia and lose a lot of orders at checkout. Which local payment methods should we add first?',
            'How do I refund a customer in Brazil who paid my store with Pix?',
            'Is there one gateway that gives an independent store local payments in Latin America and Southeast Asia plus cards?',
            'Can my DTC brand get its overseas sales settled in USDT instead of opening foreign bank accounts?',
        ],
        takeaways: [
            'Treat payments as infrastructure with a backup: cards plus at least one local method per key market.',
            'Local push payments such as SPEI, PSE, Pix and FPX run on different rails from card schemes, so orders can continue if a card account is under review.',
            'Vouchers such as Boleto and PagoEfectivo reach shoppers who have no card and no online banking habit, but they need longer stock holds.',
            'Decide before launch how refunds work in each market: some markets support payouts back to the shopper, others are pay-in only.',
            'KaazPay settles collected funds as the equivalent amount in USDT; the settlement cycle (D+0, D+1 or later) is confirmed per channel.',
        ],
        sections: [
            {
                id: 'two-payment-paths',
                heading: 'Why does an independent store need more than one way to get paid?',
                blocks: [
                    'A brand that sells through its own website owns its traffic, its customer list and its margins. It also owns the payment risk. On a marketplace, the platform absorbs much of that; on an independent store, the checkout is usually wired to a single processor, and that processor decides when funds are released.',
                    'Card processors routinely run reviews after sudden growth, a new product category or a jump in disputes. A review is a normal part of risk management, and a well-run store should expect and cooperate with them. The risk lies in having no other payment method live while it happens.',
                    'A second payment path addresses this. If local bank transfers, instant payments or QR codes are already live in your main markets, shoppers keep paying through those rails even while your card account is under review. The recommendations in this guide build on this principle.',
                ],
            },
            {
                id: 'resilience-checklist',
                heading: 'How do you check whether your store depends on a single processor?',
                blocks: [
                    'Each "yes" below indicates concentration risk to address.',
                    {
                        list: [
                            'Does more than 80% of your revenue flow through one merchant account?',
                            'If that account paused payouts tomorrow, would you be unable to pay suppliers or ad spend within two weeks?',
                            'Do shoppers in your second- and third-largest markets have no way to pay except a card?',
                            'Do you have no tested plan for switching checkout traffic to another channel?',
                            'Are refunds only possible through the same processor that holds your funds?',
                        ],
                    },
                    'Spreading revenue across several unrelated providers is one answer, but it multiplies contracts, integrations and reports. A single gateway that connects several channels is often easier to run. The trade-offs are laid out in [one gateway vs multiple providers](/compare/one-gateway-vs-multiple-providers).',
                ],
            },
            {
                id: 'methods-by-market',
                heading: 'Which local payment methods should a DTC store add in each market?',
                blocks: [
                    'Start with the method most people in that country use for online purchases, then add a cash or voucher option where many shoppers are unbanked. The table is a selection of what KaazPay supports, grouped by how the payment works.',
                    {
                        table: {
                            head: ['Market', 'Account-to-account / instant', 'Wallet, QR or voucher', 'Refund route via payout'],
                            rows: [
                                ['United States', '—', 'Cash App, [Apple Pay](/methods/apple-pay), Google Pay', 'PayPal, Cash App, Chime, cards, ACH'],
                                ['Worldwide cards', '—', 'Visa, Mastercard, UnionPay cards', 'Confirm with account manager'],
                                ['[Mexico](/payment-methods/mexico)', '[SPEI](/methods/spei), bank transfer', 'Cash payment', 'Bank transfer'],
                                ['[Colombia](/payment-methods/colombia)', '[PSE](/methods/pse), Bancolombia, Bre-B key, bank transfer', 'Bre-B QR, cash payment', 'Bank transfer'],
                                ['[Brazil](/payment-methods/brazil)', '[Pix](/methods/pix), bank transfer', '[Boleto](/methods/boleto), cash payment', 'Bank transfer'],
                                ['Peru', 'Bank transfer', '[PagoEfectivo](/methods/pagoefectivo), cash payment', 'Pay-in only'],
                                ['Malaysia', '[FPX](/methods/fpx), DuitNow', "Touch 'n Go", 'Bank transfer'],
                                ['Indonesia', '—', '[QRIS](/methods/qris)', 'Bank transfer, mobile money'],
                            ],
                        },
                    },
                    { note: 'Which channels you can use depends on market and business model, and is confirmed with your KaazPay account manager before go-live.' },
                    'For a fashion or beauty brand with first orders in Mexico and Colombia, a sensible first release is SPEI plus cash payment in Mexico and PSE plus Bre-B in Colombia, with cards kept for everyone. Add Brazil with Pix and Boleto once those markets are stable.',
                ],
            },
            {
                id: 'worked-example',
                heading: 'What does a local payment order look like from checkout to settlement?',
                blocks: [
                    'A typical order from a shopper in Mexico City paying a DTC store with SPEI:',
                    {
                        steps: [
                            'The shopper picks SPEI at checkout. Your store calls the KaazPay API to create the order with the amount in MXN and your order ID.',
                            'The shopper sees transfer details and completes the payment in their own banking app.',
                            'KaazPay sends a signed notification to your server once the payment is confirmed. Your store verifies the signature, then marks the order as paid.',
                            'Your warehouse ships. The order appears in the KaazPay dashboard alongside card and other local orders.',
                            'The collected amount is settled to you as the equivalent in USDT on the cycle agreed for that channel.',
                        ],
                    },
                    'Two details matter in practice. First, mark orders paid only from the verified notification, never from the shopper returning to your "thank you" page. Second, make the update idempotent per order ID, so a repeated notification does not create a duplicate shipment.',
                ],
            },
            {
                id: 'disputes-and-refunds',
                heading: 'How do disputes and refunds differ between cards and local methods?',
                blocks: [
                    'With a card payment, the cardholder can ask their bank to reverse the charge through the card scheme dispute process. With push payments such as SPEI, PSE, Pix, FPX or DuitNow, the shopper authorises the transfer in their own app, so the card chargeback process generally does not apply in the same way. This can reduce one type of exposure, but it does not remove the need for a fair refund policy: shoppers still request refunds. The full picture is in [chargebacks vs local payments](/compare/chargebacks-vs-local-payments).',
                    'A refund on a push payment is usually a new transfer from you to the shopper. KaazPay supports this as a payout in its payout markets (for example by bank transfer in Mexico, Colombia, Brazil and Malaysia, and to US wallets, cards and ACH) and in USDT. In pay-in-only markets such as Peru or Chile, agree a refund method with your account manager before you start selling there.',
                    { note: 'Keep proof of delivery, clear product descriptions and fast support replies. They help with every kind of complaint, whatever the payment method.' },
                ],
            },
            {
                id: 'vouchers-and-stock',
                heading: 'How should a store handle cash vouchers and unpaid orders?',
                blocks: [
                    'With Boleto, PagoEfectivo or a cash payment reference, the order is created first and paid later at a store, agent or in online banking. Until the shopper pays, you have an open order but no money.',
                    {
                        list: [
                            'Hold stock for a fixed window that matches the voucher validity, then release it automatically.',
                            'Send one reminder before the voucher expires, by email or messaging.',
                            'Do not ship until the payment notification arrives.',
                            'Track voucher conversion separately from instant methods; it is normal for it to be lower.',
                        ],
                    },
                ],
            },
            {
                id: 'reconcile-and-settle',
                heading: 'How can a store reconcile many currencies and settle in USDT?',
                blocks: [
                    'Every extra provider adds a report in a different format. With KaazPay, local pay-in, card payments, refunds and payouts are visible in one merchant dashboard, so finance can match settlements to orders from a single record.',
                    'Shoppers pay in pesos, reais, ringgit or rupiah. KaazPay settles the collected funds as the equivalent amount in USDT, so you do not need a bank account in each country. Many channels settle D+0, others D+1 or later; the cycle is confirmed per channel before go-live. More detail in [how USDT settlement works](/guides/usdt-settlement), and on checkout design in the [cross-border ecommerce checkout guide](/guides/cross-border-ecommerce-checkout).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you add local payments to your store with KaazPay?',
                blocks: [
                    'KaazPay works with [e-commerce brands](/industries/e-commerce) selling across the Americas, Asia Pacific and Africa. Onboarding includes a business review, so describe your products, markets and order flow accurately.',
                    {
                        steps: [
                            '**Open a merchant account:** share your store, product categories and target markets.',
                            '**Get your API keys:** receive sandbox and live credentials once the account is approved.',
                            '**Integrate with engineer support:** connect order creation, signed notifications and refunds; see the [developer docs](/developers).',
                            '**Go live:** channels per market are confirmed, then you switch on local methods next to your cards.',
                        ],
                    },
                    'Tell us where your shoppers are and how you take payments today. [Contact us on Telegram](/contact) and we reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'How can a DTC store reduce dependence on one card processor?', a: 'Keep cards, but switch on at least one local payment method in each important market, such as SPEI in Mexico, PSE in Colombia, Pix in Brazil or FPX in Malaysia. KaazPay provides these and card acquiring from one account.' },
            { q: 'Which local method should my store add first in Latin America?', a: 'Usually the instant bank payment: SPEI in Mexico, PSE or Bre-B in Colombia, Pix in Brazil. Add a cash or voucher option such as Boleto or PagoEfectivo afterwards for unbanked shoppers.' },
            { q: 'Are chargebacks possible on Pix or SPEI payments?', a: 'They are push payments the shopper approves in their bank app, so the card chargeback process generally does not apply in the same way. Shoppers can still request refunds, so keep a clear refund policy.' },
            { q: 'How do I refund a shopper who paid by bank transfer?', a: 'Usually by sending a payout back to their account. KaazPay supports this in its payout markets and in USDT; for pay-in-only markets such as Peru or Chile, agree a method before launch.' },
            { q: 'How is my store paid out by KaazPay?', a: 'Collected funds are settled as the equivalent amount in USDT. Many channels settle D+0, others D+1 or later, confirmed per channel before go-live.' },
        ],
    },
    zh: {
        title: '独立站收款：为 DTC 品牌搭建第二条收款通道',
        description: '面向 DTC 独立站的收款实操：保留信用卡，同时接入 SPEI、PSE、Pix、FPX 等本地支付作为第二条收款路径，提前规划各市场退款方式，并以 USDT 结算。',
        h1: 'DTC 独立站出海，应如何搭建收款体系？',
        summary: 'DTC 独立站出海，至少要有两条互不依赖的收款路径：一条是国际信用卡和钱包，另一条是各市场本地常用的银行转账、实时支付、扫码和凭证付款，例如 SPEI、PSE、Pix、FPX。退款与对账也应在上线前按市场规划好。KaazPay 在同一账户中提供本地代收、信用卡收单、退款与代付，并将代收资金以 USDT 结算。',
        queries: [
            '独立站几乎所有订单都通过一家信用卡收单机构处理，如果被冻结资金或扣保证金，会有什么影响？如何分散风险？',
            '我们卖美妆到墨西哥和哥伦比亚，结账流失很严重，应该先接哪些本地支付？',
            '巴西客户用 Pix 付款，独立站如何退款？',
            '有没有一个网关能同时接拉美、东南亚本地支付和信用卡，适合独立站？',
            '独立站海外销售额能不能直接结算成 USDT，不用在每个国家开银行账户？',
        ],
        takeaways: [
            '把收款当作基础设施来规划：信用卡之外，每个重点市场至少再接一种本地支付。',
            'SPEI、PSE、Pix、FPX 等推式付款与卡组织是两套体系，卡账户审核期间订单仍可继续成交。',
            'Boleto、PagoEfectivo 等凭证类方式能覆盖没有银行卡的消费者，但需要更长的库存保留期。',
            '上线前先确定每个市场的退款方式：有的市场支持代付退回，有的市场仅支持代收。',
            'KaazPay 将代收资金按等值 USDT 结算，D+0、D+1 或更长的周期按通道确认。',
        ],
        sections: [
            {
                id: 'two-payment-paths',
                heading: '独立站为什么不能只有一条收款通道？',
                blocks: [
                    '品牌自建独立站，流量、客户名单和利润都由品牌自己掌握，收款风险也由品牌自行承担。在电商平台上，这部分风险多由平台承担；而独立站的结账页通常只连着一家收单机构，放款时间由该机构决定。',
                    '销量突然增长、上新品类、争议率上升，都可能触发收单机构的审核。审核本身是正常的风控流程，规范经营的商户应当配合。风险在于审核期间没有其他可用的收款方式。',
                    '第二条收款路径可以解决这一问题。如果主要市场的本地银行转账、实时支付或扫码已经上线，即使信用卡账户在审核，消费者依然可以通过这些通道下单付款。本文所有建议都围绕这一思路展开。',
                ],
            },
            {
                id: 'resilience-checklist',
                heading: '如何判断独立站是否过度依赖单一收单？',
                blocks: [
                    '逐条自查，回答“是”的越多，集中风险越高：',
                    {
                        list: [
                            '超过 80% 的收入都经过同一个商户账户？',
                            '如果这个账户明天暂停出款，两周内将无法支付供应商货款和广告费用？',
                            '第二、第三大市场的消费者除了信用卡没有别的付款方式？',
                            '没有经过测试的切换方案，无法把结账流量转到其他通道？',
                            '退款只能通过持有您资金的同一家收单机构完成？',
                        ],
                    },
                    '分散到多家毫不相关的服务商是一种办法，但合同、对接和报表都会成倍增加。用一个聚合多条通道的网关通常更易于管理，两种方案的取舍见[单一网关 vs 多家服务商](/compare/one-gateway-vs-multiple-providers)。',
                ],
            },
            {
                id: 'methods-by-market',
                heading: '独立站在各市场应该接哪些本地支付？',
                blocks: [
                    '先接当地网购最常用的方式，再在无银行账户人群较多的市场补充现金或凭证付款。下表按付款原理整理了 KaazPay 支持的部分方式。',
                    {
                        table: {
                            head: ['市场', '账户直付 / 实时支付', '钱包、扫码或凭证', '代付退款路径'],
                            rows: [
                                ['美国', '—', 'Cash App、[Apple Pay](/methods/apple-pay)、Google Pay', 'PayPal、Cash App、Chime、银行卡、ACH'],
                                ['全球信用卡', '—', 'Visa、Mastercard、银联卡', '与客户经理确认'],
                                ['[墨西哥](/payment-methods/mexico)', '[SPEI](/methods/spei)、银行转账', '现金支付', '银行转账'],
                                ['[哥伦比亚](/payment-methods/colombia)', '[PSE](/methods/pse)、Bancolombia、Bre-B 密钥、银行转账', 'Bre-B 扫码、现金支付', '银行转账'],
                                ['[巴西](/payment-methods/brazil)', '[Pix](/methods/pix)、银行转账', '[Boleto](/methods/boleto)、现金支付', '银行转账'],
                                ['秘鲁', '银行转账', '[PagoEfectivo](/methods/pagoefectivo)、现金支付', '仅代收'],
                                ['马来西亚', '[FPX](/methods/fpx)、DuitNow', "Touch 'n Go", '银行转账'],
                                ['印度尼西亚', '—', '[QRIS](/methods/qris)', '银行转账、移动钱包'],
                            ],
                        },
                    },
                    { note: '可用通道取决于市场与业务类型，上线前由 KaazPay 客户经理确认。' },
                    '以首批订单来自墨西哥和哥伦比亚的服饰或美妆品牌为例，比较稳妥的第一期是：墨西哥接 SPEI 加现金支付，哥伦比亚接 PSE 加 Bre-B，信用卡继续保留。待这两个市场运行稳定后，再以 Pix 和 Boleto 开拓巴西。',
                ],
            },
            {
                id: 'worked-example',
                heading: '一笔本地支付订单从下单到结算的流程是怎样的？',
                blocks: [
                    '以墨西哥城一位消费者用 SPEI 在独立站下单为例：',
                    {
                        steps: [
                            '消费者在结账页选择 SPEI，独立站调用 KaazPay API，以 MXN 金额和自己的订单号创建订单。',
                            '消费者看到转账信息，在自己的银行 App 中完成付款。',
                            '付款确认后，KaazPay 向商户服务器发送带签名的通知，独立站验签后把订单标记为已支付。',
                            '仓库发货，这笔订单与信用卡及其他本地订单一起显示在 KaazPay 后台。',
                            '代收金额按该通道约定的周期，以等值 USDT 结算给商户。',
                        ],
                    },
                    '实际操作中有两点要注意：一是只以验签通过的异步通知作为已支付依据，不要以消费者跳回“支付成功”页面为准；二是按订单号做幂等处理，重复通知不会导致重复发货。',
                ],
            },
            {
                id: 'disputes-and-refunds',
                heading: '信用卡和本地支付在争议与退款上有什么不同？',
                blocks: [
                    '信用卡付款后，持卡人可以通过发卡行走卡组织的争议流程申请拒付。而 SPEI、PSE、Pix、FPX、DuitNow 这类推式付款，是消费者在自己的 App 里主动授权转账，信用卡拒付流程一般不以同样方式适用。这能减少一类风险，但商户仍需制定合理的退款政策，消费者依然会申请退款。详细对比见[拒付与本地支付对比](/compare/chargebacks-vs-local-payments)。',
                    '推式付款的退款，通常是由商户再发起一笔转账给消费者。KaazPay 在代付市场支持以代付形式退款，例如墨西哥、哥伦比亚、巴西、马来西亚的银行转账，美国的钱包、银行卡与 ACH，也支持 USDT。秘鲁、智利等仅代收市场，请在开卖前与客户经理商定退款方式。',
                    { note: '保留物流签收凭证、写清楚商品描述、及时回复客服，无论哪种付款方式，这些都是处理投诉的基础。' },
                ],
            },
            {
                id: 'vouchers-and-stock',
                heading: '现金凭证和未付款订单应如何处理？',
                blocks: [
                    '使用 Boleto、PagoEfectivo 或现金付款码时，订单先生成，消费者之后才去便利店、代理点或网银付款。付款前，这只是一张未付订单。',
                    {
                        list: [
                            '按凭证有效期设置固定的库存保留时间，到期自动释放。',
                            '在凭证到期前通过邮件或消息提醒一次。',
                            '收到付款通知之前不要发货。',
                            '凭证类订单的转化率单独统计，比实时支付低属于正常现象。',
                        ],
                    },
                ],
            },
            {
                id: 'reconcile-and-settle',
                heading: '多币种如何对账？能否以 USDT 结算？',
                blocks: [
                    '每多接一家服务商，就多一份格式不同的报表。在 KaazPay，本地代收、信用卡收款、退款与代付都在同一个商户后台中，财务可以用一份记录完成订单与结算的核对。',
                    '消费者用比索、雷亚尔、林吉特或印尼盾付款，KaazPay 将代收资金按等值 USDT 结算给商户，无需在各国开设银行账户。不少通道 D+0 结算，其余为 D+1 或更长，上线前按通道确认。详见 [USDT 结算说明](/guides/usdt-settlement)；结账页设计可参考[跨境电商结账页指南](/guides/cross-border-ecommerce-checkout)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 为独立站接入本地支付？',
                blocks: [
                    'KaazPay 服务在美洲、亚太和非洲销售的[电商品牌](/industries/e-commerce)。开户需经过业务审核，请如实说明商品、市场与订单流程。',
                    {
                        steps: [
                            '**开通商户账户**：提交店铺信息、商品类目和目标市场。',
                            '**获取 API 密钥**：审核通过后获得测试与正式环境密钥。',
                            '**工程师协助对接**：完成下单、签名通知与退款对接，参考[开发者文档](/developers)。',
                            '**正式上线**：逐个市场确认通道后，在信用卡旁边开启本地支付。',
                        ],
                    },
                    '请告知您的消费者分布在哪些市场，以及目前的收款方式。[通过 Telegram 联系我们](/contact)，我们会在一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '独立站怎样降低对单一信用卡收单的依赖？', a: '保留信用卡，同时在每个重点市场至少开通一种本地支付，例如墨西哥 SPEI、哥伦比亚 PSE、巴西 Pix、马来西亚 FPX。KaazPay 在同一账户中同时提供本地代收和信用卡收单。' },
            { q: '拉美市场独立站应该先接哪种本地支付？', a: '通常先接实时银行支付：墨西哥 SPEI、哥伦比亚 PSE 或 Bre-B、巴西 Pix。之后再补充 Boleto、PagoEfectivo 等凭证类方式，覆盖没有银行卡的消费者。' },
            { q: 'Pix 或 SPEI 付款会有拒付吗？', a: '它们是消费者在银行 App 中主动授权的推式付款，信用卡拒付流程一般不以同样方式适用。但消费者仍可申请退款，所以要有清晰的退款政策。' },
            { q: '消费者用银行转账付款，如何退款？', a: '一般是通过代付把款项转回消费者账户。KaazPay 在支持代付的市场及通过 USDT 提供此服务；秘鲁、智利等仅代收市场需在上线前商定退款方式。' },
            { q: 'KaazPay 如何为独立站结算？', a: '代收资金按等值 USDT 结算。不少通道 D+0，其余 D+1 或更长，上线前按通道确认。' },
        ],
    },
};
