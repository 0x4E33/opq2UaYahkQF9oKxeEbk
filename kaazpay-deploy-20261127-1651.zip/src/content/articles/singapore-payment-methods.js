export default {
    slug: 'singapore-payment-methods',
    kind: 'guide',
    published: '2025-02-25',
    updated: '2026-11-23',
    related: {
        markets: ['singapore', 'malaysia', 'thailand'],
        methods: ['paynow', 'singapore-qr'],
        industries: ['e-commerce', 'education', 'digital-goods'],
        articles: ['southeast-asia-payment-methods', 'thailand-payment-methods', 'malaysia-payment-methods', 'instant-payments-vs-bank-transfer'],
    },
    en: {
        title: 'Singapore Payment Methods: PayNow, SGQR, iBanking',
        description: 'Accept payments in Singapore with PayNow, QR payment (SGQR) and iBanking transfers, send SGD payouts to Singapore bank accounts, and get settled in USDT.',
        h1: 'How do you accept online payments from customers in Singapore?',
        summary: 'Singapore buyers increasingly pay straight from their bank: by PayNow, by scanning a payment QR code such as one under the SGQR label, or by an iBanking transfer. KaazPay supports all three for pay-in in SGD, sends payouts by bank transfer, and settles your collections in USDT through one integration.',
        queries: [
            'How can Singapore customers pay our website with PayNow?',
            'What is SGQR and do we need it to accept QR payments in Singapore?',
            'How do we send refunds or withdrawals to Singapore users?',
            'Do Singapore online shoppers still prefer credit cards?',
            'Do we need a Singapore bank account to accept SGD payments?',
        ],
        takeaways: [
            'PayNow lets buyers pay from their banking app using a mobile number, NRIC/FIN or business UEN.',
            'QR payment covers buyers who scan; SGQR is the unified label that lets one code carry several schemes.',
            'iBanking transfers suit desktop buyers and larger amounts.',
            'KaazPay pays out in SGD by bank transfer only, to Singapore bank accounts.',
            'SGD collections are settled to you in USDT, with cycles confirmed per channel.',
        ],
        sections: [
            {
                id: 'how-singapore-pays',
                heading: 'How do Singapore shoppers like to pay online?',
                blocks: [
                    'Cards are common in Singapore, but paying directly from a bank account is now routine. **PayNow**, offered by the participating Singapore banks, lets people send money instantly from their banking app to a mobile number, NRIC/FIN or a business UEN. Hawker stalls, taxis and online shops display payment QR codes, and the national **SGQR** label brings many of those schemes together on one code.',
                    'For merchants, this means a checkout that offers a bank-app option next to cards usually feels familiar to local buyers. The current channel list is on the [Singapore market page](/payment-methods/singapore).',
                ],
            },
            {
                id: 'methods-table',
                heading: 'Which Singapore payment methods does KaazPay support?',
                blocks: [
                    {
                        table: {
                            head: ['Method', 'Pay-in', 'Payout', 'How the user pays or gets paid'],
                            rows: [
                                ['PayNow', 'Yes', 'No', 'Approves the payment in a banking app'],
                                ['QR payment (Singapore QR Payment)', 'Yes', 'No', 'Scans a payment QR code and confirms in a banking or wallet app'],
                                ['iBanking', 'Yes', 'No', 'Transfers from internet or mobile banking'],
                                ['Bank transfer', 'No', 'Yes', 'Payouts land in the recipient’s Singapore bank account'],
                            ],
                        },
                    },
                    'All three pay-in methods run in SGD from the same KaazPay merchant account, with the same API and notifications.',
                ],
            },
            {
                id: 'paynow',
                heading: 'Why is PayNow worth offering first?',
                blocks: [
                    '[PayNow](/methods/paynow) is widely used by Singapore residents to split bills and pay small businesses. Because it lives inside the buyer’s banking app, there is nothing new to install and no card number to share.',
                    {
                        list: [
                            '**Familiar approval step:** the buyer confirms the amount in their own bank app, which builds trust for first-time purchases.',
                            '**Proxy-based:** payments are addressed to a mobile number, NRIC/FIN or UEN, so recipients do not need to share account numbers.',
                            '**Runs on real-time rails:** PayNow transfers between participating banks are normally processed within seconds, and KaazPay notifies your server once the payment is confirmed.',
                        ],
                    },
                ],
            },
            {
                id: 'qr-and-sgqr',
                heading: 'How do QR payments and SGQR fit in?',
                blocks: [
                    'With [Singapore QR Payment](/methods/singapore-qr), your checkout shows a QR code for the order amount, and the buyer scans it with a supported banking or wallet app and approves. On a laptop the buyer scans the screen with their phone; on a phone they can save the code and open it in their app.',
                    '**SGQR** is Singapore’s unified QR label, introduced so that one code at a counter can carry several payment schemes, PayNow among them, instead of a row of separate stickers. Online it matters less than in shops, but buyers recognise the format, which helps them trust the code they scan.',
                    { note: 'Show the amount, the merchant name and an expiry time next to the QR code. Buyers are cautious about scanning unfamiliar codes, and clear details reduce drop-off.' },
                ],
            },
            {
                id: 'ibanking',
                heading: 'When does iBanking make sense?',
                blocks: [
                    'Some buyers, often on desktop or paying larger amounts such as course fees or bulk orders, prefer to make the transfer in internet banking. With **iBanking** pay-in the buyer completes the transfer in their bank and KaazPay matches it to your order. It is also the most familiar route for business buyers paying from a company account.',
                ],
            },
            {
                id: 'checkout-example',
                heading: 'What does a Singapore checkout look like step by step?',
                blocks: [
                    'Example: a student in Tampines buys an online course on a laptop.',
                    {
                        steps: [
                            'Your server creates an SGD order through KaazPay and shows PayNow, QR payment and iBanking side by side.',
                            'The student picks PayNow; a QR code for the exact amount appears with a countdown.',
                            'They scan it with their banking app on their phone, check the amount and merchant name, and approve.',
                            'KaazPay sends a signed notification to your server, which unlocks the course and emails the receipt.',
                            'Had the student chosen iBanking instead, the page would show the transfer details and wait for the matched payment.',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: 'How do SGD payouts work?',
                blocks: [
                    'KaazPay sends SGD payouts by **bank transfer only**, to the recipient’s Singapore bank account. PayNow, QR payment and iBanking are pay-in methods; they are not used for payouts. Payouts can go one at a time or in batches, each with a status notification, which covers refunds, tutor or creator earnings, affiliate commissions and marketplace seller settlements.',
                    'Collect each recipient’s full name, bank and account number when they register, and check the name matches the account holder before you send. Read [instant payments vs bank transfers](/compare/instant-payments-vs-bank-transfer) for how real-time rails compare with standard transfers.',
                ],
            },
            {
                id: 'settlement',
                heading: 'How are SGD collections settled to you?',
                blocks: [
                    'Buyers pay in SGD and KaazPay settles the equivalent amount to you in USDT, so a Singapore bank account is not needed to receive the funds. Cycles depend on the channel: many KaazPay channels settle D+0 and others D+1 or later, confirmed for each Singapore channel before go-live. Details are in [how USDT settlement works](/guides/usdt-settlement).',
                    'For neighbouring markets, see the [Thailand guide](/guides/thailand-payment-methods), the [Malaysia guide](/guides/malaysia-payment-methods) and the regional [Southeast Asia overview](/guides/southeast-asia-payment-methods).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you start accepting Singapore payments with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your business model and expected SGD volumes.',
                            'Receive your API keys.',
                            'Integrate with a KaazPay engineer and test PayNow, QR, iBanking and payouts together; see the [developer page](/developers).',
                            'Go live with the Singapore methods and settlement cycle agreed in writing.',
                        ],
                    },
                    'Contact us on Telegram through the [contact page](/contact). We reply within one business day.',
                ],
            },
        ],
        faq: [
            { q: 'What are the main bank-based payment methods in Singapore?', a: 'PayNow, QR payment (including codes under the SGQR label) and iBanking transfers. KaazPay supports all three for pay-in in SGD, alongside international cards.' },
            { q: 'What is the difference between PayNow and SGQR?', a: 'PayNow is a real-time payment service between Singapore banks. SGQR is a unified QR label that can carry several payment schemes, including PayNow, on one code.' },
            { q: 'Can KaazPay pay out to PayNow?', a: 'No. SGD payouts on KaazPay go by bank transfer only, to Singapore bank accounts, singly or in batches. PayNow is available for pay-in.' },
            { q: 'Do I need a Singapore entity or bank account?', a: 'You do not need a Singapore bank account to receive funds, because collections are settled in USDT. Your account manager confirms onboarding requirements for your business.' },
            { q: 'How long does settlement take for Singapore payments?', a: 'It depends on the channel. Many KaazPay channels settle D+0 and others D+1 or later; each cycle is confirmed before you go live.' },
        ],
    },
    zh: {
        title: '新加坡收款指南：PayNow、SGQR 与网银 iBanking',
        description: '在新加坡用 PayNow、QR 扫码（SGQR）和网银 iBanking 收款，新元代付打入新加坡银行账户，代收资金以 USDT 结算。',
        h1: '如何向新加坡用户收取线上付款？',
        summary: '越来越多新加坡用户直接用银行付款：通过 PayNow、扫描 SGQR 等标识下的支付二维码，或用网银 iBanking 转账。KaazPay 一次接入即可支持这三种新元（SGD）代收方式，代付只走银行转账，并把代收资金以 USDT 结算给商户。',
        queries: [
            '新加坡用户怎样在我们网站上用 PayNow 付款？',
            'SGQR 是什么？在新加坡收扫码付款一定要用吗？',
            '怎么给新加坡用户退款或提现？',
            '新加坡网购用户还是更喜欢刷信用卡吗？',
            '收新元一定要有新加坡银行账户吗？',
        ],
        takeaways: [
            'PayNow 让用户在银行 App 里用手机号、身份证号（NRIC/FIN）或企业 UEN 付款。',
            'QR 扫码覆盖习惯扫码的用户；SGQR 是统一标识，一个码可承载多种支付方案。',
            '网银 iBanking 转账适合电脑端用户和较大金额。',
            'KaazPay 的新元代付只走银行转账，打入新加坡银行账户。',
            '新元代收以 USDT 结算，各通道周期上线前逐一确认。',
        ],
        sections: [
            {
                id: 'how-singapore-pays',
                heading: '新加坡用户喜欢怎样在网上付款？',
                blocks: [
                    '银行卡在新加坡很普遍，但直接从银行账户付款已是日常做法。由参与银行共同提供的 **PayNow**，让人在银行 App 里凭手机号、NRIC/FIN 或企业 UEN 即时转账。小贩中心、出租车和网店都会展示支付二维码，而全国统一的 **SGQR** 标识把多种支付方案整合在同一个码上。',
                    '对商户来说，在银行卡之外提供“用银行 App 付款”的选项，更符合本地用户的习惯。最新通道见[新加坡市场页](/payment-methods/singapore)。',
                ],
            },
            {
                id: 'methods-table',
                heading: 'KaazPay 在新加坡支持哪些支付方式？',
                blocks: [
                    {
                        table: {
                            head: ['方式', '代收', '代付', '用户如何付款或收款'],
                            rows: [
                                ['PayNow', '支持', '不支持', '在银行 App 内确认付款'],
                                ['QR 扫码（新加坡 QR 扫码支付）', '支持', '不支持', '扫描支付二维码，在银行或钱包 App 中确认'],
                                ['网银 iBanking', '支持', '不支持', '通过网银或手机银行转账'],
                                ['银行转账', '不支持', '支持', '代付打入收款人的新加坡银行账户'],
                            ],
                        },
                    },
                    '三种代收方式都以新元计价，共用同一个 KaazPay 商户账户、同一套 API 和回调。',
                ],
            },
            {
                id: 'paynow',
                heading: '为什么建议优先提供 PayNow？',
                blocks: [
                    '[PayNow](/methods/paynow) 是新加坡居民分摊账单、向小商家付款的常用方式。它内置在用户的银行 App 中，不用另装软件，也不用透露卡号。',
                    {
                        list: [
                            '**确认步骤熟悉：** 用户在自己的银行 App 里核对金额并确认，首次购买也更放心。',
                            '**用代号收付款：** 以手机号、NRIC/FIN 或 UEN 作为收款标识，收款人不必提供银行账号。',
                            '**实时清算：** 参与银行之间的 PayNow 转账通常数秒内完成，付款确认后 KaazPay 即通知商户服务器。',
                        ],
                    },
                ],
            },
            {
                id: 'qr-and-sgqr',
                heading: 'QR 扫码支付和 SGQR 是什么关系？',
                blocks: [
                    '使用[新加坡 QR 扫码支付](/methods/singapore-qr)时，收银台显示带订单金额的二维码，用户用支持的银行或钱包 App 扫码并确认。电脑端用手机扫屏幕；手机端可保存二维码后在 App 中打开。',
                    '**SGQR** 是新加坡的统一二维码标识，目的是让柜台上一个码就能承载包括 PayNow 在内的多种支付方案，而不必贴一排不同的贴纸。线上场景中它不如在门店重要，但用户熟悉这种格式，因此更容易信任所扫描的二维码。',
                    { note: '在二维码旁边写清金额、商户名称和有效期。用户对陌生二维码较为谨慎，清楚的信息有助于减少放弃付款。' },
                ],
            },
            {
                id: 'ibanking',
                heading: '什么情况下适合用网银 iBanking？',
                blocks: [
                    '部分用户，尤其是使用电脑、或支付课程费、批量订单等较大金额时，更习惯在网银中自行转账。选择 **iBanking** 代收时，用户在银行完成转账，KaazPay 将款项与订单匹配。用公司账户付款的企业客户也最熟悉这种方式。',
                ],
            },
            {
                id: 'checkout-example',
                heading: '一笔新加坡订单是怎样一步步完成的？',
                blocks: [
                    '示例：淡滨尼的一名学生在电脑上购买一门网课。',
                    {
                        steps: [
                            '商户服务器通过 KaazPay 创建新元订单，页面并排展示 PayNow、QR 扫码和 iBanking。',
                            '学生选择 PayNow，页面出现带准确金额和倒计时的二维码。',
                            '学生用手机上的银行 App 扫码，核对金额和商户名称后确认。',
                            'KaazPay 向商户服务器推送带签名的回调，系统随即开通课程并发送收据。',
                            '如果学生选的是 iBanking，页面则显示转账信息，等待匹配到账。',
                        ],
                    },
                ],
            },
            {
                id: 'payouts',
                heading: '新元代付怎么操作？',
                blocks: [
                    'KaazPay 的新元代付**只支持银行转账**，打入收款人的新加坡银行账户；PayNow、QR 扫码和网银 iBanking 只用于代收，不用于代付。可单笔也可批量，每笔都有状态回调，适用于退款、导师或创作者分成、推广佣金和平台卖家结款。',
                    '建议在收款人注册时收集全名、银行名称和账号，并在打款前核对姓名与账户持有人一致。实时支付与普通转账的区别，请看[即时支付与银行转账对比](/compare/instant-payments-vs-bank-transfer)。',
                ],
            },
            {
                id: 'settlement',
                heading: '新元代收资金如何结算给商户？',
                blocks: [
                    '用户以新元付款，KaazPay 以等额 USDT 结算给商户，收款不需要新加坡银行账户。结算周期因通道而异：KaazPay 不少通道 D+0 结算，其余 D+1 或更长，新加坡各通道的周期会在上线前确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
                    '周边市场请参阅[泰国收款指南](/guides/thailand-payment-methods)、[马来西亚收款指南](/guides/malaysia-payment-methods)和[东南亚支付方式总览](/guides/southeast-asia-payment-methods)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 开始在新加坡收款？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，说明您的业务模式和新元预估交易量。',
                            '获取 API 密钥。',
                            '与 KaazPay 工程师一起接入，联调 PayNow、QR、iBanking 和代付流程，详见[开发者页面](/developers)。',
                            '书面确认结算周期后，正式上线新加坡支付方式。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 联系我们，一个工作日内回复。',
                ],
            },
        ],
        faq: [
            { q: '新加坡主要的银行类支付方式有哪些？', a: 'PayNow、QR 扫码（包括 SGQR 标识下的二维码）以及网银 iBanking 转账。KaazPay 三种都支持以新元代收，同时也提供国际信用卡收单。' },
            { q: 'PayNow 和 SGQR 有什么区别？', a: 'PayNow 是新加坡银行之间的实时支付服务；SGQR 是统一的二维码标识，一个码可承载包括 PayNow 在内的多种支付方案。' },
            { q: 'KaazPay 能代付到 PayNow 吗？', a: '不能。KaazPay 的新元代付只走银行转账，打入新加坡银行账户，可单笔或批量；PayNow 用于代收。' },
            { q: '需要新加坡公司或银行账户吗？', a: '收款不需要新加坡银行账户，代收资金以 USDT 结算。具体开户要求由客户经理根据您的业务确认。' },
            { q: '新加坡的付款多久结算？', a: '取决于通道。KaazPay 不少通道 D+0 结算，其余 D+1 或更长，上线前逐一确认。' },
        ],
    },
};
