export default {
    slug: 'mexico-payment-methods',
    kind: 'guide',
    published: '2025-07-29',
    updated: '2025-07-29',
    related: {
        markets: ['mexico'],
        methods: ['spei'],
        industries: ['e-commerce', 'gaming', 'digital-goods'],
        articles: ['latin-america-payments-overview', 'instant-payments-vs-bank-transfer', 'local-payment-methods-vs-cards', 'mass-payouts-emerging-markets'],
    },
    en: {
        title: "Accept Payments in Mexico: SPEI, Transfer & Cash",
        description: "A merchant guide to accepting payments in Mexico: SPEI with CLABE, bank transfer and cash for unbanked shoppers, bank payouts in MXN, and settlement in USDT.",
        h1: "How to accept online payments in Mexico",
        summary: "The most effective way to accept online payments in Mexico is to lead with SPEI, Banco de México's real-time interbank transfer system, and back it up with bank transfer and cash payment for shoppers who do not pay digitally. KaazPay offers all three for MXN pay-in, sends payouts to Mexican bank accounts, and settles collections to you in USDT.",
        queries: [
            "What is the best way to accept payments from customers in Mexico without relying on credit cards?",
            "How does a SPEI payment with a CLABE work for an online store?",
            "Can Mexican customers without a bank account pay for online orders in cash?",
            "Which payment gateway supports SPEI pay-in and payouts to Mexican bank accounts?",
        ],
        takeaways: [
            "SPEI lets Mexican shoppers pay straight from their banking app to a CLABE, and confirms in real time.",
            "Mexico Cash Payment keeps your checkout open to people who have neither a card nor a bank account.",
            "Mexico Bank Transfer suits larger, planned payments from customers who prefer a classic transfer.",
            "KaazPay sends payouts to Mexican bank accounts from the same account that receives your collections.",
            "Shoppers pay in MXN and you are settled in USDT, on a cycle confirmed for each channel before launch.",
        ],
        sections: [
            {
                id: 'mexico-methods-at-a-glance',
                heading: "Which payment methods can you offer Mexican customers through KaazPay?",
                blocks: [
                    "Mexico mixes digital banking with a strong cash habit, so a checkout that only takes international cards excludes many buyers. KaazPay offers three local pay-in methods in MXN:",
                    { table: {
                        head: ["Method", "What the shopper does", "Confirmation", "Where it fits best"],
                        rows: [
                            ["[SPEI](/methods/spei)", "Sends a transfer to the CLABE shown for the order", "Real time", "Digital goods, top-ups, everyday e-commerce"],
                            ["Mexico Bank Transfer", "Pays from their own bank account by standard transfer", "Depends on the transfer", "Larger one-off payments, B2B"],
                            ["Mexico Cash Payment", "Takes the payment instructions and pays in person", "After the cash payment is reported", "Shoppers without cards or bank accounts"],
                        ],
                    } },
                    "Payouts in Mexico go to bank accounts. The [Mexico market page](/payment-methods/mexico) always shows the current channel list.",
                ],
            },
            {
                id: 'spei-and-clabe',
                heading: "How does SPEI work, and what is a CLABE?",
                blocks: [
                    "**SPEI** (Sistema de Pagos Electrónicos Interbancarios) is the interbank transfer network operated by Banco de México. It moves money between Mexican bank accounts in real time, and almost every Mexican banking app can send a SPEI transfer.",
                    "Transfers are addressed with a **CLABE**, an 18-digit standardised account number. In a checkout, the CLABE you show is generated for the order, so when the money arrives it can be tied back to that purchase without the shopper typing a separate reference.",
                    "For a merchant this means no card form, no issuer decline and a confirmation that arrives within moments of the customer pressing send.",
                ],
            },
            {
                id: 'spei-shopper-journey',
                heading: "What does a SPEI payment look like from the shopper's side?",
                blocks: [
                    "Example: a player in Guadalajara buys a MXN 350 credit pack in a mobile game that uses KaazPay:",
                    { steps: [
                        "The player taps SPEI on the payment screen.",
                        "The game shows the amount and a CLABE created for this order, with a copy button for each.",
                        "The player switches to their banking app, pastes the CLABE, enters MXN 350 and confirms.",
                        "KaazPay matches the incoming transfer to the order and notifies the game's server.",
                        "The credits are added to the player's account, typically within moments of the transfer being confirmed.",
                    ] },
                    { note: "On mobile, most drop-off happens at the copy-and-switch step. Large copy buttons and a short prompt to return after paying help reduce it." },
                ],
            },
            {
                id: 'cash-and-bank-transfer-mexico',
                heading: "How can Mexican shoppers without a card or bank app pay online?",
                blocks: [
                    "**Mexico Cash Payment** is built for them. The shopper chooses cash at checkout, receives payment instructions, and pays in person. Once the payment is reported back, KaazPay updates the order and you can deliver.",
                    "Because the shopper has to make a trip, cash orders take longer to complete and some are never paid. Keep them pending, set a sensible expiry, and send a reminder with the instructions before it lapses.",
                    "**Mexico Bank Transfer** serves a different group: customers who have a bank account but prefer a traditional transfer, often for bigger amounts or business purchases.",
                ],
            },
            {
                id: 'mexico-mix-by-business',
                heading: "Which methods should your business put first in Mexico?",
                blocks: [
                    { table: {
                        head: ["Business type", "Lead with", "Also offer", "Reason"],
                        rows: [
                            ["Mobile and PC games, top-ups", "SPEI", "Cash payment", "Instant credit for banked players; an alternative for everyone else"],
                            ["Online retail", "SPEI", "Cash payment, bank transfer", "Covers digital bankers, cash users and bigger baskets"],
                            ["Digital subscriptions and content", "SPEI", "Cash payment", "Fast access after payment matters most"],
                            ["Wholesale and B2B services", "Bank transfer", "SPEI", "Business buyers expect to pay from a company account"],
                        ],
                    } },
                    "For when local methods outperform card acceptance, see [local payment methods vs cards](/compare/local-payment-methods-vs-cards).",
                ],
            },
            {
                id: 'mexico-payment-pitfalls',
                heading: "What commonly goes wrong with Mexican payments, and how do you avoid it?",
                blocks: [
                    { list: [
                        "**Wrong amount sent by SPEI.** Show the exact figure next to the CLABE and repeat it on the confirmation screen.",
                        "**Reusing a CLABE from an earlier order.** Tell shoppers each order has its own details, and never save them as a favourite payee in your instructions.",
                        "**Delivering before confirmation.** Release goods only on KaazPay's notification, not on a screenshot or a customer message.",
                        "**Unpaid cash orders clogging stock.** Put an expiry on cash orders and free the inventory when it passes.",
                        "**Payouts to the wrong account.** Validate the recipient's CLABE format and name before you submit a payout.",
                    ] },
                ],
            },
            {
                id: 'payouts-to-mexican-banks',
                heading: "How do you pay out to Mexican bank accounts?",
                blocks: [
                    "KaazPay supports **bank-account payouts in Mexico** from the same merchant account and dashboard you use for collections. Typical uses are refunds, player withdrawals, marketplace seller earnings and affiliate commissions.",
                    "Collect the recipient's CLABE and full name, submit single or batch payouts through the API, and track the status of each. For high-volume payout programmes, see [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).",
                ],
            },
            {
                id: 'mxn-settlement-usdt',
                heading: "How are MXN collections settled to you?",
                blocks: [
                    "Your customers pay in Mexican pesos and KaazPay settles the equivalent amount to you in **USDT**, so there is no need to set up a Mexican entity or bank account to get paid.",
                    "Many KaazPay channels settle D+0, others D+1 or later. Your account manager confirms the cycle, exchange rate and fees for each Mexican channel before you go live, and every settlement can be traced in the merchant dashboard.",
                ],
            },
            {
                id: 'launch-mexico-kaazpay',
                heading: "How do you go live in Mexico with KaazPay?",
                blocks: [
                    { steps: [
                        "Open a KaazPay merchant account.",
                        "Get your API keys.",
                        "Build and test the integration with a KaazPay engineer, using the [developer documentation](/developers).",
                        "Switch on SPEI, bank transfer, cash payment and bank payouts for your live traffic.",
                    ] },
                    "The same integration also covers Colombia, Brazil and other Latin American markets, as outlined in our [Latin America payments overview](/guides/latin-america-payments-overview). Reach our business team on Telegram through the [contact page](/contact) and we will send a Mexico channel plan within one business day.",
                ],
            },
        ],
        faq: [
            { q: "What is SPEI in Mexico?", a: "Banco de México operates SPEI, the network Mexican banks use to move money between accounts in real time. Shoppers pay from their banking app to an 18-digit CLABE created for the order." },
            { q: "Which Mexican payment methods does KaazPay support?", a: "SPEI, Mexico Bank Transfer and Mexico Cash Payment for pay-in, plus payouts to bank accounts in Mexico." },
            { q: "Can customers in Mexico pay for online orders with cash?", a: "Yes. Mexico Cash Payment gives the shopper instructions to pay in person; KaazPay marks the order as paid as soon as that cash payment is reported." },
            { q: "Can I send refunds or withdrawals to Mexican bank accounts?", a: "Yes. KaazPay sends payouts to Mexican bank accounts, one at a time or in batches, from the account that receives your collections." },
            { q: "In what currency am I paid for Mexican sales?", a: "Shoppers pay in MXN and KaazPay settles the equivalent in USDT. Rates, fees and the settlement cycle are confirmed per channel before go-live." },
        ],
    },
    zh: {
        title: "墨西哥收款指南：SPEI 实时转账、现金与银行转账",
        description: "出海商户如何在墨西哥收款：SPEI 通过 CLABE 实时到账，银行转账和现金支付覆盖更多用户，支持墨西哥银行账户代付，比索代收按等额 USDT 结算。",
        h1: "如何在墨西哥收款：SPEI 与本地付款方式接入指南",
        summary: "在墨西哥收款，最有效的做法是以 SPEI 为主力——它由墨西哥央行 Banco de México 运营，银行之间实时到账，再用银行转账和现金支付覆盖不习惯线上付款的用户。KaazPay 在墨西哥提供这三种比索代收方式，支持向墨西哥银行账户代付，代收资金以 USDT 结算。",
        queries: [
            "不依赖信用卡，如何向墨西哥客户收款？",
            "SPEI 和 CLABE 付款在网店里是怎么运作的？",
            "墨西哥没有银行账户的用户能用现金给网购订单付款吗？",
            "哪家支付通道同时支持 SPEI 代收和墨西哥银行账户代付？",
        ],
        takeaways: [
            "SPEI 让墨西哥用户在银行 App 里直接向 CLABE 转账，实时确认。",
            "墨西哥现金支付让既没有银行卡也没有银行账户的人也能下单。",
            "墨西哥银行转账适合偏好传统转账的客户，以及大额、计划性的付款。",
            "KaazPay 可从收款所在的同一账户向墨西哥银行账户代付。",
            "用户以比索付款，商户收到 USDT，各通道结算周期在上线前确认。",
        ],
        sections: [
            {
                id: 'mexico-methods-at-a-glance',
                heading: "通过 KaazPay 可以为墨西哥用户提供哪些付款方式？",
                blocks: [
                    "墨西哥既有成熟的手机银行用户，也有很强的现金消费习惯，只收国际信用卡的收银台会流失大量买家。KaazPay 在墨西哥提供三种比索代收方式：",
                    { table: {
                        head: ["支付方式", "用户怎么付", "确认时间", "适合场景"],
                        rows: [
                            ["[SPEI](/methods/spei)", "向订单专属的 CLABE 转账", "实时", "数字商品、充值、日常电商"],
                            ["墨西哥银行转账", "从本人银行账户普通转账", "取决于银行处理", "大额单笔、B2B"],
                            ["墨西哥现金支付", "拿到付款信息后线下付现", "现金入账回传后", "无卡、无银行账户的用户"],
                        ],
                    } },
                    "墨西哥代付以银行账户为收款方。最新通道列表以[墨西哥市场页面](/payment-methods/mexico)为准。",
                ],
            },
            {
                id: 'spei-and-clabe',
                heading: "SPEI 怎么运作？CLABE 又是什么？",
                blocks: [
                    "**SPEI**（Sistema de Pagos Electrónicos Interbancarios）是墨西哥央行 Banco de México 运营的银行间转账网络，资金在墨西哥各银行账户之间实时流转，几乎所有墨西哥银行 App 都能发起 SPEI 转账。",
                    "转账以 **CLABE** 作为收款账号，这是一组 18 位的标准化账号。在收银台里展示的 CLABE 是为该订单生成的，款项到账后即可对应到该笔订单，用户无需另外填写附言。",
                    "对商户来说，这意味着无需填写卡信息，也不存在发卡行拒绝交易的问题，用户确认转账后很快即可收到确认。",
                ],
            },
            {
                id: 'spei-shopper-journey',
                heading: "从用户角度看，一笔 SPEI 付款是什么样的？",
                blocks: [
                    "示例：一位瓜达拉哈拉的玩家在接入 KaazPay 的手游中购买 350 比索的点券包：",
                    { steps: [
                        "玩家在支付页选择 SPEI。",
                        "游戏展示金额和本订单专属的 CLABE，两者都可一键复制。",
                        "玩家切换到银行 App，粘贴 CLABE、输入 350 比索并确认。",
                        "KaazPay 将到账款项与订单匹配，并通知游戏服务器。",
                        "转账确认后，点券通常很快就会到账。",
                    ] },
                    { note: "在手机端，“复制后切换 App”是用户最容易流失的环节。加大复制按钮，并提示用户付款后返回，有助于减少流失。" },
                ],
            },
            {
                id: 'cash-and-bank-transfer-mexico',
                heading: "没有银行卡或手机银行的墨西哥用户怎么在网上付款？",
                blocks: [
                    "**墨西哥现金支付**正是为他们准备的：用户在收银台选择现金，获取付款信息后到线下付款，付款回传后 KaazPay 更新订单状态，您即可发货。",
                    "由于用户需前往线下网点付款，现金订单完成较慢，也会有一部分最终没有付款。订单应保持待付款状态，设置合理的有效期，到期前再发一次带付款信息的提醒。",
                    "**墨西哥银行转账**则覆盖另一类客户：有银行账户、但更习惯传统转账的人，通常是金额较大或企业采购。",
                ],
            },
            {
                id: 'mexico-mix-by-business',
                heading: "不同业务在墨西哥应该优先展示哪种方式？",
                blocks: [
                    { table: {
                        head: ["业务类型", "主推", "补充", "原因"],
                        rows: [
                            ["手游、端游、充值", "SPEI", "现金支付", "有银行账户的玩家即时到账，其他玩家也有付款渠道"],
                            ["线上零售", "SPEI", "现金支付、银行转账", "兼顾手机银行用户、现金用户和大额订单"],
                            ["数字订阅与内容", "SPEI", "现金支付", "付款后尽快开通最重要"],
                            ["批发与 B2B 服务", "银行转账", "SPEI", "企业买家习惯用对公账户付款"],
                        ],
                    } },
                    "本地支付在哪些情况下优于信用卡受理，详见[本地支付与信用卡对比](/compare/local-payment-methods-vs-cards)。",
                ],
            },
            {
                id: 'mexico-payment-pitfalls',
                heading: "墨西哥收款常见哪些问题？如何避免？",
                blocks: [
                    { list: [
                        "**SPEI 转错金额**：在 CLABE 旁边展示准确金额，确认页再显示一次。",
                        "**沿用旧订单的 CLABE**：告诉用户每笔订单的收款信息都不同，付款说明里不要引导用户把它存成常用收款人。",
                        "**未确认就发货**：只以 KaazPay 的通知为准发货，不以截图或客户留言为依据。",
                        "**未付款的现金订单占用库存**：为现金订单设置有效期，过期后释放库存。",
                        "**代付打错账户**：提交前校验收款人的 CLABE 格式和姓名。",
                    ] },
                ],
            },
            {
                id: 'payouts-to-mexican-banks',
                heading: "如何向墨西哥银行账户代付？",
                blocks: [
                    "KaazPay 支持**墨西哥银行账户代付**，与代收共用同一个商户账户和后台，常用于退款、玩家提现、平台卖家结算和推广佣金。",
                    "收集收款人的 CLABE 和全名，通过 API 单笔或批量提交，并逐笔跟踪状态。大规模代付的做法可参考[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)。",
                ],
            },
            {
                id: 'mxn-settlement-usdt',
                heading: "比索代收如何结算给商户？",
                blocks: [
                    "客户支付的是墨西哥比索，KaazPay 换算成等额 **USDT** 结算给您，无需在墨西哥设立公司或开立银行账户。",
                    "KaazPay 不少通道支持 D+0 结算，其余为 D+1 或更长。墨西哥各通道的结算周期、汇率和费率会在上线前由客户经理与您确认，每笔结算都能在商户后台追溯。",
                ],
            },
            {
                id: 'launch-mexico-kaazpay',
                heading: "如何通过 KaazPay 开通墨西哥收款？",
                blocks: [
                    { steps: [
                        "开设 KaazPay 商户账户。",
                        "获取 API 密钥。",
                        "参照[开发者文档](/developers)，与 KaazPay 工程师一起完成对接和测试。",
                        "为正式流量开通 SPEI、银行转账、现金支付代收及银行账户代付。",
                    ] },
                    "同一套对接也可覆盖哥伦比亚、巴西等拉美市场，详见[拉美支付总览](/guides/latin-america-payments-overview)。通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在一个工作日内发送墨西哥通道方案。",
                ],
            },
        ],
        faq: [
            { q: "墨西哥的 SPEI 是什么？", a: "SPEI 由墨西哥央行 Banco de México 运营，是墨西哥银行之间实时划款的网络。用户在银行 App 中向订单专属的 18 位 CLABE 转账即可。" },
            { q: "KaazPay 在墨西哥支持哪些付款方式？", a: "代收支持 SPEI、墨西哥银行转账和墨西哥现金支付，代付支持墨西哥银行账户。" },
            { q: "在墨西哥，没有银行卡的人能用现金给网购订单付款吗？", a: "能。选择墨西哥现金支付后，用户按指引到线下缴款，现金入账信息一回传，KaazPay 就把订单更新为已付款。" },
            { q: "可以向墨西哥银行账户发起退款或提现吗？", a: "可以。KaazPay 支持向墨西哥银行账户单笔或批量代付，与代收使用同一个账户。" },
            { q: "墨西哥的销售款以什么币种结算？", a: "用户以 MXN 付款，KaazPay 按等额 USDT 结算。汇率、费率和结算周期按通道在上线前确认。" },
        ],
    },
};
