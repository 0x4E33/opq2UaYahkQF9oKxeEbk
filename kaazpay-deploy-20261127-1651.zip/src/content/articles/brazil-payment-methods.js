export default {
    slug: 'brazil-payment-methods',
    kind: 'guide',
    published: '2025-07-01',
    updated: '2025-07-01',
    related: { markets: ['brazil'], methods: ['pix', 'boleto'], industries: ['gaming', 'e-commerce', 'digital-goods'], articles: ['pix-vs-boleto', 'latin-america-payments-overview', 'usdt-settlement', 'local-payment-methods-vs-cards'] },
    en: {
        title: 'Brazil Payment Methods: Pix, Boleto & More',
        description: "A merchant's guide to Brazil payment methods: when to use Pix, Boleto, bank transfer or cash payment, how each checkout flows, and how BRL settles in USDT.",
        h1: 'What payment methods should you accept in Brazil?',
        summary: "Accept Pix as the main option in Brazil, because it is the country's most used payment method and usually confirms within seconds in the customer's banking app. Keep Boleto, Brazil Bank Transfer and Brazil Cash Payment as alternatives for people who pay later, offline or from their account. KaazPay offers all four for pay-in, sends payouts to Brazilian bank accounts and settles BRL collections to you in USDT.",
        queries: [
            'What is the best way to accept payments from customers in Brazil without a local company?',
            'Which payment methods do I need for a Brazilian checkout besides Pix?',
            'How long does a Boleto take to confirm compared with Pix?',
            'Can I pay out to Brazilian bank accounts and get settled in USDT?',
            'Why are my Brazil orders stuck in pending after checkout?',
        ],
        takeaways: [
            'Make Pix the first option on a Brazilian checkout: customers approve it in their bank app and confirmation usually arrives within seconds.',
            'Boleto and Brazil Cash Payment create a pending order that only completes when the customer pays, so your system must handle waiting and expiry.',
            'Brazil Bank Transfer suits customers who prefer to move money from their own account, including larger one-off amounts.',
            'Payouts in Brazil go to bank accounts; Pix, Boleto and cash are pay-in methods on KaazPay.',
            'Customers pay in BRL and KaazPay settles the equivalent to you in USDT, with the cycle confirmed per channel before launch.',
        ],
        sections: [
            { id: 'brazil-checkout-expectations', heading: 'Which payment methods do Brazilian shoppers expect to see?', blocks: [
                "A Brazilian customer arriving at your checkout usually looks for **Pix** first. Pix is the instant payment system operated by the Central Bank of Brazil, and paying with it means opening a banking app, scanning or pasting a code, and approving. A checkout that only shows international card logos often feels unfamiliar to these shoppers, and some leave without paying.",
                "Pix alone does not cover every customer. Many people still prefer to pay a **Boleto** voucher when it suits them, to send a transfer from their own account, or to pay in cash. Supporting these methods extends your checkout to a wider share of Brazilian customers. The full channel list is on the [Brazil market page](/payment-methods/brazil).",
            ] },
            { id: 'brazil-methods-at-a-glance', heading: 'How do the four Brazil methods compare for a merchant?', blocks: [
                { table: { head: ['Method', 'What the customer does', 'When you can fulfil', 'Fits best', 'Watch out for'], rows: [
                    ['Pix', 'Scans a QR code or pastes a copy-and-paste code in their bank app', 'Usually seconds after approval, any day and hour', 'Top-ups, digital goods, mobile checkout', 'Codes left unpaid if the customer closes the page'],
                    ['Boleto', 'Receives a barcode voucher and pays it in online banking, at a bank branch or a lottery outlet', 'Only after the voucher is paid and confirmed', 'Physical goods, customers who plan when they pay', 'Vouchers that are never paid'],
                    ['Brazil Bank Transfer', 'Sends money from their own bank account', 'When the transfer is received', 'Larger one-off payments', 'Customers entering a different amount'],
                    ['Brazil Cash Payment', 'Gets payment instructions and pays in person', 'After the cash payment is reported back', 'Shoppers without a card or banking app', 'Longer wait before confirmation'],
                ] } },
                { note: 'All four are pay-in methods. Payouts in Brazil are sent to recipient bank accounts.' },
            ] },
            { id: 'pix-checkout-walkthrough', heading: 'How does a Pix payment work from order to delivery?', blocks: [
                "Example: a player buys a R$50 credit pack in a mobile game. The flow usually completes in one session:",
                { steps: [
                    'The player taps "Pix" on your payment page and you create the order through the KaazPay API.',
                    'Your page displays a Pix QR code and the matching copy-and-paste code for exactly R$50.',
                    'On a phone, the player copies the code into their banking app; on a desktop, they scan the QR code with the phone.',
                    'They approve the payment in the app, and KaazPay sends your server an asynchronous notification for that order.',
                    'Your server verifies the notification and credits the pack to the account straight away.',
                ] },
                'Because confirmation is fast, Pix suits digitally delivered products as the default method. More detail is on the [Pix method page](/methods/pix).',
            ] },
            { id: 'pending-boleto-and-cash-orders', heading: 'How should you handle Boleto and cash payment orders that are not paid yet?', blocks: [
                "With [Boleto](/methods/boleto) and Brazil Cash Payment, the checkout ends before the money moves. The customer leaves with a voucher or instructions and pays later, so your platform has to treat the order as pending rather than failed.",
                { list: [
                    'Show the voucher or payment instructions on screen and send a copy by email or message so the customer can find it again.',
                    'Display the due date clearly and remind the customer before it passes.',
                    'Reserve stock or hold the booking only for as long as the voucher stays valid.',
                    'Fulfil only after KaazPay confirms the payment, never on the basis of a customer screenshot.',
                    'Close the order automatically once the voucher expires, to keep reports accurate.',
                ] },
            ] },
            { id: 'when-to-use-brazil-bank-transfer', heading: 'When does Brazil Bank Transfer make sense?', blocks: [
                'Some customers prefer to pay by transferring money between accounts, particularly for higher-value purchases. **Brazil Bank Transfer** gives them that route without leaving your checkout flow.',
                'It is a good fit for one-off payments such as course fees, annual plans or larger orders. Show the exact amount and any reference prominently, since a mismatched amount is one of the most common reasons a transfer needs manual review.',
            ] },
            { id: 'brazil-payment-troubleshooting', heading: 'Why do Brazil payments fail, and how can you fix them?', blocks: [
                { table: { head: ['Symptom', 'Likely cause', 'What to change'], rows: [
                    ['Many Pix orders created but not paid', 'Customer could not scan on the same device, or closed the page', 'Show the copy-and-paste code first on mobile and keep the order page reachable'],
                    ['Pix code rejected by the bank app', 'The code expired before the customer approved it', 'Generate a fresh code when the customer returns to the order'],
                    ['Low completion on Boleto', 'Customers forget to pay before the due date', 'Send a reminder with the voucher attached ahead of the due date'],
                    ['Orders paid but not delivered', 'Notification not processed or rejected by your server', 'Verify the signature, log every notification and make handling idempotent'],
                    ['Transfer needs manual review', 'Amount or reference does not match the order', 'Display the exact amount and reference in large type'],
                ] } },
                'Some Brazilian channels ask for payer details such as the CPF (the Brazilian taxpayer number). Your account manager confirms the required fields for each channel during integration.',
            ] },
            { id: 'brazil-payouts-and-settlement', heading: 'How do refunds, payouts and settlement work for Brazil?', blocks: [
                'From the same KaazPay merchant account you can send **payouts to Brazilian bank accounts**. Merchants use this for refunds, seller or creator earnings, affiliate commissions and player withdrawals, without a second provider.',
                'On the collection side, your customers pay in Brazilian reais and KaazPay settles the equivalent amount to you in **USDT**, so you do not need a bank account in Brazil to receive funds. Settlement timing differs by channel: many settle D+0, others D+1 or later, and the cycle for each Brazil channel is agreed before go-live. The [USDT settlement guide](/guides/usdt-settlement) explains the mechanics.',
            ] },
            { id: 'launch-brazil-with-kaazpay', heading: 'How do you start accepting payments in Brazil with KaazPay?', blocks: [
                { steps: [
                    'Open a merchant account and tell us your product, expected volume and which Brazil methods you want.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with support from our engineers, following the [developer documentation](/developers).',
                    'Go live with Pix, Boleto, bank transfer and cash payment, and enable bank account payouts if you need them.',
                ] },
                'To compare the two main options, read [Pix vs Boleto](/compare/pix-vs-boleto), or see how Brazil fits into the wider region in our [Latin America payments overview](/guides/latin-america-payments-overview). When you are ready, [reach our team on Telegram](/contact); we reply within one business day with a channel plan and pricing.',
            ] },
        ],
        faq: [
            { q: 'Which payment method do most people use in Brazil?', a: 'Pix. It is the instant payment system run by the Central Bank of Brazil and is the most used payment method in the country, with payments typically confirmed within seconds.' },
            { q: 'Does KaazPay support Pix and Boleto?', a: 'Yes. KaazPay supports Pix, Boleto, Brazil Bank Transfer and Brazil Cash Payment for pay-in through one integration.' },
            { q: 'Can I send money to customers or sellers in Brazil?', a: 'Yes. KaazPay sends payouts to bank accounts in Brazil from the same merchant account you use to collect.' },
            { q: 'Do I need a Brazilian bank account to receive funds?', a: 'No. Collections in BRL are settled to you in USDT. Onboarding requirements for your business are confirmed by your account manager.' },
            { q: 'Why do some Brazil orders stay pending?', a: 'Boleto and cash payment orders remain pending until the customer pays the voucher or completes the cash payment. Fulfil only after KaazPay confirms the payment.' },
        ],
    },
    zh: {
        title: '巴西支付方式详解：Pix、Boleto、转账与现金',
        description: '面向出海商户的巴西收款指南：Pix、Boleto、巴西银行转账和现金支付各适合什么订单，各自的付款流程，以及 BRL 如何以 USDT 结算。',
        h1: '在巴西收款，应该接入哪些支付方式？',
        summary: '在巴西收款应以 Pix 为主：它是巴西使用最广泛的支付方式，用户在银行 App 中确认后通常几秒内即可到账。再配上 Boleto、巴西银行转账和巴西现金支付，覆盖习惯稍后付款、线下付款或账户转账的用户。KaazPay 一次对接即可开通这四种代收方式，支持巴西银行账户代付，BRL 代收资金以 USDT 结算给商户。',
        queries: [
            '没有巴西公司，怎么向巴西用户收款？',
            '巴西收银台除了 Pix 还需要接哪些支付方式？',
            'Boleto 到账需要多久？与 Pix 相比如何？',
            '巴西代付可以打到银行账户吗？能用 USDT 结算吗？',
            '巴西订单一直显示待支付是什么原因？',
        ],
        takeaways: [
            'Pix 应排在巴西收银台的第一位：用户在银行 App 中确认，通常几秒内即可收到支付结果。',
            'Boleto 和巴西现金支付下单后会进入待支付状态，系统需要处理等待与过期。',
            '巴西银行转账适合习惯从本人账户付款的用户，也适合金额较大的单笔订单。',
            '巴西代付打款至银行账户；在 KaazPay 上，Pix、Boleto 和现金支付均为代收方式。',
            '用户以 BRL 付款，KaazPay 以等额 USDT 结算，各通道结算周期在上线前确认。',
        ],
        sections: [
            { id: 'brazil-checkout-expectations', heading: '巴西用户在收银台希望看到哪些付款方式？', blocks: [
                '巴西用户进入收银台，第一眼找的通常是 **Pix**。Pix 是巴西央行运营的即时支付系统，付款只需打开银行 App、扫码或粘贴付款码、点击确认。如果页面上只有国际信用卡的标志，不少巴西用户会感到陌生，可能因此放弃付款。',
                '但仅接入 Pix 无法覆盖所有用户。仍有很多人习惯在方便的时候支付 **Boleto** 凭证，或从自己的账户转账，或者用现金付款。支持这些方式，才能覆盖更多巴西用户。完整通道列表见[巴西市场页面](/payment-methods/brazil)。',
            ] },
            { id: 'brazil-methods-at-a-glance', heading: '四种巴西支付方式，对商户来说有什么不同？', blocks: [
                { table: { head: ['支付方式', '用户付款操作', '何时可以发货', '最适合', '需要注意'], rows: [
                    ['Pix', '在银行 App 中扫描二维码或粘贴付款码', '确认后通常几秒，全天候', '充值、数字商品、移动端收银', '用户关闭页面后付款码未支付'],
                    ['Boleto', '拿到条形码凭证，通过网银、银行网点或彩票站付款', '凭证付款并确认之后', '实物商品、习惯规划付款时间的用户', '凭证开出后一直未付'],
                    ['巴西银行转账', '从本人银行账户转账', '收到转账之后', '大额单笔付款', '用户转账金额与订单不符'],
                    ['巴西现金支付', '获取付款信息后线下付款', '现金付款回传之后', '没有银行卡或银行 App 的用户', '确认前等待时间较长'],
                ] } },
                { note: '以上四种均为代收方式；巴西代付统一打款至收款人银行账户。' },
            ] },
            { id: 'pix-checkout-walkthrough', heading: '一笔 Pix 付款从下单到发货是怎样完成的？', blocks: [
                '以一位玩家在手游里购买 50 雷亚尔点券为例，整个过程通常一次完成：',
                { steps: [
                    '玩家在支付页选择 Pix，您通过 KaazPay API 创建订单。',
                    '页面显示金额正好为 50 雷亚尔的 Pix 二维码和对应的复制付款码。',
                    '在手机上，玩家把付款码复制到银行 App；在电脑上，则用手机扫描二维码。',
                    '玩家在 App 中确认付款，KaazPay 向您的服务器推送该订单的异步通知。',
                    '服务器验证通知后，立即为玩家账户发放点券。',
                ] },
                '由于确认速度很快，凡是数字化交付的商品，Pix 都适合作为默认支付方式。详见 [Pix 支付方式页面](/methods/pix)。',
            ] },
            { id: 'pending-boleto-and-cash-orders', heading: 'Boleto 和现金支付订单还没付款，该怎么处理？', blocks: [
                '使用 [Boleto](/methods/boleto) 和巴西现金支付时，收银流程结束时款项尚未到账。用户带着凭证或付款信息离开，之后再去付款，所以系统应把订单视为“待支付”，而不是“失败”。',
                { list: [
                    '在页面上展示凭证或付款信息，同时通过邮件或消息发送一份，方便用户再次找到。',
                    '清楚标出截止日期，并在到期前提醒用户。',
                    '库存或预订只在凭证有效期内保留。',
                    '只有在 KaazPay 确认收款后才发货，不要凭用户截图履约。',
                    '凭证过期后自动关闭订单，保持报表准确。',
                ] },
            ] },
            { id: 'when-to-use-brazil-bank-transfer', heading: '什么情况下适合用巴西银行转账？', blocks: [
                '有些用户习惯通过账户转账付款，金额较大时尤其如此。**巴西银行转账**让他们可以按自己熟悉的方式完成付款，而不必离开您的收银流程。',
                '它适合课程学费、年度会员或大额订单等一次性付款。请把准确金额和付款附言放在显眼位置，因为金额对不上是转账需要人工核对最常见的原因之一。',
            ] },
            { id: 'brazil-payment-troubleshooting', heading: '巴西付款为什么会失败？如何解决？', blocks: [
                { table: { head: ['现象', '可能原因', '改进做法'], rows: [
                    ['大量 Pix 订单已创建但未付款', '用户无法在同一台设备上扫码，或中途关闭页面', '移动端优先展示复制付款码，并保证订单页可以重新打开'],
                    ['银行 App 提示 Pix 付款码无效', '用户确认前付款码已过期', '用户返回订单时重新生成付款码'],
                    ['Boleto 完成率偏低', '用户忘记在截止日前付款', '到期前发送附带凭证的提醒'],
                    ['已付款但未发货', '服务器未处理或拒收了支付通知', '校验签名、记录每条通知，并保证处理逻辑幂等'],
                    ['转账需要人工核对', '金额或附言与订单不符', '用大号字体展示准确金额和附言'],
                ] } },
                '部分巴西通道会要求填写付款人信息，例如 CPF（巴西税号）。各通道需要哪些字段，客户经理会在对接时与您确认。',
            ] },
            { id: 'brazil-payouts-and-settlement', heading: '巴西的退款、代付和结算如何处理？', blocks: [
                '在同一个 KaazPay 商户账户中，您可以向**巴西银行账户代付**，用于退款、卖家或主播收益、联盟佣金和玩家提现，无需再找第二家服务商。',
                '代收方面，用户以巴西雷亚尔付款，KaazPay 将等额 **USDT** 结算给您，因此收款无需在巴西开立银行账户。各通道结算时效不同：不少通道支持 D+0，其余为 D+1 或更长，巴西每个通道的周期都会在上线前确认。具体机制见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'launch-brazil-with-kaazpay', heading: '如何通过 KaazPay 开通巴西收款？', blocks: [
                { steps: [
                    '开设商户账户，告诉我们您的业务、预计交易量和需要的巴西支付方式。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在我们工程师的协助下完成对接。',
                    '正式上线 Pix、Boleto、银行转账和现金支付，如有需要同时开通银行账户代付。',
                ] },
                '如需比较两种主流方式，请阅读 [Pix 与 Boleto 对比](/compare/pix-vs-boleto)；想了解巴西在整个拉美布局中的位置，请阅读[拉丁美洲收款概览](/guides/latin-america-payments-overview)。准备好后，[通过 Telegram 联系我们](/contact)，我们会在 1 个工作日内回复通道方案与报价。',
            ] },
        ],
        faq: [
            { q: '巴西人最常用什么方式付款？', a: 'Pix。它是巴西央行运营的即时支付系统，也是巴西使用最广泛的支付方式，付款通常几秒内即可确认。' },
            { q: 'KaazPay 支持 Pix 和 Boleto 吗？', a: '支持。KaazPay 一次对接即可开通 Pix、Boleto、巴西银行转账和巴西现金支付代收。' },
            { q: '可以向巴西的用户或卖家打款吗？', a: '可以。KaazPay 支持向巴西银行账户代付，与代收使用同一个商户账户。' },
            { q: '收款需要巴西本地银行账户吗？', a: '不需要。BRL 代收资金以 USDT 结算给您。具体开户要求由客户经理根据您的业务确认。' },
            { q: '为什么有些巴西订单一直是待支付？', a: 'Boleto 和现金支付订单在用户付清凭证或完成现金付款之前都会保持待支付状态。请在 KaazPay 确认收款后再发货。' },
        ],
    },
};
