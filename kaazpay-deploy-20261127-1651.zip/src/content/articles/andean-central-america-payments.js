export default {
    slug: 'andean-central-america-payments',
    kind: 'guide',
    published: '2025-09-09',
    updated: '2025-09-09',
    related: {
        markets: ['peru', 'chile', 'ecuador', 'guatemala', 'costa-rica', 'el-salvador'],
        methods: ['pagoefectivo', 'banco-nacional'],
        industries: ['e-commerce', 'gaming', 'education'],
        articles: ['latin-america-payments-overview', 'local-payment-methods-vs-cards', 'usdt-settlement', 'one-gateway-vs-multiple-providers'],
    },
    en: {
        title: 'Peru, Chile, Ecuador & Central America Payments',
        description: 'Accept payments in Peru, Chile, Ecuador, Guatemala, Costa Rica and El Salvador: local methods such as PagoEfectivo, Banco Nacional, bank transfer and cash.',
        h1: 'How to accept payments in Peru, Chile, Ecuador, Guatemala, Costa Rica and El Salvador',
        summary: "In Peru, Chile, Ecuador, Guatemala, Costa Rica and El Salvador, online customers mostly pay by bank transfer, through a local bank, or in cash with a payment reference. KaazPay offers pay-in in all six markets through one integration, including PagoEfectivo in Peru and Banco Nacional in Costa Rica, and settles the collections to you in USDT. These six markets are pay-in only: KaazPay does not offer payouts there.",
        queries: [
            'How do I accept online payments from customers in Peru and Chile?',
            'What is PagoEfectivo and how does it work for merchants?',
            'Which payment methods can I offer in Guatemala, Costa Rica and El Salvador?',
            'Do customers in Ecuador and El Salvador pay in US dollars?',
            'Can I send payouts to Peru or Chile through a payment gateway?',
        ],
        takeaways: [
            'KaazPay covers six markets here: Peru, Chile and Ecuador in the Andes and Pacific coast, plus Guatemala, Costa Rica and El Salvador in Central America.',
            'Every market has a cash payment option; Peru adds PagoEfectivo and Costa Rica adds Banco Nacional.',
            'Ecuador and El Salvador use the US dollar, so customers there pay in USD; the others pay in PEN, CLP, GTQ or CRC.',
            'All six markets are pay-in only on KaazPay, so plan refunds and user withdrawals before launch.',
            'Collections are settled to you in USDT, with the settlement cycle confirmed per channel before go-live.',
        ],
        sections: [
            { id: 'six-markets-short-answer', heading: 'How do customers pay online in these six markets?', blocks: [
                "Many merchants cover Mexico, Colombia and Brazil in Latin America and stop there. The six markets below are smaller individually, but together they add a meaningful customer base, and their payment methods are straightforward to cover.",
                "In all six, the core of a working checkout is the same: a way to pay from a local bank account, and a way to pay in cash using a reference generated at checkout. Peru and Costa Rica each add a well-known local option on top. KaazPay connects all six through the same integration you would use for the rest of [Latin America](/guides/latin-america-payments-overview).",
            ] },
            { id: 'six-markets-coverage', heading: 'Which payment methods does KaazPay support in each country?', blocks: [
                { table: { head: ['Market', 'Currency', 'Pay-in methods on KaazPay', 'Payouts'], rows: [
                    ['Peru', 'PEN (Peruvian sol)', 'PagoEfectivo, Peru Bank Transfer, Peru Cash Payment', 'Not available'],
                    ['Chile', 'CLP (Chilean peso)', 'Chile Bank Transfer, Chile Cash Payment', 'Not available'],
                    ['Ecuador', 'USD (US dollar)', 'Ecuador Bank Transfer, Ecuador Cash Payment', 'Not available'],
                    ['Guatemala', 'GTQ (Guatemalan quetzal)', 'Guatemala Bank Transfer, Guatemala Cash Payment', 'Not available'],
                    ['Costa Rica', 'CRC (Costa Rican colón)', 'Banco Nacional, Costa Rica Cash Payment', 'Not available'],
                    ['El Salvador', 'USD (US dollar)', 'El Salvador Cash Payment', 'Not available'],
                ] } },
                { note: 'These six markets are pay-in only on KaazPay. In Latin America, payouts to bank accounts are available in Mexico, Colombia and Brazil.' },
            ] },
            { id: 'peru-payments', heading: 'How do you accept payments in Peru?', blocks: [
                "Peru has the widest choice of the six. The best-known local option is **[PagoEfectivo](/methods/pagoefectivo)**: at checkout the customer receives a payment code, then pays it through online banking, a mobile wallet, or at an agent or store. That flexibility lets one method serve both banked customers and people who prefer to pay in person.",
                "**Peru Bank Transfer** suits customers who want to pay straight from their account, and **Peru Cash Payment** covers shoppers who want to settle in cash with a reference. Customers pay in Peruvian soles (PEN). See the [Peru market page](/payment-methods/peru) for the current channel list.",
            ] },
            { id: 'chile-ecuador-payments', heading: 'How do Chile and Ecuador payments work?', blocks: [
                "**Chile**: KaazPay supports **Chile Bank Transfer** and **Chile Cash Payment**, with customers paying in Chilean pesos (CLP). Bank transfer suits customers who bank online; cash payment serves those who prefer to pay in person. Channel details are on the [Chile market page](/payment-methods/chile).",
                "**Ecuador**: the country has used the US dollar as its official currency since 2000, so customers pay in **USD**. KaazPay offers **Ecuador Bank Transfer** and **Ecuador Cash Payment**. If you already sell in USD elsewhere, dollar pricing makes Ecuador a simple market to test. See the [Ecuador market page](/payment-methods/ecuador).",
            ] },
            { id: 'central-america-payments', heading: 'How do you collect payments in Guatemala, Costa Rica and El Salvador?', blocks: [
                "**Guatemala**: customers pay in quetzales (GTQ) with **Guatemala Bank Transfer** or **Guatemala Cash Payment**. More on the [Guatemala market page](/payment-methods/guatemala).",
                "**Costa Rica**: **[Banco Nacional](/methods/banco-nacional)**, one of the country's major state banks, lets its customers pay directly from their account in colones (CRC). **Costa Rica Cash Payment** covers everyone who banks elsewhere or prefers cash. More on the [Costa Rica market page](/payment-methods/costa-rica).",
                "**El Salvador**: the US dollar is the country's currency, and KaazPay supports **El Salvador Cash Payment**, with customers paying in USD. Because every order there is paid in person after checkout, design for pending orders from the start. More on the [El Salvador market page](/payment-methods/el-salvador).",
            ] },
            { id: 'cash-reference-flow', heading: 'How does a cash payment order work from start to finish?', blocks: [
                'Cash and payment-code methods play a large role in these markets, so the order flow needs careful handling. A typical order:',
                { steps: [
                    'The customer chooses cash payment (or PagoEfectivo in Peru) and you create the order through the KaazPay API.',
                    'Your page shows the payment reference, the exact amount, the currency and the deadline, and you send the same details by email or message.',
                    'The customer pays in person or, for PagoEfectivo, through online banking or a mobile wallet as well.',
                    'Once the payment is reported, KaazPay sends your server a notification for that order.',
                    'Your system verifies the notification, marks the order paid and delivers.',
                ] },
                { list: [
                    'Do not mark an unpaid order as failed; keep it pending until the deadline.',
                    'Never fulfil on the basis of a receipt photo sent by the customer.',
                    'Remind the customer before the reference expires, and close the order automatically afterwards.',
                ] },
            ] },
            { id: 'planning-for-pay-in-only', heading: 'What does pay-in only mean for your business?', blocks: [
                'Pay-in only means KaazPay can collect from customers in these six markets but cannot send money to local bank accounts or wallets there. For many businesses (one-off digital purchases, game top-ups, online courses, subscriptions) this has no effect.',
                'It matters if your model depends on paying people back. Before launching, decide how you will handle:',
                { list: [
                    '**Refunds**: whether you offer store credit, or a manual process agreed with your account manager.',
                    '**User withdrawals or seller earnings**: platforms with balances may need to limit withdrawals in these markets or route them differently.',
                    '**Customer messaging**: tell users up front which actions are available in their country.',
                ] },
                'On the settlement side nothing changes: PEN, CLP, GTQ, CRC and USD collections are all settled to you in USDT. Many KaazPay channels settle D+0, others D+1 or later, confirmed per channel before go-live. The [USDT settlement guide](/guides/usdt-settlement) explains how it works.',
            ] },
            { id: 'launch-six-markets-with-kaazpay', heading: 'How do you launch these markets with KaazPay?', blocks: [
                { steps: [
                    'Open a merchant account and tell us which of the six markets you want, plus your expected volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with our engineers using the [developer documentation](/developers); the same integration also covers Mexico, Colombia and Brazil.',
                    'Go live and track completion per country and method, paying particular attention to pending cash orders.',
                ] },
                'If you are deciding whether to add these markets through one provider or several, our [one gateway vs multiple providers](/compare/one-gateway-vs-multiple-providers) comparison may help. To get a channel plan, [contact KaazPay on Telegram](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'What is PagoEfectivo?', a: 'PagoEfectivo is a Peruvian payment method. The customer receives a payment code at checkout and pays it in online banking, a mobile wallet, or at an agent or store. KaazPay supports it for pay-in in Peru.' },
            { q: 'Which currency do customers use in Ecuador and El Salvador?', a: 'The US dollar. Customers in both countries pay in USD. In Peru, Chile, Guatemala and Costa Rica they pay in PEN, CLP, GTQ and CRC.' },
            { q: 'Can I send payouts to Peru, Chile or Central America with KaazPay?', a: 'No. Peru, Chile, Ecuador, Guatemala, Costa Rica and El Salvador are pay-in only. In Latin America, KaazPay payouts go to bank accounts in Mexico, Colombia and Brazil.' },
            { q: 'How can customers pay in El Salvador?', a: 'KaazPay supports El Salvador Cash Payment: the customer gets payment instructions at checkout and pays in USD, and the order is confirmed after the payment is reported.' },
            { q: 'Does KaazPay support Banco Nacional in Costa Rica?', a: "Yes. Customers of Banco Nacional, one of Costa Rica's major state banks, can pay directly from their account. Costa Rica Cash Payment is also available." },
            { q: 'How am I settled for these markets?', a: 'Collections in PEN, CLP, GTQ, CRC and USD are settled to you in USDT. The settlement cycle for each channel is confirmed before go-live.' },
        ],
    },
    zh: {
        title: '秘鲁、智利、厄瓜多尔与中美洲收款指南',
        description: '在秘鲁、智利、厄瓜多尔、危地马拉、哥斯达黎加和萨尔瓦多收款：PagoEfectivo、Banco Nacional、银行转账与现金支付等本地支付方式。',
        h1: '如何在秘鲁、智利、厄瓜多尔、危地马拉、哥斯达黎加和萨尔瓦多收款？',
        summary: '在秘鲁、智利、厄瓜多尔、危地马拉、哥斯达黎加和萨尔瓦多，线上用户主要通过银行转账、本地银行直付，或凭付款编号用现金付款。KaazPay 一次对接即可在这 6 个市场开通代收，包括秘鲁的 PagoEfectivo 和哥斯达黎加的 Banco Nacional，代收资金以 USDT 结算。这 6 个市场仅支持代收，KaazPay 在当地不提供代付。',
        queries: [
            '如何向秘鲁和智利的用户在线收款？',
            'PagoEfectivo 是什么？对商户如何运作？',
            '危地马拉、哥斯达黎加、萨尔瓦多可以接哪些支付方式？',
            '厄瓜多尔和萨尔瓦多用户是用美元付款吗？',
            '可以通过支付网关向秘鲁或智利代付吗？',
        ],
        takeaways: [
            'KaazPay 在这一区域覆盖 6 个市场：安第斯与太平洋沿岸的秘鲁、智利、厄瓜多尔，以及中美洲的危地马拉、哥斯达黎加、萨尔瓦多。',
            '每个市场都有现金支付；秘鲁另有 PagoEfectivo，哥斯达黎加另有 Banco Nacional。',
            '厄瓜多尔和萨尔瓦多使用美元，用户以 USD 付款；其余市场分别以 PEN、CLP、GTQ、CRC 付款。',
            '这 6 个市场在 KaazPay 上均为仅代收，退款和用户提现需在上线前规划好。',
            '代收资金以 USDT 结算，各通道结算周期在上线前确认。',
        ],
        sections: [
            { id: 'six-markets-short-answer', heading: '这 6 个市场的用户如何在线付款？', blocks: [
                '不少商户在拉美只覆盖墨西哥、哥伦比亚和巴西。以下 6 个市场单个规模不大，但合计是一个可观的客群，且支付方式易于覆盖。',
                '这 6 个市场的收银台核心基本一致：一种从本地银行账户付款的方式，加上一种凭收银台生成的付款编号用现金支付的方式。秘鲁和哥斯达黎加各自还有一个知名的本地选项。KaazPay 用与其他[拉美市场](/guides/latin-america-payments-overview)相同的一套对接即可覆盖这 6 国。',
            ] },
            { id: 'six-markets-coverage', heading: 'KaazPay 在每个国家支持哪些支付方式？', blocks: [
                { table: { head: ['市场', '币种', 'KaazPay 代收方式', '代付'], rows: [
                    ['秘鲁', 'PEN（秘鲁索尔）', 'PagoEfectivo、秘鲁银行转账、秘鲁现金支付', '不支持'],
                    ['智利', 'CLP（智利比索）', '智利银行转账、智利现金支付', '不支持'],
                    ['厄瓜多尔', 'USD（美元）', '厄瓜多尔银行转账、厄瓜多尔现金支付', '不支持'],
                    ['危地马拉', 'GTQ（危地马拉格查尔）', '危地马拉银行转账、危地马拉现金支付', '不支持'],
                    ['哥斯达黎加', 'CRC（哥斯达黎加科朗）', 'Banco Nacional、哥斯达黎加现金支付', '不支持'],
                    ['萨尔瓦多', 'USD（美元）', '萨尔瓦多现金支付', '不支持'],
                ] } },
                { note: '以上 6 个市场在 KaazPay 上仅支持代收。拉美地区的银行账户代付目前覆盖墨西哥、哥伦比亚和巴西。' },
            ] },
            { id: 'peru-payments', heading: '如何在秘鲁收款？', blocks: [
                '秘鲁是这 6 国中选择最多的市场。最知名的本地方式是 **[PagoEfectivo](/methods/pagoefectivo)**：用户在收银台获取付款码，然后通过网银、手机钱包，或到代理点、商店付款。同一种方式既能服务有银行账户的用户，也能服务偏好线下付款的用户。',
                '**秘鲁银行转账**适合想直接从账户付款的用户，**秘鲁现金支付**则覆盖希望凭付款编号用现金付款的用户。用户以秘鲁索尔（PEN）付款。当前通道见[秘鲁市场页面](/payment-methods/peru)。',
            ] },
            { id: 'chile-ecuador-payments', heading: '智利和厄瓜多尔的收款如何运作？', blocks: [
                '**智利**：KaazPay 支持**智利银行转账**和**智利现金支付**，用户以智利比索（CLP）付款。银行转账适合使用网银的用户，现金支付则适合偏好线下付款的用户。通道详情见[智利市场页面](/payment-methods/chile)。',
                '**厄瓜多尔**：自 2000 年起以美元为法定货币，因此用户以 **USD** 付款。KaazPay 提供**厄瓜多尔银行转账**和**厄瓜多尔现金支付**。如果您在其他市场已经以美元定价，厄瓜多尔适合作为测试市场。详见[厄瓜多尔市场页面](/payment-methods/ecuador)。',
            ] },
            { id: 'central-america-payments', heading: '如何在危地马拉、哥斯达黎加和萨尔瓦多收款？', blocks: [
                '**危地马拉**：用户以格查尔（GTQ）通过**危地马拉银行转账**或**危地马拉现金支付**付款。详见[危地马拉市场页面](/payment-methods/guatemala)。',
                '**哥斯达黎加**：哥斯达黎加主要国有银行之一 **[Banco Nacional](/methods/banco-nacional)** 的客户可以直接用科朗（CRC）从账户付款；在其他银行开户或偏好现金的用户，可以使用**哥斯达黎加现金支付**。详见[哥斯达黎加市场页面](/payment-methods/costa-rica)。',
                '**萨尔瓦多**：当地使用美元，KaazPay 支持**萨尔瓦多现金支付**，用户以 USD 付款。由于每笔订单都是下单后再线下付款，系统应从一开始就支持待支付订单。详见[萨尔瓦多市场页面](/payment-methods/el-salvador)。',
            ] },
            { id: 'cash-reference-flow', heading: '一笔现金支付订单的完整流程是怎样的？', blocks: [
                '现金和付款码方式在这些市场占比较大，订单流程需要妥善处理。典型流程如下：',
                { steps: [
                    '用户选择现金支付（秘鲁也可选 PagoEfectivo），您通过 KaazPay API 创建订单。',
                    '页面显示付款编号、准确金额、币种和截止时间，并通过邮件或消息同步发送给用户。',
                    '用户线下付款；如果是 PagoEfectivo，也可以通过网银或手机钱包付款。',
                    '付款回传后，KaazPay 向您的服务器推送该订单的通知。',
                    '系统验证通知，将订单标记为已付款并完成交付。',
                ] },
                { list: [
                    '未付款订单不要标记为失败，在截止前保持待支付状态。',
                    '不要凭用户发来的付款凭证照片发货。',
                    '付款编号到期前提醒用户，到期后自动关闭订单。',
                ] },
            ] },
            { id: 'planning-for-pay-in-only', heading: '“仅代收”对您的业务意味着什么？', blocks: [
                '“仅代收”是指 KaazPay 可以向这 6 个市场的用户收款，但不能向当地银行账户或钱包代付。对一次性数字商品、游戏充值、在线课程、订阅等许多业务而言，这没有影响。',
                '如果您的业务模式需要向用户付款，则须提前规划。上线前请明确以下几点：',
                { list: [
                    '**退款**：是改为发放站内余额，还是与客户经理约定人工处理流程。',
                    '**用户提现或卖家收益**：带余额体系的平台可能需要在这些市场限制提现，或另行安排。',
                    '**用户沟通**：提前告诉用户在其所在国家可以使用哪些功能。',
                ] },
                '结算方面没有区别：PEN、CLP、GTQ、CRC 和 USD 代收都以 USDT 结算给您。KaazPay 不少通道支持 D+0，其余为 D+1 或更长，上线前按通道确认。具体机制见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'launch-six-markets-with-kaazpay', heading: '如何通过 KaazPay 上线这些市场？', blocks: [
                { steps: [
                    '开设商户账户，告诉我们需要开通 6 个市场中的哪些，以及预计交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接；同一套对接也覆盖墨西哥、哥伦比亚和巴西。',
                    '正式上线，按国家和支付方式跟踪完成率，尤其关注待支付的现金订单。',
                ] },
                '如果您在考虑用一家还是多家服务商来覆盖这些市场，可参考[单一网关与多家服务商对比](/compare/one-gateway-vs-multiple-providers)。需要通道方案，请[通过 Telegram 联系 KaazPay](/contact)，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'PagoEfectivo 是什么？', a: 'PagoEfectivo 是秘鲁的支付方式。用户在收银台获取付款码，再通过网银、手机钱包或到代理点、商店付款。KaazPay 在秘鲁支持 PagoEfectivo 代收。' },
            { q: '厄瓜多尔和萨尔瓦多用户用什么货币付款？', a: '美元。两国用户都以 USD 付款；秘鲁、智利、危地马拉和哥斯达黎加则分别以 PEN、CLP、GTQ 和 CRC 付款。' },
            { q: 'KaazPay 能向秘鲁、智利或中美洲代付吗？', a: '不能。秘鲁、智利、厄瓜多尔、危地马拉、哥斯达黎加和萨尔瓦多仅支持代收。在拉美，KaazPay 的代付覆盖墨西哥、哥伦比亚和巴西的银行账户。' },
            { q: '萨尔瓦多用户如何付款？', a: 'KaazPay 支持萨尔瓦多现金支付：用户在收银台获取付款信息后以美元付款，付款回传后订单即确认。' },
            { q: 'KaazPay 支持哥斯达黎加的 Banco Nacional 吗？', a: '支持。哥斯达黎加主要国有银行之一 Banco Nacional 的客户可以直接从账户付款，另外也提供哥斯达黎加现金支付。' },
            { q: '这些市场的资金如何结算？', a: 'PEN、CLP、GTQ、CRC 和 USD 代收均以 USDT 结算给您，各通道结算周期在上线前确认。' },
        ],
    },
};
