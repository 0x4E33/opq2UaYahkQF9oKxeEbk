export default {
    slug: 'philippines-gcash',
    kind: 'guide',
    published: '2025-03-25',
    updated: '2025-06-24',
    related: {
        markets: ['philippines'],
        methods: ['gcash'],
        industries: ['gaming', 'live-streaming', 'e-commerce', 'education'],
        articles: ['southeast-asia-payment-methods', 'mass-payouts-emerging-markets', 'payment-success-rate', 'usdt-settlement'],
    },
    en: {
        title: 'How to Accept GCash Payments in the Philippines',
        description: 'A merchant guide to GCash: how the payment flow works on mobile and desktop, what to build, which businesses gain most, PHP bank payouts and USDT settlement.',
        h1: 'How can an online business accept GCash payments?',
        summary: 'An online business accepts GCash by connecting to a payment gateway that offers GCash pay-in: you create an order in PHP, the buyer approves it in the GCash app, and your server receives a signed confirmation. KaazPay provides GCash collections, payouts to Philippine bank accounts and USDT settlement through one integration and one merchant dashboard.',
        queries: [
            'Our app has many users in the Philippines. How do we add GCash as a payment option?',
            'Can a company outside the Philippines accept GCash payments?',
            'What happens if a customer cancels inside the GCash app?',
            'Can we pay out to Filipino users after they top up with GCash?',
            'Is GCash suitable for small in-app purchases like coins and gifts?',
        ],
        takeaways: [
            'GCash is the Philippines’ leading e-wallet and often the first method Filipino buyers look for.',
            'Buyers approve payments inside the app, which keeps mobile checkout short.',
            'On KaazPay, GCash is for pay-in; payouts in the Philippines go to bank accounts in PHP.',
            'Peso collections are settled to you in USDT, so no Philippine account is needed to receive funds.',
            'Handle cancellations and pending states clearly, and fulfil only from verified notifications.',
        ],
        sections: [
            {
                id: 'why-gcash',
                heading: 'Why does GCash matter for selling to Filipino customers?',
                blocks: [
                    '[GCash](/methods/gcash) is the most widely used e-wallet in the Philippines. Filipinos use it to pay bills, shop, send money to family and pay in stores, all from their phone. For an online merchant, this means many buyers already hold a wallet balance and are used to approving payments in the app.',
                    'A checkout without GCash asks these buyers to find a card that works for online, often foreign, purchases, and many abandon the purchase at that point. Offering GCash removes that step.',
                ],
            },
            {
                id: 'payment-flow',
                heading: 'What happens during a GCash payment?',
                blocks: [
                    {
                        steps: [
                            'Your server creates a pay-in order in PHP through the KaazPay API.',
                            'The buyer selects GCash and is handed over to GCash to authorise the payment.',
                            'The buyer logs in and confirms the amount in GCash.',
                            'KaazPay sends your server a signed, real-time notification with the final status.',
                            'Your system verifies the notification, marks the order paid and delivers.',
                        ],
                    },
                    'On a phone, the buyer usually stays on one device from start to finish. On a laptop, they may need to complete the step on their phone, so state this clearly on screen before the hand-over.',
                ],
            },
            {
                id: 'what-to-build',
                heading: 'What do you need to build around GCash?',
                blocks: [
                    {
                        list: [
                            '**A waiting screen.** While the buyer is in GCash, show a page that explains the current step and updates automatically.',
                            '**A clear cancel path.** If the buyer cancels in GCash or the approval times out, return them to checkout with the order still recoverable and another chance to pay.',
                            '**Notification handling.** Verify every signature, check amount and currency, and make the handler idempotent so a repeated notification never credits twice.',
                            '**Status queries.** For orders pending longer than expected, query the status instead of assuming failure.',
                            '**Daily reconciliation.** Match GCash orders against the KaazPay dashboard every day.',
                        ],
                    },
                    'The [integration checklist](/guides/payment-gateway-integration-checklist) covers these in more depth for any market.',
                ],
            },
            {
                id: 'best-fit',
                heading: 'Which products and business models suit GCash best?',
                blocks: [
                    {
                        table: {
                            head: ['Business', 'Typical purchase', 'Why GCash fits'],
                            rows: [
                                ['Mobile games', 'Coins, passes, top-ups', 'Fast in-app approval for small amounts'],
                                ['Live streaming and social apps', 'Gifts, coins, subscriptions', 'Frequent low-value payments from a phone'],
                                ['Online courses and education', 'Course fees, memberships', 'Many learners prefer not to pay by card'],
                                ['E-commerce and digital goods', 'One-off orders, vouchers', 'Reaches shoppers without an online card'],
                            ],
                        },
                    },
                    'If your success rate on GCash looks lower than expected, [how to raise your payment success rate](/guides/payment-success-rate) explains where to look.',
                ],
            },
            {
                id: 'philippines-on-kaazpay',
                heading: 'What does KaazPay offer in the Philippines?',
                blocks: [
                    {
                        table: {
                            head: ['Item', 'Philippines on KaazPay'],
                            rows: [
                                ['Currency', 'PHP'],
                                ['Pay-in method', 'GCash'],
                                ['Payouts', 'Bank transfer to Philippine bank accounts, single or batch'],
                                ['GCash payouts', 'Not available; GCash is pay-in only'],
                                ['Settlement to you', 'Equivalent amount in USDT'],
                                ['Notifications', 'Real-time and signed, for every pay-in and payout'],
                            ],
                        },
                    },
                    'The current channel list is on the [Philippines market page](/payment-methods/philippines).',
                ],
            },
            {
                id: 'payouts-and-settlement',
                heading: 'How do payouts and settlement work in the Philippines?',
                blocks: [
                    'Platforms that also pay users, such as games paying withdrawals or apps sharing revenue with creators, can send **bank transfer payouts in PHP** from the same KaazPay account that collects GCash payments, each with a status notification. See [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
                    'Buyers pay in pesos and KaazPay settles the equivalent to you in **USDT**. Many channels settle D+0, others D+1 or later; your account manager confirms the GCash cycle before go-live. More in [how USDT settlement works](/guides/usdt-settlement).',
                ],
            },
            {
                id: 'go-live-checklist',
                heading: 'What should you test before launching GCash?',
                blocks: [
                    {
                        steps: [
                            'A completed GCash payment on mobile and on desktop.',
                            'A payment cancelled inside GCash, and a retry.',
                            'A notification delivered twice, to prove nothing is credited twice.',
                            'A payout to a Philippine bank account, plus one with a wrong account number.',
                            'How each test appears in the merchant dashboard.',
                        ],
                    },
                    'For Malaysia, Indonesia and other markets in the region, see the [Southeast Asia payment methods guide](/guides/southeast-asia-payment-methods).',
                ],
            },
            {
                id: 'get-started',
                heading: 'How do you start accepting GCash with KaazPay?',
                blocks: [
                    {
                        steps: [
                            'Open a merchant account and share your expected Philippine volumes.',
                            'Receive your API keys.',
                            'Integrate with an engineer on hand for joint testing; see the [developer page](/developers).',
                            'Go live with GCash pay-in and bank payouts.',
                        ],
                    },
                    'Message us on Telegram via the [contact page](/contact). We reply within one business day with a channel plan and pricing.',
                ],
            },
        ],
        faq: [
            { q: 'How does a business accept GCash online?', a: 'Through a payment gateway that offers GCash pay-in. With KaazPay you create a PHP order via the API, the buyer approves it in GCash, and your server receives a signed notification.' },
            { q: 'Can a company based outside the Philippines accept GCash?', a: 'KaazPay provides GCash pay-in and settles collections in USDT, so you do not need a Philippine account to receive funds. Your account manager confirms onboarding requirements for your business.' },
            { q: 'Can I send payouts to GCash wallets through KaazPay?', a: 'No. GCash is a pay-in method on KaazPay. Payouts in the Philippines go to recipient bank accounts in PHP.' },
            { q: 'What happens if the buyer cancels in GCash?', a: 'The payment does not complete and you receive the final status. Return the buyer to checkout so they can try again or choose another option.' },
            { q: 'Is GCash good for low-value, frequent purchases?', a: 'Yes. In-app approval is quick, which suits coins, gifts, top-ups and subscriptions that should be delivered immediately.' },
        ],
    },
    zh: {
        title: '如何接入 GCash：菲律宾电子钱包收款指南',
        description: '商户接入 GCash 收款指南：手机与电脑端付款流程、需要开发的配套功能、最适合的业务类型，以及菲律宾比索银行代付与 USDT 结算安排。',
        h1: '线上商户如何接受 GCash 付款？',
        summary: '线上商户要收 GCash，需要接入一个提供 GCash 代收的支付网关：以菲律宾比索（PHP）创建订单，用户在 GCash App 内确认，商户服务器收到带签名的确认通知。KaazPay 通过一次接入和一个商户后台，提供 GCash 代收、代付到菲律宾银行账户以及 USDT 结算。',
        queries: [
            '我们的 App 在菲律宾有很多用户，要怎么加上 GCash 付款？',
            '菲律宾以外的公司可以收 GCash 付款吗？',
            '用户在 GCash 里取消付款会怎么样？',
            '用户用 GCash 充值后，我们能给菲律宾用户打款吗？',
            'GCash 适合金币、礼物这类小额应用内购买吗？',
        ],
        takeaways: [
            'GCash 是菲律宾领先的电子钱包，往往是菲律宾用户在收银台首先寻找的支付方式。',
            '用户在 App 内确认付款，手机端流程很短。',
            '在 KaazPay，GCash 用于代收；菲律宾的代付以比索打入银行账户。',
            '比索代收以 USDT 结算，收款无需菲律宾账户。',
            '清楚处理取消和处理中状态，并只依据验签通过的回调发货。',
        ],
        sections: [
            {
                id: 'why-gcash',
                heading: '向菲律宾用户销售，为什么需要 GCash？',
                blocks: [
                    '[GCash](/methods/gcash) 是菲律宾使用最广泛的电子钱包。菲律宾人用它缴账单、网购、给家人转账和在店里付款，全部在手机上完成。对线上商户而言，这意味着很多用户钱包已有余额，也习惯在 App 内确认付款。',
                    '收银台如果没有 GCash，这些用户就需要另找一张支持线上（且往往是境外）交易的银行卡，不少人会因此放弃购买。提供 GCash 可省去这一步。',
                ],
            },
            {
                id: 'payment-flow',
                heading: '一笔 GCash 付款是怎么完成的？',
                blocks: [
                    {
                        steps: [
                            '商户服务器通过 KaazPay API 以 PHP 创建代收订单。',
                            '用户选择 GCash，被引导到 GCash 进行授权。',
                            '用户登录 GCash 并确认金额。',
                            'KaazPay 向商户服务器发送带签名的实时回调，告知最终状态。',
                            '商户验签后把订单标记为已付款并发货。',
                        ],
                    },
                    '用手机付款时，用户通常全程在同一台设备上完成；用电脑时，可能需要在手机上完成确认，因此跳转前应在页面上清楚说明。',
                ],
            },
            {
                id: 'what-to-build',
                heading: '围绕 GCash 需要开发哪些配套功能？',
                blocks: [
                    {
                        list: [
                            '**等待页。** 用户在 GCash 内操作时，显示说明当前进度并自动更新的页面。',
                            '**清晰的取消路径。** 用户在 GCash 内取消或确认超时，应回到收银台，订单仍可恢复，并能再次付款。',
                            '**回调处理。** 每条回调都验签、核对金额与币种，处理逻辑要幂等，重复通知也不会重复入账。',
                            '**状态查询。** 处理时间超出预期的订单，主动查询状态，而不是直接当作失败。',
                            '**每日对账。** 每天把 GCash 订单与 KaazPay 后台核对一次。',
                        ],
                    },
                    '适用于任何市场的详细要求，请看[支付接入清单](/guides/payment-gateway-integration-checklist)。',
                ],
            },
            {
                id: 'best-fit',
                heading: '哪些产品和业务最适合 GCash？',
                blocks: [
                    {
                        table: {
                            head: ['业务', '典型购买', '为什么适合 GCash'],
                            rows: [
                                ['手机游戏', '金币、通行证、充值', '小额付款在 App 内快速确认'],
                                ['直播与社交应用', '礼物、金币、订阅', '手机上的高频小额付款'],
                                ['线上课程与教育', '课程费、会员', '不少学员不愿意刷卡'],
                                ['电商与数字商品', '单次订单、兑换券', '触达没有线上用卡习惯的买家'],
                            ],
                        },
                    },
                    '如果 GCash 的成功率低于预期，可参考[如何提升支付成功率](/guides/payment-success-rate)排查。',
                ],
            },
            {
                id: 'philippines-on-kaazpay',
                heading: 'KaazPay 在菲律宾提供哪些服务？',
                blocks: [
                    {
                        table: {
                            head: ['项目', 'KaazPay 菲律宾'],
                            rows: [
                                ['币种', 'PHP'],
                                ['代收方式', 'GCash'],
                                ['代付', '银行转账到菲律宾银行账户，可单笔或批量'],
                                ['GCash 代付', '不支持，GCash 仅用于代收'],
                                ['结算给商户', '等额 USDT'],
                                ['回调通知', '每笔代收与代付均有带签名的实时通知'],
                            ],
                        },
                    },
                    '最新通道列表见[菲律宾市场页](/payment-methods/philippines)。',
                ],
            },
            {
                id: 'payouts-and-settlement',
                heading: '在菲律宾，代付和结算如何运作？',
                blocks: [
                    '需要给用户付款的平台，例如处理玩家提现的游戏、与主播分成的应用，可以从收取 GCash 的同一个 KaazPay 账户发起**比索银行代付**，每笔都有状态通知。详见[新兴市场批量代付](/guides/mass-payouts-emerging-markets)。',
                    '用户以比索付款，KaazPay 以等额 **USDT** 结算给商户。不少通道 D+0 结算，其余 D+1 或更长，GCash 的结算周期由客户经理在上线前确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
                ],
            },
            {
                id: 'go-live-checklist',
                heading: '上线 GCash 前要测试什么？',
                blocks: [
                    {
                        steps: [
                            '分别在手机和电脑上完成一笔 GCash 付款。',
                            '在 GCash 内取消一笔付款，然后重试。',
                            '让同一条回调到达两次，确认不会重复入账。',
                            '代付一笔到菲律宾银行账户，再用错误账号测一次。',
                            '检查每笔测试在商户后台的显示。',
                        ],
                    },
                    '马来西亚、印尼等区域内其他市场，请参阅[东南亚支付方式指南](/guides/southeast-asia-payment-methods)。',
                ],
            },
            {
                id: 'get-started',
                heading: '如何通过 KaazPay 开始收 GCash？',
                blocks: [
                    {
                        steps: [
                            '开通商户账户，提供菲律宾的预估交易量。',
                            '获取 API 密钥。',
                            '在工程师协助下接入并联调，详见[开发者页面](/developers)。',
                            '上线 GCash 代收和银行代付。',
                        ],
                    },
                    '通过[联系页面](/contact)在 Telegram 联系我们，一个工作日内提供通道方案与报价。',
                ],
            },
        ],
        faq: [
            { q: '商户怎样在线上接受 GCash 付款？', a: '通过提供 GCash 代收的支付网关。使用 KaazPay 时，通过 API 创建 PHP 订单，用户在 GCash 内确认，商户服务器收到带签名的回调。' },
            { q: '菲律宾以外的公司能收 GCash 吗？', a: 'KaazPay 提供 GCash 代收并以 USDT 结算，所以收款不需要菲律宾账户。具体开户要求由客户经理根据您的业务确认。' },
            { q: '能通过 KaazPay 代付到 GCash 钱包吗？', a: '不能。在 KaazPay，GCash 是代收方式，菲律宾的代付以比索打入收款人的银行账户。' },
            { q: '用户在 GCash 内取消会怎样？', a: '这笔付款不会完成，商户会收到最终状态。应将用户带回收银台，以便重试或选择其他方式。' },
            { q: 'GCash 适合小额高频购买吗？', a: '适合。App 内确认很快，适合需要即时到账的金币、礼物、充值和订阅。' },
        ],
    },
};
