export default {
    slug: 'colombia-payment-methods',
    kind: 'guide',
    published: '2025-08-12',
    updated: '2025-08-12',
    related: {
        markets: ['colombia'],
        methods: ['pse', 'bre-b', 'bancolombia'],
        industries: ['e-commerce', 'gaming', 'education'],
        articles: ['latin-america-payments-overview', 'andean-central-america-payments', 'instant-payments-vs-bank-transfer', 'one-gateway-vs-multiple-providers'],
    },
    en: {
        title: "Colombia Payments: PSE, Bre-B, Bancolombia & Cash",
        description: "How to accept payments in Colombia: PSE online banking, Bre-B by key or QR, Bancolombia, bank transfer and cash, plus COP bank payouts and USDT settlement.",
        h1: "How to accept online payments in Colombia",
        summary: "To accept online payments in Colombia, start with PSE, which lets shoppers pay from an account at almost any Colombian bank, then add Bre-B instant payments by key or QR, a direct Bancolombia option and cash for unbanked buyers. KaazPay offers all six Colombian pay-in channels through one integration, sends payouts to Colombian bank accounts and settles COP collections in USDT.",
        queries: [
            "What payment methods do I need to sell online in Colombia?",
            "How do I add PSE to my checkout for Colombian customers?",
            "What is Bre-B and should my store accept Bre-B QR payments?",
            "Is there one payment gateway for PSE, Bancolombia, Bre-B and cash in Colombia that settles in USDT?",
        ],
        takeaways: [
            "PSE is the default online bank payment in Colombia and reaches customers of almost every bank.",
            "Bre-B, the central bank's instant payment system, adds a fast key-based or QR-based option for account holders.",
            "A dedicated Bancolombia button shortens the path for the country's largest bank customer base.",
            "Bank transfer and cash payment cover larger payments and shoppers outside the banking system.",
            "KaazPay pays out to Colombian bank accounts and settles COP collections to you in USDT.",
        ],
        sections: [
            {
                id: 'colombia-channel-map',
                heading: "Which payment methods can you offer Colombian shoppers?",
                blocks: [
                    "Colombians pay online mainly through their banks; instant payments are growing, and cash remains common for buyers outside the banking system. KaazPay supports six COP pay-in channels:",
                    { table: {
                        head: ["Channel", "Rail", "How the shopper pays", "Main strength"],
                        rows: [
                            ["[PSE](/methods/pse)", "Online banking", "Picks their bank, logs in, approves", "Works with almost any Colombian bank"],
                            ["[Bre-B](/methods/bre-b) (Key)", "Instant payment", "Sends to a payment key in their app", "Typically confirms in seconds"],
                            ["[Bre-B](/methods/bre-b) (QR)", "Instant payment", "Scans the on-screen QR with a bank or wallet app", "Easy desktop-to-phone handoff"],
                            ["[Bancolombia](/methods/bancolombia)", "Bank payment", "Pays from a Bancolombia account", "Direct route for the largest bank's customers"],
                            ["Colombia Bank Transfer", "Bank transfer", "Transfers from their own account", "Larger one-off amounts"],
                            ["Colombia Cash Payment", "Cash", "Pays in person using payment instructions", "Reaches unbanked buyers"],
                        ],
                    } },
                    "The [Colombia market page](/payment-methods/colombia) keeps the live list up to date.",
                ],
            },
            {
                id: 'pse-checkout-flow',
                heading: "How does a PSE payment work at checkout?",
                blocks: [
                    "**PSE** (Pagos Seguros en Línea) is the online bank payment service run by ACH Colombia. Instead of entering a card, the shopper is sent to their own bank to approve the payment:",
                    { steps: [
                        "The shopper chooses PSE and selects their bank from a list.",
                        "Their bank's online banking page opens and they sign in as usual.",
                        "They review the amount and approve the debit from their account.",
                        "KaazPay receives the result and notifies your server, and the shopper is returned to your site.",
                    ] },
                    "Because approval happens inside the bank, PSE involves no card declines. The weak point is the redirect: a slow bank page or an expired session can lose the sale, so tell shoppers what to expect before they leave your site.",
                ],
            },
            {
                id: 'bre-b-key-or-qr',
                heading: "Bre-B key or Bre-B QR: which one suits your checkout?",
                blocks: [
                    "Banco de la República, the Colombian central bank, runs **Bre-B** as the national instant payment scheme. Both variants typically move money within seconds; the difference is how the shopper starts the payment.",
                    { list: [
                        "**Bre-B (QR)** works well when the shopper is on a laptop or tablet: they scan the code on screen with the banking or wallet app on their phone and approve there.",
                        "**Bre-B (Key)** fits shoppers already on their phone: they copy a payment key, a short identifier linked to an account, and paste it into their app without needing a second screen.",
                    ] },
                    "Offering both lets you show the right one by device. KaazPay supports the key and QR variants for pay-in.",
                ],
            },
            {
                id: 'why-separate-bancolombia',
                heading: "Why list Bancolombia as its own payment option?",
                blocks: [
                    "Bancolombia is the largest bank in the country, so many of your Colombian buyers may already bank with it. A dedicated **Bancolombia** option lets them pay straight from that account without first choosing a bank from a long PSE list.",
                    "Many stores show Bancolombia next to PSE rather than instead of it: Bancolombia customers pay directly, and all other customers use PSE.",
                ],
            },
            {
                id: 'transfer-and-cash-colombia',
                heading: "Where do bank transfer and cash payment fit in?",
                blocks: [
                    "**Colombia Bank Transfer** is for customers who prefer to move money with a classic transfer, often for tuition, larger orders or business purchases where a short wait for confirmation is acceptable.",
                    "**Colombia Cash Payment** opens your store to people who have no bank account or prefer cash. They get a set of payment instructions, settle the amount in person, and KaazPay confirms the order once that payment is reported. Give cash orders an expiry and a reminder, since some will never be paid.",
                ],
            },
            {
                id: 'bogota-store-example',
                heading: "Example: how might a Colombian online store order its payment options?",
                blocks: [
                    "Consider a Bogotá fashion shop selling to shoppers across Colombia, with most traffic on mobile. A sensible layout would be:",
                    { table: {
                        head: ["Position", "On mobile", "On desktop"],
                        rows: [
                            ["1", "PSE", "PSE"],
                            ["2", "Bre-B (Key)", "Bre-B (QR)"],
                            ["3", "Bancolombia", "Bancolombia"],
                            ["4", "Cash payment", "Bank transfer"],
                            ["5", "Bank transfer", "Cash payment"],
                        ],
                    } },
                    "The order is a starting point, not a rule. Review conversion by method after the first weeks and move the options your customers actually use higher up.",
                ],
            },
            {
                id: 'cop-payouts-and-usdt',
                heading: "How do payouts and USDT settlement work for COP?",
                blocks: [
                    "KaazPay sends **payouts to Colombian bank accounts** from the same merchant account that collects your payments. Use them for refunds, seller or creator earnings, commissions and user withdrawals, singly or in batches.",
                    "On the collection side, shoppers pay in Colombian pesos and KaazPay settles the equivalent to you in **USDT**. Many channels settle D+0, others D+1 or later, and the cycle for each Colombian channel is confirmed before launch.",
                ],
            },
            {
                id: 'colombia-prelaunch-checks',
                heading: "What should you check before launching in Colombia?",
                blocks: [
                    { list: [
                        "Your checkout explains the PSE redirect and returns shoppers cleanly to an order status page.",
                        "Bre-B QR is shown on large screens and Bre-B Key on phones.",
                        "Orders wait for KaazPay's notification before anything is delivered.",
                        "Cash and transfer orders have an expiry and a reminder message.",
                        "Payout forms capture the recipient's bank, account type and number correctly.",
                    ] },
                    "Running six methods through separate providers multiplies contracts and reconciliation work; [one gateway vs multiple providers](/compare/one-gateway-vs-multiple-providers) sets out the trade-offs.",
                ],
            },
            {
                id: 'colombia-start-kaazpay',
                heading: "How do you start accepting Colombian payments with KaazPay?",
                blocks: [
                    { steps: [
                        "Open a KaazPay merchant account.",
                        "Get your API keys.",
                        "Integrate and run joint tests with a KaazPay engineer, guided by the [developer documentation](/developers).",
                        "Go live with PSE, Bre-B, Bancolombia, bank transfer, cash and bank payouts.",
                    ] },
                    "For Peru, Ecuador and Central America, see our [Andean and Central America guide](/guides/andean-central-america-payments). Contact our business team on Telegram via the [contact page](/contact) and we will reply within one business day with a Colombia channel plan and pricing.",
                ],
            },
        ],
        faq: [
            { q: "What is the most common way to pay online in Colombia?", a: "PSE, the online bank payment service run by ACH Colombia, is a standard option because shoppers can use it with accounts at nearly all Colombian banks." },
            { q: "Does KaazPay support Bre-B payments?", a: "Yes. KaazPay supports Bre-B pay-in in Colombia by payment key and by QR code." },
            { q: "Which Colombian payment methods can I offer through KaazPay?", a: "PSE, Bancolombia, Bre-B (Key), Bre-B (QR), Colombia Bank Transfer and Colombia Cash Payment, all through one integration." },
            { q: "Can I send payouts to Colombian bank accounts?", a: "Yes. KaazPay sends payouts to bank accounts in Colombia, individually or in batches, from the account that receives your collections." },
            { q: "How am I settled for payments collected in COP?", a: "KaazPay settles the equivalent of your COP collections in USDT. The rate, fees and settlement cycle are confirmed per channel before go-live." },
        ],
    },
    zh: {
        title: "哥伦比亚收款：PSE、Bre-B、Bancolombia 与现金支付",
        description: "哥伦比亚收款指南：PSE 网银支付、Bre-B 密钥与扫码、Bancolombia、银行转账和现金支付，以及哥伦比亚银行账户代付与 USDT 结算。",
        h1: "如何在哥伦比亚开展线上收款？",
        summary: "在哥伦比亚收款，先接 PSE——用户几乎可以从任何一家哥伦比亚银行的账户付款；再加上 Bre-B 实时支付（密钥或扫码）、Bancolombia 直连和现金支付，覆盖无银行账户的买家。KaazPay 一次对接即可开通全部六种哥伦比亚代收通道，支持哥伦比亚银行账户代付，比索代收资金以 USDT 结算。",
        queries: [
            "在哥伦比亚做线上销售，需要接哪些支付方式？",
            "如何在收银台为哥伦比亚客户加入 PSE 支付？",
            "Bre-B 是什么？网店有必要支持 Bre-B 扫码吗？",
            "有没有一家支付通道能同时接 PSE、Bancolombia、Bre-B 和现金，并以 USDT 结算？",
        ],
        takeaways: [
            "PSE 是哥伦比亚默认的网银支付方式，几乎覆盖所有银行的客户。",
            "Bre-B 是哥伦比亚央行的实时支付系统，为银行用户提供密钥或扫码的快速付款方式。",
            "单独设置 Bancolombia 入口，可缩短全国最大银行客户群的付款路径。",
            "银行转账和现金支付分别覆盖大额付款和银行体系之外的买家。",
            "KaazPay 支持向哥伦比亚银行账户代付，比索代收按 USDT 结算给您。",
        ],
        sections: [
            {
                id: 'colombia-channel-map',
                heading: "可以为哥伦比亚买家提供哪些付款方式？",
                blocks: [
                    "哥伦比亚人网购主要通过银行付款，实时支付日益普及，现金仍覆盖银行体系之外的买家。KaazPay 支持六种比索代收通道：",
                    { table: {
                        head: ["通道", "类型", "用户付款操作", "主要优势"],
                        rows: [
                            ["[PSE](/methods/pse)", "网银支付", "选择银行、登录、确认", "几乎支持所有哥伦比亚银行"],
                            ["[Bre-B](/methods/bre-b)（密钥）", "实时支付", "在 App 中向支付密钥付款", "通常秒级确认"],
                            ["[Bre-B](/methods/bre-b)（扫码）", "实时支付", "用银行或钱包 App 扫码", "便于电脑下单、手机付款"],
                            ["[Bancolombia](/methods/bancolombia)", "银行支付", "从 Bancolombia 账户付款", "直达最大银行的客户"],
                            ["哥伦比亚银行转账", "银行转账", "从本人账户转账", "适合大额单笔"],
                            ["哥伦比亚现金支付", "现金", "按付款指引到线下缴款", "覆盖无银行账户的买家"],
                        ],
                    } },
                    "最新通道列表以[哥伦比亚市场页面](/payment-methods/colombia)为准。",
                ],
            },
            {
                id: 'pse-checkout-flow',
                heading: "PSE 在收银台如何完成付款？",
                blocks: [
                    "**PSE**（Pagos Seguros en Línea）是由 ACH Colombia 运营的网银支付服务。用户无需输入卡号，而是跳转到自己的银行确认付款：",
                    { steps: [
                        "用户选择 PSE，并在列表中选出自己的银行。",
                        "跳转到该银行的网银页面，照常登录。",
                        "核对金额后，确认从账户扣款。",
                        "KaazPay 收到结果并通知您的服务器，用户随后返回您的网站。",
                    ] },
                    "因为确认在银行内完成，PSE 不涉及拒卡问题。它的薄弱环节在跳转：银行页面加载慢或会话超时，都可能让订单流失，因此应在用户离开网站前说明后续步骤。",
                ],
            },
            {
                id: 'bre-b-key-or-qr',
                heading: "Bre-B 密钥还是 Bre-B 扫码，哪个更适合您的收银台？",
                blocks: [
                    "**Bre-B** 是哥伦比亚央行 Banco de la República 运营的实时支付系统。两种方式通常都能秒级到账，区别在于用户如何发起付款。",
                    { list: [
                        "**Bre-B（扫码）**：适合在电脑或平板上下单的用户，用手机上的银行或钱包 App 扫描屏幕上的二维码，在手机上确认。",
                        "**Bre-B（密钥）**：适合已在手机上操作的用户，复制一个与账户绑定的简短支付密钥，粘贴到 App 中即可，无需第二块屏幕。",
                    ] },
                    "两种都提供，就能按设备展示更合适的那一个。KaazPay 的代收同时支持密钥和扫码两种方式。",
                ],
            },
            {
                id: 'why-separate-bancolombia',
                heading: "为什么要把 Bancolombia 单独列为一个付款选项？",
                blocks: [
                    "Bancolombia 是哥伦比亚最大的银行，您的买家中很可能有不少人在这家银行开户。单独提供 **Bancolombia** 选项，可以让他们直接从账户付款，不必先在 PSE 的长列表里找银行。",
                    "很多商户会把 Bancolombia 放在 PSE 旁边，而不是替代 PSE：Bancolombia 客户可直接付款，其他客户使用 PSE。",
                ],
            },
            {
                id: 'transfer-and-cash-colombia',
                heading: "银行转账和现金支付分别适合什么情况？",
                blocks: [
                    "**哥伦比亚银行转账**适合偏好传统转账的客户，常见于学费、大额订单或企业采购，这类付款可以接受稍长的确认时间。",
                    "**哥伦比亚现金支付**让没有银行账户或偏爱现金的人也能下单：用户拿到付款信息后到线下付款，付款回传后订单确认。现金订单要设置有效期和提醒，因为部分订单不会被支付。",
                ],
            },
            {
                id: 'bogota-store-example',
                heading: "举例：哥伦比亚网店的付款选项应如何排序？",
                blocks: [
                    "以一家面向全国、以手机流量为主的波哥大服装网店为例，可以这样排列：",
                    { table: {
                        head: ["位置", "手机端", "电脑端"],
                        rows: [
                            ["1", "PSE", "PSE"],
                            ["2", "Bre-B（密钥）", "Bre-B（扫码）"],
                            ["3", "Bancolombia", "Bancolombia"],
                            ["4", "现金支付", "银行转账"],
                            ["5", "银行转账", "现金支付"],
                        ],
                    } },
                    "该排序仅作为起点参考。上线几周后按支付方式查看转化率，把客户实际常用的方式排在更前面。",
                ],
            },
            {
                id: 'cop-payouts-and-usdt',
                heading: "哥伦比亚比索的代付和 USDT 结算如何运作？",
                blocks: [
                    "KaazPay 支持从收款所用的同一商户账户**向哥伦比亚银行账户代付**，可用于退款、卖家或创作者收益、佣金和用户提现，支持单笔和批量。",
                    "代收方面，用户以哥伦比亚比索付款，KaazPay 按等额 **USDT** 结算给您。不少通道支持 D+0，其余为 D+1 或更长，每个哥伦比亚通道的结算周期在上线前确认。",
                ],
            },
            {
                id: 'colombia-prelaunch-checks',
                heading: "上线哥伦比亚收款前要检查什么？",
                blocks: [
                    { list: [
                        "收银台对 PSE 跳转有说明，付款后用户能顺利回到订单状态页。",
                        "大屏展示 Bre-B 扫码，手机展示 Bre-B 密钥。",
                        "订单在收到 KaazPay 通知后才交付。",
                        "现金和转账订单设置了有效期与提醒。",
                        "代付表单能正确采集收款人的银行、账户类型和账号。",
                    ] },
                    "六种方式分别通过不同服务商接入，合同和对账工作量都会成倍增加，详见[一个网关与多家服务商对比](/compare/one-gateway-vs-multiple-providers)。",
                ],
            },
            {
                id: 'colombia-start-kaazpay',
                heading: "如何通过 KaazPay 开通哥伦比亚收款？",
                blocks: [
                    { steps: [
                        "开设 KaazPay 商户账户。",
                        "获取 API 密钥。",
                        "参照[开发者文档](/developers)，与 KaazPay 工程师一起对接并联调。",
                        "上线 PSE、Bre-B、Bancolombia、银行转账、现金支付及银行账户代付。",
                    ] },
                    "如需拓展秘鲁、厄瓜多尔或中美洲市场，请参阅[安第斯与中美洲收款指南](/guides/andean-central-america-payments)。通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在一个工作日内回复哥伦比亚通道方案与报价。",
                ],
            },
        ],
        faq: [
            { q: "哥伦比亚最常见的线上付款方式是什么？", a: "PSE 是 ACH Colombia 运营的网银支付服务，用户几乎可以从任何一家哥伦比亚银行的账户付款，是常用的标准选项。" },
            { q: "KaazPay 支持 Bre-B 吗？", a: "支持。KaazPay 在哥伦比亚支持 Bre-B 代收，可通过支付密钥或二维码付款。" },
            { q: "通过 KaazPay 可以提供哪些哥伦比亚付款方式？", a: "PSE、Bancolombia、Bre-B（密钥）、Bre-B（扫码）、哥伦比亚银行转账和哥伦比亚现金支付，一次对接全部开通。" },
            { q: "可以向哥伦比亚银行账户代付吗？", a: "可以。KaazPay 支持向哥伦比亚银行账户单笔或批量代付，款项从您收款所用的账户发出。" },
            { q: "以比索收到的款项如何结算？", a: "KaazPay 将比索代收按等额 USDT 结算给您，汇率、费率和结算周期按通道在上线前确认。" },
        ],
    },
};
