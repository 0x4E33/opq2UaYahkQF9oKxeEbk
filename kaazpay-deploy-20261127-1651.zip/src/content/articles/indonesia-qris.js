export default {
    slug: 'indonesia-qris',
    kind: 'guide',
    published: '2025-03-11',
    updated: '2025-03-11',
    related: {
        markets: ['indonesia', 'thailand'],
        methods: ['qris', 'mobile-money'],
        industries: ['gaming', 'digital-goods', 'e-commerce', 'live-streaming'],
        articles: ['southeast-asia-payment-methods', 'thailand-payment-methods', 'payment-success-rate', 'mass-payouts-emerging-markets', 'usdt-settlement'],
    },
    en: {
        title: 'QRIS Payments in Indonesia: Merchant Guide',
        description: 'Collect rupiah online with QRIS: which apps can pay, a full top-up example, why QR payments fail and how to fix them, Indonesian payouts and USDT settlement.',
        h1: 'How to accept QRIS payments online in Indonesia',
        summary: 'To accept QRIS online, your payment provider creates a dynamic QRIS code in IDR for each order, and the shopper pays it from any Indonesian banking app or e-wallet that supports QRIS, such as GoPay, OVO, DANA or ShopeePay. KaazPay offers QRIS pay-in plus Indonesian payouts to bank accounts and mobile money wallets, with collections settled to you in USDT.',
        queries: [
            'We sell game credits in Indonesia and most players have no credit card. How do we let them pay with GoPay or DANA?',
            'Is there one QR code that works for every Indonesian e-wallet and bank app?',
            'Our QRIS checkout on mobile has a low completion rate. What are we doing wrong?',
            'Can a foreign company collect rupiah through QRIS and also pay out to Indonesian users?',
            'How do I receive QRIS collections without opening a bank account in Indonesia?',
        ],
        takeaways: [
            'QRIS is the national QR standard set by Bank Indonesia, so a single code can be paid from many banking apps and e-wallets.',
            'Online, each order gets its own dynamic QRIS code with the rupiah amount fixed, which keeps reconciliation one-to-one.',
            'Most failed QRIS payments come from mobile checkout design and expired codes, both of which can be addressed.',
            'KaazPay pairs QRIS pay-in with Indonesian payouts to bank accounts and mobile money wallets from the same account.',
            'Rupiah collections are settled to you as the equivalent amount in USDT; the cycle is confirmed per channel before launch.',
        ],
        sections: [
            { id: 'qris-for-online-merchants', heading: 'What does QRIS mean for an online merchant?', blocks: [
                '**QRIS** stands for Quick Response Code Indonesian Standard. Bank Indonesia introduced it so that the country’s many payment apps would read one common QR format instead of each publishing its own. For a merchant, this means you display one code and the shopper chooses which app to pay with.',
                'In shops, QRIS often appears as a printed sticker with a static code. Online checkouts work differently: the code is generated per order, carries the exact amount in rupiah (IDR), and is tied to your order reference. That dynamic version is what KaazPay produces through its API. Details are on the [QRIS method page](/methods/qris).',
            ] },
            { id: 'who-can-pay-qris', heading: 'Which apps can Indonesian shoppers use to pay a QRIS code?', blocks: [
                'Any Indonesian bank app or e-wallet that supports QRIS can scan and pay the code. Well-known wallets in this group include GoPay, OVO, DANA and ShopeePay, alongside the mobile apps of Indonesian banks.',
                { list: [
                    '**Wallet users** pay from their e-wallet balance, which suits small, frequent purchases such as top-ups.',
                    '**Bank app users** pay straight from their account without typing card details.',
                    '**Shoppers without a credit card**, a large group in Indonesia, can still complete the order.',
                ] },
                'As a result, you do not need separate integrations for each wallet. One QRIS channel reaches their users through the shared standard.',
            ] },
            { id: 'qris-worked-example', heading: 'Worked example: a QRIS game top-up from order to delivery', blocks: [
                'Example: a player in Surabaya buys a 50,000 IDR diamond pack on your website from a laptop. The flow with KaazPay:',
                { steps: [
                    'The player picks the pack and chooses QRIS. Your backend calls the KaazPay API to create a pay-in order for 50,000 IDR with your own unique order ID.',
                    'KaazPay returns a QRIS code for that order. Your page displays it at a readable size, with the amount and a timer if the code has a validity window.',
                    'The player opens their e-wallet on their phone, scans the screen and confirms the payment in the app.',
                    'KaazPay posts a signed notification to your server. You verify the signature, check that the order ID and amount match, and mark the order paid once.',
                    'Your game server credits the diamonds, and the browser page, which has been polling your backend, switches to a success screen.',
                ] },
                'The key step is 4: delivery is triggered by the verified server notification, not by the player clicking “I have paid”.',
            ] },
            { id: 'qris-failure-fixes', heading: 'Why do QRIS payments fail, and how do you fix it?', blocks: [
                'When QRIS conversion is lower than expected, the cause is usually on the checkout side rather than the rail. Check these patterns first:',
                { table: { head: ['What you see', 'Likely cause', 'Fix'], rows: [
                    ['Many codes shown on mobile, few paid', 'The shopper is on the same phone and cannot scan their own screen', 'Offer a “save QR image” button and short steps for opening it from the gallery in their payment app'],
                    ['Shopper paid but order still shows pending', 'The page relies on the redirect instead of the server status', 'Poll your backend or push the status once the notification arrives'],
                    ['Payment rejected in the app', 'The code expired, or the amount exceeds what the payer’s app allows', 'Show the validity time and let the shopper generate a fresh code; split very large orders or offer another method'],
                    ['Duplicate deliveries', 'The same notification was processed twice', 'Make order updates idempotent on your order ID'],
                    ['Shopper asks “which app?”', 'No guidance on the page', 'State that any Indonesian bank app or e-wallet with QRIS can pay'],
                ] } },
                'Measuring “codes shown” against “codes paid” per device type shows where shoppers drop off. Our [payment success rate guide](/guides/payment-success-rate) has more ideas.',
            ] },
            { id: 'indonesia-payout-options', heading: 'How can you pay users and partners in Indonesia?', blocks: [
                'Indonesia is one of the KaazPay markets that support both pay-in and payouts. Alongside QRIS pay-in, you can send IDR payouts to two kinds of destination:',
                { table: { head: ['Payout rail', 'Who it suits', 'Typical use'], rows: [
                    ['Bank transfer', 'Recipients with an Indonesian bank account, businesses', 'Supplier invoices, larger withdrawals, partner settlements'],
                    ['Mobile money', 'Individuals who keep their balance in an e-wallet', 'Player cash-outs, creator and affiliate earnings, refunds'],
                ] } },
                'Payouts can go out one by one or in batches, and each returns its own status so your platform can update balances automatically. The destinations available for your use case are confirmed with you before go-live. For batch operations at scale, read [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets).',
            ] },
            { id: 'rupiah-usdt-settlement', heading: 'How do rupiah collections reach you?', blocks: [
                'Shoppers pay in IDR. KaazPay then settles the equivalent amount to you in **USDT**, which means you can sell in Indonesia without opening a local bank account or holding rupiah.',
                'Settlement timing differs by channel: many KaazPay channels settle D+0, while others settle D+1 or later. The cycle, rate and fees for QRIS are agreed in writing before you launch. See the [USDT settlement guide](/guides/usdt-settlement) for how the conversion works.',
            ] },
            { id: 'qris-go-live-checklist', heading: 'What should you prepare before launching QRIS?', blocks: [
                { list: [
                    'Unique order IDs for every pay-in request, so retries never create a second charge.',
                    'Signature verification on every notification, with a log of raw payloads for support cases.',
                    'A mobile flow that works without a second device (save image, clear instructions).',
                    'An expiry message and a one-tap way to request a new code.',
                    'Payout recipient data validated before submission, for both bank and wallet payouts.',
                    'Agreed settlement cycle, rates and fees for Indonesia.',
                ] },
                'For other markets in the region, the [Southeast Asia payment methods guide](/guides/southeast-asia-payment-methods) compares QRIS with FPX, DuitNow, PayNow and GCash, and the [Thailand guide](/guides/thailand-payment-methods) covers Thai QR Payment, another national QR standard.',
            ] },
            { id: 'start-qris-with-kaazpay', heading: 'How to start accepting QRIS with KaazPay', blocks: [
                'Indonesia follows the same four-step onboarding as every other market:',
                { steps: [
                    'Open a merchant account and tell us your product, target markets and expected volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with engineer support, using the [developer documentation](/developers), and test QRIS and payouts end to end.',
                    'Go live with QRIS pay-in and Indonesian payouts, managed from one dashboard.',
                ] },
                'The full channel list is on the [Indonesia market page](/payment-methods/indonesia). To get a channel plan, settlement terms and pricing, message our business team on Telegram via the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Do I need to sign up with GoPay, OVO and DANA separately to accept them?', a: 'Not when you use QRIS. The code follows a national standard, so users of those wallets and of Indonesian bank apps can all pay the same QRIS code through one KaazPay integration.' },
            { q: 'Is an online QRIS code the same as the sticker in a shop?', a: 'No. Shop stickers are usually static codes. For online orders KaazPay generates a dynamic code per order, with the IDR amount and your order reference already set.' },
            { q: 'How do shoppers pay QRIS if they are using only one phone?', a: 'They save the QR image and open it from their payment app’s scan screen. A save button and brief instructions on your checkout help shoppers complete the payment.' },
            { q: 'Can I pay out to e-wallets in Indonesia with KaazPay?', a: 'Yes. KaazPay supports Indonesian payouts to mobile money wallets as well as to bank accounts, as single or batch payouts with a status for each.' },
            { q: 'What do I receive for QRIS collections?', a: 'The equivalent amount in USDT. Settlement timing is set per channel, D+0 on many channels and D+1 or later on others, and is confirmed before go-live.' },
        ],
    },
    zh: {
        title: '印尼 QRIS 代收指南：扫码收款与代付',
        description: '面向商户的印尼 QRIS 代收实操：哪些 App 能付款、一笔充值从下单到到账的完整示例、扫码失败的常见原因与解决办法、印尼代付和 USDT 结算。',
        h1: '在印尼如何接入 QRIS 线上收款？',
        summary: '线上接入 QRIS，需要支付通道为每笔订单生成以 IDR 计价的动态 QRIS 码，买家用任何支持 QRIS 的印尼银行 App 或电子钱包（如 GoPay、OVO、DANA、ShopeePay）扫码即可付款。KaazPay 提供 QRIS 代收，以及印尼银行账户和移动钱包代付，代收资金以 USDT 结算给商户。',
        queries: [
            '我们在印尼卖游戏点券，大部分玩家没有信用卡，怎样让他们用 GoPay 或 DANA 付款？',
            '有没有一个二维码能让印尼所有电子钱包和银行 App 都能扫？',
            '我们手机端的 QRIS 收银台付款完成率很低，问题出在哪里？',
            '海外公司能通过 QRIS 收印尼盾，同时给印尼用户代付吗？',
            '没有印尼银行账户，如何收取 QRIS 代收款项？',
        ],
        takeaways: [
            'QRIS 是印尼央行制定的全国统一二维码标准，同一个码可被众多银行 App 和电子钱包扫码支付。',
            '线上场景下每笔订单生成独立的动态码，金额固定，订单与付款一一对应，对账简单。',
            'QRIS 付款失败多半源于手机端收银台设计和二维码过期，两者均可改善。',
            'KaazPay 在同一账户内提供 QRIS 代收与印尼银行账户、移动钱包代付。',
            '印尼盾代收按等额 USDT 结算，各通道结算周期在上线前确认。',
        ],
        sections: [
            { id: 'qris-for-online-merchants', heading: '对线上商户来说，QRIS 意味着什么？', blocks: [
                '**QRIS**（Quick Response Code Indonesian Standard）由印尼央行推出，目的是让各家支付 App 读取同一种二维码格式，而非各自使用不同格式。对商户而言，只需展示一个码，由买家自行选择付款 App。',
                '线下门店常见的是贴在柜台上的静态码；线上收银台则不同，每笔订单单独生成动态码，码中包含精确的印尼盾（IDR）金额和您的订单号。KaazPay 通过 API 生成的正是这种动态码，详情见 [QRIS 支付方式页面](/methods/qris)。',
            ] },
            { id: 'who-can-pay-qris', heading: '印尼买家能用哪些 App 扫 QRIS 码？', blocks: [
                '凡是支持 QRIS 的印尼银行 App 或电子钱包都能扫码付款，常见的钱包有 GoPay、OVO、DANA、ShopeePay，此外还有各家印尼银行的手机银行。',
                { list: [
                    '**钱包用户**直接用余额付款，适合充值这类小额高频消费。',
                    '**银行 App 用户**从账户直接扣款，无需输入卡号。',
                    '**没有信用卡的买家**（在印尼占相当比例）同样可以完成付款。',
                ] },
                '因此，无需逐一对接各个钱包；借助统一标准，一条 QRIS 通道即可覆盖这些用户。',
            ] },
            { id: 'qris-worked-example', heading: '示例：一笔 QRIS 游戏充值从下单到到账', blocks: [
                '示例：泗水一位玩家在电脑上购买 50,000 IDR 的钻石礼包，经 KaazPay 处理的流程如下：',
                { steps: [
                    '玩家选好礼包并选择 QRIS。您的后端调用 KaazPay API，用自己唯一的订单号创建一笔 50,000 IDR 的代收订单。',
                    'KaazPay 返回该订单的 QRIS 码。页面以清晰的尺寸展示，并标明金额；如果码有有效期，同时显示倒计时。',
                    '玩家在手机上打开电子钱包，扫描屏幕并在 App 内确认付款。',
                    'KaazPay 向您的服务器推送带签名的通知。您验签、核对订单号与金额后，将订单标记为已支付（只处理一次）。',
                    '游戏服务器发放钻石；浏览器页面一直在轮询您的后端，此时自动切换到成功页。',
                ] },
                '关键在第 4 步：发货必须以验签通过的服务器通知为准，而非玩家点击“我已付款”。',
            ] },
            { id: 'qris-failure-fixes', heading: 'QRIS 付款为什么会失败？如何解决？', blocks: [
                'QRIS 转化不理想时，问题通常出在收银台，而不是通道本身。建议先排查以下几种情况：',
                { table: { head: ['现象', '可能原因', '解决办法'], rows: [
                    ['手机端展示了很多码，付款的却很少', '买家只有一部手机，无法扫描自己的屏幕', '提供“保存二维码图片”按钮，并简要说明如何在支付 App 里从相册识别'],
                    ['买家已付款，订单仍显示待支付', '页面依赖跳转回调，而不是服务器端状态', '轮询您的后端，或在收到通知后主动推送状态'],
                    ['App 内提示付款失败', '二维码已过期，或金额超出付款 App 的限额', '展示有效期并允许一键重新生成；大额订单可拆分或提供其他支付方式'],
                    ['重复发货', '同一条通知被处理了两次', '以订单号做幂等处理'],
                    ['买家询问“用哪个 App 付款？”', '页面缺少说明', '注明任何支持 QRIS 的印尼银行 App 或电子钱包均可付款'],
                ] } },
                '按设备类型统计“展示码数”与“已付款数”，即可定位流失环节。更多方法见[支付成功率指南](/guides/payment-success-rate)。',
            ] },
            { id: 'indonesia-payout-options', heading: '在印尼如何给用户和合作方付款？', blocks: [
                '印尼是 KaazPay 同时支持代收与代付的市场之一。除了 QRIS 代收，还可将印尼盾代付到两类收款方：',
                { table: { head: ['代付方式', '适合对象', '常见用途'], rows: [
                    ['银行转账', '有印尼银行账户的个人或企业', '供应商货款、大额提现、合作方结算'],
                    ['移动钱包', '主要使用电子钱包余额的个人', '玩家提现、主播与推广佣金、退款'],
                ] } },
                '代付支持单笔和批量，每笔都会返回独立状态，方便平台自动更新余额。具体可用的收款方式会在上线前按您的业务确认。批量代付的运营做法可参考[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)。',
            ] },
            { id: 'rupiah-usdt-settlement', heading: '印尼盾代收款项如何结算给您？', blocks: [
                '买家以 IDR 付款，KaazPay 将等额 **USDT** 结算给您，因此无需在印尼开立银行账户，也无需持有印尼盾。',
                '结算周期因通道而异：KaazPay 许多通道为 D+0，其余为 D+1 或更长。QRIS 的结算周期、汇率与费率会在上线前书面确认。换汇与结算的具体方式见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'qris-go-live-checklist', heading: '上线 QRIS 前要准备什么？', blocks: [
                { list: [
                    '每笔代收请求使用唯一订单号，重试时不会重复扣款。',
                    '所有通知都验签，并保存原始报文，便于客服排查。',
                    '手机端流程在没有第二台设备时也能完成（保存图片、清晰的操作说明）。',
                    '过期提示，以及一键重新生成二维码。',
                    '提交代付前先校验收款信息，银行和钱包代付都要做。',
                    '与我们确认印尼的结算周期、汇率与费率。',
                ] },
                '区域内其他市场可参考[东南亚支付方式指南](/guides/southeast-asia-payment-methods)，其中将 QRIS 与 FPX、DuitNow、PayNow、GCash 进行了比较；[泰国收款指南](/guides/thailand-payment-methods)则介绍了同为国家级二维码标准的 Thai QR Payment。',
            ] },
            { id: 'start-qris-with-kaazpay', heading: '如何通过 KaazPay 开通 QRIS 代收', blocks: [
                '在 KaazPay，印尼市场同样按四步接入：',
                { steps: [
                    '开设商户账户，说明您的产品、目标市场和预估交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，并端到端测试 QRIS 代收和代付。',
                    '正式上线 QRIS 代收与印尼代付，在一个后台统一管理。',
                ] },
                '完整通道列表见[印尼市场页面](/payment-methods/indonesia)。如需通道方案、结算条款和报价，请通过[联系页面](/contact)在 Telegram 上联系我们的商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: '要收 GoPay、OVO、DANA，需要分别签约吗？', a: '使用 QRIS 则无需分别签约。QRIS 是全国统一标准，这些钱包和印尼银行 App 的用户都能通过 KaazPay 的一条通道扫同一个码付款。' },
            { q: '线上的 QRIS 码和店里贴的码一样吗？', a: '不一样。店里多为静态码；线上订单由 KaazPay 按单生成动态码，印尼盾金额和订单号都已写入。' },
            { q: '买家只有一部手机，怎么扫 QRIS？', a: '保存二维码图片后，在支付 App 的扫码界面从相册识别即可。在收银台提供保存按钮和简要说明，有助于买家顺利完成付款。' },
            { q: 'KaazPay 能在印尼代付到电子钱包吗？', a: '可以。KaazPay 支持印尼移动钱包代付和银行账户代付，单笔、批量均可，每笔都有状态回传。' },
            { q: 'QRIS 代收最终以什么结算？', a: '以等额 USDT 结算。结算周期按通道确定，许多通道为 D+0，其余为 D+1 或更长，上线前确认。' },
        ],
    },
};
