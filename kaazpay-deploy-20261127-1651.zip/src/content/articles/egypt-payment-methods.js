export default {
    slug: 'egypt-payment-methods',
    kind: 'guide',
    published: '2025-11-04',
    updated: '2025-11-04',
    related: {
        markets: ['egypt'],
        methods: ['fawry', 'mobile-money'],
        industries: ['gaming', 'e-commerce', 'digital-goods', 'education'],
        articles: ['africa-mobile-money', 'mass-payouts-emerging-markets', 'payment-gateway-integration-checklist', 'usdt-settlement'],
    },
    en: {
        title: 'Egypt Payment Gateway: Fawry Pay and EGP Payouts',
        description: 'Egypt payments guide: how Fawry Pay reference codes work online, how long to hold unpaid orders, how to help customers keep their code, EGP payouts and USDT settlement.',
        h1: 'How to accept payments in Egypt with Fawry Pay',
        summary: 'In Egypt, KaazPay collects payments through Fawry Pay: the customer receives a reference code for the order and pays it at a Fawry outlet, an ATM, a mobile wallet or online, in Egyptian pounds (EGP). You fulfil once the signed payment notification arrives. KaazPay also sends EGP payouts to bank accounts and mobile money wallets and settles collections to you in USDT.',
        queries: [
            'How can customers in Egypt pay my online store without a credit card?',
            'How does a Fawry reference code payment work for an e-commerce order?',
            'Many of our Fawry orders are never paid. Is that normal and what should we do?',
            'Can we send withdrawals to Egyptian mobile wallets and bank accounts?',
            'Is there a Fawry payment gateway for foreign merchants that settles in USDT?',
        ],
        takeaways: [
            'Fawry is Egypt’s largest payment network, and Fawry Pay lets customers pay a reference code in person, at an ATM, from a mobile wallet or online.',
            'Because payment happens after checkout, Fawry orders stay pending until the signed notification arrives.',
            'Some codes will never be paid; plan reminders and a release rule rather than treating it as an error.',
            'KaazPay supports EGP payouts to both bank accounts and mobile money wallets.',
            'EGP collections are settled to you as the equivalent amount in USDT, on a cycle agreed before go-live.',
        ],
        sections: [
            { id: 'egypt-coverage', heading: 'What can you collect and pay out in Egypt with KaazPay?', blocks: [
                'Egypt on KaazPay pairs a single, widely used pay-in method with two payout rails:',
                { table: { head: ['Direction', 'Method', 'Currency', 'What it is used for'], rows: [
                    ['Pay-in', 'Fawry Pay (reference code)', 'EGP', 'Online orders, top-ups, course fees, subscriptions'],
                    ['Payout', 'Bank transfer', 'EGP', 'Sellers, suppliers, partners, larger transfers'],
                    ['Payout', 'Mobile money', 'EGP', 'User withdrawals, creator and affiliate earnings, refunds'],
                ] } },
                { note: 'Coverage can change as new channels launch. The [Egypt market page](/payment-methods/egypt) always shows the current list.' },
            ] },
            { id: 'how-fawry-pay-works', heading: 'How does Fawry Pay work for an online order?', blocks: [
                '**Fawry** runs the largest payment network in Egypt. Fawry Pay turns an online order into a **reference code**: instead of entering card details, the customer takes the code and pays it through whichever Fawry channel is convenient, whether a neighbourhood outlet, an ATM, a mobile wallet or online.',
                'This flexibility is the main advantage. Customers who prefer cash, or who prefer not to use a card on a website, can still buy from you. The trade-off is timing: the money arrives when the customer pays, which may be minutes or a day after checkout. More detail is on the [Fawry Pay method page](/methods/fawry).',
            ] },
            { id: 'fawry-worked-example', heading: 'Worked example: a Cairo student paying a course by Fawry code', blocks: [
                'A student in Cairo signs up for a 1,200 EGP online course in the evening and picks Fawry Pay.',
                { steps: [
                    'Your backend creates a pay-in order for 1,200 EGP through the KaazPay API.',
                    'The checkout shows a Fawry reference code and the amount, and your system sends the same details by email or SMS.',
                    'The order is saved as pending; the course seat is held.',
                    'Next morning the student pays the code at a Fawry outlet on the way to class.',
                    'KaazPay sends your server a signed notification; you verify it and give the student access to the course.',
                ] },
                'Nothing is unlocked at step 2. Access depends entirely on the verified notification in step 5.',
            ] },
            { id: 'unpaid-orders', heading: 'How long should you hold an unpaid Fawry order?', blocks: [
                'A share of reference codes will never be paid, as with any pay-later method. The right holding rule depends on what you sell:',
                { table: { head: ['What you sell', 'Suggested approach'], rows: [
                    ['Digital goods, top-ups, credits', 'No stock to hold. Keep the order pending and deliver instantly when the notification arrives.'],
                    ['Limited physical stock', 'Reserve for a short window, send one reminder with the code, then release the stock.'],
                    ['Courses, events, bookings with seats', 'Hold the seat for a defined period that matches your capacity and remind before cancelling.'],
                    ['Subscriptions', 'Activate on payment, and generate a fresh code for each renewal.'],
                ] } },
                'Whatever the rule, verify the signature on every notification and make order updates idempotent, so a payment that arrives late is still matched to the right order.',
            ] },
            { id: 'keep-the-code', heading: 'How do you stop customers losing their Fawry code?', blocks: [
                { list: [
                    'Show the code in large type with a copy button, and the exact EGP amount next to it.',
                    'Send the code and amount by email or SMS immediately, so it is on the customer’s phone when they reach an outlet.',
                    'Write the instructions in Arabic as well as English if your audience reads Arabic.',
                    'Link the order page from the message so the customer can check the status after paying.',
                    'Send one reminder before the code or reservation lapses.',
                ] },
                'These details are inexpensive to build and can increase the share of codes that turn into paid orders.',
            ] },
            { id: 'egypt-payouts', heading: 'How do you send payouts in Egypt?', blocks: [
                'If your platform pays people in Egypt, such as players cashing out, sellers collecting earnings or partners receiving commission, KaazPay sends **EGP payouts to bank accounts and to mobile money wallets** from the same merchant account that receives your Fawry Pay collections.',
                'Choose the rail by recipient: individuals often prefer a wallet, while businesses and larger sums usually go to a bank account. Payouts run singly or in batches, each with its own status notification. See [mass payouts in emerging markets](/guides/mass-payouts-emerging-markets) for batch design.',
            ] },
            { id: 'egp-settlement', heading: 'How are Egyptian pound collections settled?', blocks: [
                'Customers pay in EGP and KaazPay settles the equivalent amount to you in **USDT**, so you do not need an Egyptian bank account to receive funds.',
                'Many KaazPay channels settle D+0 and others D+1 or later. The cycle, rate and fees for Fawry Pay are confirmed in writing before you launch. See the [USDT settlement guide](/guides/usdt-settlement).',
            ] },
            { id: 'start-egypt-kaazpay', heading: 'How to start accepting Fawry Pay with KaazPay', blocks: [
                { steps: [
                    'Open a merchant account and tell us what you sell in Egypt and your expected volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with engineer support using the [developer documentation](/developers), testing pending, paid and unpaid Fawry orders plus payouts.',
                    'Go live and monitor code-to-payment conversion in the dashboard.',
                ] },
                'Our [payment gateway integration checklist](/guides/payment-gateway-integration-checklist) covers the wider technical preparation, and the [Africa mobile money guide](/guides/africa-mobile-money) shows the rest of our African coverage. For pricing and settlement terms, message our business team on Telegram via the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Does KaazPay support Fawry payments?', a: 'Yes. KaazPay offers Fawry Pay for pay-in in Egypt. The customer receives a reference code and pays it at a Fawry outlet, ATM, mobile wallet or online.' },
            { q: 'Can customers pay Fawry codes in cash?', a: 'Yes. One of the options is paying the code in person at a Fawry outlet, which suits customers who do not want to use a card online.' },
            { q: 'When should I deliver a Fawry order?', a: 'Only after KaazPay’s signed payment notification arrives and you have verified it. Until then, keep the order pending.' },
            { q: 'Can I pay out to mobile wallets in Egypt?', a: 'Yes. KaazPay supports EGP payouts to mobile money wallets and to bank accounts, singly or in batches.' },
            { q: 'Do I need a bank account in Egypt?', a: 'No. EGP collections are settled to you as the equivalent amount in USDT, with the cycle, rate and fees agreed before go-live.' },
        ],
    },
    zh: {
        title: '埃及收款指南：Fawry Pay 代收与 EGP 代付',
        description: '面向埃及市场的收款说明：Fawry Pay 付款码在线上订单中怎么用、未付款订单保留多久、如何避免顾客弄丢付款码，以及 EGP 代付与 USDT 结算。',
        h1: '如何在埃及通过 Fawry Pay 收款？',
        summary: '在埃及，KaazPay 通过 Fawry Pay 代收：顾客拿到订单的付款参考码后，可在 Fawry 网点、ATM、手机钱包或线上以埃及镑（EGP）付款，商户收到带签名的到账通知后再发货。KaazPay 还支持 EGP 银行账户与移动钱包代付，并以 USDT 结算代收资金。',
        queries: [
            '埃及顾客没有信用卡，怎么在我的网店付款？',
            'Fawry 付款码在电商订单里是怎么运作的？',
            '我们很多 Fawry 订单一直没付款，这正常吗？该怎么处理？',
            '能给埃及用户的手机钱包和银行账户代付提现吗？',
            '有没有面向海外商户、用 USDT 结算的 Fawry 支付通道？',
        ],
        takeaways: [
            'Fawry 是埃及最大的支付网络，Fawry Pay 让顾客凭付款码在网点、ATM、手机钱包或线上付款。',
            '付款发生在下单之后，所以 Fawry 订单在收到带签名的通知前一律保持待支付。',
            '部分付款码不会被支付，应提前设定提醒和释放规则，而不是视为异常。',
            'KaazPay 支持 EGP 银行账户代付和移动钱包代付。',
            'EGP 代收按等额 USDT 结算，周期在上线前约定。',
        ],
        sections: [
            { id: 'egypt-coverage', heading: '通过 KaazPay 在埃及可以代收和代付哪些款项？', blocks: [
                '在 KaazPay 上，埃及提供一种主流代收方式和两种代付方式：',
                { table: { head: ['方向', '方式', '币种', '用途'], rows: [
                    ['代收', 'Fawry Pay（付款参考码）', 'EGP', '线上订单、充值、课程费、订阅'],
                    ['代付', '银行转账', 'EGP', '卖家、供应商、合作方、较大金额转账'],
                    ['代付', '移动钱包', 'EGP', '用户提现、主播与推广收益、退款'],
                ] } },
                { note: '随着新通道上线，覆盖范围可能变化，最新列表以[埃及市场页面](/payment-methods/egypt)为准。' },
            ] },
            { id: 'how-fawry-pay-works', heading: 'Fawry Pay 如何用于线上订单？', blocks: [
                '**Fawry** 运营着埃及最大的支付网络。Fawry Pay 把一笔线上订单变成一个**付款参考码**：顾客不用输入卡号，而是拿着这个码，通过任意方便的 Fawry 渠道付款，例如附近的网点、ATM、手机钱包或线上渠道。',
                '灵活性是它的主要优势：习惯付现金或不想在网站上用卡的顾客，同样可以完成购买。代价是时间差：款项在顾客付款时才到账，可能是下单后几分钟，也可能是第二天。详见 [Fawry Pay 支付方式页面](/methods/fawry)。',
            ] },
            { id: 'fawry-worked-example', heading: '实例：开罗学生用 Fawry 付款码支付课程费', blocks: [
                '开罗一名学生晚上报名一门 1,200 EGP 的网课，选择了 Fawry Pay。',
                { steps: [
                    '您的后端通过 KaazPay API 创建一笔 1,200 EGP 的代收订单。',
                    '收银台展示 Fawry 付款参考码和金额，系统同时通过邮件或短信发送同样的信息。',
                    '订单保存为待支付，课程名额暂时保留。',
                    '第二天早上，学生在上课途中到 Fawry 网点付了款。',
                    'KaazPay 向您的服务器推送带签名的通知，您验签后为学生开通课程。',
                ] },
                '第 2 步不开通任何权限，是否开通完全取决于第 5 步验签通过的通知。',
            ] },
            { id: 'unpaid-orders', heading: '未支付的 Fawry 订单应该保留多久？', blocks: [
                '与所有“先下单后付款”的方式一样，部分付款码不会被支付。保留规则取决于商品类型：',
                { table: { head: ['商品类型', '建议做法'], rows: [
                    ['数字商品、充值、点数', '无需保留库存，订单保持待支付，收到通知后立即发放。'],
                    ['库存有限的实物商品', '短时间保留库存，发一次附带付款码的提醒，到期后释放库存。'],
                    ['课程、活动、有名额的预订', '按自身容量设定保留期，取消前提醒一次。'],
                    ['订阅', '付款后再开通，每次续费生成新的付款码。'],
                ] } },
                '不论采用哪种规则，每条通知都要验签，订单更新做幂等处理，这样迟到的付款也能准确匹配到原订单。',
            ] },
            { id: 'keep-the-code', heading: '怎样避免顾客弄丢 Fawry 付款码？', blocks: [
                { list: [
                    '用大字号展示付款码并提供复制按钮，旁边写清准确的 EGP 金额。',
                    '立即通过邮件或短信发送付款码和金额，便于顾客在网点付款时出示。',
                    '如果顾客读阿拉伯文，说明文字同时提供阿拉伯文和英文。',
                    '消息里附上订单页面链接，方便顾客付款后查看状态。',
                    '付款码或保留期到期前提醒一次。',
                ] },
                '这些细节开发成本不高，有助于提高付款码的实际支付比例。',
            ] },
            { id: 'egypt-payouts', heading: '在埃及如何代付？', blocks: [
                '如果您的平台需要向埃及的收款人付款，比如玩家提现、卖家领取收益、合作方收佣金，KaazPay 可以用接收 Fawry Pay 代收的同一商户账户，**以 EGP 代付到银行账户和移动钱包**。',
                '按收款人选择方式：个人通常偏好钱包，企业和大额款项一般走银行账户。代付支持单笔和批量，每笔都有独立的状态通知。批量设计参见[新兴市场批量代付指南](/guides/mass-payouts-emerging-markets)。',
            ] },
            { id: 'egp-settlement', heading: '埃及镑代收如何结算？', blocks: [
                '顾客以 EGP 付款，KaazPay 将等额 **USDT** 结算给您，您不需要埃及银行账户。',
                'KaazPay 不少通道为 D+0 结算，其余为 D+1 或更长。Fawry Pay 的结算周期、汇率与费率会在上线前书面确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'start-egypt-kaazpay', heading: '如何通过 KaazPay 开通 Fawry Pay 代收', blocks: [
                { steps: [
                    '开设商户账户，告诉我们您在埃及销售的商品以及预估交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，测试待支付、已支付、未支付的 Fawry 订单和代付流程。',
                    '正式上线，并在后台跟踪付款码到实际付款的转化。',
                ] },
                '更完整的技术准备可参考[支付通道对接清单](/guides/payment-gateway-integration-checklist)，[非洲移动钱包指南](/guides/africa-mobile-money)则介绍了我们在非洲其他国家的覆盖。关于报价和结算条款，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: 'KaazPay 支持 Fawry 收款吗？', a: '支持。KaazPay 在埃及提供 Fawry Pay 代收，顾客拿到付款参考码后，可在 Fawry 网点、ATM、手机钱包或线上付款。' },
            { q: '顾客可以用现金支付 Fawry 付款码吗？', a: '可以。其中一种方式就是到 Fawry 网点当面付款，适合不想在网上用卡的顾客。' },
            { q: 'Fawry 订单什么时候发货？', a: '应在收到 KaazPay 带签名的到账通知并验签通过之后发货。在此之前，订单保持待支付。' },
            { q: '在埃及能代付到手机钱包吗？', a: '可以。KaazPay 支持 EGP 移动钱包代付和银行账户代付，单笔、批量均可。' },
            { q: '需要在埃及开银行账户吗？', a: '不需要。EGP 代收按等额 USDT 结算给您，结算周期、汇率与费率在上线前约定。' },
        ],
    },
};
