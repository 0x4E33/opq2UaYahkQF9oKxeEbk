export default {
    slug: 'instant-payments-vs-bank-transfer',
    kind: 'compare',
    published: '2026-04-21',
    updated: '2026-04-21',
    related: {
        markets: ['eurozone', 'mexico', 'colombia', 'brazil', 'malaysia', 'south-africa'],
        methods: ['spei', 'bre-b', 'pix', 'duitnow', 'pse', 'fpx'],
        industries: ['gaming', 'digital-goods', 'e-commerce', 'education'],
        articles: ['europe-uae-bank-transfers', 'mexico-payment-methods', 'pix-vs-boleto', 'fpx-vs-duitnow-vs-touch-n-go'],
    },
    en: {
        title: "Instant Payments vs Bank Transfers for Merchants",
        description: "Instant payments vs bank transfers vs online banking: how SPEI, Pix, Bre-B and DuitNow compare with PSE, FPX and transfers on speed, effort and reconciliation.",
        h1: "Instant payment vs bank transfer: what is the difference for merchants?",
        summary: "An instant payment such as SPEI, Pix, Bre-B or DuitNow moves money between accounts in seconds and ties each payment to an order automatically, which suits top-ups and digital delivery. A traditional bank transfer is slower and depends on the customer entering the right amount and reference, but it suits larger, planned payments. Online banking such as PSE, FPX and EFT sits between the two, and KaazPay supports all three types for pay-in.",
        queries: [
            "What is the difference between an instant payment and a normal bank transfer for an online shop?",
            "Should I offer Pix or SPEI instead of bank transfer at checkout?",
            "Is PSE or FPX an instant payment or a bank transfer?",
            "Why are bank transfer payments so hard to reconcile, and do instant payments fix that?",
        ],
        takeaways: [
            "Instant payment schemes confirm in seconds and are built around a key, QR code or order-specific reference, so matching is automatic.",
            "Classic bank transfers suit shoppers who prefer them and larger sums, but confirmation is slower and errors need manual follow-up.",
            "Online banking buttons like PSE, FPX and EFT redirect the shopper to their bank and send a status back, landing between the two.",
            "Where a market has an instant scheme, show it first and keep a transfer option for big or B2B payments.",
            "Fast payment confirmation is not the same as fast settlement: KaazPay settles in USDT on a cycle agreed per channel.",
        ],
        sections: [
            {
                id: 'three-bank-rails',
                heading: "What separates instant payments, online banking and bank transfers?",
                blocks: [
                    "All three move money from a customer's bank account, but they behave very differently at checkout:",
                    { list: [
                        "**Instant payment schemes** are country-wide networks, most of them operated or supervised by a central bank, that move funds between accounts in seconds and often around the clock. The shopper pays with a key, a QR code or a reference generated for the order. Examples: [SPEI](/methods/spei) in Mexico, [Pix](/methods/pix) in Brazil, [Bre-B](/methods/bre-b) in Colombia, [DuitNow](/methods/duitnow) in Malaysia and [Capitec Pay](/methods/capitec-pay) in South Africa.",
                        "**Online banking payments** send the shopper to their own bank to sign in and approve a debit, then return a result to the merchant. Examples: [PSE](/methods/pse) in Colombia, [FPX](/methods/fpx) in Malaysia and [EFT](/methods/eft) in South Africa.",
                        "**Traditional bank transfers** ask the shopper to send money to account details you provide, using their bank's normal transfer function. Timing depends on the bank, and accuracy depends on what the shopper types.",
                    ] },
                ],
            },
            {
                id: 'rail-by-rail-comparison',
                heading: "How do they compare on speed, customer effort and matching?",
                blocks: [
                    { table: {
                        head: ["Question", "Instant payment", "Online banking", "Bank transfer"],
                        rows: [
                            ["How is the order identified?", "Key, QR or reference generated per order", "The bank session is created for the order", "A reference the shopper must type"],
                            ["What does the shopper do?", "Scan or paste, then approve in the app", "Choose bank, sign in, approve", "Copy details, enter amount and reference, send"],
                            ["When can you fulfil?", "Usually within seconds", "Once the bank returns an approval", "Only after funds arrive and are matched"],
                            ["Most common failure", "Shopper abandons before approving", "Bank page times out or shopper does not return", "Wrong amount or missing reference"],
                            ["Best suited to", "Top-ups, digital goods, fast delivery", "Shoppers who trust their bank portal", "Large, planned or B2B payments"],
                        ],
                    } },
                    { note: "This is a general, qualitative comparison. Real timings vary by scheme, bank, time of day and channel." },
                ],
            },
            {
                id: 'kaazpay-rails-by-market',
                heading: "Which of these does KaazPay offer in each market?",
                blocks: [
                    { table: {
                        head: ["Market", "Instant payment", "Online banking / bank payment", "Bank transfer pay-in", "Payouts"],
                        rows: [
                            ["[Eurozone, UK, UAE](/guides/europe-uae-bank-transfers)", "Not offered", "Not offered", "EUR, GBP, AED", "Bank transfer"],
                            ["[Mexico](/payment-methods/mexico)", "SPEI", "Not offered", "Yes", "Bank transfer"],
                            ["[Colombia](/payment-methods/colombia)", "Bre-B (Key and QR)", "PSE, Bancolombia", "Yes", "Bank transfer"],
                            ["[Brazil](/payment-methods/brazil)", "Pix", "Not offered", "Yes", "Bank transfer"],
                            ["Peru, Chile, Ecuador, Guatemala", "Not offered", "Not offered", "Yes", "Pay-in only"],
                            ["[Malaysia](/payment-methods/malaysia)", "DuitNow", "FPX", "Not offered", "Bank transfer"],
                            ["[South Africa](/payment-methods/south-africa)", "Capitec Pay", "EFT", "Not offered", "Bank transfer"],
                            ["Nigeria, Ghana", "Not offered", "Not offered", "Yes", "Bank transfer (Ghana also mobile money)"],
                        ],
                    } },
                    "Several of these markets also have cash, wallet or card options that sit outside this comparison; each market page lists the full set.",
                ],
            },
            {
                id: 'rail-by-scenario',
                heading: "Which rail fits a game top-up, an invoice or a tuition fee?",
                blocks: [
                    { table: {
                        head: ["Scenario", "Recommended rail", "Why"],
                        rows: [
                            ["MXN 200 game top-up in Mexico", "SPEI", "The player expects credits within moments of paying"],
                            ["BRL subscription renewal in Brazil", "Pix", "QR or key payment is quick on mobile and confirms almost immediately"],
                            ["Online store checkout in Malaysia", "DuitNow or FPX", "DuitNow for app-first shoppers, FPX for those who prefer their bank portal"],
                            ["Course fee paid by a family in Colombia", "PSE, with bank transfer as back-up", "Familiar bank approval for a larger amount"],
                            ["GBP 8,000 wholesale invoice in the UK", "GBP bank transfer", "Business buyers pay invoices from a company account"],
                        ],
                    } },
                ],
            },
            {
                id: 'reconciliation-differences',
                heading: "Why are bank transfers harder to reconcile?",
                blocks: [
                    "With an instant payment or an online banking payment, the payment is created for one order, so when it succeeds there is nothing to guess. A manual transfer arrives as money plus whatever the shopper typed. If the reference is missing or the amount is different, someone has to work out which order it belongs to.",
                    "This work can be reduced considerably: generate a new reference per order, display the exact amount with copy buttons, expire stale orders, and update order status only from KaazPay's server notifications rather than customer screenshots. Every payment and settlement is also visible in the KaazPay merchant dashboard.",
                ],
            },
            {
                id: 'mixing-rails-mistakes',
                heading: "What mistakes do merchants make when offering both?",
                blocks: [
                    { list: [
                        "**Hiding the instant option** below a long list of transfers, so most shoppers pick the slower route by default.",
                        "**Treating every rail the same in the order system**, for example expiring transfer orders as fast as instant ones.",
                        "**Fulfilling on the customer's word** that a transfer has been sent.",
                        "**Showing a QR code to someone already on their phone**, where a copyable key would be easier.",
                        "**Dropping bank transfer entirely**, which can push away business buyers and customers paying large amounts.",
                    ] },
                ],
            },
            {
                id: 'confirmation-vs-settlement',
                heading: "Does a faster payment mean you get your money faster?",
                blocks: [
                    "Not necessarily. Payment confirmation tells you the customer has paid and you can deliver. Settlement is when the collected funds reach you, and that follows its own cycle.",
                    "With KaazPay, what you collect is settled as the equivalent amount in USDT. Many channels settle D+0, while others are D+1 or later, regardless of whether the shopper used an instant scheme or a transfer. The cycle for each channel is confirmed before go-live; see [USDT settlement](/guides/usdt-settlement) for details.",
                ],
            },
            {
                id: 'which-order-to-show',
                heading: "Which should appear first at checkout: instant payment or transfer?",
                blocks: [
                    "In most markets where an instant scheme exists, a sound default is to show it first and keep online banking and transfers as alternatives. This gives most shoppers a fast path while still serving those who prefer their bank portal or are paying a large amount.",
                    "Brazil adds a voucher option to the mix, compared in [Pix vs Boleto](/compare/pix-vs-boleto). Malaysia adds an e-wallet, covered in [FPX vs DuitNow vs Touch 'n Go](/compare/fpx-vs-duitnow-vs-touch-n-go).",
                ],
            },
            {
                id: 'get-started-instant-transfer',
                heading: "How do you add these payment rails with KaazPay?",
                blocks: [
                    { steps: [
                        "Open a KaazPay merchant account.",
                        "Get your API keys.",
                        "Integrate with help from a KaazPay engineer, following the [developer documentation](/developers).",
                        "Go live with the instant, online banking and transfer methods your markets need.",
                    ] },
                    "To choose a launch mix, message our business team on Telegram through the [contact page](/contact) with your target markets. We reply within one business day with a recommended channel plan.",
                ],
            },
        ],
        faq: [
            { q: "What is the main difference between an instant payment and a bank transfer?", a: "An instant payment such as SPEI, Pix, Bre-B or DuitNow confirms in seconds and is tied to the order by a key, QR code or generated reference. A traditional bank transfer can take longer and depends on the shopper entering the correct amount and reference." },
            { q: "Does SPEI confirm in real time?", a: "Yes. Banco de México runs SPEI as a real-time network between Mexican banks. Through KaazPay you can offer SPEI and Mexico Bank Transfer side by side." },
            { q: "Do PSE and FPX count as instant payments?", a: "No. They are bank-redirect payments: the shopper signs in to their own bank, approves the debit, and the result goes back to the merchant. KaazPay offers PSE in Colombia and FPX in Malaysia." },
            { q: "Which markets does KaazPay support for bank transfer pay-in?", a: "Among others, the Eurozone, UK and UAE, Mexico, Colombia, Brazil, Peru, Chile, Ecuador, Guatemala, Nigeria and Ghana. The market pages list the current channels." },
            { q: "Can I pay out by bank transfer in the same markets?", a: "In payout markets such as the Eurozone, UK, UAE, Mexico, Colombia, Brazil, Malaysia, South Africa, Nigeria and Ghana, yes. Peru, Chile, Ecuador and Guatemala are currently pay-in only." },
        ],
    },
    zh: {
        title: "实时支付与银行转账对比：面向商户的选择指南",
        description: "实时支付、网银支付与银行转账有何不同？对比 SPEI、Pix、Bre-B、DuitNow 与 PSE、FPX 及普通转账在到账速度、用户操作和对账难度上的差异。",
        h1: "实时支付与银行转账：对商户有何区别？",
        summary: "SPEI、Pix、Bre-B、DuitNow 这类实时支付在几秒内完成账户间转账，并自动对应到订单，适合充值和数字商品即时交付。普通银行转账速度较慢，且依赖用户正确填写金额和附言，更适合大额、计划性付款。PSE、FPX、EFT 这类网银支付则处在中间，三类代收 KaazPay 都能提供。",
        queries: [
            "实时支付与普通银行转账，对网店有什么区别？",
            "收银台应该放 Pix、SPEI，还是银行转账？",
            "PSE 和 FPX 属于实时支付还是银行转账？",
            "为什么银行转账难以对账？实时支付能否解决？",
        ],
        takeaways: [
            "实时支付以密钥、二维码或订单专属参考号付款，几秒确认，自动对账。",
            "普通银行转账适合偏好转账的客户和大额付款，但确认慢，出错要人工跟进。",
            "PSE、FPX、EFT 等网银支付先跳转到银行确认、再回传状态，处于两者之间。",
            "市场有实时支付时优先展示，同时为大额或 B2B 付款保留转账选项。",
            "付款确认快不等于结算快：KaazPay 以 USDT 结算，周期按通道约定。",
        ],
        sections: [
            {
                id: 'three-bank-rails',
                heading: "实时支付、网银支付与银行转账有何区别？",
                blocks: [
                    "三者都是从用户的银行账户扣款，但在收银台上的表现截然不同：",
                    { list: [
                        "**实时支付**：通常由央行运营或监管的全国性系统，账户之间秒级到账，很多支持全天候运行。用户通过密钥、二维码或为订单生成的参考号付款。例如墨西哥的 [SPEI](/methods/spei)、巴西的 [Pix](/methods/pix)、哥伦比亚的 [Bre-B](/methods/bre-b)、马来西亚的 [DuitNow](/methods/duitnow) 和南非的 [Capitec Pay](/methods/capitec-pay)。",
                        "**网银支付**：用户跳转到自己的银行登录并确认扣款，结果再回传给商户。例如哥伦比亚的 [PSE](/methods/pse)、马来西亚的 [FPX](/methods/fpx) 和南非的 [EFT](/methods/eft)。",
                        "**普通银行转账**：用户按您提供的收款信息，用银行的常规转账功能汇款。到账时间取决于银行，准确性取决于用户输入。",
                    ] },
                ],
            },
            {
                id: 'rail-by-rail-comparison',
                heading: "三者在速度、用户操作和对账上有何差异？",
                blocks: [
                    { table: {
                        head: ["问题", "实时支付", "网银支付", "银行转账"],
                        rows: [
                            ["订单如何识别？", "每笔订单生成的密钥、二维码或参考号", "银行会话为该订单创建", "依赖用户手动填写附言"],
                            ["用户要做什么？", "扫码或粘贴，再在 App 中确认", "选银行、登录、确认", "复制收款信息，填金额和附言后汇款"],
                            ["何时可以交付？", "通常几秒内", "银行返回授权后", "资金到账并匹配后"],
                            ["最常见的失败", "用户确认前放弃", "银行页面超时或用户没有返回", "金额不对或漏填附言"],
                            ["最适合", "充值、数字商品、即时交付", "信任网银的用户", "大额、计划性或 B2B 付款"],
                        ],
                    } },
                    { note: "以上为一般性的定性比较，实际时效因系统、银行、时段和通道而异。" },
                ],
            },
            {
                id: 'kaazpay-rails-by-market',
                heading: "KaazPay 在各市场分别提供哪几类？",
                blocks: [
                    { table: {
                        head: ["市场", "实时支付", "网银 / 银行支付", "银行转账代收", "代付"],
                        rows: [
                            ["[欧元区、英国、阿联酋](/guides/europe-uae-bank-transfers)", "暂无", "暂无", "EUR、GBP、AED", "银行转账"],
                            ["[墨西哥](/payment-methods/mexico)", "SPEI", "暂无", "支持", "银行转账"],
                            ["[哥伦比亚](/payment-methods/colombia)", "Bre-B（密钥、扫码）", "PSE、Bancolombia", "支持", "银行转账"],
                            ["[巴西](/payment-methods/brazil)", "Pix", "暂无", "支持", "银行转账"],
                            ["秘鲁、智利、厄瓜多尔、危地马拉", "暂无", "暂无", "支持", "仅代收"],
                            ["[马来西亚](/payment-methods/malaysia)", "DuitNow", "FPX", "暂无", "银行转账"],
                            ["[南非](/payment-methods/south-africa)", "Capitec Pay", "EFT", "暂无", "银行转账"],
                            ["尼日利亚、加纳", "暂无", "暂无", "支持", "银行转账（加纳另支持移动钱包）"],
                        ],
                    } },
                    "其中不少市场还有现金、电子钱包或银行卡等方式，不在本文比较范围内，完整列表见各市场页面。",
                ],
            },
            {
                id: 'rail-by-scenario',
                heading: "游戏充值、企业发票、学费，各适合哪一类？",
                blocks: [
                    { table: {
                        head: ["场景", "推荐方式", "原因"],
                        rows: [
                            ["墨西哥 200 比索游戏充值", "SPEI", "玩家期望付款后立即到账"],
                            ["巴西雷亚尔订阅续费", "Pix", "手机上扫码或用密钥付款很快，几乎即时确认"],
                            ["马来西亚网店结账", "DuitNow 或 FPX", "习惯用 App 的选 DuitNow，偏好网银的选 FPX"],
                            ["哥伦比亚家庭缴纳课程费", "PSE，银行转账作备选", "金额较大，适合通过熟悉的银行确认"],
                            ["英国 8,000 英镑批发发票", "GBP 银行转账", "企业买家习惯用对公账户付发票"],
                        ],
                    } },
                ],
            },
            {
                id: 'reconciliation-differences',
                heading: "为什么银行转账更难对账？",
                blocks: [
                    "实时支付和网银支付都是针对某一笔订单发起的，付款成功就不存在归属问题。手动转账到账时，只有资金和用户填写的内容；若附言缺失或金额不符，就需要人工核查其对应的订单。",
                    "这部分工作可以大幅减少：每笔订单生成新附言，用复制按钮展示准确金额，过期订单及时作废，订单状态只依据 KaazPay 服务器通知更新，而不是用户截图。所有付款和结算记录也都可以在 KaazPay 商户后台查看。",
                ],
            },
            {
                id: 'mixing-rails-mistakes',
                heading: "同时提供两类方式时，商户常犯哪些错？",
                blocks: [
                    { list: [
                        "**把实时支付藏在一长串转账选项下面**，导致多数用户默认选择较慢的方式。",
                        "**订单系统对所有方式一视同仁**，比如转账订单和实时支付订单用同样短的过期时间。",
                        "**仅凭用户称已转账就发货**。",
                        "**给已经在用手机的用户展示二维码**，其实复制密钥更方便。",
                        "**完全取消银行转账**，可能流失企业买家和大额付款客户。",
                    ] },
                ],
            },
            {
                id: 'confirmation-vs-settlement',
                heading: "付款更快，是否意味着资金到账更快？",
                blocks: [
                    "不一定。付款确认表示用户已付款、您可以交付；结算则是代收资金到达您手中，有自己独立的周期。",
                    "在 KaazPay，代收资金按等额 USDT 结算。许多通道为 D+0，其他通道为 D+1 或更长，这与用户用的是实时支付还是转账无关。各通道的结算周期在上线前确认，详见 [USDT 结算说明](/guides/usdt-settlement)。",
                ],
            },
            {
                id: 'which-order-to-show',
                heading: "收银台应优先展示实时支付还是银行转账？",
                blocks: [
                    "在有实时支付系统的市场，较好的默认做法是将其放在首位，网银和转账作为备选。这样多数用户可走快速通道，偏好网银或支付大额的用户也有选择。",
                    "巴西还有凭证类支付，可参阅 [Pix 与 Boleto 对比](/compare/pix-vs-boleto)；马来西亚还有电子钱包，可参阅 [FPX、DuitNow 与 Touch 'n Go 对比](/compare/fpx-vs-duitnow-vs-touch-n-go)。",
                ],
            },
            {
                id: 'get-started-instant-transfer',
                heading: "如何通过 KaazPay 接入这些支付方式？",
                blocks: [
                    { steps: [
                        "开设 KaazPay 商户账户。",
                        "获取 API 密钥。",
                        "参照[开发者文档](/developers)，在 KaazPay 工程师协助下完成对接。",
                        "按目标市场开通需要的实时支付、网银与转账通道。",
                    ] },
                    "如需确定首批上线的支付方式，请通过[联系页面](/contact)在 Telegram 上联系商务团队并说明目标市场。我们会在一个工作日内回复，并提供通道建议。",
                ],
            },
        ],
        faq: [
            { q: "实时支付和银行转账最主要的区别是什么？", a: "SPEI、Pix、Bre-B、DuitNow 等实时支付几秒内确认，并通过密钥、二维码或生成的参考号与订单绑定；普通银行转账可能更慢，而且依赖用户正确填写金额和附言。" },
            { q: "SPEI 是实时到账的吗？", a: "是的。SPEI 由墨西哥央行 Banco de México 运营，银行之间实时划款。通过 KaazPay，您可以在墨西哥同时提供 SPEI 和普通银行转账两种付款方式。" },
            { q: "PSE 和 FPX 属于实时支付吗？", a: "不属于。它们是跳转网银的付款方式：用户登录自己的银行确认扣款，结果随后返回商户。KaazPay 提供哥伦比亚的 PSE 和马来西亚的 FPX。" },
            { q: "KaazPay 在哪些市场支持银行转账代收？", a: "包括欧元区、英国、阿联酋、墨西哥、哥伦比亚、巴西、秘鲁、智利、厄瓜多尔、危地马拉、尼日利亚和加纳等，当前通道以各市场页面为准。" },
            { q: "在相同市场能否通过银行转账代付？", a: "欧元区、英国、阿联酋、墨西哥、哥伦比亚、巴西、马来西亚、南非、尼日利亚和加纳等代付市场可以；秘鲁、智利、厄瓜多尔和危地马拉目前仅支持代收。" },
        ],
    },
};
