export default {
    slug: 'us-payment-methods',
    kind: 'guide',
    published: '2026-02-03',
    updated: '2026-04-14',
    related: {
        markets: ['united-states', 'global-cards', 'usdt'],
        methods: ['cash-app', 'apple-pay', 'google-pay', 'paypal'],
        industries: ['gaming', 'live-streaming', 'global-payroll'],
        articles: ['apple-pay-vs-google-pay-vs-cash-app', 'mass-payouts-emerging-markets', 'usdt-settlement'],
    },
    en: {
        title: 'US Payment Methods: Cash App, Wallets & Payouts',
        description: 'How to collect from US customers with Cash App, Apple Pay and Google Pay, and pay US users out to PayPal, Cash App, Chime, cards or ACH with KaazPay.',
        h1: 'How to accept US payments and send USD payouts: Cash App, Apple Pay, Google Pay, PayPal and ACH',
        summary: 'KaazPay lets merchants collect from US customers through Cash App, Apple Pay and Google Pay, and send USD payouts to PayPal, Cash App, Chime, cards and ACH bank accounts. Both directions run on one merchant account and one API, and collected funds are settled to you in USDT on a cycle agreed per channel.',
        takeaways: [
            'US pay-in options on KaazPay are Cash App, Apple Pay and Google Pay; PayPal is used for payouts, not collection.',
            'US payout rails are PayPal, Cash App, Chime, cards and ACH bank transfer, sent singly or in batches.',
            'Cash App is the only US method on KaazPay that works in both directions, which suits top-up and cash-out apps.',
            'Failed payouts commonly result from incorrect recipient details, so validate identifiers before submitting a batch.',
            'US collections settle to you in USDT; the settlement cycle is confirmed per channel before go-live.',
        ],
        sections: [
            {
                id: 'us-coverage-at-a-glance',
                heading: 'What can you collect and pay out in the US with KaazPay?',
                blocks: [
                    'US coverage is divided into pay-in and payout: three methods for collection and five rails for payouts, all in USD.',
                    { table: {
                        head: ['Direction', 'Method', 'What the customer or recipient uses', 'Good fit for'],
                        rows: [
                            ['Pay-in', 'Cash App', 'Their Cash App account', 'Top-ups, credits, creator tips'],
                            ['Pay-in', 'Apple Pay', 'A card saved in Apple Wallet on iPhone', 'Fast mobile checkout'],
                            ['Pay-in', 'Google Pay', 'A card saved to their Google account', 'Android and Chrome checkout'],
                            ['Payout', 'PayPal', 'Their PayPal account', 'Freelancers, online sellers'],
                            ['Payout', 'Cash App', 'Their Cash App account', 'Players and creators cashing out'],
                            ['Payout', 'Chime', 'Their Chime account', 'Recipients who bank on mobile'],
                            ['Payout', 'Cards', 'Their card', 'Recipients without a wallet account'],
                            ['Payout', 'ACH', 'A US bank account', 'Contractors, suppliers, larger amounts'],
                        ],
                    } },
                    'The live list is always on the [United States market page](/payment-methods/united-states). If you also want to accept Visa, Mastercard or UnionPay cards directly, that runs on the separate [global cards channel](/payment-methods/global-cards).',
                ],
            },
            {
                id: 'us-checkout-mix',
                heading: 'Which pay-in options should your US checkout show?',
                blocks: [
                    'Order the methods by device. iPhone users can confirm with Face ID or Touch ID through [Apple Pay](/methods/apple-pay), while Android and Chrome users reach for [Google Pay](/methods/google-pay). Both pull from a card the customer has already saved, so nobody types a 16-digit number on a small screen.',
                    '[Cash App](/methods/cash-app) works differently: the customer pays from their Cash App account rather than from a card in a phone wallet. It is a familiar way to send money in the US, which is why gaming, streaming and social apps often list it next to the wallet buttons.',
                    'A practical default is to show all three and let the device decide the order: Apple Pay first on iOS, Google Pay first on Android, and Cash App on every device. Our [Apple Pay vs Google Pay vs Cash App comparison](/compare/apple-pay-vs-google-pay-vs-cash-app) goes through the differences in more detail.',
                ],
            },
            {
                id: 'worked-example-us-flow',
                heading: 'Worked example: a US top-up and cash-out on one account',
                blocks: [
                    'Consider a mobile game that sells coins to US players and lets top players withdraw their prize money. With KaazPay the whole loop stays on one merchant account:',
                    { steps: [
                        'A player buys 20 USD of coins and picks Apple Pay at checkout. Your server creates a pay-in order through the KaazPay API.',
                        'The player confirms on their phone. KaazPay sends a signed notification to your callback URL, and you credit the coins only after it arrives.',
                        'Weeks later the same player wins a tournament and asks to withdraw to Cash App. Your system creates a payout order with their Cash App details and a unique reference.',
                        'KaazPay processes the payout and notifies you of the final status, at which point you mark the withdrawal as paid in the player\'s history.',
                    ] },
                    'The pay-in is settled to you in USDT, and the payout is funded from your balance, so finance sees both sides in one dashboard instead of two provider reports.',
                ],
            },
            {
                id: 'choosing-us-payout-rail',
                heading: 'How do you choose between PayPal, Cash App, Chime, card and ACH payouts?',
                blocks: [
                    'Start from where recipients already keep their money, not from what is easiest to integrate. Recipients who must open a new account to get paid are more likely to contact support.',
                    { list: [
                        '**[PayPal](/methods/paypal)** suits freelancers and marketplace sellers who already invoice through PayPal.',
                        '**Cash App** suits players, streamers and gig workers who spend from Cash App day to day.',
                        '**Chime** suits recipients whose main account is with the Chime mobile banking app.',
                        '**Cards** suit recipients who would rather receive the funds on a card they already use.',
                        '**ACH** suits contractors, agencies and suppliers who expect a transfer into a US bank account.',
                    ] },
                    'Many platforms offer two or three of these and let the recipient choose once in their profile. Payout limits and timings differ by rail and are agreed with your KaazPay account manager before launch.',
                ],
            },
            {
                id: 'us-payout-failures',
                heading: 'Why do US payouts fail, and how can you prevent it?',
                blocks: [
                    'When a payout is returned, the cause usually lies before the payment rail. Common causes and fixes:',
                    { list: [
                        '**Mistyped identifiers**: a wrong digit in a bank account or a typo in a wallet handle. Ask recipients to enter details twice and validate formats before saving.',
                        '**Name mismatch**: the payout name does not match the account holder. Collect the legal name exactly as it appears on the account.',
                        '**Closed or restricted accounts**: the destination account can no longer receive funds. Show the failure reason in the recipient\'s dashboard and let them switch method.',
                        '**Duplicate submissions**: a retry without a unique reference can create a second payout. Reuse the same reference when you retry, and only act on the final status.',
                    ] },
                    { note: 'Update balances and payout status only when the signed final-status notification arrives, never on the initial API response.' },
                ],
            },
            {
                id: 'us-go-live-prep',
                heading: 'What should you prepare before launching in the US?',
                blocks: [
                    'Prepare the following before launch:',
                    { list: [
                        'Decide which of the three pay-in methods appear on each device, and in which order.',
                        'Pick the payout rails you will offer and design the screen where recipients save their details.',
                        'Set up your callback endpoint and verify the signature on every notification.',
                        'Map each payout to the earnings, prize or invoice it covers with a unique reference.',
                        'Agree payout limits, settlement cycle and pricing with your account manager.',
                        'Run test orders in both directions with a KaazPay engineer before you switch on live traffic.',
                    ] },
                ],
            },
            {
                id: 'us-settlement-and-reach',
                heading: 'How are US funds settled, and can the same account cover other regions?',
                blocks: [
                    'USD collections are settled to you as the equivalent amount in USDT. Many KaazPay channels settle D+0 and others D+1 or later; the cycle for your US channels is confirmed before you go live. Our [USDT settlement guide](/guides/usdt-settlement) explains how this works in practice.',
                    'The same account also reaches international cards, EUR, GBP and AED bank transfers, Japan, Latin America, Southeast Asia and Africa, plus USDT pay-in and payouts. If you pay people in several countries, see the [mass payouts guide](/guides/mass-payouts-emerging-markets).',
                ],
            },
            {
                id: 'start-us-with-kaazpay',
                heading: 'How to get started with KaazPay in the United States',
                blocks: [
                    'Onboarding for the US with KaazPay follows the same four steps as every other market:',
                    { steps: [
                        'Open a KaazPay merchant account and share your business model, expected US volumes and payout needs.',
                        'Receive your merchant ID and API keys.',
                        'Integrate pay-in and payout with support from our engineers, including joint testing.',
                        'Go live and track every order and payout in the merchant dashboard.',
                    ] },
                    'Contact our team on Telegram via the [contact page](/contact) and we will reply within one business day with a channel plan. Technical details are on the [developers page](/developers).',
                ],
            },
        ],
        faq: [
            { q: 'Which US payment methods can I accept with KaazPay?', a: 'Cash App, Apple Pay and Google Pay are available for US pay-in. Visa, Mastercard and UnionPay card acceptance runs on the separate global cards channel.' },
            { q: 'Can US customers pay me with PayPal?', a: 'Not through KaazPay at the moment. PayPal is offered as a payout rail, so you can send money to US recipients\' PayPal accounts but not collect with it.' },
            { q: 'Which payout methods does KaazPay support in the US?', a: 'PayPal, Cash App, Chime, cards and ACH bank transfer. You can send them one by one or as a batch, with a status notification for each payout.' },
            { q: 'Can I collect and pay out with Cash App on the same account?', a: 'Yes. Cash App is supported for both US pay-in and US payouts, and both run on the same KaazPay merchant account.' },
            { q: 'In which currency do I receive US collections?', a: 'KaazPay settles the USD you collect as the equivalent amount in USDT, on a settlement cycle confirmed for your channels before go-live.' },
        ],
        queries: [
            'how to accept Cash App payments as a business',
            'payment gateway for US customers with Apple Pay and Google Pay',
            'send payouts to PayPal Cash App and Chime via API',
            'ACH payouts for international merchants',
            'US payment methods for online platforms',
        ],
    },
    zh: {
        title: '美国收付款方式：Cash App、钱包代收与美元代付',
        description: '用 KaazPay 向美国用户收款：支持 Cash App、Apple Pay、Google Pay 代收，以及 PayPal、Cash App、Chime、银行卡、ACH 美元代付，代收资金以 USDT 结算。',
        h1: '美国代收与代付怎么做：Cash App、Apple Pay、Google Pay、PayPal 与 ACH',
        summary: 'KaazPay 在美国提供 Cash App、Apple Pay、Google Pay 三种代收方式，代付则支持 PayPal、Cash App、Chime、银行卡和 ACH 银行账户。收款和付款共用一个商户账户、一套 API，代收资金按等额 USDT 结算，结算周期按通道在上线前确认。',
        takeaways: [
            '美国代收：Cash App、Apple Pay、Google Pay；PayPal 只做代付，不做代收。',
            '美国代付：PayPal、Cash App、Chime、银行卡、ACH，支持单笔与批量。',
            'Cash App 是 KaazPay 在美国唯一同时支持代收和代付的方式，适合“充值 + 提现”类平台。',
            '代付失败常因收款信息有误，提交批量代付前应先校验。',
            '美国代收资金以 USDT 结算，具体周期上线前按通道确认。',
        ],
        sections: [
            {
                id: 'us-coverage-at-a-glance',
                heading: 'KaazPay 在美国能收什么、付什么？',
                blocks: [
                    '美国通道分为代收和代付：三种代收方式，五种代付通道，全部以美元计价。',
                    { table: {
                        head: ['方向', '方式', '用户 / 收款人使用的是', '适用场景'],
                        rows: [
                            ['代收', 'Cash App', 'Cash App 账户', '充值、点数购买、打赏'],
                            ['代收', 'Apple Pay', 'iPhone 钱包里绑定的银行卡', '移动端快速支付'],
                            ['代收', 'Google Pay', 'Google 账户中保存的银行卡', '安卓与 Chrome 支付'],
                            ['代付', 'PayPal', 'PayPal 账户', '自由职业者、线上卖家'],
                            ['代付', 'Cash App', 'Cash App 账户', '玩家、主播提现'],
                            ['代付', 'Chime', 'Chime 账户', '以手机银行为主账户的收款人'],
                            ['代付', '银行卡', '收款人的银行卡', '没有钱包账户的收款人'],
                            ['代付', 'ACH', '美国银行账户', '合作方、供应商、大额付款'],
                        ],
                    } },
                    '最新通道以[美国市场页面](/payment-methods/united-states)为准。如需直接受理 Visa、Mastercard、银联卡，请使用独立的[全球信用卡通道](/payment-methods/global-cards)。',
                ],
            },
            {
                id: 'us-checkout-mix',
                heading: '美国收银台应该放哪些代收方式？',
                blocks: [
                    '支付方式的排序应按设备区分。iPhone 用户习惯用 [Apple Pay](/methods/apple-pay) 刷脸或指纹确认，安卓和 Chrome 用户则更常用 [Google Pay](/methods/google-pay)。两者调用的都是用户事先存好的银行卡，用户不必在小屏幕上手动输入卡号。',
                    '[Cash App](/methods/cash-app) 的逻辑不同：用户直接从 Cash App 账户付款，而不是调用手机钱包里的卡。它在美国是常见的转账工具，因此游戏、直播和社交类应用常把它和钱包按钮并排展示。',
                    '稳妥的做法是三种都提供，再按设备调整顺序：iOS 上 Apple Pay 排第一，安卓上 Google Pay 排第一，Cash App 在所有设备上都显示。三者的详细差异可参考 [Apple Pay、Google Pay 与 Cash App 对比](/compare/apple-pay-vs-google-pay-vs-cash-app)。',
                ],
            },
            {
                id: 'worked-example-us-flow',
                heading: '实例：一个账户跑通美国充值与提现',
                blocks: [
                    '以一款向美国玩家出售金币、并允许高分玩家提取奖金的手游为例，整个流程都在同一个 KaazPay 商户账户里完成：',
                    { steps: [
                        '玩家购买 20 美元金币，在收银台选择 Apple Pay，您的服务器通过 KaazPay API 创建代收订单。',
                        '玩家在手机上确认付款，KaazPay 向您的回调地址推送带签名的通知，收到通知后再给玩家加金币。',
                        '几周后，这位玩家赢得比赛并申请提现到 Cash App，您的系统用其 Cash App 信息和唯一订单号创建代付订单。',
                        'KaazPay 处理代付并推送最终状态，您据此把该笔提现标记为已到账。',
                    ] },
                    '代收部分以 USDT 结算给您，代付从账户余额中扣款，财务在一个后台就能看到收与付两端，不用再对两家服务商的报表。',
                ],
            },
            {
                id: 'choosing-us-payout-rail',
                heading: 'PayPal、Cash App、Chime、银行卡、ACH 代付怎么选？',
                blocks: [
                    '选择应以收款人平时使用的账户为出发点，而不是以接入是否省事为准。需要新开账户才能收款的收款人，更可能联系客服。',
                    { list: [
                        '**[PayPal](/methods/paypal)**：习惯用 PayPal 收款的自由职业者和平台卖家。',
                        '**Cash App**：日常用 Cash App 消费的玩家、主播和零工。',
                        '**Chime**：主账户开在 Chime 手机银行的收款人。',
                        '**银行卡**：希望款项直接打到常用银行卡上的收款人。',
                        '**ACH**：需要转入美国银行账户的外包团队、代理商和供应商。',
                    ] },
                    '很多平台会同时提供两三种，让收款人在个人资料里选一次即可。各通道的限额与到账时间不同，上线前由 KaazPay 客户经理与您确认。',
                ],
            },
            {
                id: 'us-payout-failures',
                heading: '美国代付为什么会失败？如何避免？',
                blocks: [
                    '代付被退回，原因通常出在通道之前的环节。常见原因与对策如下：',
                    { list: [
                        '**账号填错**：银行账号少一位、钱包用户名拼错。让收款人输入两次，并在保存前校验格式。',
                        '**姓名不一致**：代付姓名与账户持有人不符。请按账户上登记的法定姓名收集。',
                        '**账户已关闭或受限**：目标账户无法再入账。在收款人后台显示失败原因，并允许其更换方式。',
                        '**重复提交**：重试时没有沿用原订单号，可能导致重复付款。重试请使用同一订单号，并以最终状态为准。',
                    ] },
                    { note: '只在收到带签名的最终状态通知后更新余额与代付状态，不要以接口的首次返回为准。' },
                ],
            },
            {
                id: 'us-go-live-prep',
                heading: '上线美国通道前要准备什么？',
                blocks: [
                    '上线前请完成以下准备：',
                    { list: [
                        '确定三种代收方式在各类设备上是否显示、按什么顺序显示。',
                        '选定要提供的代付通道，并设计收款人填写账户信息的页面。',
                        '配置回调地址，并对每条通知做签名校验。',
                        '每笔代付使用唯一订单号，对应其所结算的收益、奖金或账单。',
                        '与客户经理确认代付限额、结算周期和费率。',
                        '在正式放量前，与 KaazPay 工程师一起完成代收和代付的双向测试。',
                    ] },
                ],
            },
            {
                id: 'us-settlement-and-reach',
                heading: '美国资金如何结算？同一账户能覆盖其他地区吗？',
                blocks: [
                    '美元代收按等额 USDT 结算给您。KaazPay 不少通道支持 D+0，也有 D+1 或更长的，您的美国通道周期会在上线前确认。具体流程见 [USDT 结算指南](/guides/usdt-settlement)。',
                    '同一账户还能接入国际信用卡、欧元 / 英镑 / 迪拉姆银行转账、日本、拉美、东南亚和非洲市场，并支持 USDT 代收与代付。若需向多个国家的收款人付款，可阅读[批量代付指南](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'start-us-with-kaazpay',
                heading: '如何通过 KaazPay 开通美国通道',
                blocks: [
                    '在 KaazPay，美国通道的开通流程与其他市场一致，共四步：',
                    { steps: [
                        '开通 KaazPay 商户账户，说明业务模式、预计美国交易量和代付需求。',
                        '获取商户号与 API 密钥。',
                        '在工程师协助下对接代收与代付接口，并完成联调。',
                        '正式上线，在商户后台追踪每一笔订单与代付。',
                    ] },
                    '请通过[联系页面](/contact)在 Telegram 上联系我们，我们会在一个工作日内回复通道方案。技术资料见[开发者页面](/developers)。',
                ],
            },
        ],
        faq: [
            { q: 'KaazPay 在美国支持哪些代收方式？', a: '支持 Cash App、Apple Pay 和 Google Pay。Visa、Mastercard、银联卡的受理走独立的全球信用卡通道。' },
            { q: '美国用户能用 PayPal 付款给我吗？', a: '目前 KaazPay 不提供 PayPal 代收。PayPal 是代付通道，可以向美国收款人的 PayPal 账户付款，但不能用来收款。' },
            { q: 'KaazPay 在美国支持哪些代付方式？', a: 'PayPal、Cash App、Chime、银行卡和 ACH 银行转账，可单笔或批量提交，每笔都有状态通知。' },
            { q: '同一个账户能同时做 Cash App 代收和代付吗？', a: '可以。Cash App 在美国同时支持代收和代付，均在同一个 KaazPay 商户账户中处理。' },
            { q: '美国代收资金以什么币种结算？', a: 'KaazPay 将您收到的美元按等额 USDT 结算，结算周期在上线前按通道确认。' },
        ],
        queries: [
            '美国 Cash App 代收如何接入',
            '美国 Apple Pay Google Pay 代收通道',
            'PayPal Cash App Chime 代付 API',
            '跨境商户 美国 ACH 代付',
        ],
    },
};
