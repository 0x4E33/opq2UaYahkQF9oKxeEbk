export default {
    slug: 'japan-jcb-payments',
    kind: 'guide',
    published: '2026-03-24',
    updated: '2026-03-24',
    related: {
        markets: ['japan', 'global-cards'],
        methods: ['jcb', 'visa', 'mastercard', 'unionpay'],
        industries: ['digital-goods', 'gaming', 'e-commerce', 'travel'],
        articles: ['international-card-acquiring', 'local-payment-methods-vs-cards', 'chargebacks-vs-local-payments', 'usdt-settlement'],
    },
    en: {
        title: 'Accept JCB Card Payments in Japan: Merchant Guide',
        description: 'Selling to Japan: why JCB matters, how it pairs with Visa, Mastercard and UnionPay acquiring, checkout tips for Japanese buyers, declines and USDT settlement.',
        h1: 'How to accept JCB card payments from customers in Japan',
        summary: 'JCB is Japan’s own card network and is widely held by Japanese consumers, so a checkout aimed at Japan should accept JCB alongside Visa and Mastercard. KaazPay offers JCB card pay-in in Japan in JPY and international Visa, Mastercard and UnionPay acquiring through the same integration. Japan is pay-in only on KaazPay, and card collections are settled to you in USDT.',
        queries: [
            'How can an overseas online store accept JCB cards from Japanese customers?',
            'Do I need JCB if I already accept Visa and Mastercard for Japan?',
            'Is there a payment gateway that accepts JCB, Visa, Mastercard and UnionPay and settles in USDT?',
            'Why are card payments from Japanese customers getting declined on our site?',
            'What should a checkout for Japanese shoppers look like?',
        ],
        takeaways: [
            'JCB is the only major international card brand founded in Japan, and JCB cards are widely held by Japanese consumers.',
            'On KaazPay, JCB is the Japan pay-in method, priced in JPY; Visa, Mastercard and UnionPay are available through international card acquiring.',
            'Japanese shoppers expect a Japanese-language checkout, yen prices without decimals and tax-inclusive totals.',
            'Japan is pay-in only on KaazPay: there are no JPY payouts.',
            'Card collections are settled to you as the equivalent amount in USDT, on a cycle confirmed before go-live.',
        ],
        sections: [
            { id: 'why-jcb', heading: 'Why does JCB matter when you sell to Japan?', blocks: [
                '**JCB** (Japan Credit Bureau) is the card network Japan built for itself, and it is the only major international card brand that comes from the country. JCB cards are widely held in Japan, often issued together with a department store, airline or rail loyalty programme, and many consumers use one as their main card for online shopping.',
                'A store that shows only Visa and Mastercard logos to Japanese visitors may lose customers who prefer to pay with JCB. Accepting JCB removes that barrier. Details are on the [JCB method page](/methods/jcb) and the [Japan market page](/payment-methods/japan).',
            ] },
            { id: 'jcb-and-international-cards', heading: 'How do JCB and international card acquiring fit together?', blocks: [
                'Japan on KaazPay is served by two pieces that share one integration: **JCB card pay-in** for Japanese customers, and **international card acquiring** for Visa, Mastercard and UnionPay. Together they cover the cards a Japanese shopper, a visitor to Japan or an international customer is likely to reach for.',
                { table: { head: ['Card', 'Who typically uses it', 'On KaazPay'], rows: [
                    ['JCB', 'Japanese consumers; JCB is Japan’s domestic network', 'Pay-in in Japan, in JPY'],
                    ['Visa', 'Card holders almost everywhere, including in Japan', 'International card acquiring'],
                    ['Mastercard', 'Card holders in most countries worldwide', 'International card acquiring'],
                    ['UnionPay', 'Chinese customers and travellers', 'International card acquiring'],
                ] } },
                { note: 'All card methods on KaazPay are pay-in only. For a deeper look at the international side, read our [international card acquiring guide](/guides/international-card-acquiring).' },
            ] },
            { id: 'jcb-checkout-example', heading: 'What does a JCB payment look like at checkout?', blocks: [
                'Consider a customer in Osaka buying a ¥3,300 monthly plan for a design tool you sell worldwide:',
                { steps: [
                    'Your site detects a Japanese visitor and shows the price in yen, tax included, with JCB listed among the accepted cards.',
                    'Your backend creates a card pay-in order through the KaazPay API for 3,300 JPY with a unique order ID.',
                    'The customer enters their JCB card on the payment page and completes any authentication their issuer requests.',
                    'KaazPay sends your server a signed notification with the final result.',
                    'You verify it, activate the plan and show a confirmation and receipt in Japanese.',
                ] },
                'If the customer instead uses a Visa or Mastercard, the flow is the same; only the card brand changes, and the result arrives in the same notification format.',
            ] },
            { id: 'japan-checkout-tips', heading: 'How do you build a checkout Japanese customers trust?', blocks: [
                'Japanese online shoppers are used to polished, detailed checkouts, and missing details reduce trust. Check the following before launch:',
                { list: [
                    '**Japanese language** for the product page, checkout, error messages and receipts, not only machine-translated labels.',
                    '**Yen without decimals:** JPY has no minor unit in everyday use, so show ¥3,300, not ¥3,300.00.',
                    '**Tax-inclusive totals:** Japanese rules require consumer prices to be shown including consumption tax, and shoppers expect the figure they see to be the figure charged.',
                    '**Visible card brands:** show JCB next to Visa and Mastercard so the customer knows before they start.',
                    '**Strong customer authentication:** Japan’s card security guidelines have pushed online merchants toward EMV 3-D Secure, so expect many issuers to ask the customer to confirm.',
                    '**Clear business details:** Japanese buyers look for seller information, contact routes and cancellation terms before paying.',
                ] },
            ] },
            { id: 'card-declines-japan', heading: 'Why are card payments from Japan declined, and what helps?', blocks: [
                { table: { head: ['What happens', 'Common reason', 'What helps'], rows: [
                    ['Customer abandons at the card form', 'Their card brand is not shown or not accepted', 'Accept and display JCB alongside Visa and Mastercard'],
                    ['Authentication not completed', 'The customer did not finish the issuer’s confirmation step', 'Explain on the page that their bank may ask them to confirm'],
                    ['Issuer decline on a foreign merchant', 'The issuer treats the transaction as unusual', 'Use clear billing descriptors and consistent business details; let the customer retry'],
                    ['Duplicate charge complaints', 'The customer clicked twice or retried after a timeout', 'Reuse one order ID per attempt and process each notification once'],
                ] } },
                'Cards also carry chargeback exposure that many local methods do not. Our comparison of [chargebacks vs local payments](/compare/chargebacks-vs-local-payments) explains how to plan for it, and [local payment methods vs cards](/compare/local-payment-methods-vs-cards) shows where each fits.',
            ] },
            { id: 'japan-pay-in-only', heading: 'Can you send payouts in Japan?', blocks: [
                'No. Japan is a **pay-in only** market on KaazPay: you can collect JCB card payments in JPY, but there are no JPY payouts to Japanese bank accounts or wallets. International card acquiring for Visa, Mastercard and UnionPay is pay-in only as well.',
                'If your business model involves paying partners, creators or suppliers, tell us where the recipients are. KaazPay offers payouts in many other markets as well as USDT payouts, and we can map out which rails fit before you build.',
            ] },
            { id: 'jpy-settlement', heading: 'How are JCB and card collections settled?', blocks: [
                'Customers pay by card, and KaazPay settles the equivalent amount to you in **USDT**. You do not need a Japanese bank account or a yen balance to sell to Japanese customers.',
                'Settlement cycles are set per channel: many KaazPay channels settle D+0 and others D+1 or later, and the cycle, rates and fees for card channels are confirmed in writing before go-live. See the [USDT settlement guide](/guides/usdt-settlement).',
            ] },
            { id: 'start-jcb-kaazpay', heading: 'How to start accepting JCB with KaazPay', blocks: [
                'KaazPay adds JCB and international cards through the same four steps as any other method:',
                { steps: [
                    'Open a merchant account and describe your product, your Japanese audience and your expected card volumes.',
                    'Get your API keys from the merchant dashboard.',
                    'Integrate with engineering support using the [developer documentation](/developers), testing JCB, Visa, Mastercard and UnionPay flows.',
                    'Go live and track approval rates by card brand in one dashboard.',
                ] },
                'For card pricing, review requirements and settlement terms, message our business team on Telegram through the [contact page](/contact); we reply within one business day.',
            ] },
        ],
        faq: [
            { q: 'Can I accept JCB cards through KaazPay?', a: 'Yes. KaazPay offers JCB card pay-in in Japan, priced in JPY, through the same API as its other methods.' },
            { q: 'Do I still need JCB if I accept Visa and Mastercard?', a: 'For Japanese customers, yes. JCB is Japan’s own network and many shoppers use it as their main card, so leaving it out can reduce conversions.' },
            { q: 'Does KaazPay accept Visa, Mastercard and UnionPay as well?', a: 'Yes. KaazPay provides international Visa, Mastercard and UnionPay card acquiring, which works alongside JCB in one integration.' },
            { q: 'Can I pay out to Japanese bank accounts?', a: 'No. Japan is pay-in only on KaazPay. Tell us where your recipients are and we will suggest payout rails in other markets or USDT payouts.' },
            { q: 'How are card collections from Japan settled?', a: 'KaazPay settles the equivalent amount to you in USDT. The settlement cycle, rates and fees for card channels are confirmed before go-live.' },
        ],
    },
    zh: {
        title: '日本 JCB 卡代收指南：面向日本用户收款',
        description: '向日本用户销售：JCB 为什么重要，如何与 Visa、Mastercard、银联国际收单搭配，日本用户信任的收银台细节、交易被拒原因，以及 USDT 结算。',
        h1: '如何接入 JCB 卡，向日本用户收款？',
        summary: 'JCB 是日本本土的银行卡组织，在日本消费者中普遍持有，因此面向日本的收银台应在 Visa、Mastercard 之外同时支持 JCB。KaazPay 提供以 JPY 计价的日本 JCB 卡代收，并在同一次对接中提供 Visa、Mastercard、银联国际收单。日本在 KaazPay 上仅支持代收，银行卡代收资金以 USDT 结算。',
        queries: [
            '海外网店如何受理日本用户的 JCB 卡付款？',
            '已经支持 Visa 和 Mastercard，做日本市场还需要 JCB 吗？',
            '是否有支付通道能同时受理 JCB、Visa、Mastercard、银联，并以 USDT 结算？',
            '为什么日本用户在我们网站上刷卡经常被拒？',
            '面向日本买家的收银台应如何设计？',
        ],
        takeaways: [
            'JCB 是唯一源自日本的主要国际卡组织，JCB 卡在日本消费者中普遍持有。',
            '在 KaazPay 上，JCB 是日本的代收方式，以 JPY 计价；Visa、Mastercard、银联通过国际收单提供。',
            '日本买家期待日文收银台、不带小数的日元价格，以及含税总价。',
            '日本在 KaazPay 上仅支持代收，没有 JPY 代付。',
            '银行卡代收按等额 USDT 结算，周期在上线前确认。',
        ],
        sections: [
            { id: 'why-jcb', heading: '为什么面向日本销售需要支持 JCB？', blocks: [
                '**JCB**（Japan Credit Bureau）是日本本土建立的银行卡组织，也是唯一源自日本的主要国际卡品牌。JCB 卡在日本普遍持有，很多是与百货公司、航空公司或铁路积分计划联名发行的，许多消费者将其作为网购的主要用卡。',
                '只向日本访客展示 Visa 和 Mastercard 标志的网店，可能流失偏好使用 JCB 的顾客。支持 JCB 可消除这一障碍。详见 [JCB 支付方式页面](/methods/jcb)和[日本市场页面](/payment-methods/japan)。',
            ] },
            { id: 'jcb-and-international-cards', heading: 'JCB 与国际信用卡收单如何搭配？', blocks: [
                'KaazPay 的日本方案由两部分组成，共用一次对接：面向日本用户的 **JCB 卡代收**，以及覆盖 Visa、Mastercard、银联的**国际信用卡收单**。两者结合，可覆盖日本本地买家、来日游客和海外顾客常用的卡。',
                { table: { head: ['卡组织', '典型用户', '在 KaazPay 上'], rows: [
                    ['JCB', '日本消费者，JCB 是日本本土卡组织', '日本代收，以 JPY 计价'],
                    ['Visa', '几乎各国持卡人，包括日本', '国际信用卡收单'],
                    ['Mastercard', '全球大多数国家的持卡人', '国际信用卡收单'],
                    ['银联 UnionPay', '中国消费者与游客', '国际信用卡收单'],
                ] } },
                { note: 'KaazPay 上所有银行卡方式均仅支持代收。国际卡部分的详细介绍见[国际信用卡收单指南](/guides/international-card-acquiring)。' },
            ] },
            { id: 'jcb-checkout-example', heading: 'JCB 付款在收银台上的流程是怎样的？', blocks: [
                '以大阪一位顾客订阅您面向全球销售的设计工具月费方案（¥3,300）为例：',
                { steps: [
                    '网站识别到日本访客，以日元显示含税价格，并在可用卡种中列出 JCB。',
                    '您的后端通过 KaazPay API 创建一笔 3,300 JPY 的银行卡代收订单，带唯一订单号。',
                    '顾客在支付页面输入 JCB 卡信息，并完成发卡行要求的验证。',
                    'KaazPay 向您的服务器推送带签名的最终结果通知。',
                    '您验签后开通方案，并以日文展示确认页和收据。',
                ] },
                '如果顾客改用 Visa 或 Mastercard，流程完全相同，只是卡组织不同，结果也以同样格式的通知回传。',
            ] },
            { id: 'japan-checkout-tips', heading: '如何打造日本用户信任的收银台？', blocks: [
                '日本网购用户习惯精致、信息完整的收银台，细节缺失会降低信任。上线前请逐项检查：',
                { list: [
                    '**日文：**商品页、收银台、错误提示和收据都用日文，而不只是机器翻译的按钮文字。',
                    '**日元不带小数：**JPY 日常不使用辅币单位，显示 ¥3,300，而不是 ¥3,300.00。',
                    '**含税总价：**日本规定面向消费者的价格须含消费税显示，顾客也期待看到的金额就是实际扣款金额。',
                    '**醒目的卡组织标志：**把 JCB 与 Visa、Mastercard 并列展示，让顾客在付款前即可确认。',
                    '**强身份验证：**日本的银行卡安全指引已推动线上商户采用 EMV 3-D Secure，很多发卡行会要求顾客确认。',
                    '**清楚的商户信息：**日本买家付款前会查看卖家信息、联系方式和退订条款。',
                ] },
            ] },
            { id: 'card-declines-japan', heading: '日本用户的银行卡付款为何被拒？如何改善？', blocks: [
                { table: { head: ['现象', '常见原因', '改善方法'], rows: [
                    ['顾客在填卡页面放弃', '未展示或不支持其所用卡组织', '支持并展示 JCB，与 Visa、Mastercard 并列'],
                    ['验证未完成', '顾客未完成发卡行的确认步骤', '在页面上提前说明银行可能要求确认'],
                    ['发卡行拒绝境外商户交易', '发卡行认为交易异常', '使用清楚的账单描述和一致的商户信息，并允许顾客重试'],
                    ['投诉重复扣款', '顾客重复点击或超时后重试', '每次尝试沿用同一订单号，每条通知只处理一次'],
                ] } },
                '银行卡还存在拒付（chargeback）风险，而很多本地支付方式没有。应对方法见[拒付与本地支付对比](/compare/chargebacks-vs-local-payments)，各自适用场景见[本地支付与银行卡对比](/compare/local-payment-methods-vs-cards)。',
            ] },
            { id: 'japan-pay-in-only', heading: '在日本可以代付吗？', blocks: [
                '不可以。日本在 KaazPay 上是**仅代收**市场：可以收以 JPY 计价的 JCB 卡付款，但不提供到日本银行账户或钱包的 JPY 代付。Visa、Mastercard、银联国际收单同样仅支持代收。',
                '如果您的业务需要给合作方、创作者或供应商付款，请告知收款人所在地。KaazPay 在许多其他市场提供代付，也支持 USDT 代付，我们可在您开发前协助规划合适的通道。',
            ] },
            { id: 'jpy-settlement', heading: 'JCB 与银行卡代收如何结算？', blocks: [
                '顾客刷卡付款，KaazPay 将等额 **USDT** 结算给您。向日本用户销售，不需要日本银行账户，也不必持有日元。',
                '结算周期按通道确定：KaazPay 许多通道为 D+0，其他通道为 D+1 或更长，银行卡通道的周期、费率与汇率会在上线前书面确认。详见 [USDT 结算指南](/guides/usdt-settlement)。',
            ] },
            { id: 'start-jcb-kaazpay', heading: '如何通过 KaazPay 开通 JCB 代收', blocks: [
                '在 KaazPay，JCB 与国际信用卡同样按四步接入：',
                { steps: [
                    '开设商户账户，介绍您的产品、日本用户群和预估银行卡交易量。',
                    '在商户后台获取 API 密钥。',
                    '参考[开发者文档](/developers)，在工程师协助下完成对接，测试 JCB、Visa、Mastercard 和银联流程。',
                    '正式上线，在同一后台按卡组织查看授权通过率。',
                ] },
                '关于银行卡费率、审核要求和结算条款，请通过[联系页面](/contact)在 Telegram 上联系商务团队，我们会在 1 个工作日内回复。',
            ] },
        ],
        faq: [
            { q: '可以通过 KaazPay 受理 JCB 卡吗？', a: '可以。KaazPay 提供日本 JCB 卡代收，以 JPY 计价，与其他支付方式使用同一套 API。' },
            { q: '已经支持 Visa 和 Mastercard，还需要 JCB 吗？', a: '面向日本用户时需要。JCB 是日本本土卡组织，许多买家将其作为主要用卡，不支持可能导致订单流失。' },
            { q: 'KaazPay 也支持 Visa、Mastercard 和银联吗？', a: '支持。KaazPay 提供 Visa、Mastercard、银联国际信用卡收单，可与 JCB 在同一次对接中使用。' },
            { q: '可以代付到日本银行账户吗？', a: '不可以，日本在 KaazPay 上仅支持代收。告诉我们收款人所在地，我们会建议其他市场的代付通道或 USDT 代付。' },
            { q: '日本的银行卡代收如何结算？', a: 'KaazPay 将等额 USDT 结算给您，银行卡通道的结算周期、费率与汇率在上线前确认。' },
        ],
    },
};
