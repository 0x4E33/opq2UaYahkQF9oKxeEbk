export default {
    slug: 'usdt-settlement',
    kind: 'guide',
    published: '2025-04-22',
    updated: '2025-04-22',
    related: {
        markets: ['usdt', 'mexico', 'colombia', 'malaysia'],
        methods: ['spei', 'pse', 'fpx'],
        industries: ['web3', 'gaming', 'global-payroll'],
        articles: ['usdt-vs-local-currency-settlement', 'usdt-networks-compared', 'mass-payouts-emerging-markets', 'merchant-onboarding-kyc-checklist'],
    },
    en: {
        title: 'How USDT Settlement Works for Payment Merchants',
        description: 'Practical guide to USDT settlement: customers pay in pesos, ringgit or cedis, you receive the USDT equivalent. Flow, timing, rates, wallets and reconciliation.',
        h1: 'How does USDT settlement work for merchants?',
        summary: 'With USDT settlement, your customers keep paying in their own currency with local methods, and the gateway pays out what it collected as the equivalent value in USDT instead of in each local currency. KaazPay settles every pay-in channel this way; the settlement cycle, rate and fees are agreed per channel before go-live, and each settlement is itemised in the merchant dashboard.',
        queries: [
            'We sell in Mexico, Colombia and Malaysia. Can a payment gateway pay us out in USDT instead of three local currencies?',
            'How does USDT settlement actually work if my customers pay with SPEI or FPX?',
            'How long does it take for local payments to be settled to us in USDT?',
            'What should we check about our wallet before a gateway starts settling USDT to it?',
            'How do I reconcile USDT settlements with the orders my customers paid in local currency?',
        ],
        takeaways: [
            'Settlement in USDT changes nothing for the buyer: they still pay with SPEI, PSE, FPX, mobile money or a card.',
            'Collections from different countries end up in one USDT balance rather than a bank account per currency.',
            'Timing is set by each channel: many KaazPay channels settle D+0, while others settle D+1 or later.',
            'Agree the rate basis, fees, cycle and settlement network for each channel in writing before launch.',
            'The receiving wallet is yours to protect, so lock down keys and whitelist addresses carefully.',
        ],
        sections: [
            {
                id: 'usdt-settlement-in-one-paragraph',
                heading: 'What does USDT settlement mean in practice?',
                blocks: [
                    'Every gateway does two jobs: it collects money from your buyers, and later it hands that money over to you. **USDT settlement** describes the second job. Rather than wiring Mexican pesos to a Mexican account and Malaysian ringgit to a Malaysian one, the gateway converts what it collected and transfers the equivalent value to you in USDT, a stablecoin designed to track the US dollar.',
                    'The buyer-facing side stays local. Someone in Mexico City pays with [SPEI](/methods/spei), someone in Medellín uses [PSE](/methods/pse), and someone in Kuala Lumpur pays through [FPX](/methods/fpx). None of them touches crypto.',
                    { note: 'Do not confuse USDT settlement with USDT as a payment method. Settlement is how you, the merchant, get paid. USDT pay-in and payout are options your own users can pick. KaazPay offers both, on separate terms.' },
                ],
            },
            {
                id: 'worked-example',
                heading: 'Worked example: one day of orders, one USDT settlement',
                blocks: [
                    'Consider an online game studio selling coin packs in three markets. On a single day it receives:',
                    {
                        table: {
                            head: ['Market', 'Buyer pays with', 'Collected in', 'What the studio receives'],
                            rows: [
                                ['Mexico', 'SPEI bank transfer', 'MXN', 'USDT equivalent, per the agreed rate and fee for that channel'],
                                ['Colombia', 'PSE online banking', 'COP', 'USDT equivalent, per that channel’s terms'],
                                ['Malaysia', 'FPX online banking', 'MYR', 'USDT equivalent, per that channel’s terms'],
                            ],
                        },
                    },
                    'Without USDT settlement the studio would need somewhere to receive three currencies and would then convert each one separately. With it, all three flows arrive in the same USDT balance, and each settlement line shows which channel and which orders it covers. The amounts here are illustrative; the real rate and fee for each channel come from your KaazPay quote.',
                ],
            },
            {
                id: 'settlement-flow',
                heading: 'What happens between a customer payment and your USDT balance?',
                blocks: [
                    {
                        steps: [
                            'Your server creates an order in the buyer’s currency and the buyer pays with the local method shown at checkout.',
                            'KaazPay confirms the payment and posts a signed, real-time notification to your server, which you verify before releasing goods.',
                            'When the channel’s settlement cycle comes round, the collected amount is converted at the agreed rate, net of the agreed fees.',
                            'The equivalent USDT is credited to your merchant balance and itemised in the dashboard, ready to withdraw to your wallet or to fund payouts.',
                        ],
                    },
                    'Because collections and payouts share one merchant account, the same balance can also pay sellers, creators or players through [local payouts](/guides/mass-payouts-emerging-markets).',
                ],
            },
            {
                id: 'settlement-timing',
                heading: 'How long does USDT settlement take?',
                blocks: [
                    'Settlement timing is set by the local channel, not by USDT. A real-time rail and a cash voucher network release funds on different schedules, so KaazPay agrees a cycle with you for each channel.',
                    {
                        list: [
                            '**D+0:** many KaazPay channels settle on the same day the payment is collected.',
                            '**D+1 or later:** other channels settle a day or more after collection, depending on the local scheme.',
                            '**Per channel, in advance:** your account manager confirms every cycle before go-live, so you can forecast cash flow market by market.',
                        ],
                    },
                    'Once a settlement is released, it moves on-chain, so it is not held up by banking hours or international wire cut-offs.',
                ],
            },
            {
                id: 'choose-network-and-wallet',
                heading: 'How do you set up the wallet that receives settlements?',
                blocks: [
                    'KaazPay can settle USDT on **Tron, Ethereum, BSC, Solana or Polygon**. Network fees and confirmation times differ, so pick one deliberately; our [USDT network comparison](/compare/usdt-networks-compared) explains the trade-offs.',
                    {
                        list: [
                            'Generate the receiving address on exactly the network you have agreed. A 0x address can belong to Ethereum, BSC or Polygon, so the address alone does not tell you the network.',
                            'Hold the keys in a setup your treasury team controls: a hardware wallet or a multi-signature wallet rather than one person’s phone.',
                            'Change the settlement address only through a documented, two-person process, and send a small test amount after any change.',
                            'Keep a record of which address and network were active for each settlement period.',
                        ],
                    },
                    { note: 'KaazPay staff will never ask for your private keys or seed phrase, or tell you to send funds to a personal account. Treat any such request as fraud and check it through the official Telegram contacts.' },
                ],
            },
            {
                id: 'reconcile-settlements',
                heading: 'How do you reconcile USDT settlements against orders?',
                blocks: [
                    'USDT settlement simplifies reconciliation, provided the process is in place from the start:',
                    {
                        steps: [
                            'Store KaazPay’s order reference next to your own order ID for every payment.',
                            'Mark orders paid only from verified notifications, never from the browser returning to your site.',
                            'Each day, export the settlement lines from the dashboard and match them to the paid orders by channel.',
                            'Check that the USDT credited equals the local amount converted at the agreed rate, minus the agreed fee.',
                            'Match each withdrawal to your wallet against its on-chain transaction hash.',
                        ],
                    },
                    'Our [integration checklist](/guides/payment-gateway-integration-checklist) covers notification handling in more depth.',
                ],
            },
            {
                id: 'is-it-right-for-you',
                heading: 'Is USDT settlement a good fit for your business?',
                blocks: [
                    'It usually fits when you sell into several countries without local companies there, when you pay out as well as collect, or when your treasury already runs in dollars or stablecoins. It may fit less well if one market dominates your revenue and you already hold a local entity and bank account there.',
                    'For a side-by-side view of both models, read [USDT vs local-currency settlement](/compare/usdt-vs-local-currency-settlement). Ask your accountant how stablecoin balances are treated where your company is based. This guide explains settlement mechanics and is not investment advice.',
                ],
            },
            {
                id: 'start-with-kaazpay',
                heading: 'How do you get USDT settlement with KaazPay?',
                blocks: [
                    'KaazPay settles every pay-in channel in USDT. Getting started takes four steps:',
                    {
                        steps: [
                            'Open a merchant account and share your markets, methods and expected volumes. Our [onboarding checklist](/guides/merchant-onboarding-kyc-checklist) lists what to prepare.',
                            'Receive your API keys once the account is approved.',
                            'Integrate with a KaazPay engineer alongside you for joint testing, using the [developer docs](/developers).',
                            'Go live with the settlement network, cycles and rates you agreed.',
                        ],
                    },
                    'Contact us on Telegram through the [contact page](/contact); we reply within one business day with a channel plan and pricing.',
                ],
            },
        ],
        faq: [
            { q: 'Do my customers need a crypto wallet?', a: 'No. They pay in their own currency with methods such as SPEI, PSE, FPX, GCash or mobile money. USDT is only used to settle funds to you, the merchant.' },
            { q: 'Which blockchain does KaazPay settle USDT on?', a: 'You choose one of the supported networks: Tron, Ethereum, BSC, Solana or Polygon. Agree it at onboarding and make sure your receiving address is on that same network.' },
            { q: 'Is every channel settled on the same day?', a: 'No. Many KaazPay channels settle D+0, but others settle D+1 or later. Your account manager confirms the cycle for each channel before you go live.' },
            { q: 'How is the conversion to USDT calculated?', a: 'Each channel has an agreed rate basis and fee, confirmed before launch. Every settlement line in the dashboard shows what was collected and what was credited, so you can check the maths.' },
            { q: 'Can I use the USDT balance to pay people?', a: 'Yes. Pay-in and payouts share one merchant account, so the balance can fund bank, mobile money, US wallet or USDT payouts in the markets where payouts are available.' },
        ],
    },
    zh: {
        title: 'USDT 结算怎么运作？商户收款结算指南',
        description: '用户用比索、林吉特、塞地等本币付款，商户收到等额 USDT。本文用实例讲清 USDT 结算的资金流程、到账周期、汇率费率确认、收款钱包设置与对账方法。',
        h1: 'USDT 结算是怎么运作的？',
        summary: 'USDT 结算是指用户照常用本地支付方式、以本币付款，支付通道再把代收资金按等额价值以 USDT 结算给商户，而不是分别打入各国本币账户。KaazPay 所有代收通道都以 USDT 结算，每个通道的结算周期、汇率和费率在上线前逐一约定，每笔结算都在商户后台列明。',
        queries: [
            '我们在墨西哥、哥伦比亚和马来西亚都有用户，支付通道能否统一以 USDT 结算？',
            '用户用 SPEI 或 FPX 付款，如何以 USDT 结算给商户？',
            '本地代收的钱多久能以 USDT 结算到账？',
            '通道开始往我们的钱包结算 USDT 之前，钱包这边要注意什么？',
            'USDT 结算如何与用户的本币订单对账？',
        ],
        takeaways: [
            '对付款用户没有任何影响，他们照样用 SPEI、PSE、FPX、移动钱包或银行卡付款。',
            '多个国家的代收资金汇入同一个 USDT 余额，不必为每种货币开银行账户。',
            '到账时间由通道决定：KaazPay 不少通道 D+0 结算，其余为 D+1 或更长。',
            '上线前把每个通道的汇率依据、费率、周期和结算链以书面形式确认。',
            '收款钱包由商户自己保管，私钥与地址白名单都要严格管理。',
        ],
        sections: [
            {
                id: 'usdt-settlement-in-one-paragraph',
                heading: 'USDT 结算是什么意思？',
                blocks: [
                    '支付通道做两件事：先向用户收款，再把钱交给商户。**USDT 结算**说的是第二件事。通道不再把墨西哥比索汇到墨西哥账户、把马来西亚林吉特汇到马来西亚账户，而是把代收金额折算后，以等值的 USDT（一种锚定美元的稳定币）转给商户。',
                    '用户端保持本地化：墨西哥城的用户用 [SPEI](/methods/spei) 转账，麦德林的用户用 [PSE](/methods/pse) 网银付款，吉隆坡的用户用 [FPX](/methods/fpx) 付款，全程都不接触加密货币。',
                    { note: '注意区分：USDT 结算是商户收钱的方式；USDT 代收、代付则是您的用户可以选择的支付方式。KaazPay 两者都提供，条款分别约定。' },
                ],
            },
            {
                id: 'worked-example',
                heading: '示例：一天的订单如何汇总为 USDT 结算',
                blocks: [
                    '假设一家游戏公司在三个市场销售金币礼包，某一天的收款情况如下：',
                    {
                        table: {
                            head: ['市场', '用户付款方式', '代收币种', '商户收到'],
                            rows: [
                                ['墨西哥', 'SPEI 银行转账', 'MXN', '按该通道约定汇率与费率折算的等额 USDT'],
                                ['哥伦比亚', 'PSE 网银', 'COP', '按该通道条款折算的等额 USDT'],
                                ['马来西亚', 'FPX 网银', 'MYR', '按该通道条款折算的等额 USDT'],
                            ],
                        },
                    },
                    '如果没有 USDT 结算，这家公司要准备三个收款账户，再分别换汇；采用 USDT 结算后，三路资金进入同一个 USDT 余额，每条结算记录都写明来自哪个通道、对应哪些订单。上表仅作示意，各通道的实际汇率与费率以 KaazPay 报价为准。',
                ],
            },
            {
                id: 'settlement-flow',
                heading: '从用户付款到 USDT 入账，中间经过哪些环节？',
                blocks: [
                    {
                        steps: [
                            '商户服务器以用户所在国币种创建订单，用户在收银台选择本地支付方式付款。',
                            'KaazPay 确认收款后，向商户服务器发送带签名的实时回调；商户验签通过后再发货。',
                            '到了该通道的结算周期，代收金额按约定汇率折算，并扣除约定费用。',
                            '等额 USDT 记入商户余额，并在后台逐笔列明，可提到自己的钱包，也可直接用于代付。',
                        ],
                    },
                    '代收与代付共用一个商户账户，所以这笔余额还能用来给卖家、主播或玩家[发起本地代付](/guides/mass-payouts-emerging-markets)。',
                ],
            },
            {
                id: 'settlement-timing',
                heading: 'USDT 结算多久到账？',
                blocks: [
                    '结算时间由本地通道决定，而非 USDT。实时支付网络和现金凭证网络的放款时间不同，因此 KaazPay 会按通道逐一约定结算周期。',
                    {
                        list: [
                            '**D+0：** KaazPay 不少通道在收款当天即可结算。',
                            '**D+1 或更长：** 其他通道视当地清算规则，在收款后一天或更久结算。',
                            '**按通道、提前确认：** 上线前客户经理会逐个通道确认周期，方便商户按市场预估现金流。',
                        ],
                    },
                    '结算一经放出就在链上转账，不受银行营业时间或跨境电汇截止时间影响。',
                ],
            },
            {
                id: 'choose-network-and-wallet',
                heading: '接收结算的钱包应该怎么设置？',
                blocks: [
                    'KaazPay 支持在 **Tron、Ethereum、BSC、Solana、Polygon** 上结算 USDT。各链的手续费和确认速度不同，建议认真比较后再定，可参考 [USDT 各链对比](/compare/usdt-networks-compared)。',
                    {
                        list: [
                            '收款地址必须生成在约定的那条链上。0x 开头的地址可能属于 Ethereum、BSC 或 Polygon，单看地址无法判断是哪条链。',
                            '私钥交由财务团队可控的方式保管，例如硬件钱包或多签钱包，不要只放在某个人的手机里。',
                            '修改结算地址必须走书面流程、双人复核，改完后先转一笔小额测试。',
                            '记录每个结算周期使用的地址和链，方便日后追溯。',
                        ],
                    },
                    { note: 'KaazPay 工作人员绝不会索要私钥或助记词，也不会要求您向个人账户转账。遇到此类要求一律视为诈骗，请通过官方 Telegram 联系方式核实。' },
                ],
            },
            {
                id: 'reconcile-settlements',
                heading: 'USDT 结算如何与订单对账？',
                blocks: [
                    'USDT 结算可简化对账，前提是从一开始就建立好流程：',
                    {
                        steps: [
                            '每笔订单都把 KaazPay 订单号和自己的订单号一起保存。',
                            '只根据验签通过的回调把订单标记为已付款，不要依据浏览器跳转。',
                            '每天从后台导出结算明细，按通道与已付款订单逐笔核对。',
                            '核对入账的 USDT 是否等于本币金额按约定汇率折算、扣除约定费用后的结果。',
                            '每次提币到钱包，都用链上交易哈希对应核实。',
                        ],
                    },
                    '回调处理的更多细节，请看[支付接入清单](/guides/payment-gateway-integration-checklist)。',
                ],
            },
            {
                id: 'is-it-right-for-you',
                heading: 'USDT 结算适合您的业务吗？',
                blocks: [
                    '如果您在多个国家销售但当地没有公司、既收款又要付款，或者资金管理本来就以美元或稳定币为主，USDT 结算通常较为合适。如果收入高度集中在单一市场，并且当地已有公司和银行账户，本币结算可能更合适。',
                    '两种模式的逐项对比，请看 [USDT 结算与本币结算对比](/compare/usdt-vs-local-currency-settlement)。稳定币余额在您公司所在地的财务与税务处理，请咨询会计师。本文仅说明结算机制，不构成投资建议。',
                ],
            },
            {
                id: 'start-with-kaazpay',
                heading: '如何在 KaazPay 开通 USDT 结算？',
                blocks: [
                    'KaazPay 所有代收通道均以 USDT 结算。开通分为四步：',
                    {
                        steps: [
                            '开通商户账户，并说明目标市场、支付方式和预估交易量。需要准备的资料见[商户开户清单](/guides/merchant-onboarding-kyc-checklist)。',
                            '账户审核通过后获取 API 密钥。',
                            '参照[开发者文档](/developers)接入，KaazPay 工程师全程协助联调。',
                            '按约定的结算链、周期与费率正式上线。',
                        ],
                    },
                    '请通过[联系页面](/contact)在 Telegram 联系我们，我们会在一个工作日内回复通道方案与报价。',
                ],
            },
        ],
        faq: [
            { q: '用户付款需要有加密钱包吗？', a: '不需要。用户用 SPEI、PSE、FPX、GCash、移动钱包等方式以本币付款，USDT 只用于向商户结算。' },
            { q: 'KaazPay 在哪条链上结算 USDT？', a: '可在 Tron、Ethereum、BSC、Solana、Polygon 中选择一条。开户时约定，并确保收款地址属于同一条链。' },
            { q: '所有通道都是当天结算吗？', a: '不是。KaazPay 不少通道 D+0 结算，也有通道为 D+1 或更长，上线前由客户经理逐个确认。' },
            { q: '本币折算成 USDT 是怎么计算的？', a: '每个通道都有约定的汇率依据和费率，上线前确认。后台每条结算记录都列出代收金额与入账金额，方便自行核算。' },
            { q: 'USDT 余额可以直接用来代付吗？', a: '可以。代收与代付共用一个商户账户，余额可用于有代付服务的市场的银行、移动钱包、美国钱包或 USDT 代付。' },
        ],
    },
};
