export default {
    slug: 'international-card-acquiring',
    kind: 'guide',
    published: '2026-03-10',
    updated: '2026-04-14',
    related: {
        markets: ['global-cards', 'japan', 'united-states'],
        methods: ['visa', 'mastercard', 'unionpay', 'jcb'],
        industries: ['travel', 'digital-goods', 'e-commerce'],
        articles: ['japan-jcb-payments', 'local-payment-methods-vs-cards', 'chargebacks-vs-local-payments', 'usdt-settlement'],
    },
    en: {
        title: 'International Card Acquiring: Visa, UnionPay & JCB',
        description: 'Accept foreign Visa, Mastercard and UnionPay cards worldwide and JCB in Japan: how card acquiring works, why payments decline, fraud controls and settlement.',
        h1: 'How to accept international card payments: Visa, Mastercard, UnionPay and JCB',
        summary: 'International card acquiring is the service that lets you charge cards issued outside your own country. KaazPay accepts Visa, Mastercard and UnionPay cards worldwide and JCB cards in Japan through one integration, protected by 3DS 2.0 and transaction monitoring. The card channel is for pay-in only, and card collections are settled to you in USDT.',
        takeaways: [
            'KaazPay acquires Visa, Mastercard and UnionPay worldwide, and JCB in Japan, through a single card integration.',
            'UnionPay helps you reach Chinese shoppers and travellers; JCB is the card to support for customers in Japan.',
            'Cross-border declines often come from issuer rules and abandoned 3DS checks, so watch decline reasons, not just volume.',
            'The international card channel handles pay-in only; pay customers or partners through local payout rails or USDT.',
            'Card collections are settled in USDT, with the cycle confirmed per channel before go-live.',
        ],
        sections: [
            {
                id: 'how-card-acquiring-works',
                heading: 'How does international card acquiring work?',
                blocks: [
                    'An acquirer is the party that accepts a card payment on the merchant\'s behalf and routes it to the card network and the bank that issued the card. When that bank sits in a different country from the merchant, the payment is a cross-border, or international, card transaction. A typical online payment moves through these stages:',
                    { steps: [
                        'The customer enters card details or picks a saved card at your checkout.',
                        'The issuing bank may ask the customer to confirm their identity through 3-D Secure, for example with a code or a banking-app approval.',
                        'The card network passes the authorisation request to the issuer, which approves or declines it within seconds.',
                        'Approved payments are captured and later settled by the acquirer to the merchant.',
                    ] },
                    'With KaazPay, that acquirer role is covered by the [global cards channel](/payment-methods/global-cards), and the result of every payment reaches your server as a signed notification.',
                ],
            },
            {
                id: 'kaazpay-card-coverage',
                heading: 'Which card networks can you accept through KaazPay?',
                blocks: [
                    { table: {
                        head: ['Network', 'Coverage on KaazPay', 'Why merchants add it', 'Direction'],
                        rows: [
                            ['[Visa](/methods/visa)', 'Worldwide', 'Issued by banks in almost every country, as credit, debit and prepaid cards', 'Pay-in'],
                            ['[Mastercard](/methods/mastercard)', 'Worldwide', 'The other global baseline network, with similarly broad issuance', 'Pay-in'],
                            ['[UnionPay](/methods/unionpay)', 'Worldwide', 'The card many shoppers and travellers from China carry', 'Pay-in'],
                            ['[JCB](/methods/jcb)', 'Japan', 'Japan\'s home-grown network, widely held by Japanese consumers', 'Pay-in'],
                        ],
                    } },
                    'KaazPay also runs local card pay-in in several African markets, such as Nigeria, Kenya, South Africa and Ghana. Those sit on each country\'s own market page rather than on the international channel.',
                ],
            },
            {
                id: 'why-unionpay-and-jcb',
                heading: 'Why add UnionPay and JCB next to Visa and Mastercard?',
                blocks: [
                    'Visa and Mastercard cover most customers, but some prefer a different card. A hotel booking site that sees guests from mainland China, or a digital store selling to fans in Asia, will meet buyers whose everyday card is UnionPay. Offering it reduces drop-off at the payment step.',
                    'The same applies in Japan. JCB was created in Japan and remains widely held by Japanese consumers, so a merchant selling into the country should treat it as a core option. KaazPay accepts JCB for the [Japan market](/payment-methods/japan); our [JCB payments guide](/guides/japan-jcb-payments) covers that market in more depth.',
                    'All four networks run on the same KaazPay card integration, so you do not sign or build anything separately per network.',
                ],
            },
            {
                id: 'cross-border-declines',
                heading: 'Why are cross-border card payments declined, and what helps?',
                blocks: [
                    'Foreign card payments decline more often than domestic ones, and the cause is frequently outside the merchant\'s control. Common causes:',
                    { list: [
                        '**Issuer rules on foreign transactions**: some banks block or question purchases from overseas merchants by default. A clear checkout and a recognisable descriptor reduce confusion.',
                        '**Abandoned 3-D Secure checks**: the customer never completes the bank\'s verification step. Keep the flow mobile-friendly and tell customers to expect it.',
                        '**Insufficient funds or limits**: common with prepaid and debit cards. Offering a local method or a second card gives the customer an alternative.',
                        '**Card data errors**: typos in the number, expiry or security code. Inline field validation catches most of these before submission.',
                        '**Risk-rule matches**: unusual amounts, many attempts in a row or mismatched location data can trigger a decline. Review these patterns with your account manager.',
                    ] },
                    'Track declines by reason code rather than as one overall number. That shows whether the fix belongs in your checkout, your risk rules or your payment-method mix.',
                ],
            },
            {
                id: 'card-fraud-controls',
                heading: 'How do you keep card fraud and chargebacks under control?',
                blocks: [
                    'Cards are pull payments: you charge the card, and the cardholder can later dispute the charge through their bank. That makes fraud prevention part of running a card channel, not an extra. KaazPay applies 3DS 2.0, risk scoring and 24/7 transaction monitoring to help keep fraud and chargebacks down without turning away genuine buyers.',
                    'Merchant-side practices matter as well:',
                    { list: [
                        'Describe what the customer is buying in plain words at checkout and on the receipt.',
                        'Keep delivery or usage records for digital goods, so you can answer a dispute with evidence.',
                        'Publish a clear refund route; customers who can obtain a refund are less likely to file a chargeback.',
                        'Verify the signature on every payment notification before you deliver goods.',
                    ] },
                    'For a side-by-side view of dispute exposure, see [chargebacks vs local payments](/compare/chargebacks-vs-local-payments).',
                ],
            },
            {
                id: 'cards-and-local-methods',
                heading: 'Should cards replace local payment methods in emerging markets?',
                blocks: [
                    'No. In many markets the default way to pay is a wallet, a bank app or an instant-payment scheme rather than a card: SPEI in Mexico, PSE in Colombia, Pix in Brazil, GCash in the Philippines, M-Pesa in Kenya. A checkout that only takes cards leaves those customers without a familiar option.',
                    'Cards serve as the international layer: they cover travellers, cross-border buyers and customers who prefer to pay by card. A common pattern is to lead with the strongest local method in each country and keep Visa, Mastercard and UnionPay available everywhere, with JCB added for Japan. Our [local payment methods vs cards comparison](/compare/local-payment-methods-vs-cards) walks through the trade-offs.',
                ],
            },
            {
                id: 'card-settlement-and-payouts',
                heading: 'How are card payments settled, and can you send payouts to cards?',
                blocks: [
                    'Card collections are settled to you in USDT, the same as every other KaazPay channel, so you hold one balance rather than a separate account per currency. Settlement cycles vary by channel and are confirmed with your account manager before launch; the [USDT settlement guide](/guides/usdt-settlement) explains the mechanics.',
                    { note: 'The international card channel is for pay-in only. For money out, use KaazPay payouts in supported markets (including card payouts in the United States) or USDT.' },
                ],
            },
            {
                id: 'start-cards-with-kaazpay',
                heading: 'How to start accepting international cards with KaazPay',
                blocks: [
                    { steps: [
                        'Open a KaazPay merchant account and tell us where your customers are and which networks you need.',
                        'Receive your merchant ID and API keys.',
                        'Integrate the card pay-in flow with our engineers, including joint testing of 3DS and notifications.',
                        'Go live and follow every card payment in the merchant dashboard.',
                    ] },
                    'Reach our team on Telegram through the [contact page](/contact); we reply within one business day. Integration details are on the [developers page](/developers).',
                ],
            },
        ],
        faq: [
            { q: 'Can I accept UnionPay cards through KaazPay?', a: 'Yes. KaazPay accepts UnionPay cards worldwide on the same card integration as Visa and Mastercard.' },
            { q: 'Does KaazPay support JCB?', a: 'Yes, JCB cards are accepted for the Japan market.' },
            { q: 'Do I need a separate integration for each card network?', a: 'No. Visa, Mastercard, UnionPay and JCB all run through one KaazPay card integration and one merchant account.' },
            { q: 'Why are some foreign cards declined at my checkout?', a: 'Common reasons include issuer blocks on overseas purchases, unfinished 3-D Secure checks, insufficient funds and mistyped card data. Reviewing decline reason codes shows which one applies.' },
            { q: 'Can I send payouts to cards through the international card channel?', a: 'The international card channel handles pay-in. Payouts run through local rails in supported markets, card payouts in the United States, or USDT.' },
            { q: 'How do I receive the money from card payments?', a: 'Card collections are settled to you in USDT, on a cycle confirmed for your channel before go-live.' },
        ],
        queries: [
            'how to accept international credit cards online',
            'accept UnionPay payments for overseas merchants',
            'JCB card acquiring for Japanese customers',
            'why are foreign credit cards declined online',
            'card acquiring with USDT settlement',
        ],
    },
    zh: {
        title: '国际信用卡收单：Visa、Mastercard、银联与 JCB',
        description: '在全球受理 Visa、Mastercard、银联卡，在日本受理 JCB：国际收单流程、跨境交易被拒原因、风控做法，以及代收资金如何以 USDT 结算。',
        h1: '如何受理境外银行卡付款：Visa、Mastercard、银联与 JCB 收单指南',
        summary: '国际信用卡收单，是指让商户能够向境外银行发行的卡扣款的服务。KaazPay 在全球受理 Visa、Mastercard 和银联卡，在日本受理 JCB 卡，全部走同一套对接，并配备 3DS 2.0 与交易监控。信用卡通道仅支持代收，资金以 USDT 结算。',
        takeaways: [
            'KaazPay 在全球受理 Visa、Mastercard、银联，在日本受理 JCB，只需一套信用卡对接。',
            '银联覆盖中国消费者与出境游客，JCB 是面向日本用户的关键卡种。',
            '跨境交易被拒常与发卡行规则和 3DS 验证中断有关，要按拒绝原因分析，而不只看总量。',
            '国际信用卡通道只做代收；付款给用户或合作方请走本地代付通道或 USDT。',
            '信用卡代收以 USDT 结算，周期在上线前按通道确认。',
        ],
        sections: [
            {
                id: 'how-card-acquiring-works',
                heading: '国际信用卡收单如何运作？',
                blocks: [
                    '收单机构代表商户受理银行卡付款，并把交易送往卡组织和发卡行。如果发卡行与商户不在同一个国家，这笔交易就属于跨境（国际）刷卡。一笔典型的线上卡支付会经过以下环节：',
                    { steps: [
                        '用户在收银台输入卡号，或选择已保存的卡。',
                        '发卡行可能要求用户通过 3-D Secure 验证身份，例如输入验证码或在银行 App 中确认。',
                        '卡组织把授权请求转给发卡行，发卡行在几秒内批准或拒绝。',
                        '获批的交易完成请款，之后由收单机构结算给商户。',
                    ] },
                    '在 KaazPay，这一收单环节由[全球信用卡通道](/payment-methods/global-cards)承担，每笔交易结果都会以带签名的通知推送到您的服务器。',
                ],
            },
            {
                id: 'kaazpay-card-coverage',
                heading: '通过 KaazPay 能受理哪些卡组织？',
                blocks: [
                    { table: {
                        head: ['卡组织', 'KaazPay 受理范围', '商户为什么需要', '方向'],
                        rows: [
                            ['[Visa](/methods/visa)', '全球', '几乎所有国家的银行都发行，涵盖信用卡、借记卡、预付卡', '代收'],
                            ['[Mastercard](/methods/mastercard)', '全球', '另一大全球通用卡组织，发卡范围同样广泛', '代收'],
                            ['[银联 UnionPay](/methods/unionpay)', '全球', '中国消费者和出境游客广泛持有的卡', '代收'],
                            ['[JCB](/methods/jcb)', '日本', '日本本土卡组织，日本消费者普遍持有', '代收'],
                        ],
                    } },
                    'KaazPay 还在尼日利亚、肯尼亚、南非、加纳等多个非洲市场提供本地银行卡代收，这些通道列在各国市场页面，不属于国际信用卡通道。',
                ],
            },
            {
                id: 'why-unionpay-and-jcb',
                heading: '已有 Visa 和 Mastercard，为什么还要加银联和 JCB？',
                blocks: [
                    'Visa 和 Mastercard 可覆盖大多数用户，但部分用户更常用其他卡。酒店预订网站若常接待来自中国内地的客人，或数字商店的买家集中在亚洲，就会遇到日常用银联卡的用户。支持银联可减少付款环节的流失。',
                    '日本的情况类似。JCB 源自日本，至今仍被日本消费者普遍持有，面向日本销售的商户应把它当作核心选项。KaazPay 为[日本市场](/payment-methods/japan)受理 JCB，更多细节见 [JCB 收款指南](/guides/japan-jcb-payments)。',
                    '四个卡组织都在同一套 KaazPay 信用卡对接里，无需按卡组织分别签约或开发。',
                ],
            },
            {
                id: 'cross-border-declines',
                heading: '境外卡为何容易被拒？如何改善？',
                blocks: [
                    '境外卡的拒绝率通常高于本地卡，而且原因往往不在商户这一侧。常见情况包括：',
                    { list: [
                        '**发卡行限制境外交易**：部分银行默认拦截或核查海外商户的消费。清晰的收银台和容易辨认的账单描述能减少误会。',
                        '**3-D Secure 验证未完成**：用户没有走完银行的验证步骤。验证流程要适配手机，并提前提示用户。',
                        '**余额或额度不足**：预付卡和借记卡较常见。同时提供本地支付方式或允许换卡，可为用户提供替代选择。',
                        '**卡信息输错**：卡号、有效期或安全码打错。在输入框做即时校验，可在提交前拦截大部分错误。',
                        '**触发风控规则**：金额异常、短时间多次尝试或地区信息不一致都可能导致拒绝。可与客户经理共同检视这些情况。',
                    ] },
                    '建议按拒绝原因码统计，而不是只看一个总拒绝率，这样才能判断该改收银台、风控规则还是支付方式组合。',
                ],
            },
            {
                id: 'card-fraud-controls',
                heading: '如何控制信用卡欺诈与拒付？',
                blocks: [
                    '信用卡属于“拉取式”支付：商户发起扣款，持卡人事后可以通过银行发起争议。因此风控是信用卡通道的基础环节，而不是附加项。KaazPay 采用 3DS 2.0、风险评分和 7×24 交易监控，在尽量不影响正常用户的前提下帮助降低欺诈和拒付。',
                    '商户自身的做法同样重要：',
                    { list: [
                        '在收银台和收据上清楚说明用户购买的内容。',
                        '数字商品要保留发货或使用记录，遇到争议时可以拿出证据。',
                        '公开清晰的退款途径，能顺利退款的用户较少发起拒付。',
                        '每条支付通知都先验证签名，再交付商品。',
                    ] },
                    '拒付风险的对比分析，可参考[拒付与本地支付对比](/compare/chargebacks-vs-local-payments)。',
                ],
            },
            {
                id: 'cards-and-local-methods',
                heading: '在新兴市场，信用卡能取代本地支付吗？',
                blocks: [
                    '不能。很多市场的默认付款方式是钱包、银行 App 或实时支付，而不是刷卡：墨西哥用 SPEI，哥伦比亚用 PSE，巴西用 Pix，菲律宾用 GCash，肯尼亚用 M-Pesa。只收卡的收银台，会使这些用户缺少熟悉的选项。',
                    '信用卡的作用在于国际覆盖：服务游客、跨境买家和偏好刷卡的用户。常见做法是在每个国家优先展示当地最主流的方式，同时在所有市场保留 Visa、Mastercard、银联，并为日本加上 JCB。详细权衡见[本地支付与信用卡对比](/compare/local-payment-methods-vs-cards)。',
                ],
            },
            {
                id: 'card-settlement-and-payouts',
                heading: '信用卡收款如何结算？能代付到卡上吗？',
                blocks: [
                    '与 KaazPay 其他通道一样，信用卡代收资金以 USDT 结算给您，您只需管理一个余额，不必为每种货币单独开户。结算周期因通道而异，上线前由客户经理确认，具体机制见 [USDT 结算指南](/guides/usdt-settlement)。',
                    { note: '国际信用卡通道仅支持代收。如需付款，请使用 KaazPay 在支持市场的代付通道（包括美国的银行卡代付）或 USDT。' },
                ],
            },
            {
                id: 'start-cards-with-kaazpay',
                heading: '如何通过 KaazPay 开通国际信用卡收单',
                blocks: [
                    { steps: [
                        '开通 KaazPay 商户账户，告诉我们您的用户分布和需要的卡组织。',
                        '获取商户号与 API 密钥。',
                        '在工程师协助下对接信用卡代收流程，联调 3DS 与回调通知。',
                        '正式上线，在商户后台追踪每一笔刷卡交易。',
                    ] },
                    '请通过[联系页面](/contact)在 Telegram 上联系我们，我们会在一个工作日内回复。对接说明见[开发者页面](/developers)。',
                ],
            },
        ],
        faq: [
            { q: 'KaazPay 能受理银联卡吗？', a: '可以。KaazPay 在全球受理银联卡，与 Visa、Mastercard 走同一套信用卡对接。' },
            { q: 'KaazPay 支持 JCB 吗？', a: '支持，JCB 卡在日本市场受理。' },
            { q: '每个卡组织都要单独对接吗？', a: '不需要。Visa、Mastercard、银联和 JCB 都通过同一套 KaazPay 信用卡对接和同一个商户账户处理。' },
            { q: '为什么部分境外卡在我的收银台被拒？', a: '常见原因有发卡行拦截境外消费、3-D Secure 验证未完成、余额不足和卡信息输错。查看拒绝原因码即可判断具体原因。' },
            { q: '国际信用卡通道能代付到卡上吗？', a: '国际信用卡通道只做代收。代付可使用支持市场的本地通道、美国的银行卡代付或 USDT。' },
            { q: '信用卡代收资金如何结算给我？', a: '信用卡代收资金以 USDT 结算给您，结算周期在上线前按通道确认。' },
        ],
        queries: [
            '国际信用卡收单 如何开通',
            '境外商户 银联卡代收',
            '日本 JCB 收单通道',
            '境外信用卡支付被拒 原因',
            '信用卡收款 USDT 结算',
        ],
    },
};
