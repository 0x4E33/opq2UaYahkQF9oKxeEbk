// Build-time only (imported by entry-server): every article's full body, for JSON-LD and llms-full.txt.
const FILES = import.meta.glob('./articles/*.js', { eager: true, import: 'default' });
export const ARTICLE_BODIES = Object.fromEntries(Object.values(FILES).filter((a) => a?.slug).map((a) => [a.slug, a]));
