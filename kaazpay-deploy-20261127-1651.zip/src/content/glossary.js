/**
 * Payments glossary (/glossary) — bilingual term definitions for SEO / GEO.
 *
 * Shape: { id, category, en: { term, aka, short, body }, zh: { term, aka, short, body }, links }
 *   category : 'concept' | 'method' | 'settlement' | 'risk'
 *   short    : one-sentence definition (≤ 30 words), suitable for DefinedTerm / meta descriptions
 *   body     : 2–4 sentence explanation, incl. how the term relates to KaazPay where relevant
 *   links    : internal paths (/methods/<slug>, /payment-methods/<slug>, /guides/<slug>, /compare/<slug>, static pages)
 *
 * Plain ES module, no imports. Facts must stay consistent with src/data/channels.js and src/data/methods.js.
 */

export const GLOSSARY_CATEGORIES = {
    concept: { en: 'Core concepts', zh: '基础概念' },
    method: { en: 'Payment methods', zh: '支付方式' },
    settlement: { en: 'Settlement & USDT', zh: '结算与 USDT' },
    risk: { en: 'Risk & compliance', zh: '风控与合规' },
};

export const GLOSSARY = [
    // ── Core concepts ───────────────────────────────────────────────────────────
    {
        id: 'pay-in',
        category: 'concept',
        en: {
            term: 'Pay-in',
            aka: ['Collection', 'Acceptance', 'Payment collection'],
            short: 'Collecting money from customers into a merchant account, usually through local payment methods such as bank transfers, e-wallets or QR codes.',
            body: 'Pay-in covers every step from the customer choosing a payment method to the funds being credited to the merchant. KaazPay provides local pay-in in each supported market, so customers pay in their own currency with the methods they already use. Collected funds are settled to the merchant in USDT.',
        },
        zh: {
            term: '代收',
            aka: ['收款', 'Pay-in'],
            short: '通过银行转账、电子钱包、扫码等本地支付方式，向消费者收取款项并入账至商户账户。',
            body: '代收涵盖从消费者选择支付方式到资金入账商户的全过程。KaazPay 在各支持市场提供本地代收，消费者可使用当地货币和熟悉的支付方式付款。代收资金以 USDT 结算给商户。',
        },
        links: ['/capabilities', '/methods'],
    },
    {
        id: 'payout',
        category: 'concept',
        en: {
            term: 'Payout',
            aka: ['Disbursement', 'Withdrawal', 'Pay-out'],
            short: 'Sending money from a merchant account to recipients, such as users, sellers or staff, through bank transfers, mobile wallets or other payout rails.',
            body: 'Payouts are used for withdrawals, refunds to users, seller earnings and payroll. Available payout rails vary by market: some markets support bank transfer only, others also support mobile wallets. KaazPay manages pay-in and payouts from the same merchant account.',
        },
        zh: {
            term: '代付',
            aka: ['出款', '付款', 'Payout'],
            short: '通过银行转账、移动钱包等渠道，从商户账户向用户、卖家或员工等收款方付款。',
            body: '代付常用于用户提现、退款、卖家结款和薪资发放。各市场可用的代付方式不同：部分市场仅支持银行转账，部分市场还支持移动钱包。在 KaazPay，代收与代付在同一个商户账户中管理。',
        },
        links: ['/capabilities', '/guides/mass-payouts-emerging-markets'],
    },
    {
        id: 'payment-gateway',
        category: 'concept',
        en: {
            term: 'Payment gateway',
            aka: ['Payment service provider', 'PSP'],
            short: 'A service that connects a merchant to payment channels, passing payment requests and results between the merchant, the customer and the underlying payment networks.',
            body: 'A gateway gives merchants one integration instead of separate connections to each bank, wallet or card network. KaazPay is a cross-border payment gateway: it provides local pay-in, local payouts and USDT settlement through one API and one merchant portal. KaazPay is not a bank.',
        },
        zh: {
            term: '支付网关',
            aka: ['支付服务商', 'PSP'],
            short: '连接商户与各支付通道的服务，在商户、消费者和底层支付网络之间传递支付请求与结果。',
            body: '通过支付网关，商户只需一次对接，无需分别连接每家银行、钱包或卡组织。KaazPay 是跨境支付网关，通过一套 API 和一个商户后台提供本地代收、本地代付与 USDT 结算。KaazPay 不是银行。',
        },
        links: ['/about', '/compare/one-gateway-vs-multiple-providers'],
    },
    {
        id: 'payment-channel',
        category: 'concept',
        en: {
            term: 'Payment channel',
            aka: ['Channel', 'Payment rail'],
            short: 'A specific route used to process a payment, defined by the payment method, the market and the provider that processes it.',
            body: 'The same payment method can be offered through more than one channel, each with its own limits, fees, success rate and settlement cycle. KaazPay confirms these terms per channel before a merchant goes live.',
        },
        zh: {
            term: '支付通道',
            aka: ['通道'],
            short: '处理一笔支付所经过的具体路径，由支付方式、所在市场以及处理该支付的服务方共同确定。',
            body: '同一种支付方式可能有多条通道，每条通道的限额、费率、成功率和结算周期各不相同。KaazPay 在商户上线前逐条确认这些条件。',
        },
        links: ['/methods', '/compare/one-gateway-vs-multiple-providers'],
    },
    {
        id: 'local-payment-method',
        category: 'concept',
        en: {
            term: 'Local payment method',
            aka: ['LPM', 'Alternative payment method', 'APM'],
            short: 'A payment method used mainly within one country or region, such as a domestic bank transfer scheme, e-wallet, QR standard or mobile money service.',
            body: 'In many markets, customers prefer local methods over international cards. Examples include FPX and DuitNow in Malaysia, Pix in Brazil, QRIS in Indonesia and M-Pesa in Kenya. KaazPay offers local payment methods market by market, alongside international cards.',
        },
        zh: {
            term: '本地支付方式',
            aka: ['LPM', '替代支付方式', 'APM'],
            short: '主要在单一国家或地区使用的支付方式，如本国银行转账、电子钱包、扫码标准或移动钱包服务。',
            body: '在许多市场，消费者更习惯使用本地支付方式而非国际信用卡，例如马来西亚的 FPX 与 DuitNow、巴西的 Pix、印度尼西亚的 QRIS 和肯尼亚的 M-Pesa。KaazPay 按市场提供本地支付方式，并同时支持国际信用卡。',
        },
        links: ['/methods', '/compare/local-payment-methods-vs-cards'],
    },
    {
        id: 'acquiring',
        category: 'concept',
        en: {
            term: 'Acquiring',
            aka: ['Card acquiring', 'Merchant acquiring'],
            short: 'The service of accepting card payments on behalf of a merchant and routing them through card networks to the issuing bank for approval.',
            body: 'An acquirer, or a provider working with one, processes card transactions and is responsible for the merchant relationship towards the card network. KaazPay offers international card acceptance for Visa, Mastercard and UnionPay, and JCB in Japan.',
        },
        zh: {
            term: '收单',
            aka: ['信用卡收单', '商户收单'],
            short: '代表商户受理银行卡支付，并通过卡组织将交易发送至发卡行进行授权的服务。',
            body: '收单机构或与其合作的服务方负责处理卡交易，并就商户关系对卡组织负责。KaazPay 支持 Visa、Mastercard、银联国际信用卡收款，日本市场支持 JCB。',
        },
        links: ['/guides/international-card-acquiring', '/payment-methods/global-cards', '/methods/visa', '/methods/mastercard'],
    },
    {
        id: 'mdr',
        category: 'concept',
        en: {
            term: 'MDR (merchant discount rate)',
            aka: ['Processing fee', 'Transaction fee', 'Rate'],
            short: 'The fee a merchant pays for processing a payment, usually a percentage of the transaction amount, sometimes combined with a fixed fee per transaction.',
            body: 'Fees differ by market, payment method and channel, and pay-in and payout are usually priced separately. At KaazPay, fees are quoted per channel by the account manager before go-live and itemised in the merchant portal.',
        },
        zh: {
            term: '费率（MDR）',
            aka: ['手续费', '交易费', 'MDR'],
            short: '商户为处理一笔支付所支付的费用，通常按交易金额的百分比计算，有时另加每笔固定费用。',
            body: '费率因市场、支付方式和通道而异，代收与代付通常分别计价。在 KaazPay，费率由客户经理按通道报价并在上线前确认，交易明细可在商户后台查看。',
        },
        links: ['/contact'],
    },
    {
        id: 'smart-routing',
        category: 'concept',
        en: {
            term: 'Smart routing',
            aka: ['Payment routing', 'Dynamic routing'],
            short: 'Automatically sending each payment to the channel most likely to complete it, based on channel performance and availability at that moment.',
            body: 'Routing matters in markets where one payment method is available through several channels. Where a market has more than one channel, KaazPay sends each payment to the channel performing best at that moment.',
        },
        zh: {
            term: '智能路由',
            aka: ['支付路由', '动态路由'],
            short: '根据各通道当下的表现与可用性，自动将每笔支付分配至最可能成功的通道。',
            body: '当同一种支付方式有多条通道时，路由尤为重要。在有多条通道的市场，KaazPay 会将每笔支付分配至当前表现最佳的通道。',
        },
        links: ['/capabilities', '/guides/payment-success-rate'],
    },
    {
        id: 'failover',
        category: 'concept',
        en: {
            term: 'Failover',
            aka: ['Automatic failover', 'Channel switching'],
            short: 'Switching payments to a backup channel when the primary channel slows down or becomes unavailable.',
            body: 'Failover limits the impact of a single channel outage on a merchant’s checkout. Where more than one channel is available in a market, KaazPay switches traffic automatically if a channel slows down.',
        },
        zh: {
            term: '故障切换',
            aka: ['自动切换', '通道切换', 'Failover'],
            short: '当主通道响应变慢或不可用时，将支付切换至备用通道。',
            body: '故障切换可减少单一通道中断对商户收款的影响。在有多条通道的市场，KaazPay 会在通道响应变慢时自动切换。',
        },
        links: ['/capabilities', '/compare/one-gateway-vs-multiple-providers'],
    },
    {
        id: 'success-rate',
        category: 'concept',
        en: {
            term: 'Success rate',
            aka: ['Approval rate', 'Conversion rate', 'Authorisation rate'],
            short: 'The share of initiated payments that complete successfully, a key measure of how well a checkout and its payment channels perform.',
            body: 'Success rate depends on the payment methods offered, channel stability, customer experience at checkout and risk rules. Offering the local methods customers prefer, together with routing and failover across channels, are common ways to improve it.',
        },
        zh: {
            term: '支付成功率',
            aka: ['成功率', '授权通过率', '转化率'],
            short: '已发起的支付中成功完成的比例，是衡量收银台和支付通道表现的关键指标。',
            body: '成功率取决于所提供的支付方式、通道稳定性、付款体验和风控规则。提供消费者偏好的本地支付方式，并结合多通道路由与故障切换，是提升成功率的常见做法。',
        },
        links: ['/guides/payment-success-rate'],
    },
    {
        id: 'webhook',
        category: 'concept',
        en: {
            term: 'Webhook',
            aka: ['Callback', 'Notification URL', 'Asynchronous notification'],
            short: 'An HTTP request a payment provider sends to the merchant’s server to report a change in payment status, such as success or failure.',
            body: 'Many local payment methods complete outside the merchant’s page, so the final result arrives by callback rather than in the initial API response. KaazPay sends real-time, signed callbacks for every pay-in and payout; merchants should verify the signature before updating an order.',
        },
        zh: {
            term: '回调通知',
            aka: ['Webhook', '异步通知', '回调'],
            short: '支付服务方向商户服务器发送的 HTTP 请求，用于通知支付状态变化，如成功或失败。',
            body: '许多本地支付方式在商户页面之外完成，最终结果通过回调送达，而非在首次 API 响应中返回。KaazPay 为每笔代收和代付发送实时签名回调；商户应先验证签名，再更新订单状态。',
        },
        links: ['/developers', '/guides/payment-gateway-integration-checklist'],
    },
    {
        id: 'request-signature',
        category: 'concept',
        en: {
            term: 'Request signature',
            aka: ['Signing', 'HMAC', 'Signature verification'],
            short: 'A cryptographic value computed from a request’s content and a secret key, used to prove the request is authentic and unchanged.',
            body: 'The sender signs each request with its key, and the receiver recomputes the signature to verify it; HMAC is a common method. KaazPay uses request signing for API calls and signs callbacks so merchants can verify them with their key.',
        },
        zh: {
            term: '请求签名',
            aka: ['签名', '验签', 'HMAC'],
            short: '根据请求内容和密钥计算出的加密值，用于证明请求来源真实且内容未被篡改。',
            body: '发送方使用密钥对每个请求签名，接收方重新计算签名进行校验，HMAC 是常用算法之一。KaazPay 的 API 调用使用请求签名，回调同样带有签名，商户可使用密钥验证。',
        },
        links: ['/developers', '/guides/payment-gateway-integration-checklist'],
    },
    {
        id: 'ip-whitelist',
        category: 'concept',
        en: {
            term: 'IP whitelist',
            aka: ['IP allow-list', 'IP allowlisting'],
            short: 'A list of approved server IP addresses; requests from any other address are rejected.',
            body: 'IP whitelisting adds a layer of protection on top of API keys and signatures. KaazPay supports IP allow-listing, together with request signing and TLS on every call.',
        },
        zh: {
            term: 'IP 白名单',
            aka: ['IP 允许列表'],
            short: '预先登记的服务器 IP 地址列表，来自其他地址的请求将被拒绝。',
            body: 'IP 白名单在 API 密钥和签名之外再增加一层防护。KaazPay 支持 IP 白名单，并对每次调用使用请求签名与 TLS 加密。',
        },
        links: ['/developers'],
    },
    {
        id: 'idempotency',
        category: 'concept',
        en: {
            term: 'Idempotency',
            aka: ['Idempotent request', 'Duplicate prevention'],
            short: 'A property that lets the same request be sent more than once without creating duplicate payments or payouts.',
            body: 'Network timeouts can cause a merchant to resend a request. Using a unique merchant order number per transaction, and handling repeated callbacks for the same order only once, prevents double charges and double payouts.',
        },
        zh: {
            term: '幂等性',
            aka: ['幂等', '防重复'],
            short: '同一请求重复发送多次，也不会产生重复支付或重复代付的特性。',
            body: '网络超时可能导致商户重复发送请求。每笔交易使用唯一的商户订单号，并对同一订单的重复回调只处理一次，可避免重复扣款和重复出款。',
        },
        links: ['/guides/payment-gateway-integration-checklist'],
    },
    {
        id: 'mass-payout',
        category: 'concept',
        en: {
            term: 'Mass payout',
            aka: ['Bulk payout', 'Batch disbursement'],
            short: 'Sending many payouts in one batch or through automated API calls, for example to sellers, creators, players or contractors.',
            body: 'Mass payouts require accurate recipient details, per-market payout rails and clear status tracking for each transfer. KaazPay supports payouts to bank accounts, mobile wallets in selected markets and USDT wallets, with status reported by callback.',
        },
        zh: {
            term: '批量代付',
            aka: ['批量出款', '批量付款'],
            short: '通过批量操作或自动化 API 调用一次发出多笔代付，例如向卖家、创作者、玩家或外包人员付款。',
            body: '批量代付需要准确的收款人资料、各市场适用的代付方式以及每笔转账的状态跟踪。KaazPay 支持代付至银行账户、部分市场的移动钱包以及 USDT 钱包，并通过回调通知每笔状态。',
        },
        links: ['/guides/mass-payouts-emerging-markets', '/industries/global-payroll'],
    },

    // ── Settlement & USDT ──────────────────────────────────────────────────────
    {
        id: 'settlement',
        category: 'settlement',
        en: {
            term: 'Settlement',
            aka: ['Funds settlement', 'Merchant settlement'],
            short: 'The transfer of collected funds, after fees, from the payment provider to the merchant.',
            body: 'Settlement terms define the currency, timing and destination of a merchant’s funds. KaazPay settles collected funds in USDT; the settlement cycle is confirmed per channel.',
        },
        zh: {
            term: '结算',
            aka: ['资金结算', '商户结算'],
            short: '支付服务方扣除费用后，将代收资金转给商户的过程。',
            body: '结算条款约定商户资金的币种、时间和去向。KaazPay 以 USDT 结算代收资金，结算周期按通道确认。',
        },
        links: ['/guides/usdt-settlement', '/compare/usdt-vs-local-currency-settlement'],
    },
    {
        id: 'settlement-cycle',
        category: 'settlement',
        en: {
            term: 'Settlement cycle',
            aka: ['T+0', 'D+0', 'D+1', 'T+1'],
            short: 'The time between a payment being collected and the funds being settled to the merchant, written as D+0 (same day), D+1 (next day) and so on.',
            body: 'D counts calendar days and T usually counts business days; definitions can differ between providers. At KaazPay, many channels settle D+0 and others D+1 or later; the cycle for each channel is confirmed before go-live.',
        },
        zh: {
            term: '结算周期',
            aka: ['T+0', 'D+0', 'D+1', 'T+1'],
            short: '从支付完成到资金结算给商户之间的时间，以 D+0（当日）、D+1（次日）等表示。',
            body: 'D 通常按自然日计算，T 通常按工作日计算，各服务方的定义可能不同。在 KaazPay，多条通道支持 D+0，其余为 D+1 或更长，每条通道的结算周期在上线前确认。',
        },
        links: ['/guides/usdt-settlement'],
    },
    {
        id: 'usdt',
        category: 'settlement',
        en: {
            term: 'USDT',
            aka: ['Tether', 'Tether USD'],
            short: 'A US dollar–denominated stablecoin issued by Tether, available on several blockchain networks and widely used for cross-border settlement.',
            body: 'USDT moves between wallets on public blockchains, so it can be transferred across borders without correspondent banking. KaazPay settles merchant funds in USDT and also offers USDT pay-in and payout through its global USDT channel.',
        },
        zh: {
            term: 'USDT',
            aka: ['泰达币', 'Tether'],
            short: '由 Tether 发行、以美元计价的稳定币，可在多条区块链网络上流转，广泛用于跨境结算。',
            body: 'USDT 在公链钱包之间转移，跨境转账无需经过代理行。KaazPay 以 USDT 为商户结算资金，并通过全球 USDT 通道提供 USDT 代收与代付。',
        },
        links: ['/payment-methods/usdt', '/guides/usdt-settlement'],
    },
    {
        id: 'stablecoin',
        category: 'settlement',
        en: {
            term: 'Stablecoin',
            aka: ['Fiat-backed token'],
            short: 'A digital token designed to hold a stable value by tracking a reference asset, most often the US dollar.',
            body: 'Stablecoins combine the price stability of a fiat currency with the transfer speed of a blockchain. USDT is the most widely used stablecoin and is the settlement currency at KaazPay.',
        },
        zh: {
            term: '稳定币',
            aka: ['法币稳定币'],
            short: '通过锚定参考资产（通常为美元）来保持价值稳定的数字代币。',
            body: '稳定币兼具法币的价格稳定性和区块链的转账速度。USDT 是使用最广泛的稳定币，也是 KaazPay 的结算币种。',
        },
        links: ['/guides/usdt-settlement', '/compare/usdt-vs-local-currency-settlement'],
    },
    {
        id: 'usdt-networks',
        category: 'settlement',
        en: {
            term: 'USDT networks (TRC-20, ERC-20)',
            aka: ['TRC-20', 'ERC-20', 'BEP-20', 'Blockchain network', 'Chain'],
            short: 'The blockchains on which USDT is issued; TRC-20 is USDT on Tron and ERC-20 is USDT on Ethereum, each with different fees and confirmation times.',
            body: 'Sender and receiver must use the same network, or funds can be lost. KaazPay supports USDT on Tron, Ethereum, BSC, Solana and Polygon; merchants confirm the network with their account manager before the first transfer.',
        },
        zh: {
            term: 'USDT 网络（TRC-20、ERC-20）',
            aka: ['TRC-20', 'ERC-20', 'BEP-20', '链', '区块链网络'],
            short: 'USDT 所发行的区块链；TRC-20 指 Tron 上的 USDT，ERC-20 指以太坊上的 USDT，各网络的手续费和确认时间不同。',
            body: '转出方和接收方必须使用同一网络，否则可能造成资金损失。KaazPay 支持 Tron、Ethereum、BSC、Solana 和 Polygon 网络的 USDT；首次转账前，请与客户经理确认所用网络。',
        },
        links: ['/compare/usdt-networks-compared', '/payment-methods/usdt'],
    },
    {
        id: 'wallet-address',
        category: 'settlement',
        en: {
            term: 'Wallet address',
            aka: ['Deposit address', 'Receiving address'],
            short: 'A string of characters that identifies where crypto assets such as USDT are sent on a specific blockchain network.',
            body: 'Addresses differ in format between networks, and a transfer sent to a wrong address or network usually cannot be reversed. Merchants should register their settlement address in advance and verify it carefully; KaazPay staff never ask for wallet private keys.',
        },
        zh: {
            term: '钱包地址',
            aka: ['收款地址', '充值地址'],
            short: '在特定区块链网络上标识 USDT 等加密资产接收位置的字符串。',
            body: '不同网络的地址格式不同，发送至错误地址或错误网络的转账通常无法撤回。商户应提前登记结算地址并仔细核对；KaazPay 工作人员绝不会索取钱包私钥。',
        },
        links: ['/compare/usdt-networks-compared', '/guides/usdt-settlement'],
    },
    {
        id: 'reconciliation',
        category: 'settlement',
        en: {
            term: 'Reconciliation',
            aka: ['Payment reconciliation', 'Account matching'],
            short: 'Matching a merchant’s own order records against the provider’s transaction, fee and settlement records to confirm every amount is accounted for.',
            body: 'Reconciliation catches missing callbacks, duplicate orders and fee differences. In KaazPay, orders, balances, settlements and payouts are available in the merchant portal, with fees itemised per transaction.',
        },
        zh: {
            term: '对账',
            aka: ['交易对账', '资金对账'],
            short: '将商户自身的订单记录与服务方的交易、费用和结算记录逐一核对，确认每笔金额准确无误。',
            body: '对账可以发现遗漏的回调、重复订单和费用差异。在 KaazPay 商户后台，可查看订单、余额、结算与代付记录，费用按笔列明。',
        },
        links: ['/developers', '/guides/payment-gateway-integration-checklist'],
    },

    // ── Risk & compliance ──────────────────────────────────────────────────────
    {
        id: 'chargeback',
        category: 'risk',
        en: {
            term: 'Chargeback',
            aka: ['Dispute', 'Card dispute'],
            short: 'A reversal of a card payment initiated by the cardholder’s bank after the cardholder disputes the transaction.',
            body: 'Chargebacks return funds to the cardholder and usually carry an extra fee for the merchant. Push payments such as bank transfers, instant payments and many QR and wallet payments are authorised by the payer and generally have no card-style chargeback process.',
        },
        zh: {
            term: '拒付',
            aka: ['退单', 'Chargeback', '争议交易'],
            short: '持卡人对交易提出争议后，由发卡行发起的银行卡交易撤销。',
            body: '拒付会将资金退回持卡人，商户通常还需承担额外费用。银行转账、实时支付以及多数扫码和钱包支付由付款人主动授权推送，一般没有信用卡式的拒付流程。',
        },
        links: ['/compare/chargebacks-vs-local-payments', '/guides/international-card-acquiring'],
    },
    {
        id: 'refund',
        category: 'risk',
        en: {
            term: 'Refund',
            aka: ['Reversal', 'Return'],
            short: 'Money returned to a customer by the merchant, either in full or in part, after a completed payment.',
            body: 'Unlike a chargeback, a refund is initiated by the merchant. With local push payments, refunds are often made as a separate transfer back to the customer, for example through a payout. How refunds work depends on the method and channel.',
        },
        zh: {
            term: '退款',
            aka: ['退还'],
            short: '支付完成后，商户将全部或部分款项退还给消费者。',
            body: '与拒付不同，退款由商户主动发起。对于本地推送式支付，退款通常以另一笔转账（例如代付）退回给消费者。具体方式取决于支付方式和通道。',
        },
        links: ['/compare/chargebacks-vs-local-payments'],
    },
    {
        id: '3-d-secure',
        category: 'risk',
        en: {
            term: '3-D Secure',
            aka: ['3DS', '3DS2', 'Visa Secure', 'Mastercard Identity Check'],
            short: 'An authentication protocol that asks the cardholder to confirm an online card payment with their issuing bank, for example by app approval or one-time code.',
            body: '3-D Secure reduces fraud on card-not-present payments and can shift liability for certain fraud chargebacks away from the merchant. Whether it applies depends on the card channel and the issuer’s rules.',
        },
        zh: {
            term: '3-D Secure',
            aka: ['3DS', '3DS2', '3D 验证'],
            short: '要求持卡人通过发卡行确认线上卡支付的身份验证协议，例如 App 确认或一次性验证码。',
            body: '3-D Secure 可减少无卡交易中的欺诈，并可在部分欺诈类拒付中将责任从商户转移。是否启用取决于卡通道和发卡行规则。',
        },
        links: ['/guides/international-card-acquiring', '/compare/chargebacks-vs-local-payments'],
    },
    {
        id: 'kyc',
        category: 'risk',
        en: {
            term: 'KYC (Know Your Customer)',
            aka: ['Identity verification', 'Customer due diligence'],
            short: 'Verifying the identity of a customer or business owner before providing financial services, using documents such as ID, proof of address and company records.',
            body: 'KYC is required by payment providers and their banking partners to prevent fraud and financial crime. When opening a KaazPay account, merchants provide business and ownership details for review.',
        },
        zh: {
            term: 'KYC（了解你的客户）',
            aka: ['身份验证', '客户尽职调查'],
            short: '在提供金融服务前，通过身份证件、地址证明、公司资料等核实客户或企业所有人身份。',
            body: '支付服务方及其银行合作方需执行 KYC，以防范欺诈和金融犯罪。开通 KaazPay 账户时，商户需提供业务与股东资料以供审核。',
        },
        links: ['/guides/merchant-onboarding-kyc-checklist'],
    },
    {
        id: 'kyb',
        category: 'risk',
        en: {
            term: 'KYB (Know Your Business)',
            aka: ['Merchant onboarding', 'Merchant due diligence', 'Underwriting'],
            short: 'Reviewing a business before opening a merchant account, covering its registration, owners, products, website and expected transaction volume.',
            body: 'KYB determines which channels a merchant can use and on what terms. For a first enquiry, KaazPay asks for the target region and product type, product URL and test account, time in operation, daily volume and complaint rate.',
        },
        zh: {
            term: 'KYB（了解你的企业）',
            aka: ['商户入网', '商户审核', '商户尽职调查'],
            short: '开通商户账户前对企业进行的审核，涵盖注册信息、股东、产品、网站与预计交易量。',
            body: 'KYB 结果决定商户可使用哪些通道及相应条件。首次咨询时，KaazPay 会请商户提供接入地区与产品类型、产品网址与测试账户、运营时间、日交易量与投诉率情况。',
        },
        links: ['/guides/merchant-onboarding-kyc-checklist', '/contact'],
    },
    {
        id: 'aml',
        category: 'risk',
        en: {
            term: 'AML (anti-money laundering)',
            aka: ['Anti-money laundering', 'Transaction monitoring', 'CFT'],
            short: 'Laws, controls and monitoring designed to detect and prevent money laundering and the financing of illegal activity.',
            body: 'AML controls include customer due diligence, transaction monitoring and sanctions screening. They apply to fiat and USDT flows alike, so a provider may ask for additional information on unusual transactions.',
        },
        zh: {
            term: 'AML（反洗钱）',
            aka: ['反洗钱', '交易监控', '反恐融资'],
            short: '用于发现和防范洗钱及非法资金活动的法规、控制措施和监控机制。',
            body: '反洗钱措施包括客户尽职调查、交易监控和制裁名单筛查，同样适用于法币和 USDT 资金流。因此，服务方可能会就异常交易要求补充资料。',
        },
        links: ['/guides/merchant-onboarding-kyc-checklist'],
    },
    {
        id: 'high-risk-merchant',
        category: 'risk',
        en: {
            term: 'High-risk merchant',
            aka: ['High-risk industry', 'High-risk vertical'],
            short: 'A business that payment providers classify as carrying higher chargeback, fraud or regulatory risk, such as gaming, live streaming, Web3 or forex.',
            body: 'High-risk merchants usually face stricter reviews and fewer provider options. KaazPay works with sectors that need tailored compliance reviews, including digital entertainment, Web3 and live streaming; available channels are confirmed after reviewing the business model.',
        },
        zh: {
            term: '高风险商户',
            aka: ['高风险行业', '高风险类目'],
            short: '被支付服务方认定为拒付、欺诈或监管风险较高的业务，如游戏、直播、Web3 或外汇。',
            body: '高风险商户通常面临更严格的审核，可选服务方也更少。KaazPay 服务数字娱乐、Web3、直播等需要定制合规审核的行业，在审核业务模式后确认可用通道。',
        },
        links: ['/industries', '/guides/igaming-payments', '/guides/forex-broker-payments'],
    },

    // ── Payment methods ────────────────────────────────────────────────────────
    {
        id: 'instant-payment',
        category: 'method',
        en: {
            term: 'Instant payment',
            aka: ['Real-time payment', 'RTP', 'Faster payment'],
            short: 'A bank-to-bank transfer that is processed and credited within seconds, at any time of day, through a national real-time payment system.',
            body: 'Examples include Pix in Brazil, DuitNow in Malaysia, PayNow in Singapore and SPEI in Mexico. Instant payments usually confirm faster than standard bank transfers and are irrevocable once completed.',
        },
        zh: {
            term: '实时支付',
            aka: ['即时支付', 'RTP', '快速支付'],
            short: '通过国家级实时支付系统，在数秒内完成处理并入账的银行间转账，全天候可用。',
            body: '例如巴西的 Pix、马来西亚的 DuitNow、新加坡的 PayNow 和墨西哥的 SPEI。实时支付通常比普通银行转账确认更快，完成后不可撤销。',
        },
        links: ['/compare/instant-payments-vs-bank-transfer', '/methods/pix', '/methods/duitnow'],
    },
    {
        id: 'bank-transfer',
        category: 'method',
        en: {
            term: 'Bank transfer',
            aka: ['Wire transfer', 'Online banking', 'iBanking'],
            short: 'Moving money directly between bank accounts, initiated by the payer through online banking, a banking app or a bank branch.',
            body: 'Bank transfer is available in most markets for both pay-in and payouts. In Thailand and Singapore, KaazPay payouts are made by bank transfer only.',
        },
        zh: {
            term: '银行转账',
            aka: ['网银转账', '电汇', 'iBanking'],
            short: '由付款人通过网上银行、银行 App 或银行柜台，在银行账户之间直接转移资金。',
            body: '银行转账在大多数市场同时适用于代收和代付。在泰国和新加坡，KaazPay 的代付仅支持银行转账。',
        },
        links: ['/compare/instant-payments-vs-bank-transfer', '/payment-methods/thailand', '/payment-methods/singapore'],
    },
    {
        id: 'e-wallet',
        category: 'method',
        en: {
            term: 'E-wallet',
            aka: ['Digital wallet', 'Mobile wallet'],
            short: 'An app that stores money or payment credentials so users can pay online or in store from their phone.',
            body: 'Some e-wallets hold a stored balance, such as GCash or Touch ’n Go, while others store card details, such as Apple Pay and Google Pay. KaazPay supports e-wallet pay-in in several markets.',
        },
        zh: {
            term: '电子钱包',
            aka: ['数字钱包', '手机钱包'],
            short: '存储资金或支付凭证的应用，用户可通过手机进行线上或线下支付。',
            body: '部分电子钱包存有余额，如 GCash 和 Touch ’n Go；部分则存储银行卡信息，如 Apple Pay 和 Google Pay。KaazPay 在多个市场支持电子钱包代收。',
        },
        links: ['/methods/gcash', '/methods/touch-n-go', '/methods/apple-pay', '/compare/apple-pay-vs-google-pay-vs-cash-app'],
    },
    {
        id: 'qr-payment',
        category: 'method',
        en: {
            term: 'QR payment',
            aka: ['QR code payment', 'Scan to pay'],
            short: 'A payment made by scanning a QR code with a banking or wallet app, which then confirms the transfer to the merchant.',
            body: 'Many countries operate a national QR standard that works across banks and wallets, such as QRIS in Indonesia, Thai QR Payment (PromptPay) in Thailand and SGQR in Singapore. QR payments suit both mobile and desktop checkouts.',
        },
        zh: {
            term: '扫码支付',
            aka: ['二维码支付', 'QR 支付'],
            short: '用户使用银行或钱包 App 扫描二维码并确认向商户转账的支付方式。',
            body: '许多国家设有跨银行、跨钱包通用的国家级二维码标准，如印度尼西亚的 QRIS、泰国的 Thai QR Payment（PromptPay）和新加坡的 SGQR。扫码支付同时适用于手机端和电脑端收银台。',
        },
        links: ['/methods/qris', '/methods/thai-qr', '/methods/singapore-qr'],
    },
    {
        id: 'fpx',
        category: 'method',
        en: {
            term: 'FPX',
            aka: ['Financial Process Exchange'],
            short: 'Malaysia’s online banking payment network, which lets customers pay from their bank account by logging in to their bank during checkout.',
            body: 'FPX is one of the most used online payment methods in Malaysia. KaazPay offers FPX pay-in in Malaysia alongside DuitNow and Touch ’n Go.',
        },
        zh: {
            term: 'FPX',
            aka: ['Financial Process Exchange'],
            short: '马来西亚的网上银行支付网络，消费者在付款时登录自己的银行，直接从银行账户付款。',
            body: 'FPX 是马来西亚最常用的线上支付方式之一。KaazPay 在马来西亚提供 FPX 代收，同时支持 DuitNow 与 Touch ’n Go。',
        },
        links: ['/methods/fpx', '/payment-methods/malaysia', '/compare/fpx-vs-duitnow-vs-touch-n-go'],
    },
    {
        id: 'duitnow',
        category: 'method',
        en: {
            term: 'DuitNow',
            aka: ['DuitNow QR', 'DuitNow Transfer'],
            short: 'Malaysia’s national real-time payment service, covering instant transfers by phone number or account and the DuitNow QR standard.',
            body: 'DuitNow works across participating Malaysian banks and e-wallets. KaazPay offers DuitNow pay-in in Malaysia.',
        },
        zh: {
            term: 'DuitNow',
            aka: ['DuitNow QR', 'DuitNow 转账'],
            short: '马来西亚的国家级实时支付服务，包括按手机号或账号的即时转账以及 DuitNow 二维码标准。',
            body: 'DuitNow 可在马来西亚各参与银行和电子钱包之间通用。KaazPay 在马来西亚提供 DuitNow 代收。',
        },
        links: ['/methods/duitnow', '/payment-methods/malaysia', '/compare/fpx-vs-duitnow-vs-touch-n-go'],
    },
    {
        id: 'promptpay',
        category: 'method',
        en: {
            term: 'PromptPay / Thai QR',
            aka: ['Thai QR Payment', 'PromptPay QR'],
            short: 'Thailand’s national real-time payment service and its standard QR code, accepted by Thai banking apps.',
            body: 'Customers scan the QR code in their banking app and confirm the transfer. In Thailand, KaazPay offers pay-in by Thai QR Payment and bank transfer; payouts are by bank transfer only.',
        },
        zh: {
            term: 'PromptPay / 泰国 QR',
            aka: ['Thai QR Payment', '泰国二维码支付'],
            short: '泰国的国家级实时支付服务及其标准二维码，泰国各银行 App 均可扫码付款。',
            body: '消费者在银行 App 中扫码并确认转账。在泰国，KaazPay 提供 Thai QR Payment 和银行转账代收；代付仅支持银行转账。',
        },
        links: ['/methods/thai-qr', '/payment-methods/thailand', '/guides/thailand-payment-methods'],
    },
    {
        id: 'paynow',
        category: 'method',
        en: {
            term: 'PayNow',
            aka: ['PayNow QR'],
            short: 'Singapore’s real-time transfer service that lets customers pay using a mobile number, company registration number or PayNow QR code.',
            body: 'PayNow is supported by participating Singapore banks and some wallets. In Singapore, KaazPay offers pay-in by iBanking, PayNow and SGQR; payouts are by bank transfer only.',
        },
        zh: {
            term: 'PayNow',
            aka: ['PayNow QR'],
            short: '新加坡的实时转账服务，消费者可通过手机号、企业注册号或 PayNow 二维码付款。',
            body: '新加坡各参与银行和部分钱包支持 PayNow。在新加坡，KaazPay 提供 iBanking、PayNow 和 SGQR 代收；代付仅支持银行转账。',
        },
        links: ['/methods/paynow', '/payment-methods/singapore', '/guides/singapore-payment-methods'],
    },
    {
        id: 'sgqr',
        category: 'method',
        en: {
            term: 'SGQR',
            aka: ['Singapore Quick Response Code', 'Singapore QR Payment'],
            short: 'Singapore’s unified QR code standard, which combines multiple payment schemes into a single code.',
            body: 'One SGQR code can be scanned by apps from different banks and wallets. KaazPay offers Singapore QR Payment as a pay-in method in Singapore.',
        },
        zh: {
            term: 'SGQR',
            aka: ['新加坡统一二维码', '新加坡 QR 扫码支付'],
            short: '新加坡统一的二维码标准，将多种支付方案整合在一个二维码中。',
            body: '同一个 SGQR 二维码可被不同银行和钱包的 App 扫描。KaazPay 在新加坡提供新加坡 QR 扫码支付代收。',
        },
        links: ['/methods/singapore-qr', '/payment-methods/singapore'],
    },
    {
        id: 'qris',
        category: 'method',
        en: {
            term: 'QRIS',
            aka: ['Quick Response Code Indonesian Standard'],
            short: 'Indonesia’s national QR code standard, which lets one QR code be paid from any participating bank or e-wallet app.',
            body: 'QRIS is set by Bank Indonesia and is widely used for both online and in-store payments. KaazPay offers QRIS pay-in in Indonesia.',
        },
        zh: {
            term: 'QRIS',
            aka: ['印度尼西亚标准二维码'],
            short: '印度尼西亚的国家二维码标准，同一个二维码可被任何参与的银行或电子钱包 App 扫码付款。',
            body: 'QRIS 由印度尼西亚央行制定，广泛用于线上和线下支付。KaazPay 在印度尼西亚提供 QRIS 代收。',
        },
        links: ['/methods/qris', '/payment-methods/indonesia', '/guides/indonesia-qris'],
    },
    {
        id: 'gcash',
        category: 'method',
        en: {
            term: 'GCash',
            aka: [],
            short: 'A widely used mobile wallet in the Philippines, used for transfers, bill payments and online purchases.',
            body: 'Customers pay from their GCash balance in the app. KaazPay offers GCash pay-in in the Philippines.',
        },
        zh: {
            term: 'GCash',
            aka: [],
            short: '菲律宾广泛使用的手机钱包，可用于转账、缴费和线上购物。',
            body: '消费者在 App 中使用 GCash 余额付款。KaazPay 在菲律宾提供 GCash 代收。',
        },
        links: ['/methods/gcash', '/payment-methods/philippines', '/guides/philippines-gcash'],
    },
    {
        id: 'pix',
        category: 'method',
        en: {
            term: 'Pix',
            aka: [],
            short: 'Brazil’s instant payment system, operated by the Central Bank of Brazil, that settles transfers within seconds at any time.',
            body: 'Customers pay by scanning a Pix QR code or using a Pix key in their banking app. KaazPay offers Pix pay-in in Brazil, along with bank transfer, cash payment and Boleto.',
        },
        zh: {
            term: 'Pix',
            aka: [],
            short: '由巴西央行运营的实时支付系统，全天候在数秒内完成转账。',
            body: '消费者在银行 App 中扫描 Pix 二维码或使用 Pix 密钥付款。KaazPay 在巴西提供 Pix 代收，同时支持银行转账、现金支付和 Boleto。',
        },
        links: ['/methods/pix', '/payment-methods/brazil', '/compare/pix-vs-boleto'],
    },
    {
        id: 'spei',
        category: 'method',
        en: {
            term: 'SPEI',
            aka: ['Sistema de Pagos Electrónicos Interbancarios'],
            short: 'Mexico’s real-time interbank transfer system, operated by Banco de México, that uses an 18-digit CLABE account number.',
            body: 'Customers pay by transferring to a CLABE reference from their banking app. KaazPay offers SPEI pay-in in Mexico, with payouts by bank transfer.',
        },
        zh: {
            term: 'SPEI',
            aka: ['墨西哥银行间电子支付系统'],
            short: '由墨西哥央行运营的实时银行间转账系统，使用 18 位 CLABE 账号。',
            body: '消费者通过银行 App 向 CLABE 账号转账付款。KaazPay 在墨西哥提供 SPEI 代收，代付通过银行转账完成。',
        },
        links: ['/methods/spei', '/payment-methods/mexico', '/guides/mexico-payment-methods'],
    },
    {
        id: 'mobile-money',
        category: 'method',
        en: {
            term: 'Mobile money',
            aka: ['M-Pesa', 'Mobile wallet'],
            short: 'A phone-number-based wallet service, usually run by a mobile network operator, used widely across Africa for payments and transfers.',
            body: 'M-Pesa in Kenya is the best-known example; other services operate across East, West and Central Africa. KaazPay offers mobile money pay-in in many African markets and mobile money payouts where available.',
        },
        zh: {
            term: '移动钱包（Mobile Money）',
            aka: ['M-Pesa', '手机钱包'],
            short: '以手机号为账户的钱包服务，通常由电信运营商提供，在非洲广泛用于支付和转账。',
            body: '肯尼亚的 M-Pesa 是最知名的例子，东非、西非和中非也有多种同类服务。KaazPay 在多个非洲市场提供移动钱包代收，并在已开通的市场支持移动钱包代付。',
        },
        links: ['/methods/m-pesa', '/methods/mobile-money', '/guides/africa-mobile-money', '/compare/mobile-money-vs-bank-transfer-africa'],
    },
];
