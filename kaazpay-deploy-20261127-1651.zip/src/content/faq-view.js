/** FAQ helpers shared by the page, the SEO layer and the prerender. Answers may use {{markets}} / {{payout}}. */
import { FAQ_GROUPS } from './faq';
import { COVERAGE_STATS } from '../data/channels';

export { FAQ_GROUPS };
const fill = (s) => String(s).replace(/\{\{\s*markets\s*\}\}/g, COVERAGE_STATS.markets).replace(/\{\{\s*payout\s*\}\}/g, COVERAGE_STATS.payoutMarkets);
export const faqText = (item, lang) => ({ q: fill(item[lang].q), a: fill(item[lang].a) });
export const FAQ_ALL = (lang) => FAQ_GROUPS.flatMap((g) => g.items.map((it) => ({ ...faqText(it, lang), id: it.id, group: g[lang].title })));
