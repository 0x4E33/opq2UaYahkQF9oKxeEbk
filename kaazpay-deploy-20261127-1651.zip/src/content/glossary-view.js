/** Glossary helpers shared by the page, the SEO layer and the prerender (llms.txt). */
import { GLOSSARY } from './glossary';
import { getArticle, articleLang } from './index';
import { getMethod, methodName } from '../data/methods';
import { getMarket, marketName } from '../data/channels';

export { GLOSSARY };
export const GLOSSARY_CATEGORIES = ['concept', 'method', 'settlement', 'risk'].filter((c) => GLOSSARY.some((g) => g.category === c));

const PAGE_LABELS = {
    '/faq': { en: 'FAQ', zh: '常见问题' },
    '/glossary': { en: 'Glossary', zh: '支付术语表' },
    '/methods': { en: 'Payment methods', zh: '支付方式' },
    '/capabilities': { en: 'Platform capabilities', zh: '产品能力' },
    '/developers': { en: 'Developers', zh: '开发者' },
    '/contact': { en: 'Contact us', zh: '联系我们' },
    '/about': { en: 'About KaazPay', zh: '关于 KaazPay' },
    '/industries': { en: 'Industry solutions', zh: '行业方案' },
    '/guides': { en: 'Payment guides', zh: '支付指南' },
    '/compare': { en: 'Comparisons', zh: '方案对比' },
};

/** Human label for an internal link (method / market / article name, else the page name). */
export const glossaryLinkLabel = (href, lang) => {
    const [path, hash] = href.split('#');
    let m;
    if ((m = path.match(/^\/methods\/([^/]+)$/)) && getMethod(m[1])) return methodName(getMethod(m[1]), lang);
    if ((m = path.match(/^\/payment-methods\/([^/]+)$/)) && getMarket(m[1])) return marketName(getMarket(m[1]), lang);
    if ((m = path.match(/^\/(guides|compare)\/([^/]+)$/))) {
        const a = getArticle(m[1] === 'guides' ? 'guide' : 'compare', m[2]);
        if (a) return articleLang(a, lang).h1 || articleLang(a, lang).title;
    }
    if (path === '/glossary' && hash) {
        const g = GLOSSARY.find((x) => x.id === hash);
        if (g) return g[lang].term;
    }
    return PAGE_LABELS[path]?.[lang] || path;
};
