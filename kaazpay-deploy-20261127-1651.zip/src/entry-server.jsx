/* global Buffer */
// Build-time prerender entry (see scripts/prerender.mjs). Not shipped to the browser.
import { StaticRouter } from 'react-router-dom';
import { prerenderToNodeStream } from 'react-dom/static';
import i18n from './i18n';
import { AppShell } from './App.jsx';

export { getSeo, headTags, PRERENDER_ROUTES, BASE_ROUTES, ROUTE_DATES, marketCopy, methodCopy, industryCopy } from './seo';
export { ARTICLES, articlePath, plain } from './content';
import { ARTICLE_BODIES } from './content/bodies';
import { setArticleBodies } from './seo';
setArticleBodies(ARTICLE_BODIES);
export { ARTICLE_BODIES };
export { METHODS, methodMarkets, methodName } from './data/methods';
export { INDUSTRIES } from './data/industries';
export { MILESTONES } from './data/milestones';
export { articleCover } from './content/covers';
export { localizePath, langFromPath, stripLocale, LANGS } from './lib/locale';
import { langFromPath } from './lib/locale';
export { MARKETS, REGIONS, COVERAGE_STATS, SITE_URL, hasPayout, getMarket } from './data/channels';
export { marketPhoto } from './data/media';
export { industryPhoto } from './data/industries';
export { getMethod } from './data/methods';
export { GLOSSARY } from './content/glossary-view';
export { FAQ_ALL } from './content/faq-view';

const streamToString = async (stream) => {
    const chunks = [];
    for await (const chunk of stream) chunks.push(typeof chunk === 'string' ? Buffer.from(chunk) : chunk);
    return Buffer.concat(chunks).toString('utf8');
};

export async function render(url) {
    await i18n.changeLanguage(langFromPath(url));
    const app = () => (
        <StaticRouter location={url}>
            <AppShell />
        </StaticRouter>
    );
    // Static HTML must carry each page's content in place. Pass 1 resolves the lazy page / article
    // chunks; pass 2 renders them inline. progressiveChunkSize: Infinity stops React from "outlining"
    // large Suspense boundaries (spinner in place, real content in a hidden <div> after the footer,
    // moved by a script) — which crawlers that don't run JavaScript (most AI crawlers) can't follow.
    const opts = { progressiveChunkSize: Infinity };
    await streamToString((await prerenderToNodeStream(app(), opts)).prelude);
    const { prelude } = await prerenderToNodeStream(app(), opts);
    return streamToString(prelude);
}
