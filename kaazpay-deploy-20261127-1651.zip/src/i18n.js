import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import en from './locales/en.json';
import zh from './locales/zh.json';

// The URL decides the language (/zh/... = Chinese); main.jsx / the router set it. No browser detection or caching
// here: a visitor's saved choice lives in localStorage 'kp_lang' and is only written by the language switcher.
i18n
  .use(initReactI18next)
  .init({
    resources: { en: { translation: en }, zh: { translation: zh } },
    lng: 'en',
    fallbackLng: 'en',
    interpolation: { escapeValue: false },
  });

export default i18n;
