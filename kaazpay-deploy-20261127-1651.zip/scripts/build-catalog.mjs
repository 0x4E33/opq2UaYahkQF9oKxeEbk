/**
 * Writes src/content/catalog.json: the light metadata of every article (titles, dates, related
 * pages, reading time). The browser bundle only ships this catalog; each article's full body is
 * loaded on its own page (and fully prerendered into HTML for search engines).
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dir = path.join(root, 'src/content/articles');
const files = (await fs.readdir(dir)).filter((f) => f.endsWith('.js')).sort();

const text = (c) => [c.summary, ...(c.takeaways || []), ...c.sections.flatMap((s) => [s.heading, ...s.blocks.map((b) => (typeof b === 'string' ? b : JSON.stringify(b)))]), ...c.faq.flatMap((f) => [f.q, f.a])].join(' ');
const minutes = (c, zh) => Math.max(2, Math.round(zh ? text(c).replace(/\s/g, '').length / 400 : text(c).split(/\s+/).length / 220));

const catalog = [];
for (const f of files) {
    const a = (await import(`${pathToFileURL(path.join(dir, f)).href}?t=${Date.now()}`)).default;
    if (!a?.slug || !a.en || !a.zh) { console.warn(`! skipped ${f}: missing slug/en/zh`); continue; }
    if (`${a.slug}.js` !== f) throw new Error(`${f}: slug "${a.slug}" must match the file name`);
    const pick = (c) => ({ title: c.title, description: c.description, h1: c.h1 });
    catalog.push({
        slug: a.slug, kind: a.kind, published: a.published, updated: a.updated || a.published, related: a.related || {},
        minutes: { en: minutes(a.en, false), zh: minutes(a.zh, true) },
        en: pick(a.en), zh: pick(a.zh),
    });
}
await fs.writeFile(path.join(root, 'src/content/catalog.json'), `${JSON.stringify(catalog, null, 2)}\n`);
console.log(`✓ content catalog: ${catalog.length} articles`);
