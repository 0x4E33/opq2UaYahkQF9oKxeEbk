/**
 * Responsive image variants (run before every build; only (re)creates a variant when its source is newer).
 * Cards and phone headers then download a right-sized copy instead of the full-width original:
 *   articles/*.webp   (1600w) -> articles/sm/*.webp   (800w)   article cards
 *   industries/*.webp (1600w) -> industries/sm/*.webp (800w)   industry cards / tiles
 *   markets/*.webp    (2400w) -> markets/sm/*.webp    (1200w)  market headers on phones
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const JOBS = [['src/assets/articles', 800], ['src/assets/industries', 800], ['src/assets/markets', 1200]];
let made = 0;
for (const [dir, width] of JOBS) {
    const abs = path.join(root, dir);
    await fs.mkdir(path.join(abs, 'sm'), { recursive: true });
    for (const f of await fs.readdir(abs)) {
        if (!f.endsWith('.webp')) continue;
        const src = path.join(abs, f);
        const out = path.join(abs, 'sm', f);
        const [s, o] = await Promise.all([fs.stat(src), fs.stat(out).catch(() => null)]);
        if (o && o.mtimeMs >= s.mtimeMs) continue;
        await sharp(src).resize({ width, withoutEnlargement: true }).webp({ quality: 74 }).toFile(out);
        made++;
    }
}
console.log(`✓ responsive variants up to date (${made} generated)`);
