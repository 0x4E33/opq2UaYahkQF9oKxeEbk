#!/usr/bin/env bash
# Tell Bing / Yandex / Seznam / Naver (IndexNow) which pages changed, so they are recrawled within hours
# instead of weeks. Bing's index also feeds ChatGPT search and Microsoft Copilot. Google does not use IndexNow
# (it reads sitemap.xml on its own schedule).
#
# Usage: scripts/indexnow.sh <site_dir>
#   Submits the URLs in <site_dir>/indexnow-urls.txt (pages whose content changed in this build, written by
#   scripts/prerender.mjs). Nothing changed → nothing is sent. Never fails the deploy.
SITE_DIR="${1:-dist}"
HOST="kaazpay.info"
KEY="b7e06e25c774498f410bbb947dfc4c51"   # must match public/$KEY.txt (served at https://kaazpay.info/$KEY.txt)
LIST="$SITE_DIR/indexnow-urls.txt"
[ -f "$LIST" ] || { echo "IndexNow: $LIST not found, skipped"; exit 0; }
COUNT=$(grep -c '^https://' "$LIST" || true)
[ "${COUNT:-0}" -gt 0 ] || { echo "IndexNow: no page content changed, nothing to submit"; exit 0; }
URLS=$(grep '^https://' "$LIST" | head -10000 | sed 's/.*/"&"/' | paste -sd, -)
BODY="{\"host\":\"$HOST\",\"key\":\"$KEY\",\"keyLocation\":\"https://$HOST/$KEY.txt\",\"urlList\":[$URLS]}"
CODE=$(curl -s -o /dev/null -w '%{http_code}' -m 20 -X POST 'https://api.indexnow.org/indexnow' -H 'Content-Type: application/json; charset=utf-8' --data "$BODY" || echo 000)
echo "IndexNow: submitted $COUNT changed URL(s), HTTP $CODE (200/202 = accepted)"
exit 0
