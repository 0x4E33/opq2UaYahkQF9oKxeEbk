#!/bin/bash

# ==========================================
# KaazPay 官网 一键部署脚本
# 适用于全新 Ubuntu 云服务器（以 root 身份运行，无需 sudo）
#
# 用法：
#   1. 本地执行 ./pack.sh 生成干净的上传包（自动排除 node_modules / dist / .backup / 竞品代码目录等）
#   2. 上传到服务器后 unzip 解压（更新时解压覆盖到同一目录即可）
#   3. chmod +x deploy.sh
#   4. ./deploy.sh
#   更新网站时重复以上步骤即可（脚本可重复执行，更新过程中网站不下线）
#
# 可选环境变量：
#   HTTP_PORT=8080 ./deploy.sh   网站容器改用其它端口（80 已被现有网站占用、想由现有 Nginx/面板反向代理时）
#   FREE_PORT=1 ./deploy.sh      80 端口被本机的 nginx / apache2 / caddy 等服务占用时，自动停止并禁用该服务
#   INDEXNOW=0 ./deploy.sh       跳过通知搜索引擎
#   CF_ZONE_ID / CF_API_TOKEN    部署成功后自动清除 Cloudflare 缓存（Cloudflare 缓存页面 HTML 时需要）；
#                                写在服务器项目目录的 .cf.env 里即可（不会被打包、不会被上传包覆盖）：
#                                  CF_ZONE_ID=xxxxxxxx
#                                  CF_API_TOKEN=xxxxxxxx   （只需 Zone → Cache Purge 权限）
#
# 脚本会自动完成：
#   - 系统依赖 (curl/unzip/git 等) + 字体（构建时生成分享图用）
#   - Node.js / npm 安装
#   - 项目依赖安装 + 构建 (npm ci && npm run build)：预渲染全部中英文页面、生成小尺寸图片、每页分享图、sitemap、llms.txt
#   - Docker / Docker Compose 安装
#   - Nginx 容器化部署 (静态资源 + Gzip + SPA 路由)
#   - 零停机发布：构建成功后才把新版本同步到线上目录 site/，构建失败时旧版本继续在线
#   - 低内存 VPS 自动开启 swap，防止构建被 OOM Kill
#   - 防火墙放行 80/443（若 ufw 已启用）
# ==========================================

set -Eeuo pipefail
# 任何步骤意外失败时都明确提示失败位置，而不是无声退出
trap 'echo -e "\033[0;31m✗ 部署在 deploy.sh 第 ${LINENO} 行意外中止（命令：${BASH_COMMAND}），请根据上面的输出排查后重新执行。\033[0m" >&2' ERR

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}>>> $1${NC}"; }
warn() { echo -e "${YELLOW}!!! $1${NC}"; }
err()  { echo -e "${RED}✗ $1${NC}"; }

# 脚本所在目录 = 项目根目录（不管解压到哪个路径都能正确工作）
PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

HTTP_PORT="${HTTP_PORT:-80}"
if ! [[ "$HTTP_PORT" =~ ^[0-9]+$ ]] || [ "$HTTP_PORT" -lt 1 ] || [ "$HTTP_PORT" -gt 65535 ]; then
    echo "HTTP_PORT 必须是 1-65535 的数字（当前：$HTTP_PORT）"; exit 1
fi

# ---------- 0. 权限检查 ----------
if [ "$(id -u)" -ne 0 ]; then
    err "请以 root 用户运行本脚本（当前脚本假设无需 sudo，即你已经是 root）。"
    exit 1
fi

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} KaazPay 部署开始，项目目录: $PROJECT_DIR ${NC}"
echo -e "${GREEN}=============================================${NC}"

# ---------- 1. 基础系统依赖 ----------
log "1. 更新软件源并安装基础依赖 (curl/unzip/ca-certificates/gnupg/字体)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
# fontconfig + DejaVu：构建时用 sharp 生成每页分享图（og/*.jpg），图上的 KaazPay 字样需要系统字体
apt-get install -y curl unzip ca-certificates gnupg git rsync fontconfig fonts-dejavu-core

# ---------- 2. 低内存服务器自动开启 swap ----------
log "2. 检查内存与 swap（防止构建时被 OOM 杀死）..."
MEM_TOTAL_MB=$(free -m | awk '/^Mem:/{print $2}')
SWAP_TOTAL_MB=$(free -m | awk '/^Swap:/{print $2}')
if [ "$SWAP_TOTAL_MB" -eq 0 ] && [ "$MEM_TOTAL_MB" -lt 4096 ]; then
    if [ ! -f /swapfile ]; then
        warn "检测到内存较小 (${MEM_TOTAL_MB}MB) 且无 swap，正在创建 2G swap 文件..."
        fallocate -l 2G /swapfile || dd if=/dev/zero of=/swapfile bs=1M count=2048
        chmod 600 /swapfile
        mkswap /swapfile
        swapon /swapfile
        grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
        log "swap 创建完成。"
    else
        swapon /swapfile 2>/dev/null || true
    fi
else
    echo "内存/swap 充足，跳过。"
fi

# ---------- 3. 安装 Node.js / npm ----------
log "3. 检查并安装 Node.js (LTS 22.x，Vite 7 需要 Node >= 20.19)..."
NEED_NODE_INSTALL=1
if command -v node &> /dev/null; then
    NODE_MAJOR=$(node -v | sed -E 's/^v([0-9]+)\..*/\1/')
    NODE_MINOR=$(node -v | sed -E 's/^v[0-9]+\.([0-9]+).*/\1/')
    if [ "$NODE_MAJOR" -ge 22 ] || { [ "$NODE_MAJOR" -eq 20 ] && [ "$NODE_MINOR" -ge 19 ]; }; then
        NEED_NODE_INSTALL=0
        echo "已安装 Node.js $(node -v)，跳过安装。"
    else
        warn "当前 Node.js $(node -v) 版本过低，将升级到 22.x"
    fi
fi
if [ "$NEED_NODE_INSTALL" -eq 1 ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
    apt-get install -y nodejs
fi
echo "Node: $(node -v)  npm: $(npm -v)"

# ---------- 4. 安装依赖并构建前端 ----------
log "4. 安装项目依赖并执行生产构建 (npm ci && npm run build)..."
if [ -f package-lock.json ]; then
    npm ci --no-audit --no-fund || npm install --no-audit --no-fund
else
    npm install --no-audit --no-fund
fi
# 只清理构建目录；线上服务读取的是 site/，构建期间网站照常在线
rm -rf "$PROJECT_DIR/dist" "$PROJECT_DIR/dist-ssr"
if ! npm run build; then
    err "构建失败，线上网站保持旧版本不变。请检查上面的构建日志。"
    exit 1
fi

if [ ! -f "$PROJECT_DIR/dist/index.html" ] || [ ! -d "$PROJECT_DIR/dist/assets" ]; then
    err "构建产物不完整（缺少 dist/index.html 或 dist/assets），线上网站保持旧版本不变。"
    exit 1
fi
log "构建成功，产物位于 $PROJECT_DIR/dist"

# ---------- 5. 安装 Docker ----------
log "5. 环境检查与 Docker 安装..."
if ! command -v docker &> /dev/null; then
    echo "Docker 未安装，正在自动安装..."
    curl -fsSL https://get.docker.com | bash -s docker
    systemctl enable docker
    systemctl start docker
else
    echo "Docker 已安装，跳过安装步骤。"
fi

# ---------- 6. 生成 Nginx 配置 ----------
log "6. 生成 Nginx 高性能配置..."
mkdir -p "$PROJECT_DIR/conf"

# 安全响应头单独成文件，每个 location 都 include：
# Nginx 的子级 location 只要自己写了 add_header，就不再继承上级的 add_header，容易漏掉
cat > "$PROJECT_DIR/conf/security-headers.conf" <<'NGINX'
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header X-Frame-Options "SAMEORIGIN" always;
add_header Permissions-Policy "camera=(), microphone=(), geolocation=(), payment=()" always;
# 全站只走 HTTPS（浏览器记住一年）；未加 includeSubDomains，避免影响尚未配置 HTTPS 的子域名
add_header Strict-Transport-Security "max-age=31536000" always;
# 只放不会影响页面运行的限制：禁止被其他网站嵌入（防点击劫持）、禁止 <base> 注入、禁用插件、表单只能提交到本站
add_header Content-Security-Policy "frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'; upgrade-insecure-requests" always;
add_header Cross-Origin-Opener-Policy "same-origin" always;
NGINX

cat > "$PROJECT_DIR/conf/default.conf" <<'NGINX'
server {
    listen 80;
    server_name _;

    root /usr/share/nginx/html;
    index index.html;
    charset utf-8;
    charset_types text/plain text/css text/xml application/javascript application/json application/xml;

    # 安全设置：隐藏 Nginx 版本号 + 基础安全响应头
    server_tokens off;

    # 301 用相对地址：源站只跑 http，前面是 Cloudflare 的 https；
    # 绝对地址会先跳到 http:// 再被 Cloudflare 跳回 https://，多绕一圈
    absolute_redirect off;

    # 统一主域名：www.kaazpay.info → https://kaazpay.info（与页面 canonical 一致，避免两套网址分走权重）
    if ($host = www.kaazpay.info) {
        return 301 https://kaazpay.info$request_uri;
    }

    # 统一网址结尾：/guides/ → /guides（首页 / 除外），同一页面只保留一个网址
    rewrite ^/(.+)/$ /$1 permanent;
    include /etc/nginx/snippets/security-headers.conf;

    # 性能优化：开启 Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_min_length 256;
    gzip_types
        text/plain
        text/css
        text/javascript
        application/javascript
        application/json
        application/xml
        image/svg+xml
        font/woff2;

    # 使用构建时预压缩的 .gz 文件（vite-plugin-compression 生成）
    gzip_static on;

    # 旧的"全球覆盖"页已并入首页通道板块，301 保留 SEO 权重
    # /payment-methods 本身没有页面（各国页在 /payment-methods/xxx），301 到首页通道板块；中文版同理
    location ~ ^/payment-methods/?$ { return 301 /#coverage; }
    location ~ ^/zh/payment-methods/?$ { return 301 /zh#coverage; }

    # 旧站遗留的法律条款页已删除：返回 410 Gone，让 Google 尽快从索引移除，
    # 不再 301 到首页（跳到无关页面会被当成重复内容 / soft 404）
    location ~ ^/(terms|privacy|cookies)/?$ { return 410; }

    # 构建 / IndexNow 用的内部文件留在 site/ 里给脚本读，但不对外公开
    location ~ ^/(lastmod\.json|indexnow-urls\.txt)$ { return 404; }

    # 所有页面（英文 /xxx 与中文 /zh/xxx）都已预渲染为各自的 index.html。
    # 不存在的网址返回真正的 404（/404.html），避免搜索引擎把错误网址当成首页的重复内容（soft 404）
    # 页面 HTML 不做长缓存，保证发布后立即生效
    error_page 404 /404.html;
    location / {
        try_files $uri $uri/index.html =404;
        add_header Cache-Control "no-cache";
        include /etc/nginx/snippets/security-headers.conf;
    }

    # 构建产物带哈希（含 three.js 地球分包、背景视频及其手机版 -sm、页面图片及其小尺寸版本），可长期缓存；视频支持拖动播放（Range）
    location ^~ /assets/ {
        expires 1y;
        add_header Cache-Control "public, no-transform, immutable";
        include /etc/nginx/snippets/security-headers.conf;
        access_log off;
    }

    # 其它静态文件（logo、robots、sitemap、每页分享图 /og/*.jpg、llms.txt 等）短缓存
    location ~* \.(png|jpg|jpeg|gif|ico|svg|webp|avif|woff2|ttf|txt|xml|mp4|webm)$ {
        expires 1d;
        add_header Cache-Control "public";
        include /etc/nginx/snippets/security-headers.conf;
        access_log off;
    }

    # 健康检查端点 (可选，给云监控用)
    location /health {
        access_log off;
        default_type text/plain;
        return 200 'healthy';
    }
}
NGINX

# ---------- 7. 生成 Docker Compose 配置 ----------
log "7. 生成 Docker Compose 配置..."
# 线上目录是 site/（不是 dist/）：构建期间与构建失败时都不影响正在运行的网站
cat > "$PROJECT_DIR/docker-compose.yml" <<YAML
services:
  web:
    image: nginx:alpine
    container_name: kaazpay_web
    restart: always
    ports:
      - "${HTTP_PORT}:80"
    volumes:
      - ./site:/usr/share/nginx/html:ro
      - ./conf/default.conf:/etc/nginx/conf.d/default.conf:ro
      - ./conf/security-headers.conf:/etc/nginx/snippets/security-headers.conf:ro
    environment:
      - TZ=Asia/Shanghai
YAML

# ---------- 8. 发布新版本（零停机） ----------
log "8. 发布新版本到线上目录 site/ ..."
SITE_DIR="$PROJECT_DIR/site"
mkdir -p "$SITE_DIR/assets"
# 顺序很重要：
#   ① 先放新的带哈希资源（不删旧的）→ 此刻线上旧页面仍完整可用
#   ② 再替换页面 HTML / sitemap 等（--delete 不碰 assets/）→ 访客刷新即拿到新版
#   ③ 旧哈希资源保留 7 天再清理，避免正在浏览旧页面的访客懒加载分包时 404
rsync -a "$PROJECT_DIR/dist/assets/" "$SITE_DIR/assets/"
rsync -a --delete --exclude '/assets/' "$PROJECT_DIR/dist/" "$SITE_DIR/"
find "$SITE_DIR/assets" -type f -mtime +7 -print0 | while IFS= read -r -d '' f; do
    [ -e "$PROJECT_DIR/dist/assets/$(basename "$f")" ] || rm -f "$f"
done

# ---------- 端口检查：容器启动前确认 HTTP_PORT 没被其它程序占用 ----------
# 本脚本自己的容器 kaazpay_web 正在使用该端口属于正常（更新部署）
# 端口空闲时 grep 找不到任何结果会返回非 0；结尾的 || true 防止脚本在 set -e 下无声退出
port_owner() { ss -H -ltnp "sport = :$HTTP_PORT" 2>/dev/null | grep -o 'users:(("[^"]*"' | head -1 | sed 's/users:(("//; s/"$//' || true; }
OUR_PORT=$(docker port kaazpay_web 80/tcp 2>/dev/null | head -1 | sed 's/.*://' || true)
OWNER=$(port_owner)
if [ -n "$OWNER" ] && [ "$OUR_PORT" != "$HTTP_PORT" ]; then
    warn "端口 $HTTP_PORT 已被占用，占用程序：$OWNER"
    if [ "$OWNER" = "docker-proxy" ]; then
        echo "占用者是另一个 Docker 容器："
        docker ps --format '  {{.Names}}  ({{.Image}})  {{.Ports}}' | grep -E ":$HTTP_PORT->" || true
        err "请先停止该容器（docker stop <容器名>），或改用其它端口：HTTP_PORT=8080 ./deploy.sh"
        echo "新版网站文件已发布到 $SITE_DIR，只是容器未能启动；处理端口后重新执行 ./deploy.sh 即可。"
        exit 1
    fi
    SERVICE=""
    case "$OWNER" in
        nginx) SERVICE=nginx ;;
        apache2|httpd) SERVICE=apache2 ;;
        caddy) SERVICE=caddy ;;
        lighttpd) SERVICE=lighttpd ;;
    esac
    if [ -n "$SERVICE" ] && [ "${FREE_PORT:-0}" = "1" ]; then
        warn "FREE_PORT=1：停止并禁用本机服务 $SERVICE，让出端口 $HTTP_PORT ..."
        systemctl stop "$SERVICE" || true
        systemctl disable "$SERVICE" >/dev/null 2>&1 || true
        sleep 1
        if [ -n "$(port_owner)" ]; then
            err "停止 $SERVICE 后端口 $HTTP_PORT 仍被占用（$(port_owner)），请手动检查：ss -ltnp 'sport = :$HTTP_PORT'"
            exit 1
        fi
        log "端口 $HTTP_PORT 已释放。"
    else
        err "端口 $HTTP_PORT 被 $OWNER 占用，KaazPay 网站容器无法启动。可选处理方式："
        if [ -n "$SERVICE" ]; then
            echo "  ① 这台服务器只放 KaazPay 官网：执行  FREE_PORT=1 ./deploy.sh  自动停止并禁用 $SERVICE"
            echo "     （或手动：systemctl stop $SERVICE && systemctl disable $SERVICE，再重新执行 ./deploy.sh）"
        else
            echo "  ① 停止占用端口的程序后重新执行 ./deploy.sh（查看详情：ss -ltnp 'sport = :$HTTP_PORT'）"
        fi
        echo "  ② 服务器上还有其它网站要保留：执行  HTTP_PORT=8080 ./deploy.sh，"
        echo "     再在现有的 Nginx / 面板里把 kaazpay.info 反向代理到 http://127.0.0.1:8080"
        echo "新版网站文件已发布到 $SITE_DIR，只是容器未能启动；处理后重新执行 ./deploy.sh 即可。"
        exit 1
    fi
fi

log "启动/更新 Nginx 容器（端口 $HTTP_PORT）..."
# 同名容器若不是由本目录的 Compose 管理（旧版本从其它目录部署过），先移除再重建
EXISTING_DIR=$(docker inspect -f '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' kaazpay_web 2>/dev/null || true)
if docker inspect kaazpay_web >/dev/null 2>&1 && [ "$EXISTING_DIR" != "$PROJECT_DIR" ]; then
    warn "发现非本目录管理的旧容器 kaazpay_web（${EXISTING_DIR:-未知来源}），移除后重建..."
    docker rm -f kaazpay_web >/dev/null
fi
# 只有 compose 配置变化（如首次从 dist/ 切换到 site/）才会重建容器，否则容器保持运行
docker compose up -d
# 若项目目录曾被删除/重新解压，旧容器仍挂着已删除的旧 site/ 目录（看到的是空目录，Nginx 报 500），
# 而 compose 配置未变时 up -d 不会重建容器。这里校验容器内能看到新首页，看不到就强制重建以重新挂载。
if ! docker exec kaazpay_web test -f /usr/share/nginx/html/index.html; then
    warn "容器内看不到 site/index.html（挂载已失效），强制重建容器..."
    docker compose up -d --force-recreate
    if ! docker exec kaazpay_web test -f /usr/share/nginx/html/index.html; then
        err "重建后容器内仍看不到 index.html，请检查 $SITE_DIR 与 docker inspect kaazpay_web 的 Mounts"
        exit 1
    fi
fi
# 配置文件是绑定挂载的，内容已经更新；先校验再热重载，校验失败则 Nginx 继续用旧配置服务
if docker exec kaazpay_web nginx -t >/dev/null 2>&1; then
    docker exec kaazpay_web nginx -s reload >/dev/null
else
    err "Nginx 配置校验失败（网站仍以旧配置运行），详情："
    docker exec kaazpay_web nginx -t || true
    exit 1
fi

# ---------- 9. 防火墙放行（若 ufw 已启用才处理，避免误开防火墙） ----------
if command -v ufw &> /dev/null && ufw status | grep -q "Status: active"; then
    log "9. 检测到 ufw 已启用，放行 $HTTP_PORT/443 端口..."
    ufw allow "$HTTP_PORT"/tcp || true
    ufw allow 443/tcp || true
else
    echo "ufw 未启用，跳过防火墙配置（云厂商安全组请自行确保 $HTTP_PORT 端口已放行）。"
fi

# ---------- 10. 健康检查 ----------
# 最多等 15 秒；确认英文首页、中文首页、国家页与支付指南都能正常返回
HEALTH="⚠️  未响应，请用 docker logs kaazpay_web 排查"
HEALTHY=0
for _ in $(seq 1 15); do
    if curl -sf http://localhost:$HTTP_PORT/health > /dev/null \
        && curl -sf -o /dev/null http://localhost:$HTTP_PORT/ \
        && curl -sf -o /dev/null http://localhost:$HTTP_PORT/zh \
        && curl -sf -o /dev/null http://localhost:$HTTP_PORT/payment-methods/united-states \
        && curl -sf -o /dev/null http://localhost:$HTTP_PORT/guides; then
        HEALTH="✅ 正常（中英文首页、国家页与支付指南均可访问）"
        HEALTHY=1
        break
    fi
    sleep 1
done

# ---------- 10b. 清除 Cloudflare 缓存（Cloudflare 缓存了页面 HTML 时，让访客立即看到新版） ----------
# 旧的带哈希资源保留 7 天，所以即使不清缓存，边缘节点上的旧页面也不会坏，只是要等缓存过期才显示新内容。
[ -f "$PROJECT_DIR/.cf.env" ] && . "$PROJECT_DIR/.cf.env"
if [ "$HEALTHY" = "1" ] && [ -n "${CF_ZONE_ID:-}" ] && [ -n "${CF_API_TOKEN:-}" ]; then
    log "10b. 清除 Cloudflare 缓存..."
    if curl -sf -m 20 -X POST "https://api.cloudflare.com/client/v4/zones/${CF_ZONE_ID}/purge_cache" \
        -H "Authorization: Bearer ${CF_API_TOKEN}" -H "Content-Type: application/json" \
        --data '{"purge_everything":true}' | grep -q '"success":true'; then
        echo "   ✅ Cloudflare 缓存已清除"
    else
        warn "Cloudflare 缓存清除失败（请检查 .cf.env 里的 CF_ZONE_ID / CF_API_TOKEN），可到 Cloudflare 后台 Caching → Purge Everything 手动清除"
    fi
fi

# ---------- 11. 通知搜索引擎（IndexNow：Bing / Yandex 等；Bing 的索引也供 ChatGPT 搜索与 Copilot 使用） ----------
# 只在网站健康时通知，且只提交本次内容有变化的页面（构建时生成的 indexnow-urls.txt）。
# 失败不影响部署；如需跳过：INDEXNOW=0 ./deploy.sh
if [ "$HEALTHY" = "1" ] && [ "${INDEXNOW:-1}" != "0" ] && [ -x "$PROJECT_DIR/scripts/indexnow.sh" ]; then
    log "11. 通知搜索引擎重新抓取有变化的页面（IndexNow）..."
    "$PROJECT_DIR/scripts/indexnow.sh" "$SITE_DIR" || true
fi

PUBLIC_IP=$(curl -s --max-time 5 ifconfig.me || echo "获取失败")

echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN} ✅ 部署成功！KaazPay 官网已上线。 ${NC}"
if [ "$HTTP_PORT" = "80" ]; then
    echo -e "${GREEN} 🌍 访问地址: http://${PUBLIC_IP} ${NC}"
else
    echo -e "${GREEN} 🌍 访问地址: http://${PUBLIC_IP}:${HTTP_PORT}（请在现有 Nginx / 面板把 kaazpay.info 反向代理到 http://127.0.0.1:${HTTP_PORT}） ${NC}"
fi
echo -e "${GREEN} 🩺 健康检查: ${HEALTH} ${NC}"
echo -e "${GREEN} ⚠️  如使用 Cloudflare，请确保已开启 Proxy（小黄云）。 ${NC}"
echo -e "${GREEN}=============================================${NC}"
